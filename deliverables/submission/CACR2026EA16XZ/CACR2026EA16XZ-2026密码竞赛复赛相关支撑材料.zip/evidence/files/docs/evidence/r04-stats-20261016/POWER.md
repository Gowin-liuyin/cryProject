# T26 功效分析 / MDE（r04-stats-20261016）

本页是**只读复算**：输入全部是已提交的锁频采集 CSV，不重新采集、不改动任何已有证据文件、
不做密钥恢复。每个数字都可以由 `robustness-src/r04_power.py` 从原始 CSV 重算；
输入文件摘要见[附录 A](#附录-a输入文件摘要)，与既有证据的逐项交叉核对见[附录 B](#附录-b与既有证据的交叉核对)。

## 1. 方法

### 1.1 数据粒度

一行 = 一个**主类对实例** = 一次 run × 一个臂 × 两类样本（class0 − class1）。
这个粒度与预注册 Holm 家族的成员表 `stats/members/members.csv.gz` 完全同构，
所以家族 m 可以直接套用（M2 = 3 run × 2 臂 = 6，M3 = 6，M4 = 6，M5 = 3）。

- **主类对**：M1 未修/已修、M2 未修/已修、M3 on/off、M4 vulnerable/ct、M5 reference。
- **R03 两个族外对照**：对照 A `valid vs malformed`、对照 B `valid vs truncated`，各 3 臂 × 3 种子。
- 平台侧各模块的**对照类对**（M2 malformed-zero-tail/ff-tail、M3/M5 bit-flipped/random、
  M4 截断对照）不在本页范围内：它们不是主类对，也不是 R03 的两个对照。

### 1.2 每类 SD 与 n

SD 一律取**样本标准差**（`numpy.std(..., ddof=1)`）。
口径由既有证据锁定：`stats/members/members.csv.gz` 的 `sd0_ns`/`sd1_ns` 与各
`stats/<dataset>/ci_welch.json` 的 `standard_error_ns` 都能被 ddof=1 逐位复现，ddof=0 不能。
本批全部 41 个主类对都是 `n0 = n1 = 10000`（预热 100 次在计时窗口外，不计入）。

### 1.3 MDE 公式与实现

两样本、双侧 α、目标功效 1−β、等 n 的最小可检测效应：

```
MDE = (z_{1-α/2} + z_{1-β}) * sqrt( sd0^2 / n0 + sd1^2 / n1 )
```

本页取 α = 0.05、1−β = 0.80，于是
z_{1-α/2} = 1.959963985、z_{1-β} = 0.841621234，两者之和 = 2.801585218。
等 n 时它退化为教科书的 `2.8016 * sd * sqrt(2/n)`；实现保留不等 n 的一般形式。

实现：`robustness-src/r04_common.py::mde_ns`，正态分位用标准库 `statistics.NormalDist().inv_cdf`，
不引入近似表。MDE 是**统计可检测性**（在给定 n 与实测离散度下，80% 功效能分辨的最小均值差），
不是物理泄漏阈值、不是密钥恢复门槛。

### 1.4 Holm 校正后的有效 α

Holm 逐步法的最小阈值是 `α/m`（最显著那一项）。要在**整族**上保证设计期功效，
就要按最严阈值反推可检测效应，因此本页取

```
α_eff = α / m        （族外不校正：α_eff = α）
```

家族与 m 直接取自已提交的成员表：M2 = 6、M5 = 3、M3 = 6、M4 = 6、**M1 = 6**。
**M1 的 m 需要带一句限定（2026-10-21 复核更正）**：M1 族在冻结计划
`r02-r04-close-20261016/PLAN.md`（包内副本：evidence/files/docs/evidence/r02-r04-close-20261016/PLAN.md） §1.2 里事前写的是 **m = 8**
（含两项 dudect 成员），**采集完成后**收敛为 m = 6（dudect 的多批最大 t 不是有效 p 值），
原 `holm.csv` 也被原地覆盖为 6 行——**这与冻结文件「检验族构成在采集后绝不修改」的约定不一致，
属预注册完整性缺口**，详见 `r02-r04-close-20261016/RESULT.md`（包内副本：evidence/files/docs/evidence/r02-r04-close-20261016/RESULT.md） §6
（事前族的 8 行原字节另存为 `holm.m8.csv`）。**两种 m 下家族级判定相同**
（m=8：未修主检验 p=1.30117e-05、阈值 α/7=0.00714 仍拒绝；已修 p=0.19615、阈值 0.010 仍不拒绝；
m=6：阈值 0.00833 / 0.01667，判定相同），MDE 随 m 变（m=8：32.26 / 36.54 ns；m=6：31.39 / 35.56 ns）、
判定不变。下表与 §1.1 的 MDE 按 **m = 6** 给出，并另附 m = 8 的对照值。
R03 两个对照没有预注册家族（R03 PLAN 写明「不做 Holm、不做任何多重比较校正」），故 α_eff = 0.05。

> **口径更正（主控 2026-10-16）**：本文件初稿把 M1 主类对写成"族外、无预注册家族"，
> 这是**错的**。M1 的 Holm 家族在 `r02-r04-close-20261016/PLAN.md`（包内副本：evidence/files/docs/evidence/r02-r04-close-20261016/PLAN.md）
> 中**事前冻结为 m = 8**（§1.2），**采集后收敛为 m = 6**（见上段与 RESULT §6），
> 成员表见 `holm.csv`（包内副本：evidence/files/docs/evidence/r02-r04-close-20261016/holm.csv），**m = 6**，
> 其中 `unfixed_ci_zero_vs_ones` 就是主类对（原始 p = 1.30117e-05，阈值 0.00833，**拒绝**）。
> 因此 M1 主类对应按 **α_eff = 0.05/6 = 0.008333** 计算，而不是 0.05。
> 下表已加入 M1 一行；§1 明细表第 1–2 行的 MDE(Holm) 见 §1.1 的更正值。
> 更正后**结论不变**：未修臂的观测 Δ = +39.337 ns 仍超过更正后的 MDE(31.39 ns)，
> 已修臂的 −13.209 ns 仍小于更正后的 MDE(35.56 ns)。

| 家族 | m | α_eff = 0.05/m | z_{1-α_eff/2} |
| --- | ---: | ---: | ---: |
| `m2_end_to_end_full_decaps_v1` | 6 | 0.008333333 | 2.638257273 |
| `m3_lut_arm_end_to_end_v1` | 6 | 0.008333333 | 2.638257273 |
| `m4_compare_arm_session_v1` | 6 | 0.008333333 | 2.638257273 |
| **M1 冻结家族（`r02-r04-close-20261016/holm.csv`）** | **6** | **0.008333333** | **2.638257273** |
| `m5_reference_end_to_end_v1` | 3 | 0.016666667 | 2.393979800 |
| （族外：R03 两个对照） | — | 0.050000000 | 1.959963985 |

### 1.1 M1 主类对的更正后 MDE

| # | 臂 | run | SD0/SD1（ns） | SE（ns） | MDE(α=0.05)（ns） | **MDE(m=6)（ns）** | 观测 Δ（ns） | 超过 MDE(m=6)? |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | M1 未修 | `hist010-vulnerable` | 673.198 / 600.369 | 9.0201 | 25.2709 | **31.3901** | **+39.3372** | **是** |
| 2 | M1 已修 | `hist010-fixed` | 719.614 / 725.531 | 10.2192 | 28.6289 | **35.5613** | −13.2093 | 否 |

（MDE(m=6) = (2.638257273 + 0.841621234) × SE；SE 与 §1 明细表同源。）
本更正不改动 §1 明细表里已打印的原始数字，只补充按 m=6 计算的 MDE 与家族归属；
也不改变任何已提交的 Holm 判定（那由 `holt.csv` 冻结记录决定）。

## 2. 一句话结论（可直接引用）

> **M2/M3/M5「端到端未检出」的确切含义是：在本机、本编译产物、本类对与本次样本预算下，
> 观测到的类间均值差小于本设计的最小可检测效应 MDE（M2 约 25–67 ns、M3 约 18–34 ns、
> M5 约 14–28 ns），所以这套预算**分辨不出**任何小于该量级的效应；
> 「未检出」= 观测效应 < MDE，**不等于零效应**，也不构成恒时证明或物理泄漏界。**

可检测性上界不是一个「泄漏界」：MDE 说的是「用这套 n 与实测 SD，80% 功效能分辨多大的均值差」，
不是「机制最多只能泄漏多少纳秒」。

## 3. 主表：一行一个主类对

单位 ns。「观测 Δ」= class0 均值 − class1 均值，与既有证据同向。
95% CI 是既有口径的正态近似区间（z = 1.96，方差除数 n−1），仅作参照，不参与 MDE 判定。

| # | 模块 | 臂 | run | 家族(m) | α_eff | n0/n1 | SD0 | SD1 | MDE(α=0.05) | MDE(Holm α_eff) | MDE%(α) | MDE%(Holm) | 观测 Δ | 95% CI | \|Δ\|>MDE(α) | \|Δ\|>MDE(Holm) |
| ---: | --- | --- | --- | --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- |
| 1 | M1 | 未修 | `hist010-vulnerable` | **M1 m=6** | 0.008333333 | 10000/10000 | 673.198 | 600.369 | 25.2709 | 25.2709 | 0.0444% | 0.0444% | +39.3372 | [+21.658, +57.016] | **是** | **是** |
| 2 | M1 | 已修 | `hist010-fixed` | **M1 m=6** | 0.008333333 | 10000/10000 | 719.614 | 725.531 | 28.6289 | 28.6289 | 0.0495% | 0.0495% | -13.2093 | [-33.238, +6.819] | 否 | 否 |
| 3 | M2 | 未修 | `m2-s1-unfixed` | m2_end_to_end_full_decaps_v1(6) | 0.008333333 | 10000/10000 | 443.875 | 740.771 | 24.1939 | 30.0514 | 0.0426% | 0.0529% | +10.5296 | [-6.396, +27.455] | 否 | 否 |
| 4 | M2 | 已修 | `m2-s1-fixed` | m2_end_to_end_full_decaps_v1(6) | 0.008333333 | 10000/10000 | 1531.539 | 1170.387 | 54.0017 | 67.0761 | 0.0888% | 0.1103% | +21.6566 | [-16.123, +59.436] | 否 | 否 |
| 5 | M2 | 未修 | `m2-s2-unfixed` | m2_end_to_end_full_decaps_v1(6) | 0.008333333 | 10000/10000 | 696.181 | 681.782 | 27.2992 | 33.9086 | 0.0481% | 0.0597% | +19.1259 | [+0.028, +38.224] | 否 | 否 |
| 6 | M2 | 已修 | `m2-s2-fixed` | m2_end_to_end_full_decaps_v1(6) | 0.008333333 | 10000/10000 | 996.534 | 1087.528 | 41.3250 | 51.3302 | 0.0680% | 0.0845% | -17.0804 | [-45.991, +11.830] | 否 | 否 |
| 7 | M2 | 未修 | `m2-s3-unfixed` | m2_end_to_end_full_decaps_v1(6) | 0.008333333 | 10000/10000 | 537.946 | 461.987 | 19.8659 | 24.6757 | 0.0350% | 0.0435% | +9.9828 | [-3.915, +23.881] | 否 | 否 |
| 8 | M2 | 已修 | `m2-s3-fixed` | m2_end_to_end_full_decaps_v1(6) | 0.008333333 | 10000/10000 | 588.637 | 595.607 | 23.4605 | 29.1406 | 0.0386% | 0.0479% | -15.5125 | [-31.925, +0.900] | 否 | 否 |
| 9 | M3 | on | `m3-s1-on` | m3_lut_arm_end_to_end_v1(6) | 0.008333333 | 10000/10000 | 490.455 | 835.026 | 27.1308 | 33.6994 | 0.0931% | 0.1156% | -10.7228 | [-29.703, +8.258] | 否 | 否 |
| 10 | M3 | off | `m3-s1-off` | m3_lut_arm_end_to_end_v1(6) | 0.008333333 | 10000/10000 | 526.486 | 565.765 | 21.6517 | 26.8938 | 0.0740% | 0.0920% | -5.4645 | [-20.612, +9.683] | 否 | 否 |
| 11 | M3 | on | `m3-s2-on` | m3_lut_arm_end_to_end_v1(6) | 0.008333333 | 10000/10000 | 330.923 | 469.173 | 16.0849 | 19.9793 | 0.0553% | 0.0687% | -5.7634 | [-17.016, +5.489] | 否 | 否 |
| 12 | M3 | off | `m3-s2-off` | m3_lut_arm_end_to_end_v1(6) | 0.008333333 | 10000/10000 | 391.308 | 374.539 | 15.1752 | 18.8493 | 0.0519% | 0.0645% | +4.8004 | [-5.816, +15.417] | 否 | 否 |
| 13 | M3 | on | `m3-s3-on` | m3_lut_arm_end_to_end_v1(6) | 0.008333333 | 10000/10000 | 382.956 | 383.534 | 15.1843 | 18.8606 | 0.0522% | 0.0648% | +7.1260 | [-3.497, +17.749] | 否 | 否 |
| 14 | M3 | off | `m3-s3-off` | m3_lut_arm_end_to_end_v1(6) | 0.008333333 | 10000/10000 | 314.020 | 399.374 | 14.2333 | 17.6793 | 0.0487% | 0.0605% | -3.7747 | [-13.732, +6.183] | 否 | 否 |
| 15 | M4 | vulnerable | `m4-s1-vuln` | m4_compare_arm_session_v1(6) | 0.008333333 | 10000/10000 | 4.513 | 4.833 | 0.1853 | 0.2301 | 0.7437% | 0.9237% | -4.1022 | [-4.232, -3.973] | **是** | **是** |
| 16 | M4 | ct | `m4-s1-ct` | m4_compare_arm_session_v1(6) | 0.008333333 | 10000/10000 | 47.717 | 3.521 | 1.3405 | 1.6650 | 4.6094% | 5.7254% | +0.4151 | [-0.523, +1.353] | 否 | 否 |
| 17 | M4 | vulnerable | `m4-s2-vuln` | m4_compare_arm_session_v1(6) | 0.008333333 | 10000/10000 | 6.883 | 41.785 | 1.1864 | 1.4736 | 4.7212% | 5.8643% | -4.3508 | [-5.181, -3.521] | **是** | **是** |
| 18 | M4 | ct | `m4-s2-ct` | m4_compare_arm_session_v1(6) | 0.008333333 | 10000/10000 | 7.068 | 28.392 | 0.8197 | 1.0181 | 2.8294% | 3.5144% | -0.2270 | [-0.800, +0.346] | 否 | 否 |
| 19 | M4 | vulnerable | `m4-s3-vuln` | m4_compare_arm_session_v1(6) | 0.008333333 | 10000/10000 | 35.922 | 4.892 | 1.0157 | 1.2616 | 4.0493% | 5.0296% | -3.5151 | [-4.226, -2.805] | **是** | **是** |
| 20 | M4 | ct | `m4-s3-ct` | m4_compare_arm_session_v1(6) | 0.008333333 | 10000/10000 | 41.022 | 3.673 | 1.1539 | 1.4332 | 3.9660% | 4.9262% | +0.3473 | [-0.460, +1.155] | 否 | 否 |
| 21 | M5 | reference | `m5-s1-meas` | m5_reference_end_to_end_v1(3) | 0.016666667 | 10000/10000 | 454.179 | 505.301 | 19.0344 | 21.9832 | 0.0651% | 0.0752% | -5.5961 | [-18.912, +7.720] | 否 | 否 |
| 22 | M5 | reference | `m5-s2-meas` | m5_reference_end_to_end_v1(3) | 0.016666667 | 10000/10000 | 627.306 | 610.520 | 24.5238 | 28.3230 | 0.0835% | 0.0965% | -6.9461 | [-24.103, +10.211] | 否 | 否 |
| 23 | M5 | reference | `m5-s3-meas` | m5_reference_end_to_end_v1(3) | 0.016666667 | 10000/10000 | 291.818 | 299.865 | 11.7224 | 13.5385 | 0.0400% | 0.0462% | -4.8185 | [-13.019, +3.382] | 否 | 否 |
| 24 | R03 | M1 未修 / 对照 A：合法 vs 格式破损 | `r03-m1unfixed-s1` | 族外 | 0.050000000 | 10000/10000 | 508.538 | 531.393 | 20.6062 | 20.6062 | 0.0372% | 0.0372% | +7.8656 | [-6.550, +22.282] | 否 | 否 |
| 25 | R03 | M1 未修 / 对照 B：合法 vs 截断 | `r03-m1unfixed-s1` | 族外 | 0.050000000 | 10000/10000 | 508.538 | 4.647 | 14.2477 | 14.2477 | 0.0514% | 0.0514% | +55437.8425 | [+55427.875, +55447.810] | **是** | **是** |
| 26 | R03 | M1 已修 / 对照 A：合法 vs 格式破损 | `r03-m1fixed-s1` | 族外 | 0.050000000 | 10000/10000 | 682.932 | 582.146 | 25.1408 | 25.1408 | 0.0459% | 0.0459% | +4.6502 | [-12.938, +22.239] | 否 | 否 |
| 27 | R03 | M1 已修 / 对照 B：合法 vs 截断 | `r03-m1fixed-s1` | 族外 | 0.050000000 | 10000/10000 | 682.932 | 4.753 | 19.1334 | 19.1334 | 0.0698% | 0.0698% | +54767.8174 | [+54754.432, +54781.203] | **是** | **是** |
| 28 | R03 | M5 / 对照 A：合法 vs 格式破损 | `r03-m5ref-s1` | 族外 | 0.050000000 | 10000/10000 | 321.586 | 309.659 | 12.5073 | 12.5073 | 0.0426% | 0.0426% | -2.2435 | [-10.994, +6.507] | 否 | 否 |
| 29 | R03 | M5 / 对照 B：合法 vs 截断 | `r03-m5ref-s1` | 族外 | 0.050000000 | 10000/10000 | 321.586 | 4.660 | 9.0104 | 9.0104 | 0.0613% | 0.0613% | +29341.3771 | [+29335.073, +29347.681] | **是** | **是** |
| 30 | R03 | M1 未修 / 对照 A：合法 vs 格式破损 | `r03-m1unfixed-s2` | 族外 | 0.050000000 | 10000/10000 | 363.224 | 363.237 | 14.3913 | 14.3913 | 0.0260% | 0.0260% | +1.5751 | [-8.493, +11.643] | 否 | 否 |
| 31 | R03 | M1 未修 / 对照 B：合法 vs 截断 | `r03-m1unfixed-s2` | 族外 | 0.050000000 | 10000/10000 | 363.224 | 4.651 | 10.1769 | 10.1769 | 0.0368% | 0.0368% | +55232.4545 | [+55225.335, +55239.574] | **是** | **是** |
| 32 | R03 | M1 已修 / 对照 A：合法 vs 格式破损 | `r03-m1fixed-s2` | 族外 | 0.050000000 | 10000/10000 | 746.418 | 562.436 | 26.1836 | 26.1836 | 0.0475% | 0.0475% | +9.8189 | [-8.499, +28.137] | 否 | 否 |
| 33 | R03 | M1 已修 / 对照 B：合法 vs 截断 | `r03-m1fixed-s2` | 族外 | 0.050000000 | 10000/10000 | 746.418 | 13.242 | 20.9148 | 20.9148 | 0.0758% | 0.0758% | +55117.0957 | [+55102.464, +55131.728] | **是** | **是** |
| 34 | R03 | M5 / 对照 A：合法 vs 格式破损 | `r03-m5ref-s2` | 族外 | 0.050000000 | 10000/10000 | 408.862 | 374.534 | 15.5341 | 15.5341 | 0.0530% | 0.0530% | -1.2044 | [-12.072, +9.663] | 否 | 否 |
| 35 | R03 | M5 / 对照 B：合法 vs 截断 | `r03-m5ref-s2` | 族外 | 0.050000000 | 10000/10000 | 408.862 | 6.072 | 11.4559 | 11.4559 | 0.0781% | 0.0781% | +29294.0512 | [+29286.037, +29302.066] | **是** | **是** |
| 36 | R03 | M1 未修 / 对照 A：合法 vs 格式破损 | `r03-m1unfixed-s3` | 族外 | 0.050000000 | 10000/10000 | 557.928 | 472.536 | 20.4837 | 20.4837 | 0.0372% | 0.0372% | -3.2359 | [-17.566, +11.094] | 否 | 否 |
| 37 | R03 | M1 未修 / 对照 B：合法 vs 截断 | `r03-m1unfixed-s3` | 族外 | 0.050000000 | 10000/10000 | 557.928 | 4.714 | 15.6314 | 15.6314 | 0.0567% | 0.0567% | +55100.7157 | [+55089.780, +55111.651] | **是** | **是** |
| 38 | R03 | M1 已修 / 对照 A：合法 vs 格式破损 | `r03-m1fixed-s3` | 族外 | 0.050000000 | 10000/10000 | 581.346 | 601.870 | 23.4433 | 23.4433 | 0.0426% | 0.0426% | +0.4706 | [-15.930, +16.871] | 否 | 否 |
| 39 | R03 | M1 已修 / 对照 B：合法 vs 截断 | `r03-m1fixed-s3` | 族外 | 0.050000000 | 10000/10000 | 581.346 | 4.642 | 16.2874 | 16.2874 | 0.0592% | 0.0592% | +54947.6969 | [+54936.302, +54959.091] | **是** | **是** |
| 40 | R03 | M5 / 对照 A：合法 vs 格式破损 | `r03-m5ref-s3` | 族外 | 0.050000000 | 10000/10000 | 248.360 | 250.568 | 9.8840 | 9.8840 | 0.0337% | 0.0337% | -2.5786 | [-9.493, +4.336] | 否 | 否 |
| 41 | R03 | M5 / 对照 B：合法 vs 截断 | `r03-m5ref-s3` | 族外 | 0.050000000 | 10000/10000 | 248.360 | 4.735 | 6.9593 | 6.9593 | 0.0474% | 0.0474% | +29321.8309 | [+29316.962, +29326.700] | **是** | **是** |

## 4. 臂级汇总（每个主类对一行：跨 run 的 SD 与 MDE 范围）

「MDE(Holm) 最坏」= 该臂 3 次 run 中最大的 Holm 有效 α 下 MDE，是引用单个数时该用的保守值。

| 模块 | 臂 | run 数 | 家族(m) | n/类 | SD0 范围 | SD1 范围 | MDE(α) 范围 | MDE(Holm) 范围 | MDE(Holm) 最坏 | 观测 Δ 范围 | 超 MDE(α) | 超 MDE(Holm) |
| --- | --- | ---: | --- | ---: | --- | --- | --- | --- | ---: | --- | ---: | ---: |
| M1 | 未修 | 1 | **M1 m=6** | 10000 | 673.2–673.2 | 600.4–600.4 | 25.2709–25.2709 | 25.2709–25.2709 | 25.2709 | +39.337 … +39.337 | 1/1 | 1/1 |
| M1 | 已修 | 1 | **M1 m=6** | 10000 | 719.6–719.6 | 725.5–725.5 | 28.6289–28.6289 | 28.6289–28.6289 | 28.6289 | -13.209 … -13.209 | 0/1 | 0/1 |
| M2 | 未修 | 3 | m2_end_to_end_full_decaps_v1(6) | 10000 | 443.9–696.2 | 462.0–740.8 | 19.8659–27.2992 | 24.6757–33.9086 | 33.9086 | +9.983 … +19.126 | 0/3 | 0/3 |
| M2 | 已修 | 3 | m2_end_to_end_full_decaps_v1(6) | 10000 | 588.6–1531.5 | 595.6–1170.4 | 23.4605–54.0017 | 29.1406–67.0761 | 67.0761 | -17.080 … +21.657 | 0/3 | 0/3 |
| M3 | on | 3 | m3_lut_arm_end_to_end_v1(6) | 10000 | 330.9–490.5 | 383.5–835.0 | 15.1843–27.1308 | 18.8606–33.6994 | 33.6994 | -10.723 … +7.126 | 0/3 | 0/3 |
| M3 | off | 3 | m3_lut_arm_end_to_end_v1(6) | 10000 | 314.0–526.5 | 374.5–565.8 | 14.2333–21.6517 | 17.6793–26.8938 | 26.8938 | -5.464 … +4.800 | 0/3 | 0/3 |
| M4 | vulnerable | 3 | m4_compare_arm_session_v1(6) | 10000 | 4.5–35.9 | 4.8–41.8 | 0.1853–1.1864 | 0.2301–1.4736 | 1.4736 | -4.351 … -3.515 | 3/3 | 3/3 |
| M4 | ct | 3 | m4_compare_arm_session_v1(6) | 10000 | 7.1–47.7 | 3.5–28.4 | 0.8197–1.3405 | 1.0181–1.6650 | 1.6650 | -0.227 … +0.415 | 0/3 | 0/3 |
| M5 | reference | 3 | m5_reference_end_to_end_v1(3) | 10000 | 291.8–627.3 | 299.9–610.5 | 11.7224–24.5238 | 13.5385–28.3230 | 28.3230 | -6.946 … -4.819 | 0/3 | 0/3 |
| R03 | M1 未修 / 对照 A：合法 vs 格式破损 | 3 | 族外 | 10000 | 363.2–557.9 | 363.2–531.4 | 14.3913–20.6062 | 14.3913–20.6062 | 20.6062 | -3.236 … +7.866 | 0/3 | 0/3 |
| R03 | M1 未修 / 对照 B：合法 vs 截断 | 3 | 族外 | 10000 | 363.2–557.9 | 4.6–4.7 | 10.1769–15.6314 | 10.1769–15.6314 | 15.6314 | +55100.716 … +55437.842 | 3/3 | 3/3 |
| R03 | M1 已修 / 对照 A：合法 vs 格式破损 | 3 | 族外 | 10000 | 581.3–746.4 | 562.4–601.9 | 23.4433–26.1836 | 23.4433–26.1836 | 26.1836 | +0.471 … +9.819 | 0/3 | 0/3 |
| R03 | M1 已修 / 对照 B：合法 vs 截断 | 3 | 族外 | 10000 | 581.3–746.4 | 4.6–13.2 | 16.2874–20.9148 | 16.2874–20.9148 | 20.9148 | +54767.817 … +55117.096 | 3/3 | 3/3 |
| R03 | M5 / 对照 A：合法 vs 格式破损 | 3 | 族外 | 10000 | 248.4–408.9 | 250.6–374.5 | 9.8840–15.5341 | 9.8840–15.5341 | 15.5341 | -2.579 … -1.204 | 0/3 | 0/3 |
| R03 | M5 / 对照 B：合法 vs 截断 | 3 | 族外 | 10000 | 248.4–408.9 | 4.7–6.1 | 6.9593–11.4559 | 6.9593–11.4559 | 11.4559 | +29294.051 … +29341.377 | 3/3 | 3/3 |

## 5. 用 MDE 读「未检出」

### 5.1 数值读法

- **M2**（家族 m = 6，α_eff = 0.008333）：主类对 6 项的 |Δ| 全部小于 Holm 有效 α 下的 MDE
  （MDE(α) 19.9–54.0 ns，MDE(Holm) 24.7–67.1 ns），所以预注册家族 Holm 全部不拒绝。
  这套预算对**小于几十纳秒**的端到端均值差没有分辨力。M2 的**定位层**阳性的内容是
  「未修链三个热点各含 1 个 `div`、已修链 0 个」，那是**指令与数据流层面**的结论，
  不是本机测到的物理时差；两层互不冒充（见 `m2-kem-20261016/RESULT.md`）。
- **M3**（m = 6，MDE(α) 14.2–27.1 ns，MDE(Holm) 17.7–33.7 ns）：on / off 两臂的 |Δ| 都小于 MDE，
  属于「观测效应被预算盖住」。M3 是**人工构造校准**，本页只记录可检测性，不据此作泄漏结论。
- **M4**（m = 6）：vulnerable 臂的 |Δ| **远大于** MDE（3/3 run 超过，最坏情况下 MDE(Holm) 也只有 1.47 ns，
  而 |Δ| ≈ 3.5–4.4 ns）；ct 臂的 |Δ| 小于 MDE（0/3 超过）。
  这正是「该臂的效应大到这套预算足以分辨」与「该臂分辨不了」的分界。
  注意 M4 是**人工构造校准**（人工提前退出比较夹具），不是上游 CVE。
- **M5**（m = 3，MDE(α) 11.7–24.5 ns，MDE(Holm) 13.5–28.3 ns）：|Δ| 小于 MDE，未检出。
- **M1 未修**：Δ = +39.337 ns，|Δ| **超过** α = 0.05 下的 MDE 25.271 ns。
- **M1 已修**：Δ = -13.209 ns，|Δ| **小于** MDE 28.629 ns。
  这两个数**属于 M1 预注册的 m=6 家族**（见 §1 更正），按 α_eff=0.05/6 计算；
  （`tooling-strengthen-20261015/PROTOCOL.md` 里那句「没有 Holm」只描述该轮 CI 路线自身的口径，
  已被 `r02-r04-close-20261016/PLAN.md` 预注册的 m=6 家族与冻结的 `holm.csv` 取代。）本文件的 MDE 是事后功效描述，不改变 `r02-r04-close-20261016/holm.csv` 里已冻结的判定。同一批数据的族外 online dudect
  方向相同（未修臂三次越过上游 `t > 10` 阈值、已修臂三次都在 2.05 以下），同样不进 Holm。
- **R03 对照 A**（valid vs malformed）：9 个「臂 × 种子」组合的 |Δ| 都小于 MDE（0/9 超过），
  即隐式拒绝路径与接受路径在本预算下不可区分；**对照 B**（valid vs truncated）的 |Δ| ≈ 29–55 µs，
  比该对比的 MDE（约 7–21 ns）大 3–4 个数量级，说明这是封装层长度检查的接口语义差，
  不是秘密相关泄漏。两者都**族外**（R03 PLAN：不做 Holm、不做任何多重比较校正）。

### 5.2 「未检出」的正确措辞

未检出 = 「观测效应 < MDE」。它**不**推出下列任何一条：

1. 效应恰好为零；
2. 机制在物理上恒时；
3. 攻击者不可利用；
4. 换机器、换编译产物、换类对、换样本预算后仍然未检出。

它**确实**推出：在这套 n 与实测 SD 下，凡是小于表中 MDE 的均值差都照不出来；
要缩小 MDE，只能按 `MDE ∝ 1/sqrt(n)` 加样本，或降低测量噪声（锁频、绑核、缩短窗口）。

## 6. 边界

- MDE 是**统计可检测性**，不是物理泄漏阈值，也不是恒时证明；本页不给出物理误差界。
- 本页**不做密钥恢复**，不运行 exploit demo，不给出真实总体检出率/误报率。
- MDE 用的是**本次实测 SD**，属于事后（post hoc）功效描述：它说明「这套数据能看见多大」，
  不是事先的样本量规划，也不改变任何已提交的 Holm 判定。
- M3/M4 是**人工构造校准**（M3 为 LUT 机制校准、M4 为人工提前退出比较夹具），不是上游 CVE。
- R03 与 dudect/RTLF 一律**族外**；dudect 的最大 t 不转伪 p，本页不引用它做任何 MDE 计算。
- M1 的实测样本取自 `liboqs010-locked-20261015/runs/{vulnerable,fixed}/samples.csv`
  （锁频采集，单次、seed 31337、CPU2），与平台四模块的控制器采集不是同一条流水线；
  `tooling-strengthen-20261015/csv/*-message-zero-ones.csv` 是同一批样本的派生两列文件，
  只用于逐值一致性旁证（附录 B）。两边的 `.meta` 都有
  `cpu_affinity=not_pinned` 与 `frequency_control=not_configured` 的固定字符串，
  真正的绑核与频率门在各自 README / `logs/status.log` / 控制器落盘件里。
- 本页只读已有证据，没有新增任何采集，没有改任何已有证据文件。

## 附录 A：输入文件摘要

每个主类对的原始 CSV（仓库相对路径）、解压后内容 SHA-256 与容器文件 SHA-256。
解压后摘要的口径与各目录既有的 `input.sha256` / `.meta` 一致。
M1 两臂的源文件是未压缩 `.csv`，故两列摘要相同。
R03 的同一份 run CSV 同时提供两个对照类对，故第 24–41 行有 9 组重复文件——这是同一原件的两次使用，
不是两份数据。

| # | 主类对 | 原始 CSV | 解压内容 sha256 | 容器 sha256 |
| ---: | --- | --- | --- | --- |
| 1 | M1-unfixed-s1 | `docs/evidence/liboqs010-locked-20261015/runs/vulnerable/samples.csv` | `bfc89df22216525369b2671d6a26f42a51f768b1446bb3384dee1c33f8dd71f7` | `bfc89df22216525369b2671d6a26f42a51f768b1446bb3384dee1c33f8dd71f7` |
| 2 | M1-fixed-s1 | `docs/evidence/liboqs010-locked-20261015/runs/fixed/samples.csv` | `1c2673bf002a23ad98d311d41741bf96c9e2853137976f88d1b54746344b7c8c` | `1c2673bf002a23ad98d311d41741bf96c9e2853137976f88d1b54746344b7c8c` |
| 3 | M2-unfixed-s1 | `docs/evidence/platform-collection-20261016/M2/m2-s1-unfixed/unfixed-main.csv.gz` | `d46686f9653fc7d8f80459557a6ba0c7f63570e78aa978baf1ed6c1c89bad79c` | `b5d210d17be3f17d0688caedf95f20acb03e33220aeb03699fb1a82f6cfc26a3` |
| 4 | M2-fixed-s1 | `docs/evidence/platform-collection-20261016/M2/m2-s1-fixed/fixed-main.csv.gz` | `d4235c6da47c89e5eb7af95dda50f216fd2518c5dd344a0f6397ed2728b05aa1` | `b7b534f4184b0b018b75a0112b727cd05ae71b9a6f59f5fc1016c1e5e8ecfe60` |
| 5 | M2-unfixed-s2 | `docs/evidence/platform-collection-20261016/M2/m2-s2-unfixed/unfixed-main.csv.gz` | `83e55897a3b2c53535b143690f52b9850eb793cf9e0f1f85ddb6a3e01988a45a` | `09245a69d103a538309fad489a08e9f2bb41f7354032402dc4883dbf9fd55965` |
| 6 | M2-fixed-s2 | `docs/evidence/platform-collection-20261016/M2/m2-s2-fixed/fixed-main.csv.gz` | `b0c6d41092e6ab19fb7621640d3c7b8e25ce05ad92009b5442b37f9afcd12fc8` | `b06b928997f03d715e1cf04f27901ba4a025c2bb27c5bf426e0a82f897c56a2f` |
| 7 | M2-unfixed-s3 | `docs/evidence/platform-collection-20261016/M2/m2-s3-unfixed/unfixed-main.csv.gz` | `cd348312177e9f0471a2d582becf3abdaf5e827d6da28d50eb14c7ce05562e12` | `9c79e9f1ab056e86bdad4e66970fe85380cccd87627cadb21a82f6dce4331f37` |
| 8 | M2-fixed-s3 | `docs/evidence/platform-collection-20261016/M2/m2-s3-fixed/fixed-main.csv.gz` | `a32b7e91868962195faece6ac401f2b119d7841304b3eeda0d7d3527e0d556bd` | `b96b858fd73b8ce1001fbb31f71536a38b570f2cd46e9b7c886bc4ed98833a52` |
| 9 | M3-on-s1 | `docs/evidence/platform-collection-20261016/M3/m3-s1-on/on-samples.csv.gz` | `ea588f7f3b69113b3bb7b5de8db5572a9fa96a0d1f241ba04645ab41809feb44` | `dd80ef648cfc2f75e51195bb360bbcab2426604191654f9f01e15a559f766cad` |
| 10 | M3-off-s1 | `docs/evidence/platform-collection-20261016/M3/m3-s1-off/off-samples.csv.gz` | `9d700c7652230bd211bd0db276ff5cdb2379932d7baafb2c20da8055d3bca8ff` | `374d15481307848449ae797b0565f875730fccc58a80aedbcfa775d2e59cef84` |
| 11 | M3-on-s2 | `docs/evidence/platform-collection-20261016/M3/m3-s2-on/on-samples.csv.gz` | `cf1e5be1faaf5aba8ea577b3442f824cc24b59b5ab7633c9baf66ecd024a9c30` | `1f682ed35850cf978f4550f054864addca51fa246d0b420ed2ae1da10b681a90` |
| 12 | M3-off-s2 | `docs/evidence/platform-collection-20261016/M3/m3-s2-off/off-samples.csv.gz` | `d265d594e12c797ded88245edb71accfd01c2d3713ee71d176ae540bfb97b23d` | `29c15b817aaef875e48a7a957553013c555d8a4d680cd9499492d18e47b8b8dd` |
| 13 | M3-on-s3 | `docs/evidence/platform-collection-20261016/M3/m3-s3-on/on-samples.csv.gz` | `deb48e05b3d2bfc3e70277ba41fe41d09577b9e1ca07b2fc6eec0fdb02447d03` | `603571b8d4055a0ca691d333dcc64624ee33cb8b916f0d5cb93d6b35b0bb1732` |
| 14 | M3-off-s3 | `docs/evidence/platform-collection-20261016/M3/m3-s3-off/off-samples.csv.gz` | `8b25f6236ef2908d18a16623857d8921ed5576c1900ec35226f5d8256c63539d` | `01a30a6c0305621964e3f2b9094bdd100c212dada46153c0ca67ef51ac97eb1f` |
| 15 | M4-vuln-s1 | `docs/evidence/platform-collection-20261016/M4/m4-s1-vuln/vuln-samples.csv.gz` | `1c5601313e9b96d366918114d459e4e783addaf4b786203871f555df9e147d25` | `6b4d45625ffcc8cb577275e68e108f28a79af7ada9967c009aed72eb2a478f6b` |
| 16 | M4-ct-s1 | `docs/evidence/platform-collection-20261016/M4/m4-s1-ct/ct-samples.csv.gz` | `c9a552af97b88e355d4371f9cf8303cdf38ea2d7a18b6e2665feb1deea5aca9e` | `5cfe8617582d232b4f39b3eb323a749bd3177a4abdcd47e8c8d53b17b32eee09` |
| 17 | M4-vuln-s2 | `docs/evidence/platform-collection-20261016/M4/m4-s2-vuln/vuln-samples.csv.gz` | `9f5e3c90453ae6138275dbb12506cb03c1885b01ff78590b8b2bdf61efa4e0e1` | `f80cba969e8d1ae3d25aa316ce25ca14d439cb69545a6e9817f5053900a3ba26` |
| 18 | M4-ct-s2 | `docs/evidence/platform-collection-20261016/M4/m4-s2-ct/ct-samples.csv.gz` | `9e2790c13a9bd27df282170836983cdf7cb3426265df701635bf7ff94984ff7f` | `2fb8e6bb9bf1b032c71af1dd915b953d560476d90aaba7c2e578f64f86a5738b` |
| 19 | M4-vuln-s3 | `docs/evidence/platform-collection-20261016/M4/m4-s3-vuln/vuln-samples.csv.gz` | `10a3e4e2ba8afc7b28ff246b2e47f95584216c795b73aa6ecea922feb88abadf` | `ed99c2eaeabc9a28c6305f96da186692c30e1022d37f063475139454050c238d` |
| 20 | M4-ct-s3 | `docs/evidence/platform-collection-20261016/M4/m4-s3-ct/ct-samples.csv.gz` | `13c3602dad298f0561d4cf614badf33bffc120100113e465bde20ce83dcf6588` | `ffcbfdc5d9921382ccd04cf5b041ce1edbb9f46f94e2c1142e49dffe40d3d051` |
| 21 | M5-reference-s1 | `docs/evidence/platform-collection-20261016/M5/m5-s1-meas/m5-samples.csv.gz` | `bf9b7865e2a4a3a586224ce7065b274e87fc25ed749ca2c867a4e440892c7b17` | `04228c2007aad1e619074d42e73cc7225c5558f1ffb058ad0bf9df3487bee709` |
| 22 | M5-reference-s2 | `docs/evidence/platform-collection-20261016/M5/m5-s2-meas/m5-samples.csv.gz` | `c6c91ed3f14256b8dd52c7f41c5d3e0939b807ad3f89879284083e536341d1e6` | `b32920d2cbfc915cc5106b9d113fe92fe9c373e59de3eb7d573be704af4a1d30` |
| 23 | M5-reference-s3 | `docs/evidence/platform-collection-20261016/M5/m5-s3-meas/m5-samples.csv.gz` | `95f4cf763b8dac95473decd467b3e99e41a501bddb2321330ed26ffadc075caa` | `fee5907a5fa1e4a910b43583fd1f6c8b6a2a33e43e9ec49d43cf08e0b5a26add` |
| 24 | R03-valid-malformed-m1unfixed-s1 | `docs/evidence/r03-malformed-20261016/R03/r03-m1unfixed-s1/r03-m1unfixed-s1.csv.gz` | `89b029c6033bc57c6f4e2a43b8127ba184ad6026c1891982fe61a42173d08f15` | `08e383c1642c21801fc43b1b32da7498da8f3d693ad8a5bf5b525a19be96f444` |
| 25 | R03-valid-truncated-m1unfixed-s1 | `docs/evidence/r03-malformed-20261016/R03/r03-m1unfixed-s1/r03-m1unfixed-s1.csv.gz` | `89b029c6033bc57c6f4e2a43b8127ba184ad6026c1891982fe61a42173d08f15` | `08e383c1642c21801fc43b1b32da7498da8f3d693ad8a5bf5b525a19be96f444` |
| 26 | R03-valid-malformed-m1fixed-s1 | `docs/evidence/r03-malformed-20261016/R03/r03-m1fixed-s1/r03-m1fixed-s1.csv.gz` | `4c02e6c003e57be9644efbb07e0b3b014aa708a7ca5b03501ad78ea1102192c6` | `ef9bc8919252db2f51f6e781fc11edc63c23c905609a73609dc0b887ab77e00b` |
| 27 | R03-valid-truncated-m1fixed-s1 | `docs/evidence/r03-malformed-20261016/R03/r03-m1fixed-s1/r03-m1fixed-s1.csv.gz` | `4c02e6c003e57be9644efbb07e0b3b014aa708a7ca5b03501ad78ea1102192c6` | `ef9bc8919252db2f51f6e781fc11edc63c23c905609a73609dc0b887ab77e00b` |
| 28 | R03-valid-malformed-m5ref-s1 | `docs/evidence/r03-malformed-20261016/R03/r03-m5ref-s1/r03-m5ref-s1.csv.gz` | `bc6ce47dbe28c40420a37959eead7e2309dfbe16776faf608adca0375c5e603f` | `8ba47ae672d043f3f98d47d107668f729a35c936aaac595ba58dcf61de3f117c` |
| 29 | R03-valid-truncated-m5ref-s1 | `docs/evidence/r03-malformed-20261016/R03/r03-m5ref-s1/r03-m5ref-s1.csv.gz` | `bc6ce47dbe28c40420a37959eead7e2309dfbe16776faf608adca0375c5e603f` | `8ba47ae672d043f3f98d47d107668f729a35c936aaac595ba58dcf61de3f117c` |
| 30 | R03-valid-malformed-m1unfixed-s2 | `docs/evidence/r03-malformed-20261016/R03/r03-m1unfixed-s2/r03-m1unfixed-s2.csv.gz` | `689d6889879d0d818fc3a8d6265ce38f954982d1fe8943761890f7e189a28518` | `953d8dae2ba9676cab9acfe0fa3c630babe5e80d63059d5d79c1d4c7910cf861` |
| 31 | R03-valid-truncated-m1unfixed-s2 | `docs/evidence/r03-malformed-20261016/R03/r03-m1unfixed-s2/r03-m1unfixed-s2.csv.gz` | `689d6889879d0d818fc3a8d6265ce38f954982d1fe8943761890f7e189a28518` | `953d8dae2ba9676cab9acfe0fa3c630babe5e80d63059d5d79c1d4c7910cf861` |
| 32 | R03-valid-malformed-m1fixed-s2 | `docs/evidence/r03-malformed-20261016/R03/r03-m1fixed-s2/r03-m1fixed-s2.csv.gz` | `5a6e73a1c9be2ec131164a0c594d14b93b5b63ba5db5932db013a8b85e5b0fa3` | `868536a39f25b1972721a8eea56ca41cdd9d367bc9a6ee9ece39c7e88029537b` |
| 33 | R03-valid-truncated-m1fixed-s2 | `docs/evidence/r03-malformed-20261016/R03/r03-m1fixed-s2/r03-m1fixed-s2.csv.gz` | `5a6e73a1c9be2ec131164a0c594d14b93b5b63ba5db5932db013a8b85e5b0fa3` | `868536a39f25b1972721a8eea56ca41cdd9d367bc9a6ee9ece39c7e88029537b` |
| 34 | R03-valid-malformed-m5ref-s2 | `docs/evidence/r03-malformed-20261016/R03/r03-m5ref-s2/r03-m5ref-s2.csv.gz` | `c076f3c6231d1ef0f62986120a086f572860689b902d65cd2798d66270513553` | `efef1570e654f20124b48c9aa771a18ff35befae60b9e221f564cd5617a47269` |
| 35 | R03-valid-truncated-m5ref-s2 | `docs/evidence/r03-malformed-20261016/R03/r03-m5ref-s2/r03-m5ref-s2.csv.gz` | `c076f3c6231d1ef0f62986120a086f572860689b902d65cd2798d66270513553` | `efef1570e654f20124b48c9aa771a18ff35befae60b9e221f564cd5617a47269` |
| 36 | R03-valid-malformed-m1unfixed-s3 | `docs/evidence/r03-malformed-20261016/R03/r03-m1unfixed-s3/r03-m1unfixed-s3.csv.gz` | `4100c85f4d3cd8de3301608d2bbb96c2e86f36eca49ef8f280993651a94d365b` | `ba942e2cafab2979d20a39901e0d55921b1e76d06ded1dc85e6ea126e0daaf31` |
| 37 | R03-valid-truncated-m1unfixed-s3 | `docs/evidence/r03-malformed-20261016/R03/r03-m1unfixed-s3/r03-m1unfixed-s3.csv.gz` | `4100c85f4d3cd8de3301608d2bbb96c2e86f36eca49ef8f280993651a94d365b` | `ba942e2cafab2979d20a39901e0d55921b1e76d06ded1dc85e6ea126e0daaf31` |
| 38 | R03-valid-malformed-m1fixed-s3 | `docs/evidence/r03-malformed-20261016/R03/r03-m1fixed-s3/r03-m1fixed-s3.csv.gz` | `5bb39657552042b0028fa614e021732287157f6499075c3e564ef81f93dff2db` | `f2cc5f86823bc9c479abcf63c587dd9af91a7d3bc99cdb52618f95769586b606` |
| 39 | R03-valid-truncated-m1fixed-s3 | `docs/evidence/r03-malformed-20261016/R03/r03-m1fixed-s3/r03-m1fixed-s3.csv.gz` | `5bb39657552042b0028fa614e021732287157f6499075c3e564ef81f93dff2db` | `f2cc5f86823bc9c479abcf63c587dd9af91a7d3bc99cdb52618f95769586b606` |
| 40 | R03-valid-malformed-m5ref-s3 | `docs/evidence/r03-malformed-20261016/R03/r03-m5ref-s3/r03-m5ref-s3.csv.gz` | `8823a5c508e6a1ceef5511dfce38cbb125b1093a04bc20ba2b6258048b4ca7a9` | `cdf985eaec4cf72a0b8862d0468608029e0d27d6dcd48fff3f98183600f564d5` |
| 41 | R03-valid-truncated-m5ref-s3 | `docs/evidence/r03-malformed-20261016/R03/r03-m5ref-s3/r03-m5ref-s3.csv.gz` | `8823a5c508e6a1ceef5511dfce38cbb125b1093a04bc20ba2b6258048b4ca7a9` | `cdf985eaec4cf72a0b8862d0468608029e0d27d6dcd48fff3f98183600f564d5` |

## 附录 B：与既有证据的交叉核对

- 与 `stats/members/members.csv.gz` 的 `mean0/mean1/sd0/sd1/n0/n1` 逐项比对：
  **21/21 一致**。
- 与各 `stats/<dataset>/ci_welch.json` 的 `mean_difference_class0_minus_class1_ns`
  与 `standard_error_ns` 逐项比对：**39/39 一致**。
- M1 两臂与派生文件 `tooling-strengthen-20261015/csv/*-message-zero-ones.csv` 的
  逐值（排序后）比对：**2/2 一致**。

## 附录 C：复现命令

```bash
cd <repo-root>
python3 docs/evidence/r04-stats-20261016/robustness-src/r04_power.py
# 一次跑完 T26 + T27（含图）：
python3 docs/evidence/r04-stats-20261016/robustness-src/r04_run_all.py
```

依赖：Python 3.9+ 标准库 + numpy（本机为 Python 3.9.6 / numpy 2.0.2）。
脚本只读仓库内已有 CSV，不联网、不采集、不写已有证据文件。


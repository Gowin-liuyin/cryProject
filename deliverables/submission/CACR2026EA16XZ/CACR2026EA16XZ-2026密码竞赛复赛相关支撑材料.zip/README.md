# 多泄漏模块检测平台 · 匿名支撑材料卷

本卷是《ML-KEM 解封装实现的时间侧信道检测与常数时间防护》的**匿名支撑材料**：
报告正文、题面 12 条的逐条证据索引与查看器、统计产物、运行输出图与原始日志、
以及可离线复算的 C 统计工具与自检入口。**全卷不含凭证、构建产物或远端依赖资源。**

## 从哪看起

| 想看 | 打开 |
|---|---|
| 报告（可读版） | [`report/index.html`](report/index.html)（离线单页，含章节导航） |
| 报告（PDF） | [`report/report.pdf`](report/report.pdf) |
| 报告（文字源） | [`report/report.md`](report/report.md) · [`report/report.tex`](report/report.tex) |
| 题面 12 条的证据索引 | [`index.html`](index.html) 的 E01–E70 列表，或 `evidence/E*.html` |
| 运行输出图与原始日志 | [`evidence/screenshots/SCREENSHOTS.md`](evidence/screenshots/SCREENSHOTS.md) |
| 离线复算怎么跑 + **包完整性自检命令** | [`REPRODUCE.md`](REPRODUCE.md) |
| 每个成员的来源与变换 | [`PROVENANCE.json`](PROVENANCE.json) |
| 每个成员的摘要 | [`MANIFEST.json`](MANIFEST.json) |

## 目录结构

```
README.md          本文件
REPRODUCE.md       离线复算说明 + 包完整性自检命令 + 本卷有什么/没有什么
reproduce.sh       离线复算入口（sh reproduce.sh <新输出目录>）
index.html         证据索引（E01–E70）与各卷入口
report/            报告（md / tex / pdf / 离线 html / 数据与表 / 证据快照）
evidence/E*.html   每份来源的查看器（现生成，**不是原件**）
evidence/files/    来源文件的匿名副本，路径与仓库相对路径一一对应
evidence/screenshots/ 4 张运行输出图与其原始日志说明
expected/          打包时用包内 C 工具现算的复算基准（只检验重建一致性）
data/              M1 的 6 份原始数值 CSV（离线复算的输入）
source/            自有实现、统计工具、夹具与 mlkem-native 参考实现
CMakeLists.txt     离线复算用的构建定义（只构建本卷自带的那几个目标）
MANIFEST.json      每个成员的路径、字节数与 SHA-256
PROVENANCE.json    每个成员的来源路径、变换方式与匿名副本摘要
```

## 路径对应

正文与证据页里的路径是**仓库相对路径**（如 `docs/evidence/...`），
本卷把它们镜像在 `evidence/files/<同一路径>` 下；
`PROVENANCE.json` 的 `files` 数组给出每个包内成员的来源路径与变换方式。

## 匿名口径

全卷按统一规则把**用户名、邮箱、主机名、绝对路径、IP、仓库目录名、
个人机器名**替换成占位符（如 `[REMOTE_PROJECT]`、`[LOCAL_USER]`、`[LOCAL_HOST]`）；
**被替换项的清单与扫描覆盖范围见仓库侧的包审计记录**（校验器不在卷内：
它的模式源码含作者真实邮箱，随卷分发会泄露）。

## 本卷不包含

原始计时长表（约 46 MB）、第三方源码树（`vendor/*`、`third_party/*`）、硬件时间采集。
逐项原因与取件方式写在 [`REPRODUCE.md`](REPRODUCE.md) 的「本卷有什么 / 没有什么」一节。

> 上传时本文件按官方角色名另存为「编号-2026密码竞赛复赛相关支撑材料.zip」（内容逐字节相同）。

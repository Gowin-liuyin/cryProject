# 离线复算

运行 `sh reproduce.sh <不存在的新输出目录>`。只读取包内数据，构建现有 C11 统计工具并执行五项 CTest，再逐字比较 CI JSON 与归一化 CSV。原始数值 CSV 保持字节，M1 的派生宽表只在输出目录改表头以适配统计接口，不改数值。

打包时 C 输出作为确定性复算参照，只检验打包/重建一致；统计功能另由已有手算 oracle 与拒绝测试检查，不能拿自产期望证明算法正确。外部 RTLF、Mona、dudect、Binsec 未在本入口重执行；不采硬件时间、不改频率、不需要联网。ML-KEM 依赖仅为原 C 统计共用代码的链接依赖，本入口不运行密码采集。

需要 CMake>=3.21、C11 编译器、POSIX shell、awk、shasum、cmp、sed；报告重编译另需 XeLaTeX/ctex/Fandol。
`shasum` 由 Perl 提供（Alpine 等最小化环境没有 `sha256sum` 时需先装 perl 或改用 sha256sum）。

## 包完整性自检（一行一条，不需要任何外部工具）

```sh
# 1) 成员数、revision 与文档状态（与 MANIFEST.json 一致）
python3 -c "import json;m=json.load(open('MANIFEST.json'));print(m['revision'], len(m['files']), 'files;', m['document_state'])"

# 2) 逐成员重算 SHA-256，与 MANIFEST.json 对账
python3 - <<'PY'
import hashlib, json, pathlib, sys
manifest = json.load(open("MANIFEST.json"))
bad = []
for entry in manifest["files"]:
    path = pathlib.Path(entry["path"])
    if not path.is_file():
        bad.append((entry["path"], "missing"))
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != entry["sha256"]:
        bad.append((entry["path"], "sha mismatch"))
print("checked", len(manifest["files"]), "files;", len(bad), "problems")
for item in bad:
    print("  ", item)
sys.exit(1 if bad else 0)
PY

# 3) 本地 HTML 链接是否都可达
python3 - <<'PY'
import pathlib, re, sys
broken = []
for page in list(pathlib.Path(".").rglob("*.html")):
    text = page.read_text(encoding="utf-8", errors="replace")
    for href in re.findall(r'href="([^"]+)"', text):
        if href.startswith(("http://", "https://", "#", "mailto:")):
            continue
        target = (page.parent / href.split("#")[0]).resolve()
        if not target.exists():
            broken.append((str(page), href))
print("broken local links:", len(broken))
for item in broken[:20]:
    print("  ", item)
sys.exit(1 if broken else 0)
PY
```

## 报告里的路径怎么对应到包内文件

正文与证据页里出现的路径是**仓库相对路径**（例如 `docs/evidence/...`），
本卷把它们镜像在 `evidence/files/<同一路径>` 下；所以：

```sh
# 仓库路径 → 包内路径
echo "evidence/files/docs/evidence/platform-collection-20261016/stats/holm/holm.csv.gz"
```

`PROVENANCE.json` 的 `files` 数组给出**每个包内成员的来源路径与变换方式**，
可用来核对「某个包内文件对应仓库里的哪一个」。包里**没有**仓库里的 `verify_package.py`
（它的模式源码含作者真实邮箱，见包内 README 的说明），包审计在仓库侧执行。

## 本卷有什么 / 没有什么

**有**：报告（Markdown / LaTeX / PDF / 离线 HTML）、题面 12 条的证据索引 E01–E70 与对应查看器、
M1–M5 的**统计产物**（每数据集 `ci_welch.json`、规范化逐样本 `normalized.csv.gz`、
家族成员表 `members.csv.gz`、Holm 输出 `holm.csv.gz` / `pooled.csv.gz`、
控制器运行汇总 `status.log`）、RTLF 的逐数据集结果、KAT 向量原件
（`tests/vectors/mlkem768.txt`）与机器可读汇总、采集与统计工具源码、4 张运行输出图与其原始日志。

**没有**（原因写在下面，取件方式也写在下面）：
- 仓库里**完整采集树**（各模块的原始长表、逐次记录与工具输出，合计约 46 MB）未随卷分发。
  **卷内已含**的是可复算所需的最小集：每个数据集的**原始逐样本长表** `stats/<数据集>/input.csv.gz`
  （42 份，共约 6 MB）、规范化后的 `normalized.csv.gz`、每成员统计 `ci_welch.json`、
  家族成员表 `members.csv.gz` 与 Holm 输出 `holm.csv.gz`——这些**足以复算 Welch CI、Holm 家族判定与 MDE**；
  完整的采集树在仓库 `docs/evidence/platform-collection-20261016/` 下，摘要见同目录 `*.sha256`。
- **第三方源码树**（`vendor/liboqs-0.10.0`、`vendor/kyber-kyberslash-*`、`third_party/*`）：
  体积与许可原因未随卷分发；取件脚本 `tools/fetch_all_vendors.sh` 与
  `tools/fetch_liboqs_0.10.0.sh` **在卷内**，取件后按脚本里的 SHA-256 校验。
- **硬件时间采集**：本入口不采硬件时间、不改频率；卷内的采集结果都是已归档的原件。

## 怎么重跑报告里的四张图

图 1–4 是**按统一终端样式渲染的运行输出图（不是屏幕照片）**，
原始日志都在卷内 `evidence/files/` 下（见 `evidence/screenshots/SCREENSHOTS.md`）：

| 图 | 卷内原始日志 |
|---|---|
| 图 1（quick 档 263/263） | `evidence/files/docs/evidence/screenshots-20261020/reproduce-quick-terminal-p2b.log` |
| 图 2（Memcheck 命中） | `evidence/files/docs/evidence/m3-completion-20261016/native-8b6f2d91/on-secret.memcheck.log` |
| 图 3（控制器状态） | `evidence/files/docs/evidence/r12-innovation-20261016/remote/logs/status.log` |
| 图 4（离线展示） | 由 `report/index.html` 渲染 |

**在评委可见环境重拍**需要完整仓库与硬件（锁频控制器、M3 的 Memcheck 探针），
见报告 §17 的一键入口 `sh tools/fetch_all_vendors.sh` 与 `sh scripts/reproduce_all.sh quick`
（两者都在卷内 `evidence/files/` 下，但需要 vendor 树与硬件，故本卷无法单独完成）。

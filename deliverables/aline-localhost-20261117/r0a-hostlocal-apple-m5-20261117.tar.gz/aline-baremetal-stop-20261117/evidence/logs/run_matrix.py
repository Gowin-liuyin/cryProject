#!/usr/bin/env python3
"""Host-local R0a matrix. Not controller.py. Frequency lock is not retried."""

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

WORK = Path("/Users/yin/code/cryProject/build/Cry/r0a-branchfix-20261117-39827f75dd86")
os.environ["TMPDIR"] = str(WORK / "tmp")
os.environ["XDG_CACHE_HOME"] = str(WORK / "cache")
(WORK / "tmp").mkdir(exist_ok=True)
(WORK / "cache").mkdir(exist_ok=True)

ARMS = {
    "a0": WORK / "build-ordinary/collector/a0/m2_decaps_collector",
    "a1": WORK / "build-ordinary/collector/a1/m2_decaps_collector",
    "a2": WORK / "build-ordinary/collector/a2/m2_decaps_collector",
}
PK = WORK / "fixtures/pk.bin"
SK = WORK / "fixtures/sk.bin"
MATRIX = (
    ("r0a-r01-a0", "a0", "31337", 2),
    ("r0a-r01-a2", "a2", "31337", 2),
    ("r0a-r01-a1", "a1", "31337", 2),
    ("r0a-r02-a1", "a1", "424242", 2),
    ("r0a-r02-a2", "a2", "424242", 2),
    ("r0a-r02-a0", "a0", "424242", 2),
    ("r0a-r03-a2", "a2", "31337", 6),
    ("r0a-r03-a0", "a0", "31337", 6),
    ("r0a-r03-a1", "a1", "31337", 6),
)
LOG = WORK / "logs/matrix.log"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def emit(message: str) -> None:
    line = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()) + " " + message
    print(line, flush=True)
    with LOG.open("a") as handle:
        handle.write(line + "\n")


def main() -> int:
    if PK.stat().st_size != 1184 or SK.stat().st_size != 2400:
        emit("MEMBER_FAIL preflight pk/sk size")
        return 1
    manifest = WORK / "runs/MANIFEST.sha256"
    lines = [
        f"{sha256(path)}  runnable-macho/{arm}/m2_decaps_collector"
        for arm, path in ARMS.items()
    ]
    lines.append(f"{sha256(PK)}  fixtures/pk.bin")
    lines.append(f"{sha256(SK)}  fixtures/sk.bin")
    lines.append(
        "note  runnable images are AppleClang x86_64 Mach-O under Rosetta; "
        "they are not the sealed Linux ELF hashes"
    )
    lines.append(
        "note  frequency gate failed before this matrix; lock was not retried; "
        "planned CPU 2/6 was not applied because taskset is absent"
    )
    manifest.write_text("\n".join(lines) + "\n")
    emit("MANIFEST written before matrix samples")
    failures = 0
    for run_name, arm, seed, planned_cpu in MATRIX:
        raw_dir = WORK / "runs" / run_name / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        csv_path = raw_dir / "m2-main.csv"
        meta_path = raw_dir / "m2-main.meta"
        if csv_path.exists() or meta_path.exists():
            emit(f"MEMBER_FAIL {run_name} output exists; not overwritten; not retried")
            failures += 1
            continue
        command = [
            str(ARMS[arm]),
            "--class",
            "message-zero,message-ones",
            "--samples",
            "10000",
            "--seed",
            seed,
            "--warmup",
            "100",
            "--raw",
            str(csv_path),
            "--meta",
            str(meta_path),
            "--run-id",
            run_name,
            "--public-key",
            str(PK),
            "--secret-key",
            str(SK),
        ]
        emit(
            f"START {run_name} arm={arm} seed={seed} planned_cpu={planned_cpu} "
            "affinity=not_pinned"
        )
        started = time.time()
        try:
            completed = subprocess.run(
                command,
                timeout=300,
                capture_output=True,
                text=True,
                check=False,
            )
            code = completed.returncode
            (raw_dir / "stdout.txt").write_text(completed.stdout)
            (raw_dir / "stderr.txt").write_text(completed.stderr)
        except subprocess.TimeoutExpired as error:
            code = 124
            stdout = error.stdout or ""
            stderr = error.stderr or ""
            if isinstance(stdout, bytes):
                stdout = stdout.decode("utf-8", "replace")
            if isinstance(stderr, bytes):
                stderr = stderr.decode("utf-8", "replace")
            (raw_dir / "stdout.txt").write_text(stdout)
            (raw_dir / "stderr.txt").write_text(stderr + "\nTIMEOUT 300s\n")
        elapsed = time.time() - started
        note = {
            "schema": "host-local-note-not-controller-terminal",
            "run_name": run_name,
            "arm": arm,
            "seed": seed,
            "planned_cpu": planned_cpu,
            "cpu_affinity": "not_pinned",
            "taskset": "absent",
            "frequency_gate": "fail",
            "frequency_gate_reason": (
                "no scaling_cur_freq; sudo -n refused; Apple M5; "
                "target 4300000 kHz not applied; lock not retried"
            ),
            "sampling": "host-local-rosetta-x86_64-unlocked",
            "operator_order": "本地跑，你就是裸金属",
            "worker_exit_code": code,
            "wall_seconds": round(elapsed, 3),
            "timeout_seconds": 300,
            "retry": "not_done",
        }
        (WORK / "runs" / run_name / "host-local-terminal.json").write_text(
            json.dumps(note, indent=2) + "\n"
        )
        if code != 0:
            failures += 1
            emit(f"MEMBER_FAIL {run_name} exit={code} wall={elapsed:.1f}s")
        else:
            emit(f"MEMBER_OK {run_name} exit=0 wall={elapsed:.1f}s")
    emit(f"MATRIX_DONE failures={failures}")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

# platform_holm 结果

Holm 家族按预注册 m 计算；RTLF 与 dudect 一律族外，最大 t 不得转伪 p。

族水平 alpha = 0.05；adjusted_p 单调不减，一旦某项不拒绝，其后全部不拒绝。

## Holm 逐步检验

| family_id | member_id | raw_p | rank | threshold | adjusted_p | reject |
| --- | --- | --- | --- | --- | --- | --- |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r02-a1 | 0.000458765 | 1 | 0.00555556 | 0.00412888 | yes |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r02-a0 | 0.00731677 | 2 | 0.00625 | 0.0585342 | no |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r01-a0 | 0.0163752 | 3 | 0.00714286 | 0.114627 | no |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r03-a0 | 0.0229309 | 4 | 0.00833333 | 0.137586 | no |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r03-a1 | 0.0386953 | 5 | 0.01 | 0.193476 | no |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r03-a2 | 0.162775 | 6 | 0.0125 | 0.651101 | no |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r01-a2 | 0.309362 | 7 | 0.0166667 | 0.928087 | no |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r01-a1 | 0.681245 | 8 | 0.025 | 1 | no |
| m2_branchfix_hostlocal_unlocked_v1 | r0a-r02-a2 | 0.760596 | 9 | 0.05 | 1 | no |

## 固定效应合并

theta = mean0 - mean1；se = sqrt(sd0^2/n0 + sd1^2/n1)；w = 1/se^2；
pooled = sum(w*theta)/sum(w)；pooled_se = 1/sqrt(sum(w))；ci95 = pooled +- 1.96*pooled_se；
Q = sum(w*(theta-pooled)^2)；df = m-1；I2 = (Q > df) ? (Q-df)/Q*100 : 0。

| family_id | m | pooled_effect_ns | pooled_se_ns | ci95_low_ns | ci95_high_ns | q_statistic | df | i2_percent |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| m2_branchfix_hostlocal_unlocked_v1 | 9 | 58.5300666 | 11.3893403 | 36.2069597 | 80.8531735 | 11.5134632 | 8 | 30.5161285 |

数值护栏：se == 0、n0 == 0 或 n1 == 0 一律报错退出码 2，不跳过也不除零。
并列 p 值按输入出现顺序作为次级键，排名稳定。

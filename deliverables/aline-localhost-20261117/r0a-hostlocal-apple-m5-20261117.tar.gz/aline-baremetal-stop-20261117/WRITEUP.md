# R0a 三层结论（本机，2026-11-17）

采集机：Apple M5，Darwin 25.6.0，x86_64 Mach-O 经 Rosetta。时钟 `CLOCK_MONOTONIC`，`clock_resolution_ns=1000`。九份 CSV 的每个 `elapsed_nanoseconds` 都是 1000 的倍数。`zero_elapsed_count=0`，`failed_decapsulation_count=0`，`chosen_message_accept_mismatch_count=0`。

这三层分开写。产物层的反汇编不代替 Memcheck。统计层的区间不代替产物层。

## 1. 产物层

判据是 `pqcrystals_kyber768_ref_poly_frommsg` 的 `secret_conditional_jumps`：A0/A1/A2 = 1/1/0。脚本退出码 1 且计数为 1，是 A0/A1 的通过；A2 退出码 0 且计数为 0。

封存 Linux ELF（GNU objdump 2.47，`evidence/logs/artifact-gate-sealed.txt`）：

| 臂 | SHA-256 | secret_conditional_jumps | verdict |
|---|---|---:|---|
| A0 | `b1e820e848d83cb334a967c64573c3c3355451e6e72778b45af96724e9c96b5d` | 1 | secret_branch_present |
| A1 | `c9cecdafb6bb855c44f08e52289baf2754fc6376fde0422ec004ec8945f4e9a8` | 1 | secret_branch_present |

A2 没有封存全链接 ELF。产物门打在补丁后的 `poly.c` 译出的 ELF 目标文件上（`evidence/logs/artifact-gate-elfobj.txt`）：A0 = 1，A1 = 1，A2 = 0（`conditional_jumps` 从 3 降到 2，`verdict=branchless`）。

可运行的 Mach-O 上，同一脚本的结论是 `verdict=symbol_not_found`（Mach-O 符号带下划线前缀）。该日志的 `secret_conditional_jumps=0` 是符号未找到时的空计数，不作为产物层结果。见 `evidence/logs/artifact-gate-a0a1.txt`。

可运行镜像 SHA-256（不是封存 ELF）：

| 臂 | SHA-256 | 运行时 SHA3-256 |
|---|---|---|
| A0 | `a06e8c6ac1225071516c04829df318533e7dc774416ed2a9aa0716c82df2821c` | `41b057751027687cad211dfa75d617c95beb5f7103a34b5edf9c7dbb7fb194b2` |
| A1 | `cd901204f34ada026f3f44d5f4085c44e00a1d5c89bbe599201e6e35f1298b56` | `d2ce0d03c5957e61640d07ec9cd9b37f16288a7793d0a8f547d09be293888f21` |
| A2 | `8eaf10c72a94af2b5a0f4fee3c37184288b7796e7bba72783dcb52381e785240` | `89c82b5bda1b895fe3ba8ba461fc5fbf6fea0de7147e2a5facdd3fc615321ba8` |

A1 与 A2 的 CSV `implementation` 字段都是 `m2-kyber768-round3-fixed`（两者都带 `PLATFORM_M2_FIXED`）。臂别看 `run_id` 和上面的可执行文件摘要。

产物层按 ELF 目标文件与封存 ELF 的计数，A0/A1/A2 = 1/1/0。

## 2. 定位层

`valgrind` 不在本机，本轮没有安装。R0a-2 记为工具缺失。没有上下文数，也没有把反汇编或本机计时写成 Memcheck。

## 3. 统计层

频率放行门在九次采样之前失败，锁频没有重试。冻结家族 `m2_branchfix_end_to_end_v1` 的锁频成员全部 `not_run`，未进入 Holm。

下面是另一家族：`m2_branchfix_hostlocal_unlocked_v1`。九个成员都完成了，m=9，α=0.05。Welch 来自本机编译的 `platform_stats`（源文件是仓库里的 `stats_csv.c` 与 `timing_statistics.c`；二进制 SHA-256 `fa37c311a377beeb374ab2b99751547504f5712027f70c67ed2533ae6357144f`，不是冻结 ELF `ddc48b9ef92a010e9b804389cabc4089e042c814ac8af4b3fa89e541bf4ac9e2`）。Holm 来自 `platform_holm`（SHA-256 `612b810de0d4ab798e65bd60f3138c4d4effcb7594af6976b6bf0ed0b4a5ed76`）。

效应是 mean(message-zero) − mean(message-ones)，单位 ns。含 0 的 95% CI 记为未检出。未检出只表示该区间含 0。本文件不把未检出写成恒时。

| 成员 | 臂 | 均值差 | CI 下 | CI 上 | 含 0 | Holm 拒绝 |
|---|---|---:|---:|---:|---|---|
| r0a-r01-a0 | A0 | 83.5 | 15.32 | 151.68 | 否 | 否 |
| r0a-r01-a2 | A2 | 58.1 | -53.92 | 170.12 | 是，未检出 | 否 |
| r0a-r01-a1 | A1 | -13.7 | -79.07 | 51.67 | 是，未检出 | 否 |
| r0a-r02-a1 | A1 | 114.9 | 50.63 | 179.17 | 否 | 是 |
| r0a-r02-a2 | A2 | 10.2 | -55.41 | 75.81 | 是，未检出 | 否 |
| r0a-r02-a0 | A0 | 90.2 | 24.29 | 156.11 | 否 | 否 |
| r0a-r03-a2 | A2 | 45.1 | -18.23 | 108.43 | 是，未检出 | 否 |
| r0a-r03-a0 | A0 | 70.7 | 9.78 | 131.62 | 否 | 否 |
| r0a-r03-a1 | A1 | 66.1 | 3.44 | 128.76 | 否 | 否 |

`platform_holm` 输出：`families=1 members=9 rejected=1 alpha=0.05`。被拒绝的成员是 `r0a-r02-a1`（A1，seed 424242），raw p = 0.000458764622472446，rank 1，阈值 0.00555555555555556，adjusted p = 0.00412888160225201。其余八个成员 `reject=0`。

A2 的三个 CI 都含 0，Holm 也没有拒绝它们，统计层对 A2 记未检出。

固定效应合并（工具 `pooled.csv`，九个成员合在一起，不是单臂结论）：pooled effect 58.5300665624061 ns，95% CI 36.2069596606786 到 80.8531734641335。该区间不含 0。合并区间整个落在一个时钟刻度（1000 ns）以下。样本本身仍是 1000 ns 的整数倍。

`evidence/runs/smoke/` 是 A0 的 50 次冒烟，不进任何家族。

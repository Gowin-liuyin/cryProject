# A 线采集：本机作为采集机（2026-11-17）

操作者指令是「本地跑，你就是裸金属」。本次采集机是 `yindeMacBook-Air.local`（Darwin 25.6.0，Apple M5，arm64，10 个物理核等于 10 个逻辑核）。实验室主机 `nss-marker@10.144.144.5` 的 SSH 会话没有建立，见 `ssh-preflight.txt` 与 `ssh-recheck.txt`。没有在那台机器上锁频，也没有改它的 policy 或 boost。

采集源是 `a31518d70dc8ea5b4f2c024da73ea5e105795b0a` 的 detached HEAD。`PLAN.md`、`RUNBOOK.md`、`A_LINE_BUNDLE.md` 未改。`vendor/`、`sources/`、已提交的 `docs/evidence/` 与该提交相比无差异。没有记录口令，没有 `git push`。

工作根：`build/Cry/r0a-branchfix-20261117-39827f75dd86`（`build/` 被 gitignore）。`TMPDIR` 在该根的 `tmp/` 下。原件副本在本包的 `evidence/`。

## 入口

- PLAN git blob：`4c0ec9fba80b6a5c7922451e0dae209c0619b0e6`
- PLAN 内容 SHA-256：`cb5eb33617e3efd1e405f8fcb8d6a6d7ec9ce08b321205586760c7a4b2978510`
- 上传包两次摘要相同：`a4432efb0ace74f3d0d2443489666e6a221b88703812830f5e7f98801b46beee`
- 补丁 SHA-256：`5e7fe0fce1132f0a13e0202e4bed73f0664231a686866836fb4510cd14838eed`

## 这次实际做了什么

三层结论在 `WRITEUP.md`。采样日志在 `r0a-run.txt`。统计在 `r0a-holm.txt`。

频率放行门失败（没有 `scaling_cur_freq`，`sudo -n` 要口令，没有 `taskset`，目标 4300000 kHz 没有写入）。锁频没有重试。计划中的 CPU2/CPU6 没有绑上，采集程序自己写下 `cpu_affinity=not_pinned`、`frequency_control=not_configured`。

九次主类对仍按冻结的种子和臂顺序跑完，每类 10000、预热 100，固定密钥 `--key-seed 31337`。可执行文件是 AppleClang 的 x86_64 Mach-O，经 Rosetta 运行。封存的 Linux ELF 只做了摘要和产物门，没有执行。

冻结家族 `m2_branchfix_end_to_end_v1` 的锁频成员记为 `not_run`，没有进入 Holm。本机这九份 CSV 另用家族名 `m2_branchfix_hostlocal_unlocked_v1` 做了 `platform_stats` 和 `platform_holm`（m=9，α=0.05）。

## 同一趟没有跑成的项

| 项 | 结果 |
|---|---|
| R0a-2 Memcheck | `valgrind` 不在本机。没有安装。没有填写上下文数。 |
| R18 SMT pilot | 观测者编译失败：本机没有 `CPU_SET` / `sched_setaffinity`。物理核数等于逻辑核数。pilot 未开始，`mde_budget.py` 未调用，正式批数未冻结。 |
| R19 cache pilot | 同一编译失败。pilot 未开始。 |
| A-R17-01..03、A-R23-01 | Memcheck 工具不在。本趟没有重跑 KAT。 |
| A-R24 | `binsec` 不在本机。装载失败。没有写成 secure。 |
| A-R17-04、A-R23-02 | 按冻结范围本轮不执行，包内无这两项的结果文件。 |

远端退出核对：SSH 没有打开，所以没有 32 路 policy / global boost 回读，也没有控制器锁可释放。本机 `sudo -n` 被拒绝，频率策略没有被改过。

# 固定库文档范围

原vendor仅包含固定提交的mlkem目录，源码、许可证、原README不修改。原README中12处父级examples/dev/scripts相对引用属于未vendoring的上游开发资料，不是本作品证据或运行依赖；[逐项原地址映射](vendor-documentation-scope.json)固定原提交，在线访问与本包离线材料分开。当前作品不新增这些架构或硬件示例。[作品入口](../../index.html)与[使用说明](product-workflow.md)给出实际CMake路径。

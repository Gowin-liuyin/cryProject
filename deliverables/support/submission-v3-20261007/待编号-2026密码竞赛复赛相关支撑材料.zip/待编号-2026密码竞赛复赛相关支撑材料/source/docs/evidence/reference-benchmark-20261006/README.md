> 历史匿名派生副本。数值CSV原字节保留；身份文本已转换，历史hash记录保为original-record，仅说明原运行，不可对当前source或缺失原二进制作完整性检查。当前分发清单另生。此前失败/模拟器/未提交状态保留；不重启停止路线。

# 参考版普通负载：2026-10-06 本地新采集

平台为真实Apple M5/ARM64 macOS 26.6.2、Darwin25.6.0；Apple Clang21、Ninja、CMake4.3.2，
RelWithDebInfo实际 `-O2 -g -DNDEBUG -std=c11`、严格警告、sanitizers=OFF、无LTO。
`environment.log`记录 `kern.hv_vmm_present=0`、`sysctl.proc_translated=0`，正式文件为arm64 Mach-O。
未使用QEMU或架构翻译命令；CPU亲和性、频率和后台负载未配置。

源码HEAD为 `22910deeeb375e172f59e99ad7a8e6d35dfb3b1f` **加未提交内容**，不是干净提交。
`tested-source.diff`、`tested-source.sha256.original-record.txt`、`release-build-identity.txt`及每份meta保留当时身份；
新源文件随本轮交付。后续提交不得回填日志中的旧HEAD。
正式可执行文件SHA3-256：
`281fdabc9ddaf2e5cfac0393a4035ccd1e3a04cf8107b6fd267d13d8fdec6f52`，三份meta与独立摘要一致。
构建目录及二进制SHA-256分别见 `build-directories.json`、`binaries.sha256.original-record.txt`，不归档二进制副本。

`sampling-plan.txt`在采集前写定三次运行、三类1:1:1、每类1000、每次100次预热。
文件名20261006/07/08是公开种子编号，三次均在本轮同日顺序执行，并非三个不同日期。
9000条完整解封装记录全部保留；每次一个测试密钥，每类1000个派生输入槽位，未保存
密文指纹，不能由CSV单独证明去重数量或随机独立性。退出码均0、meta complete，
所有命令及起止时间见 `step-exits.tsv`。动态构建的接口测试样本在临时目录，仅作正确性。

| 种子 | 类别 | 次数 | 均值ns | P50ns | P90ns | P99ns |
|---:|---|---:|---:|---:|---:|---:|
| 20261006 | valid | 1000 | 14505 | 14000 | 15000 | 19000 |
| 20261006 | bit-flipped | 1000 | 14393 | 14000 | 15000 | 17000 |
| 20261006 | random | 1000 | 14435 | 14000 | 15000 | 17000 |
| 20261007 | valid | 1000 | 13893 | 14000 | 14000 | 16000 |
| 20261007 | bit-flipped | 1000 | 13923 | 14000 | 14000 | 17000 |
| 20261007 | random | 1000 | 13894 | 14000 | 14000 | 17000 |
| 20261008 | valid | 1000 | 13912 | 14000 | 14000 | 16000 |
| 20261008 | bit-flipped | 1000 | 13845 | 14000 | 14000 | 15000 |
| 20261008 | random | 1000 | 14018 | 14000 | 14000 | 17000 |

混合均值分别14444.333、13903.333、13925.000ns，只作描述；P50/P90/P99规则为
`floor(p*(n-1)+0.5)`零基下标、不插值。所有类别最大值和原序四段均值保留在 `.summary`。
其中random/20261008最大98000ns，未删长尾；类别差异不命名为秘密泄露。

三次 `clock_getres`均1000ns，观察最小正读钟步长均1000ns，10000个增量的零值计数为
9827、9835、9824（具体以meta核验）；空窗口1000个，均值分别15、16、20ns，
零值比例高，最小0、最大1000ns。空窗平均小于报告分辨率并不提供相同的单次精度，
没有扣除它、没有插值。meta逐项保留10000个读钟增量和1000个空窗值。

正式反汇编 `reference-disassembly.txt`：主循环 `0x100000cfc`起点读钟、
`0x100000d1c`完整包装层解封装调用、`0x100000d28`终点读钟；
`0x100000d40`写原始值，`0x100000d48–0x100000d54`消费输出，
`0x100000d84`才进入批量文件输出。包装层 `0x1000113a4`尾调用真实内核，
内核 `0x10000bc64`仍进行重加密。地址只对上述摘要产物有效，未据此证明全库恒时。

普通与ASan/UBSan各运行参考5项及新增2项，共7个不同测试，全部通过。
新增C检查含三类等量、顺序可复现、自检记录完整、拒绝覆盖、零次数、meta路径错误及
限制文件大小的写入失败；失败返回非零，部分产物不能作性能结果。
动态产物与正式目录隔离，测试样本不混入本表。

核验本目录、当前被测源码与仍保存的正式文件：

```sh
shasum -a 256 -c docs/evidence/reference-benchmark-20261006/SHA256SUMS
shasum -a 256 -c docs/evidence/reference-benchmark-20261006/tested-source.sha256.original-record.txt
shasum -a 256 -c docs/evidence/reference-benchmark-20261006/binaries.sha256.original-record.txt
```

性能只适用于此ARM64本地条件，无受控改进、独立确认或真实x86_64 Linux实测声明。

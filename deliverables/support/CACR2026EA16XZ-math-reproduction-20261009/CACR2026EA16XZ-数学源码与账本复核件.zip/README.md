# 固定整数数学源码复核件

日期：2026-10-08。来源别名：`SOURCE-MATH-COST-01`。该别名不是 Git 提交号、版本签名或独立时间戳。本件目前为未提交、未由 Git 封存的内部复核载荷，供项目组核对 M01 的数学源码和已经发生的固定数据记录。

本件补充42页报告与摘要为 `59b858391d21392e3725e01791b8b877f942599ccce46d323aacc22d109cf9ee` 的数据解释件所未包含的软件重建能力；它不替换该件、旧v2或已封存的软件v3。目录仅含自有纯数学 C、构建配置、固定整数输入和一次原运行的数据副本，没有密码实现、缺陷变体、密钥、网络入口、原计时可执行文件或机器码。

## 三种角色

| 材料 | 含义与边界 |
|---|---|
| `update_cost.c`、`update_cost.h`、`snapshots/`、`failure_check.cmake` | 原观察器、两种数学更新函数和软件失败检查的原字节；C11、同编译器、`-O2`、独立翻译单元、`-fno-lto`、IPO关闭。CMake经导出适配，取消对Git的依赖，固定输入测试使用随包 `inputs/`。源码相同不保证不同目录重建的二进制摘要或实际耗时相同。 |
| `audit/result_audit.c`、`frozen-evidence/run/` | 原独立 C 审计源码和原运行记录。审计重新计算行间一致性、结果消费、时钟差值、对应比值与摘要，并逐字核对24份输入副本，不调用两种统计函数，不重新产生原160个正式窗口。原尾数与 p 值依据固定独立基线和合同，审计器没有重新枚举20对输入的全部状态。 |
| `checks/` | 本次导出软件检查的编译链、源码摘要、产物摘要和明确的匿名路径视图。新普通、ASan/UBSan和独立审计产物是软件检查产物；它们不是原正式计时产物。 |

原正式计时产物 SHA256 是 `79dc6ba9b890fd136a62a1a1b1d9dddbfd77aaf8b14c8a963527db38155cef9b`。原阶段状态中的 `artifact_mechanism_review=pending_external` 保持原字节，是记录产生时的阶段状态；后续产物资格解释见已有报告和数据解释件。新软件检查不继承旧产物机制审查或计时资格。

`inputs/` 含原 C01 的8份 CSV、8份 plan和8份 `r1-baseline.report`，已与上述59b数据解释件对应条目逐字核对。`frozen-evidence/run/inputs/` 的24项是同一输入的原运行副本，仅供审计器比较，不是新增数据。任务3与7的CSV完全相同且全零，保留它们不构成八份独立不同任务。固定输入中的交换与 iid 字段是合成任务声明，不证明真实测量总体的前提。

`final-state.pending` 从原运行目录逐字复制；它与原 `final-state.meta` 的相等关系由审计器检查，没有为本件重新生成发布过程。含本机路径的 `input-records.tsv` 没有进入本件。实际来源、原摘要和副本角色见 [字节来源清单](manifest.json)。

## 只进行软件检查

从本件根目录使用CMake 3.21或以上、GCC/Clang，在Linux或macOS构建。不联网、不需要Git；普通与动态检查分目录。以下命令只做小规模手算自检、24文件加载、失败留证以及原数据离线核对。失败留证测试使用不存在的输入，止于加载失败；不会执行正式统计窗口。

```sh
cmake -S . -B build-normal -DBUILD_TESTING=ON -DUPDATE_COST_SANITIZERS=OFF
cmake --build build-normal --parallel 2
ctest --test-dir build-normal --output-on-failure
cmake --build build-normal --target format-check

cmake -S . -B build-sanitize -DBUILD_TESTING=ON -DUPDATE_COST_SANITIZERS=ON
cmake --build build-sanitize --parallel 2
ctest --test-dir build-sanitize --output-on-failure

cmake -S audit -B build-audit -DBUILD_TESTING=ON
cmake --build build-audit --parallel 2
ctest --test-dir build-audit --output-on-failure
cmake --build build-audit --target format-check
```

`format-check` 在可用的clang-format下提供，开发格式检查固定使用21版；没有该工具时普通构建仍可进行。CMake开发格式检查采用cmake-format 0.6.13及随包规则。原 C 副本没有格式化重写。

本次在macOS/ARM、Apple Clang 21上，普通软件检查3/3、ASan/UBSan检查3/3、独立审计1/1及格式检查通过。独立审计的检查包装经两次离线补验各1/1；它为每次核验选择新的 JSON 路径，拒绝覆盖，首轮核验输出保持，新输出逐字相同。该补验没有重新执行正式观察器。普通和动态失败检查也在同一构建目录分别补验1/1，原失败状态文件保持，新普通失败记录仍为零统计窗口，动态检查没有创建输出目录。日志中的CTest时长只描述软件检查，不能替代算法或整进程成本。

`checks/independent-audit.json` 是本次导出审计构建读取原记录生成的核验输出。`checks/build-views/` 含编译命令、链接命令、源码清单和日志的匿名路径视图；原本机绝对路径以 `PACKAGE_ROOT`、`SOFTWARE_BUILD_ROOT` 等别名替换。视图不是原命令字节，也不直接宣称为可执行命令；实用构建入口以上述CMake命令为准。原始本地日志和实际构建目录由项目组另存，构建目录本身不作为实验原始证据。

## 独立复现的范围

本轮固定预算只允许一次正式运行，该次原记录完整保留，本件没有为好结果重跑。软件可以在独立环境重新构建，但若要重新观察成本，须建立新的运行身份、资源检查、预算、完整原值记录、输入与产物摘要及产物审查，形成另一次实验。新结果不得回填为本轮原确认，也不得只因重建成功继承原成本比。

数学观察器和独立核验器不链接或调用ML-KEM、缺陷变体、秘密输入、密码散列实现或网络服务。CMake的软件失败检查使用其自带文件摘要能力来检验不覆盖状态，这不构成密码实验。构建链接与符号视图支持本件的软件范围核对。

本件不关闭R02/R04，不证明真实总体误报率、检出率、交换性、平稳性或恒时安全，不作Linux实测替代，也不补人员签署或平台回执。

## 授权状态

仓库未发现自有数学源码的专门开源许可，本复核副本未添加授权声明；对外许可由所有者另行决定。本件是向仓库所有者交付的自有工程复核副本，不含vendor，也未借用第三方许可证。

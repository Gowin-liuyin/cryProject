build/sanitizer/audit check

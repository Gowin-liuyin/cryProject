cmp runner-01-work/native/model/raw.csv docs/evidence/finite-calibration-20261007/model/raw.csv

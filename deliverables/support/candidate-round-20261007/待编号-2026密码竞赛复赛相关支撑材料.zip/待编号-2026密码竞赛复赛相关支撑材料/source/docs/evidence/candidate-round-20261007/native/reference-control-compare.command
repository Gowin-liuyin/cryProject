cmp runner-01-work/native/reference-control/raw.csv docs/evidence/reference-label-control-20261007/qualified/control/raw.csv

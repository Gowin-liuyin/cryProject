build/release/audit check

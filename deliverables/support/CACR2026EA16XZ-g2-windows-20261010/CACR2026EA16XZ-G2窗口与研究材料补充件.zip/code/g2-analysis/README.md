# G2-A：已封存普通参考窗口的离线科学复算

本目录只分发原字节C11分析源与CMake配置，不包含采集worker、管理员、SSH或恢复程序，也不附可执行二进制。它只读取包内已经取得的JSONL；构建、CTest及以下复算不会访问硬件计数器、生成密钥或启动新的密码负载。原始normal的126528次调用来自已封存G2；中断stdout为空保持部分或未知，不能解释为零操作。

G2-A既有软件验证覆盖macOS/ARM和Linux/x86_64，以下离线构建及复算说明限于这两类环境；需要CMake3.21以上和GCC／Clang，分析源不需要第三方库。这是普通软件复算，动态检查须另建构建目录，不构成新的硬件采集或测时证据。

云端使用时，压缩包、解压目录、构建、临时文件、缓存与复算输出都必须实际位于已获授权的PRIVATE_PROJECT_ROOT子树内；不得通过符号链接让真实落盘路径越界。PRIVATE_PROJECT_ROOT是中性名称，实际目录由已有授权确定。本机复算在新的本地工作树内进行。先进入相应的新解压包根目录，再执行下面的相对命令；`reproduction`必须尚不存在，避免覆盖原件或旧复算。

```sh
mkdir reproduction
mkdir reproduction/tmp reproduction/cache
export TMPDIR="$PWD/reproduction/tmp"
export TMP="$TMPDIR"
export TEMP="$TMPDIR"
export XDG_CACHE_HOME="$PWD/reproduction/cache"
export CCACHE_DIR="$PWD/reproduction/cache/ccache"
cmake -S code/g2-analysis -B reproduction/g2-analysis -DBUILD_TESTING=ON
cmake --build reproduction/g2-analysis --parallel 4
ctest --test-dir reproduction/g2-analysis --output-on-failure
mkdir reproduction/g2-output
reproduction/g2-analysis/analyze_windows data/g2/normal.stdout.jsonl > reproduction/g2-output/normal-windows.csv 2> reproduction/g2-output/normal-summary.json
cmp data/g2/normal-windows.csv reproduction/g2-output/normal-windows.csv
cmp data/g2/normal-summary.json reproduction/g2-output/normal-summary.json
reproduction/g2-analysis/analyze_windows data/g2/parent-loss.stdout.jsonl > reproduction/g2-output/parent-loss-windows.csv 2> reproduction/g2-output/parent-loss-summary.json
```

最后一条命令预期退出1，CSV预期0字节，摘要应为missing_summary_or_count_mismatch和engineering_diagnostic=no；这是已保存的缺数据结果，不能当作复算失败后重跑采集的理由。分别与data/g2下同名两文件逐字比较。正常命令退出0，stdout为CSV、stderr为JSON摘要；不要把stderr摘要当作可删除日志。

正式判据、单进程依赖、时钟／物理标尺条件、完整长尾和覆盖缺口见[完整科学合同](../../research/g2/EXPERIMENT_PLAN.html)与[全量核对](../../research/g2/SCIENTIFIC_REVIEW.html)。所有false认证字段及R02/R04部分状态保持；可重算工程输出不证明真实统计前提或恒时。图按这两份固定正常C输出绘制，PNG/PDF与图注在本包，绘图源另存作者归档。

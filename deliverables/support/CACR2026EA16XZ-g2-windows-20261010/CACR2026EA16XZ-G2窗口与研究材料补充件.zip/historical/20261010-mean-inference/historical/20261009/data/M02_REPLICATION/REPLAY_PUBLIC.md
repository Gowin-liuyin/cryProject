# 分发件中的已有M02账本只读核验

本页使用原56ad数学源码ZIP和本包M02专用C汇总快照；只编译工具、审计已有行和生成新JSON，不启动正式观察器。新产物不继承bc61计时资格。原独立C账本审计器要求所审原记录为Darwin/arm64，不能据此签收Linux测量。

在解压本包的根目录执行，使用一个新的工作目录。先逐项核对根SHA256SUMS和内嵌源码包固定摘要56ad7ece879df934c5be8b740729058063ae214f23081afb04ed1540102fcc24；任一不符停止，不给替换文件重新生成期待摘要。命令使用CMake/CTest来源，输出路径必须不存在。

```sh
set -eu
package_root=$(pwd -P)
shasum -a 256 -c SHA256SUMS
archive_path="$package_root/software/CACR2026EA16XZ-数学源码与账本复核件.zip"
actual_archive_digest=$(shasum -a 256 "$archive_path")
actual_archive_digest=${actual_archive_digest%% *}
test "$actual_archive_digest" = 56ad7ece879df934c5be8b740729058063ae214f23081afb04ed1540102fcc24
replay_root=$(mktemp -d "${TMPDIR:-/tmp}/m02-readonly.XXXXXX")
mkdir "$replay_root/source" "$replay_root/views" "$replay_root/outputs"
unzip -q "$archive_path" -d "$replay_root/source"
(cd "$replay_root/source" && shasum -a 256 -c SHA256SUMS)
cmake -S "$replay_root/source/audit" -B "$replay_root/audit" -DBUILD_TESTING=OFF
cmake --build "$replay_root/audit" --parallel 2
cmake -S "$package_root/data/M02_REPLICATION/preparation/summary-source" -B "$replay_root/summary" -DBUILD_TESTING=OFF -DSUMMARY_SANITIZERS=OFF
cmake --build "$replay_root/summary" --parallel 2
for process_number in 1 2 3; do
    mkdir "$replay_root/views/process-$process_number"
    ln -s "$package_root/data/M02_REPLICATION/run-$process_number" "$replay_root/views/process-$process_number/run"
    "$replay_root/audit/update_cost_result_review" "$replay_root/views/process-$process_number" "$package_root/data/M02_REPLICATION/preparation/fixed-inputs" "$replay_root/outputs/process-$process_number.json"
done
"$replay_root/summary/process_summary" "$package_root/data/M02_REPLICATION" "$replay_root/outputs/process-summary.json"
```

数值、meta、pending、输入副本和既有C审计JSON原字节保持。input-records.tsv是路径视图，原C审计器不读取该定位TSV；固定输入与run副本按实际字节核对。此只读步骤不独立枚举全部状态，不证明匿名路径视图原始运行身份，也不产生新成本样本。真正运行身份由执行UTC/PID、退出码、前后摘要和机器码审查原证据支持。

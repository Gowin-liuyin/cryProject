# M3 解封装路径夹具与功能/定位计划

日期：2026-10-16。对象是公开标注的人工访存校准，不是上游漏洞。
本计划只允许构建、功能测试与秘密标记动态定位；不允许物理计时采样或调频。

1. 固定 `vendor/mlkem-native/PIN.md` 的上游库，只在各自构建 overlay 中对 `mlk_poly_frommsg`
   应用 `docs/patches/m3-mem-lut-toggle.patch`。开版将消息位作为两个跨缓存行的系数表索引，
   表值 `{0,1665}` 直接参与重加密；关版采用上游值屏障与常数时间选择。
2. 两版各自编成独立静态库、CLI 和 measure；计时入口不执行。
   完整路径为 `mlkem_decapsulate → baseline_native_dec → indcpa_dec → indcpa_enc → poly_frommsg`。
   不跳过重加密比较、隐式拒绝或密钥验证，不添加 sleep、空转、随机延迟或运行秘密输出。
3. 普通与 ASan/UBSan 各执行开/关独立 NIST KAT 与接口边界、随机源失败、64 公开种子
   ×5 类输入的完整公开测试转录逐字等价（含原始未修改参考版）；拒绝类另验证 `J(z||c)`。
4. 原生 Linux 新目录必须为 `[REMOTE_PROJECT]/platform-m3-20261016-<nonce>` 物理子树，
   源码、构建、临时、缓存、日志和结果均在该树内。最多并行编译 4 任务。
5. 动态探针只用公开确定性种子，在完整解封装前 poison 私钥的秘密多项式与拒绝种子，
   嵌入公钥与公开 hash 保持 defined；完整解封装后恢复标记再消费返回状态。
   标准 Memcheck 开版应报秘密地址、关版应不报；普通不带 poison 入口也检查内存错误。
6. 本次探测 Pin/Microwalk/.NET 与 Docker。若缺 Pin 或 Docker 存储不能证明全在 Cry，
   按平台计划降级为 Memcheck 秘密地址定位；不能把 clone 或命令存在当作运行结果。

统计采集另见 `STATISTICAL_PLAN.md`，必须由主控提交并冻结后独占 CPU2/CPU6 调度，
本路不采数、不写频率控制、不关闭共享 SSH socket、不 stage/commit/push。

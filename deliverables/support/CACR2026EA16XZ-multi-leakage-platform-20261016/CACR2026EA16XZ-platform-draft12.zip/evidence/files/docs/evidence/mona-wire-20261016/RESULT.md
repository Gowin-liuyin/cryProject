# Mona 实接入结果（2026-10-16）

软件接入已完成，实际执行了固定上游统计类。macOS/ARM 与真实 Linux/x86_64 的
构建及 CTest 各 1/1 通过；合成阴性、阳性分别得到无分离、有验证分离，S5 长表
与宽表输出一致，非法 CSV 和覆盖旧输出目录均被拒绝。本路没有采集新硬件时间。

## 既有 M1 数据真实离线回放

六份输入各含 10000 值/类，已与各自 `samples.csv` 中 message-zero/ones 逐值、
按原类内顺序独立核对。没有裁剪、抽样、修正、重标类或调参。

| M1 输入 | 上游验证成功记录 | 失败记录 | 结论 |
|---|---:|---:|---|
| 主数据 vulnerable | 0 | 9 | 无通过验证的箱体分离 |
| 主数据 fixed | 1 | 8 | 有箱体分离，仅剩一个验证子集 |
| seed-424242 vulnerable | 0 | 9 | 无通过验证的箱体分离 |
| seed-424242 fixed | 1 | 1 | 有箱体分离，仅剩一个验证子集 |
| CPU6 vulnerable | 0 | 9 | 无通过验证的箱体分离 |
| CPU6 fixed | 0 | 0 | 未找到最优箱体 |

这是上游 Mona 算法的真实对照，未与既有 M1 检测方向一致。两项 fixed 成功均发生
在迭代扩展子集后只剩一个子集的末轮：主数据 `X<Y` 的 10%–11% 箱体、5120 值；
seed-424242 的 31%–32% 箱体、10000 值。相邻同类子集重叠条件此时没有后续子集可比。
该实现从数据自适应寻找箱体并扩展子集，因此不能把成功记录解释成受控误报率或
上游修复失效；也不能用 vulnerable 无分离推翻既有 M1 统计。这里是工具规则的
独立补充观察，未替换 CI/Welch、Holm、RTLF 或 dudect。

Linux 完整摘要见 `native-qualification/run/m1/m1-mona.csv`；每项保存原始
`box-results.csv`、逐项 `mona-validations.csv`、Mona 日志、输入与源码/字节码摘要。
六份原始输入及 JSON/CSV/Markdown 摘要、逐项验证输出均与本地离线运行逐字一致。

## 定位、统计与边界

**定位：** 本路调用 `StatisticEvaluation.calibrationPhase`、`BoxTest`、
`BoxTestResults`；它是统计对照，不产生新的二进制泄漏定位证据。

**统计：** 完整运行上游自适应箱体搜索、最小子集搜索和批次验证；输出原名
`Confidence Interval` 的字段为批次成功百分比，不是覆盖 CI 或 p 值，不入 Holm。
接口输出 `holm_member=false`、`p_value=null`、`alpha=null`。

**边界：** 无密钥恢复、网络攻击或新硬件采数；无分离不证明恒时。Linux 实测
这里指离线软件构建及数据回放，不是重新测量密码算法或新增独立实验环境。
M2 尚无本路真实对照行，待主控提供已冻结合同下的新数据。

## Linux 原件与准备失败

成功原件根为 `[REMOTE_PROJECT]/platform-mona-20261016-1de26030f145`，
使用主控已核验的共享 SSH，以 `taskset -c 0,1` 启动整个离线构建、校准及回放。
系统 Java 21.0.12.1 已含 `jdk.compiler` 模块但缺 `javac` 命令，因此只在自有
`run/tools/` 建立 Java 编译器启动器，没有安装系统包或下载 JDK。

前三次准备失败原件分别保留于同一 Cry 下的 `platform-mona-20261016-9739782d8827`、
`platform-mona-20261016-91cff524d9c0`、`platform-mona-20261016-8a79566b085d`：
依次为 FindJava 要求未使用的 jar/javadoc、运行时缺跨版本 ct.sym、模块启动器不展开
classpath 通配符。最终自有 CMake 仅要求实际使用的工具、使用 source/target 11 和
显式三个 JAR；上游源码未修改。失败日志可读副本在 `failed-preparation/`。

四树完整原包在成功根的 `originals.tar.gz`，SHA-256 为
`387bbfd7d477ef960d1ca7fdbad77554cffd4549c365c6cc784d87096989ee0e`。
拉回后核对 1317 份清单内原件及四树清单，压缩包没有符号链接；校验记录见
`archive-verification.json`。因原包含许可未明确的上游源码/JAR，本地保存在被本目录
`.gitignore` 排除的 `private-originals/`；可提交日志、输入、摘要按原字节选出。
Java 子进程结束核对为空，未关闭主控共享 SSH，未调频或占用 CPU2/6。

## 复现与交接

本地实际命令：

```sh
cmake -S scripts/platform_mona -B build/platform-mona-local-20261016 -DBUILD_TESTING=ON
cmake --build build/platform-mona-local-20261016 --target platform_mona
ctest --test-dir build/platform-mona-local-20261016 --output-on-failure
sh scripts/platform_mona/run_m1.sh [REPOSITORY] \
  [REPOSITORY]/build/platform-mona-local-20261016/platform-mona/classes \
  [REPOSITORY]/docs/evidence/mona-wire-20261016/local-qualification/m1
```

远端复现源码必须保留 `scripts/platform_mona/`、`cmake/PlatformMona.cmake`、
固定上游完整源码和依赖以及上述六份 M1 CSV 的原路径。在新的
`Cry/platform-mona-20261016-<nonce>/source` 调用：

```sh
sh <source>/scripts/platform_mona/run_native.sh <source> <assigned-root>/run
```

它核对物理路径，将 Java 临时和缓存全部限定在自有根内，禁用 JVM perf 临时文件，
以 CPU0/1 运行离线校准与回放；不占 CPU2/6，不调频，不安装系统依赖。默认 JDK
及其 compiler 模块均不存在时须在同根准备固定 JDK，不能绕过路径约束。

尚未 stage、commit 或 push。根 CMake 入口及 S5 脚本由各自所有者合并，本路未修改。

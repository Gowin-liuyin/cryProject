# 多泄漏模块检测平台补充报告

统一检测、定位、修复与复测的证据分层

日期：2026-10-16

摘要：真实历史路径与人工校准分列；软件、定位、统计和验收分层。当前新增模块统计仍按实际状态列示，未运行不写成未检出。


## 1 研究对象与证据口径

平台将编译器引入分支、秘密操作数除法、秘密访存地址和提前退出比较分开处理，并以固定参考实现作为阴性候选。统一接口的目的，是让不同机制接受相同的来源记录、调用窗口、数据格式与结果审查，而不是用模块数量代替安全结论。

M1 与 M2 来源于固定历史真实实现。M3 与 M4 为人工构造校准：前者对秘密下标查表，后者保留提前退出。人工夹具的阳性只能检验工具是否能识别目标机制，不能计为新发现漏洞。M5 是阴性候选；有限标记调用无报警与时间统计须分别记录，不能自动写成全套工具不误报。

本报告把软件资格、源与产物机制、工具定位、原始时间观察、正式统计和竞赛验收分列。未运行用 not_run 表示；没有报警或有限预算内未检出不等于恒时证明。完整完成条件以 E01 为准，原 M1 范围保持封存身份。 [E01,E02,E10]


## 2 平台架构与机制矩阵

共享层记录公开输入、源与二进制身份、全调用测量窗口、类别乱序、逐次原值、环境和恢复。统计层输出均值差及区间、参数检验族、RTLF 与 dudect 的独立结果；动态层使用秘密标记、可变时指令检查和反汇编；有界验证层单独记录秘密模型、入口、边界和探索完成性。

各层证据不可互相替代。静态存在 div 不自动说明处理器已出现可测时差，工具报警次数不是采样量，功能测试通过也不表示统计阴性。图中灰格是封存引用，蓝格是已执行的当前层次，浅棕格是未运行或待完成；状态同时以文字显示。 [E03-E08,E10]

平台证据矩阵（原仓库引用：platform-matrix.svg）


## 3 统一测量与统计方法

普通计时应覆盖声明的完整调用；输入生成、分配、日志、结果消费和 I/O 位于窗口外。热点微基准和独立夹具必须另标调用边界，不与完整解封装混合。普通长尾保留；动态检查与正式采集使用不同产物。源、未提交改动摘要、编译器、选项、ISA、时钟单位、种子、CPU 与二进制摘要共同限定结果。

正式采数之前须冻结并提交 PLAN，写明主类对、样本预算、停止条件、复测和参数假设族。锁频任务由主控在 CPU2/CPU6 串行调度；boost 关闭，performance，约 4.30 GHz，并保存进入、采中与退出记录。请求频率、可见回读及真实物理恒频是不同声明；退出恢复必须实际核对 restore_match。

现有 C 电池使用两组样本均值、样本方差与 Welch t 和自由度。95% 区间及 p 值采用大样本正态近似，不能称有限样本精确 Student-t 结果。零方差、数据不足、缺工具或失败均单列状态。参数 p 按事前家族做 Holm；RTLF 固定 alpha=0.01；dudect 最大 t、RTLF 二值结果与 Mona 结果不伪造为 p 纳入 Holm。

CSV 离线调用上游 dudect 统计内核与在线 rdtsc 采集不同。Mona 自适应寻找箱体，其批次成功百分比也不是覆盖置信区间或 p。软件的合成正负校准不能填充密码实现的统计结果。 [E01,E08,E09]


## 4 M1 既有真实案例与 Mona 对照

既有 M1 针对固定 liboqs 0.10.0、Clang 18 与便携 C 路径，保留原源码、产物分支、工具、逐次数据和官方修复复测证据。本报告仅引用 E02 的限定结论，不修改旧 CSV、旧家族或原报告。

原 E02 表中主类对三次未修均值差为 +39.337、+31.117、+22.337 ns；对应已修为 -13.209、+8.354、-4.885 ns。这里的数字是封存引用，不是报告生成时的新采集；区间、预算、环境和原族以原件为准。

新增 Mona 对既有六份类对真实离线回放并未与既有检测方向一致：三份 vulnerable 均无通过验证的箱体分离；primary 与 seed-424242 的 fixed 各有一个成功记录，CPU6 fixed 未找到最优箱体。两项成功都出现在扩展后只剩一个验证子集的末轮，不能解释为受控总体误报率或上游修复失效。

Mona 是独立补充观察，不替换 CI/Welch、Holm、RTLF 或 dudect。其规则造成的差异完整保留；不调参追求方向一致。当前新执行环境、输入摘要与全部验证记录见 E09。 [E02,E09]


## 5 M2 KyberSlash：检测与定位

历史 Kyber768 完整 keygen/encap/decap 已接通；macOS/ARM 与 x86_64 Linux 普通及 ASan/UBSan 均各 7/7，两版各 100 例官方 round3 KAT 全字段匹配。新生产 ELF 的三热点 div 差异仍在；旧 varlat 1280/3 对 0/0 只按旧热点 ELF 引用。时序未运行。

未修固定为 a621b8dde405cc507cbcfc5f794570a4f98d69cc，完整已修固定为 272125f6acc8e8b6850fd68ceb901a660ff48196；均以完整提交而非 exact tag 钉版。中间 dda29cc 只修 KyberSlash1，不能当作完整修复。对象是历史 Kyber768，不能冒称 FIPS 203 ML-KEM-768。

定位实际在 x86_64 Linux、Clang 18.1.3、-Oz 且关闭向量化的固定产物中执行。poly_tomsg、poly_compress、polyvec_compress 的秘密相关操作数数据流与各自一条 div 对应。varlat 默认上下文 PC 落在系数 load，不能直接把该 PC 当成静态 div 地址；归因来自同 ELF 数据流、源码、反汇编及 varlat 开关对照。

初始公开人工定位输入直接调用未修改上游热点，不是完整 KEM 或物理时延实验。新增完整 KEM 的适用独立 KAT、边界与原生产物资格见 E13；完整调用软件合同 E12 与实际结果分开。新生产 ELF 未重跑旧 varlat 探针，旧定位不倒写成新产物动态结果。后续若完整调用有限预算内未检出，应保留该结果，并按已冻结合同分层解释热点微基准。 [E03,E04,E12,E13]


## 6 M3 与 M4：人工机制校准

人工 LUT 已挂载到真实完整 ML-KEM 解封装重加密路径；本机与 Linux 普通及 ASan/UBSan 均各 6/6，64 公开种子乘 5 类的完整字节等价通过。新 Linux 秘密标记 on 为 1280 errors / 2 contexts，off 与两 defined 对照均 0/0。Microwalk 记证据化降级；时序未运行。

M3 初始独立夹具的 32/1 对 0/0 只按原产物引用。新增完整解封装挂载以同一消息位生成真实重加密系数，on 秘密索引 load 与 off 公开等价读取保留同样密码输出及隐式拒绝。每代产物分别绑定资格和定位，不能把新 1280/2 与旧 32/1 混作一次运行；人工性质不变，未构成新 CVE。

独立 32 字节 checked compare 保留提前退出/全长度归约两版及软件资格。旧 Linux Memcheck 为 32 errors / 1 context 对 0/0。新增 Binsec 0.11.3 与 Z3 4.15.3 对固定 i386 -O1、公开长度 1-16 的抽取内核完整探索：vulnerable 为 insecure，ct 为有界 secure；halt 为 32/32 与 16/16，pending/cut/discontinued/solver unknown 均为零。时序仍未运行。

M4 两版本只返回相等性，不提供标准 memcmp 的正负排序语义。封装先检查长度与空指针，真实短数组不传给内核；每变体以标准库 memcmp(...)==0 为 oracle，枚举长度、差异位置及替换字节。poison 只包住秘密输入到目标调用，结果消费前取消标记，避免把允许的返回值公开误记为内核分支。

新增 Binsec 只验证固定 i386 -O1 抽取内核。入口 m4_entry、终点 m4_halt；秘密数组 16 字节，候选数组和长度公开，长度 1-16、具体栈指针。在消费允许公开的比较结果之前停止；两版所有路径均到达 halt，工作队列为空，未超时、截断或出现 solver unknown。反例 PC 0x8049047 对应 compare_early.c:9。有界 secure 不外推到 32 字节普通采集 ELF、任意长度、完整 KEM、其他编译条件或物理恒时。 [E05,E06,E14,E16]


## 7 M5：参考实现阴性候选

完整 mlkem-native 参考的原生普通/ASan+UBSan 资格通过；明确标记秘密 PKE 区及拒绝种子 z，保持公钥/hash/密文公开。v2 普通 ELF 在系统 Memcheck 与 patched varlat=no/yes 均各 10 次完整标记调用、0 errors / 0 contexts。在线 dudect 入口已准备但未计时，正式时序仍未运行。

固定 mlkem-native 提交为 b3ba7b32773e657dd37f6f87bce82528459ad8a4；完整库及许可证共 126 文件复核一致。实际调用链为 reference_measure 到 mlkem_decapsulate，再到 baseline_native_dec；普通测量链接 reference/libmlkem.a，未混入历史 liboqs 或人工补丁变体。

普通与 ASan/UBSan 各 5/5 的本机资格使用独立 NIST ACVP 固定向量，覆盖密钥生成、封装、解封装及边界，并保留隐式拒绝。系统随机源往返和失败处理另有记录；没有用自产预期答案证明自身正确。

本机 ARM 软件资格与新增 Linux 原生定位分别留证。有限秘密标记与 varlat 的 10 次调用无报警只能支持当前标记范围；后续还须在冻结类对、预算、频率控制和复测条件下运行统计。无报警与预算内未检出均不推广到任意秘密、任意输入或物理恒时。 [E07,E15]


## 8 修复与复测的判定链

真实历史案例优先使用上游官方修复，并保存未修/已修完整身份、许可证和构建条件；人工校准使用明确标注的目标机制开关。修复前后首先核对功能等价与拒绝语义，然后检查实际调用和产物，再做同模型工具复测，最后比较同类输入的时间统计。

M2 的完整已修热点已显示目标 div 消失及 varlat 对应报警消失，这是定位层修复复测；没有时间原值时不能补写统计防护有效。M3/M4 关闭目标机制后的单次无报警也是有限工具对照，不能推广到全实现。M5 的参考资格不是阴性验收。

版本间总运行成本不同不是秘密泄漏证据。正式时序比较应先在每个变体内部比较相同的两类输入，再解释修复前后效应及独立复测；若方向反转、残差或工具不一致出现，完整保留，并按产物/输入/环境分层调查。任何工具失败都不能自动归入安全阴性。 [E01,E03-E09]


## 9 可复算材料、离线展示与匿名副本

每项结论链接到带状态的证据来源；生成时记录来源相对路径、字节长度和 SHA-256。报告源、矩阵、离线 HTML 与支撑包由同一显式状态数据生成。状态的更新必须对应新的实际 RESULT，不能从计划、工具安装或另一个模块自动继承完成。

匿名包采用显式白名单：报告、有限证据副本、允许再分发的依赖、独立 CMake 与 C 离线复算入口。数值 CSV 保持原字节；含个人路径/主机信息的文本只在新副本中转换，并记录原件与副本两套摘要。旧证据原件不改写；不打包密钥、凭证、缓存、构建 ELF 或许可不明确的工具源码。

实包校验应覆盖唯一成员、相对路径与无符号链接、逐成员摘要、直接身份字串、报告元数据和本地引用。只从真实 ZIP 提取后构建并执行包内 CTest，验证离线复算结果与输入保持。离线复算只重算已有数据，不算新硬件实验；外部 RTLF、Mona、dudect 或 Binsec 缺依赖时仍明示未重跑。

本报告及新展示是多机制平台的补充载体，不替换旧官方报告，不宣称全部竞赛要求已验收。最终发布状态由本轮实际复算、视觉核验与主控汇总决定。 [E01,E08,E11]


## 10 当前局限与后续验收

完整 KEM、人工挂载及 M4 小函数有界验证均已有对应证据；各新模块的正式时序、在线 dudect 与复测仍待主控冻结合同后执行。M2 新时间数据的 Mona 对照和锁频控制器修复后的实际空任务恢复资格仍须按实际结果核对。

正式统计完成并不要求每个历史实现都在当前 x86_64 上出现阳性。若完整调用不可区分，应报告预算、区间和工具状态，保留定位与微基准的分层结果。若阴性候选出现阳性，应调查噪声、样本结构和产物机制，不能为了满足预期删除普通长尾或改类。

本项目不做密钥恢复、不交付 exploit，不把历史 Kyber 等同于最终标准 ML-KEM。物理精度、逐调用恒频、所有输入下恒时和总体误报率均须单独证据；本报告没有增加这些主张。后续以 E01 的逐项条件核对，而不是以文稿、图表或模块数量替代实验完成。 [E01]


## 证据来源索引

- [E01] 完整完成条件；requirements_only；docs/platform/COMPLETION_REQUIREMENTS.md

- [E02] M1 既有封存结论；frozen_reference；docs/evidence/r02-r04-close-20261016/RESULT.md

- [E03] M2 定位结果；localization_only；docs/evidence/m2-kyberslash-20261016/RESULT.md

- [E04] M2 版本审计；pinned_history；docs/evidence/m2-kyberslash-20261016/VERSION_AUDIT.md

- [E05] M3 独立校准夹具；localization_only；docs/evidence/m3-memaccess-20261016/RESULT.md

- [E06] M4 独立校准夹具；localization_only；docs/evidence/m4-compare-20261016/RESULT.md

- [E07] M5 前置接线；software_only；docs/evidence/m5-mlkem-native-20261016/RESULT.md

- [E08] 统计电池协议；software_contract；scripts/platform_stats/README.md

- [E09] Mona 实际对照；offline_replay_only；docs/evidence/mona-wire-20261016/RESULT.md

- [E10] 架构与证据边界；architecture；docs/platform/ARCHITECTURE.md

- [E11] 工具固定来源与许可；source_inventory；third_party/REPOS.md

- [E12] M2 完整调用软件合同；software_contract_only；docs/evidence/m2-kem-20261016/SOFTWARE_CONTRACT.md

- [E13] M2 完整历史 KEM 原生资格；native_functional_qualified_statistics_not_run；docs/evidence/m2-kem-20261016/RESULT.md

- [E14] M3 完整解封装人工 LUT；native_functional_and_localization_statistics_not_run；docs/evidence/m3-completion-20261016/RESULT.md

- [E15] M5 原生秘密标记与 varlat；native_limited_dynamic_negative_statistics_not_run；docs/evidence/m5-completion-20261016/RESULT.md

- [E16] M4 Binsec 实际有界验证；bounded_formal_complete_statistics_not_run；docs/evidence/m4-completion-20261016/RESULT.md

#!/bin/sh
set -eu
package_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
output_root=$1
if [ -e "$output_root" ]; then printf "%s\n" "New output directory required" >&2; exit 2; fi
mkdir -p "$output_root"
output_root=$(CDPATH= cd -- "$output_root" && pwd -P)
cmake -S "$package_root" -B "$output_root/build" -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build "$output_root/build" --parallel 2
ctest --test-dir "$output_root/build" --output-on-failure
mkdir "$output_root/m1-primary-vulnerable"
sed '1s/.*/class0_ns,class1_ns/' "$package_root/data/m1-primary-vulnerable.csv" > "$output_root/m1-primary-vulnerable/converted.csv"
"$output_root/build/platform_stats" "$output_root/m1-primary-vulnerable/converted.csv" wide class0_ns class1_ns "$output_root/m1-primary-vulnerable"
cmp "$package_root/expected/m1-primary-vulnerable/ci_welch.json" "$output_root/m1-primary-vulnerable/ci_welch.json"
cmp "$package_root/expected/m1-primary-vulnerable/normalized.csv" "$output_root/m1-primary-vulnerable/normalized.csv"
mkdir "$output_root/m1-primary-fixed"
sed '1s/.*/class0_ns,class1_ns/' "$package_root/data/m1-primary-fixed.csv" > "$output_root/m1-primary-fixed/converted.csv"
"$output_root/build/platform_stats" "$output_root/m1-primary-fixed/converted.csv" wide class0_ns class1_ns "$output_root/m1-primary-fixed"
cmp "$package_root/expected/m1-primary-fixed/ci_welch.json" "$output_root/m1-primary-fixed/ci_welch.json"
cmp "$package_root/expected/m1-primary-fixed/normalized.csv" "$output_root/m1-primary-fixed/normalized.csv"
mkdir "$output_root/m1-seed-424242-vulnerable"
sed '1s/.*/class0_ns,class1_ns/' "$package_root/data/m1-seed-424242-vulnerable.csv" > "$output_root/m1-seed-424242-vulnerable/converted.csv"
"$output_root/build/platform_stats" "$output_root/m1-seed-424242-vulnerable/converted.csv" wide class0_ns class1_ns "$output_root/m1-seed-424242-vulnerable"
cmp "$package_root/expected/m1-seed-424242-vulnerable/ci_welch.json" "$output_root/m1-seed-424242-vulnerable/ci_welch.json"
cmp "$package_root/expected/m1-seed-424242-vulnerable/normalized.csv" "$output_root/m1-seed-424242-vulnerable/normalized.csv"
mkdir "$output_root/m1-seed-424242-fixed"
sed '1s/.*/class0_ns,class1_ns/' "$package_root/data/m1-seed-424242-fixed.csv" > "$output_root/m1-seed-424242-fixed/converted.csv"
"$output_root/build/platform_stats" "$output_root/m1-seed-424242-fixed/converted.csv" wide class0_ns class1_ns "$output_root/m1-seed-424242-fixed"
cmp "$package_root/expected/m1-seed-424242-fixed/ci_welch.json" "$output_root/m1-seed-424242-fixed/ci_welch.json"
cmp "$package_root/expected/m1-seed-424242-fixed/normalized.csv" "$output_root/m1-seed-424242-fixed/normalized.csv"
mkdir "$output_root/m1-cpu-6-vulnerable"
sed '1s/.*/class0_ns,class1_ns/' "$package_root/data/m1-cpu-6-vulnerable.csv" > "$output_root/m1-cpu-6-vulnerable/converted.csv"
"$output_root/build/platform_stats" "$output_root/m1-cpu-6-vulnerable/converted.csv" wide class0_ns class1_ns "$output_root/m1-cpu-6-vulnerable"
cmp "$package_root/expected/m1-cpu-6-vulnerable/ci_welch.json" "$output_root/m1-cpu-6-vulnerable/ci_welch.json"
cmp "$package_root/expected/m1-cpu-6-vulnerable/normalized.csv" "$output_root/m1-cpu-6-vulnerable/normalized.csv"
mkdir "$output_root/m1-cpu-6-fixed"
sed '1s/.*/class0_ns,class1_ns/' "$package_root/data/m1-cpu-6-fixed.csv" > "$output_root/m1-cpu-6-fixed/converted.csv"
"$output_root/build/platform_stats" "$output_root/m1-cpu-6-fixed/converted.csv" wide class0_ns class1_ns "$output_root/m1-cpu-6-fixed"
cmp "$package_root/expected/m1-cpu-6-fixed/ci_welch.json" "$output_root/m1-cpu-6-fixed/ci_welch.json"
cmp "$package_root/expected/m1-cpu-6-fixed/normalized.csv" "$output_root/m1-cpu-6-fixed/normalized.csv"
printf "%s\n" "offline_replay=pass; hardware_collection=not_run; external_tools=not_reexecuted"

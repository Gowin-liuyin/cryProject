# 离线复算

运行 `sh reproduce.sh <不存在的新输出目录>`。只读取包内数据，构建现有 C11 统计工具并执行五项 CTest，再逐字比较 CI JSON 与归一化 CSV。原始数值 CSV 保持字节，M1 的派生宽表只在输出目录改表头以适配统计接口，不改数值。

打包时 C 输出作为确定性复算参照，只检验打包/重建一致；统计功能另由已有手算 oracle 与拒绝测试检查，不能拿自产期望证明算法正确。外部 RTLF、Mona、dudect、Binsec 未在本入口重执行；不采硬件时间、不改频率、不需要联网。ML-KEM 依赖仅为原 C 统计共用代码的链接依赖，本入口不运行密码采集。

需要 CMake>=3.21、C11 编译器、POSIX shell、awk、shasum、cmp、sed；报告重编译另需 XeLaTeX/ctex/Fandol。

cmp runner-01-work/work/results/model/raw.csv docs/evidence/finite-calibration-20261007/model/raw.csv

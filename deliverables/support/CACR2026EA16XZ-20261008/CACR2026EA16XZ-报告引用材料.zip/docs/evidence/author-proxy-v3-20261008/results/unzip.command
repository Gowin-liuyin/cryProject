python3 -c import zipfile,sys; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; z.extractall(sys.argv[2]) runner-01-work/待编号-2026密码竞赛复赛相关支撑材料.zip runner-01-work/work/unpacked

cmake --preset baseline

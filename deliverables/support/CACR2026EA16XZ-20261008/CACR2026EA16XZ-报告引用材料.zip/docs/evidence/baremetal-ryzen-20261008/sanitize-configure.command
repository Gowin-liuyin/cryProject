cmake --preset sanitize

/tmp/cryproject-r07.G6Vreo/work/build/analyze /tmp/cryproject-r07.G6Vreo/work/raw/reference-seed90210.csv /tmp/cryproject-r07.G6Vreo/work/raw/reference-seed90210.report

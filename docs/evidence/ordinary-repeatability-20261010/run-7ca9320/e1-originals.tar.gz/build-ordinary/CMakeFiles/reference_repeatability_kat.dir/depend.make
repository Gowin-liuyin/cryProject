# Empty dependencies file for reference_repeatability_kat.
# This may be replaced when dependencies are built.

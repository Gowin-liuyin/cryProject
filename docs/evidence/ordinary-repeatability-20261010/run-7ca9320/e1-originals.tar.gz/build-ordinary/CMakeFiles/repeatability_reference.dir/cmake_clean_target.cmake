file(REMOVE_RECURSE
  "librepeatability_reference.a"
)

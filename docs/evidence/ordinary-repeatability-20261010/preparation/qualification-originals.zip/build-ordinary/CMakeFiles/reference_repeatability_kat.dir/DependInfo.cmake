
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/yin/code/cryProject/src/inputs.c" "CMakeFiles/reference_repeatability_kat.dir/Users/yin/code/cryProject/src/inputs.c.o" "gcc" "CMakeFiles/reference_repeatability_kat.dir/Users/yin/code/cryProject/src/inputs.c.o.d"
  "/Users/yin/code/cryProject/tests/test_mlkem.c" "CMakeFiles/reference_repeatability_kat.dir/Users/yin/code/cryProject/tests/test_mlkem.c.o" "gcc" "CMakeFiles/reference_repeatability_kat.dir/Users/yin/code/cryProject/tests/test_mlkem.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

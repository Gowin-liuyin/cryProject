# CMake generated Testfile for 
# Source directory: /Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010
# Build directory: /Users/yin/code/cryProject/build/aris-ordinary-repeatability-20261010/qualification-initial/build-ordinary
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[reference_repeatability_selfcheck]=] "/Users/yin/code/cryProject/build/aris-ordinary-repeatability-20261010/qualification-initial/build-ordinary/reference_repeatability" "--selfcheck")
set_tests_properties([=[reference_repeatability_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;94;add_test;/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;0;")
add_test([=[reference_repeatability_analysis_selfcheck]=] "/Users/yin/code/cryProject/build/aris-ordinary-repeatability-20261010/qualification-initial/build-ordinary/analyze_reference_repeatability" "--selfcheck")
set_tests_properties([=[reference_repeatability_analysis_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;95;add_test;/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;0;")
add_test([=[reference_repeatability_fixture_check]=] "/Users/yin/code/cryProject/build/aris-ordinary-repeatability-20261010/qualification-initial/build-ordinary/reference_repeatability" "--fixture-check")
set_tests_properties([=[reference_repeatability_fixture_check]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;98;add_test;/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;0;")
add_test([=[reference_repeatability_nist_kat]=] "/Users/yin/code/cryProject/build/aris-ordinary-repeatability-20261010/qualification-initial/build-ordinary/reference_repeatability_kat" "/Users/yin/code/cryProject/tests/vectors/mlkem768.txt")
set_tests_properties([=[reference_repeatability_nist_kat]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;107;add_test;/Users/yin/code/cryProject/docs/research/aris-ordinary-repeatability-20261010/CMakeLists.txt;0;")

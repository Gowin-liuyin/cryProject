# Empty dependencies file for msr_counter_snapshot.
# This may be replaced when dependencies are built.

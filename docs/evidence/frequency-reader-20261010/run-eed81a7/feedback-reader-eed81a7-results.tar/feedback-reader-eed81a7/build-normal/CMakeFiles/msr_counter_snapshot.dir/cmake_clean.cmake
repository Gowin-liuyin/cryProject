file(REMOVE_RECURSE
  "CMakeFiles/msr_counter_snapshot.dir/msr_counter_snapshot.c.o"
  "CMakeFiles/msr_counter_snapshot.dir/msr_counter_snapshot.c.o.d"
  "msr_counter_snapshot"
  "msr_counter_snapshot.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/msr_counter_snapshot.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/feedback-reader-eed81a7/source/docs/research/aris-frequency-reader-20261010
# Build directory: /home/nss-marker/yhr/Cry/feedback-reader-eed81a7/build-sanitize
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[msr_counter_snapshot_selfcheck]=] "/home/nss-marker/yhr/Cry/feedback-reader-eed81a7/build-sanitize/msr_counter_snapshot" "--selfcheck")
set_tests_properties([=[msr_counter_snapshot_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/feedback-reader-eed81a7/source/docs/research/aris-frequency-reader-20261010/CMakeLists.txt;36;add_test;/home/nss-marker/yhr/Cry/feedback-reader-eed81a7/source/docs/research/aris-frequency-reader-20261010/CMakeLists.txt;0;")

file(REMOVE_RECURSE
  "CMakeFiles/frequency_reference.dir/home/nss-marker/yhr/Cry/window-source-c0e5990/source/src/kernel.c.o"
  "CMakeFiles/frequency_reference.dir/home/nss-marker/yhr/Cry/window-source-c0e5990/source/src/kernel.c.o.d"
  "CMakeFiles/frequency_reference.dir/home/nss-marker/yhr/Cry/window-source-c0e5990/source/src/mlkem.c.o"
  "CMakeFiles/frequency_reference.dir/home/nss-marker/yhr/Cry/window-source-c0e5990/source/src/mlkem.c.o.d"
  "CMakeFiles/frequency_reference.dir/home/nss-marker/yhr/Cry/window-source-c0e5990/source/src/random.c.o"
  "CMakeFiles/frequency_reference.dir/home/nss-marker/yhr/Cry/window-source-c0e5990/source/src/random.c.o.d"
  "libfrequency_reference.a"
  "libfrequency_reference.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/frequency_reference.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

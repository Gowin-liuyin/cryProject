# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/window-source-c0e5990/source/docs/research/aris-frequency-window-20261010
# Build directory: /home/nss-marker/yhr/Cry/window-source-c0e5990/build-sanitize
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[frequency_workload_selfcheck]=] "/home/nss-marker/yhr/Cry/window-source-c0e5990/build-sanitize/frequency_workload" "--selfcheck")
set_tests_properties([=[frequency_workload_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/window-source-c0e5990/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;60;add_test;/home/nss-marker/yhr/Cry/window-source-c0e5990/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;0;")
add_test([=[frequency_workload_process_safety]=] "/home/nss-marker/yhr/Cry/window-source-c0e5990/build-sanitize/frequency_workload" "--process-safety-check")
set_tests_properties([=[frequency_workload_process_safety]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/window-source-c0e5990/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;64;add_test;/home/nss-marker/yhr/Cry/window-source-c0e5990/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;0;")
add_test([=[frequency_reference_kat]=] "/home/nss-marker/yhr/Cry/window-source-c0e5990/build-sanitize/frequency_reference_kat" "/home/nss-marker/yhr/Cry/window-source-c0e5990/source/tests/vectors/mlkem768.txt")
set_tests_properties([=[frequency_reference_kat]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/window-source-c0e5990/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;74;add_test;/home/nss-marker/yhr/Cry/window-source-c0e5990/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;0;")

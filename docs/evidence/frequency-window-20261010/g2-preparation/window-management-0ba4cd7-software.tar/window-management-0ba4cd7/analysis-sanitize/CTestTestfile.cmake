# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/window-management-0ba4cd7/source/docs/research/aris-frequency-window-analysis-20261010
# Build directory: /home/nss-marker/yhr/Cry/window-management-0ba4cd7/analysis-sanitize
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[frequency_analysis_selfcheck]=] "/home/nss-marker/yhr/Cry/window-management-0ba4cd7/analysis-sanitize/analyze_windows" "--selfcheck")
set_tests_properties([=[frequency_analysis_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/window-management-0ba4cd7/source/docs/research/aris-frequency-window-analysis-20261010/CMakeLists.txt;41;add_test;/home/nss-marker/yhr/Cry/window-management-0ba4cd7/source/docs/research/aris-frequency-window-analysis-20261010/CMakeLists.txt;0;")

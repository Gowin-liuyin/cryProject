file(REMOVE_RECURSE
  "CMakeFiles/analyze_windows.dir/analyze_windows.c.o"
  "CMakeFiles/analyze_windows.dir/analyze_windows.c.o.d"
  "analyze_windows"
  "analyze_windows.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/analyze_windows.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

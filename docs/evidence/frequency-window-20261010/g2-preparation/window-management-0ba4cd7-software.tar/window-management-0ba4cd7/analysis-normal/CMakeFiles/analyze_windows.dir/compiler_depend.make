# Empty compiler generated dependencies file for analyze_windows.
# This may be replaced when dependencies are built.

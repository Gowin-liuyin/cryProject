file(REMOVE_RECURSE
  "libfrequency_reference.a"
)

# Empty compiler generated dependencies file for frequency_reference_kat.
# This may be replaced when dependencies are built.

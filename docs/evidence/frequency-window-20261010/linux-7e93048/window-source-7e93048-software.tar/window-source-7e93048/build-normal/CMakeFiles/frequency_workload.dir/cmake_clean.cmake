file(REMOVE_RECURSE
  "CMakeFiles/frequency_workload.dir/frequency_workload.c.o"
  "CMakeFiles/frequency_workload.dir/frequency_workload.c.o.d"
  "frequency_workload"
  "frequency_workload.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/frequency_workload.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

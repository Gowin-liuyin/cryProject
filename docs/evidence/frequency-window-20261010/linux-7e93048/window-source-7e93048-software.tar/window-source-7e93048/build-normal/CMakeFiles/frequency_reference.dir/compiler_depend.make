# Empty compiler generated dependencies file for frequency_reference.
# This may be replaced when dependencies are built.

# Empty compiler generated dependencies file for frequency_workload.
# This may be replaced when dependencies are built.

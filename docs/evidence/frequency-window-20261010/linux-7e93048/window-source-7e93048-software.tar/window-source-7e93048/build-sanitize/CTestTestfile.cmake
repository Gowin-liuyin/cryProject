# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/window-source-7e93048/source/docs/research/aris-frequency-window-20261010
# Build directory: /home/nss-marker/yhr/Cry/window-source-7e93048/build-sanitize
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[frequency_workload_selfcheck]=] "/home/nss-marker/yhr/Cry/window-source-7e93048/build-sanitize/frequency_workload" "--selfcheck")
set_tests_properties([=[frequency_workload_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/window-source-7e93048/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;50;add_test;/home/nss-marker/yhr/Cry/window-source-7e93048/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;0;")
add_test([=[frequency_reference_kat]=] "/home/nss-marker/yhr/Cry/window-source-7e93048/build-sanitize/frequency_reference_kat" "/home/nss-marker/yhr/Cry/window-source-7e93048/source/tests/vectors/mlkem768.txt")
set_tests_properties([=[frequency_reference_kat]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/window-source-7e93048/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;57;add_test;/home/nss-marker/yhr/Cry/window-source-7e93048/source/docs/research/aris-frequency-window-20261010/CMakeLists.txt;0;")

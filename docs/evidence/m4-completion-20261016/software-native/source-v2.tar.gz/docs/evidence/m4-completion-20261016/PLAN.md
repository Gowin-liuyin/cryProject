# M4 完成轮：非计时验证与软件准备计划

日期：2026-10-16。基础提交 `ac46e625c5c8e0db239f95b2464c9eaa6f55bf72`。本轮新目录独立于上轮已提交证据，旧比较夹具保持原字节。

本路允许实际执行 Binsec 有界验证、构建和无计时输入/参数自检；**不允许启动时间采样、在线 dudect 的测量模式或调频**。统计合同在 `STATISTICAL_PLAN_DRAFT.md`，主控须冻结具体提交、源/产物摘要及控制器合同后另行采集。

形式验证目标为既有 `compare_early.c` 与 `compare_ct.c` 的 `m4_compare_bytes`。新无 libc 的 32 位 Linux ELF harness 以 `m4_entry` 为入口，在 `m4_halt` 入口停止；避免依赖未安装的 multilib libc 和 x86_64 解码插件。秘密为 16 字节 `m4_secret_input`，公开为 16 字节 `m4_public_input` 和 `m4_public_length`，具体栈指针。第一合同是公开长度 1–16；若工具或路径预算不足，独立执行固定长度 16 的备用合同，结果不互相替代。

Binsec 使用实际固定版本和求解器，记录源码提交、下载摘要、版本、license、入口、配置脚本、ELF/反汇编和完整输出。每份合同用 `-sse -checkct -sse-depth 10000 -sse-timeout 120 -smt-timeout 5`，每次保留新的输出目录。记录到达 halt 数、pending、深度截断、solver unknown/timeout；只有无泄漏且完整探索才允许写该模型内 secure。找到泄漏可以写 insecure，即便另有探索缺口也必须保留。

预期提前退出存在秘密控制流、归约版本在小边界通过，均为待检假设。结果不构成任意长度、完整 KEM 或物理时间恒定证明；不存在密钥恢复或 exploit。

所有远端项目文件、依赖源码、工具、日志、缓存、OPAMROOT、本地 switch、临时及恢复快照只存于真实物理根 `/home/nss-marker/yhr/Cry/platform-m4-20261016-6hRHRUxH`。不改 HOME，不安装系统包，不用默认 Docker 层，不关闭共享 SSH；构建/验证仅用 CPU0/1、最多 j4。CPU2/CPU6 的锁频采数只由主控串行安排。旧 M1 vendor、所有已提交证据和 `sources/` 只读。

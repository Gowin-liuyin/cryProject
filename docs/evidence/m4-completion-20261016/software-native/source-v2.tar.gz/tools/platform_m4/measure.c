#define _POSIX_C_SOURCE 200809L

#include "compare.h"
#include "inputs.h"

#include <inttypes.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#if defined(__linux__)
#define M4_CLOCK_ID CLOCK_MONOTONIC_RAW
#define M4_CLOCK_NAME "CLOCK_MONOTONIC_RAW"
#else
#define M4_CLOCK_ID CLOCK_MONOTONIC
#define M4_CLOCK_NAME "CLOCK_MONOTONIC"
#endif

static volatile unsigned observed_result;

static int read_nanoseconds(uint64_t *timestamp_nanoseconds)
{
    struct timespec timestamp;
    if (clock_gettime(M4_CLOCK_ID, &timestamp) != 0 || timestamp.tv_sec < 0 ||
        timestamp.tv_nsec < 0 || timestamp.tv_nsec >= 1000000000L ||
        (uint64_t)timestamp.tv_sec >
            (UINT64_MAX - (uint64_t)timestamp.tv_nsec) / UINT64_C(1000000000)) {
        return 1;
    }
    *timestamp_nanoseconds =
        (uint64_t)timestamp.tv_sec * UINT64_C(1000000000) + (uint64_t)timestamp.tv_nsec;
    return 0;
}

static int has_valid_run_id(const char *run_id)
{
    size_t run_id_bytes = strlen(run_id);
    if (run_id_bytes == 0U || run_id_bytes > 63U) {
        return 0;
    }
    for (size_t character_index = 0U; character_index < run_id_bytes; character_index++) {
        char character = run_id[character_index];
        if (!((character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z') ||
                (character >= '0' && character <= '9') || character == '-' || character == '_')) {
            return 0;
        }
    }
    return 1;
}

int main(int argument_count, char **argument_values)
{
    if (argument_count == 2 && strcmp(argument_values[1], "--describe") == 0) {
        puts("module=M4 case=artificial_compare boundary=complete_checked_compare bytes=32 "
             "classes=mismatch-first,mismatch-last timing_collection=not_run");
        return 0;
    }
    uint64_t calls_per_class;
    uint64_t order_seed;
    if (argument_count != 6 || strcmp(argument_values[1], "--collect") != 0 ||
        m4_parse_unsigned(argument_values[3], 2U, 1000000U, &calls_per_class) != 0 ||
        m4_parse_unsigned(argument_values[4], 1U, UINT64_MAX, &order_seed) != 0 ||
        !has_valid_run_id(argument_values[5])) {
        fputs("usage: m4_measure --describe | --collect NEW.csv CALLS_PER_CLASS SEED RUN_ID\n",
            stderr);
        return 2;
    }
    size_t call_count = (size_t)calls_per_class * 2U;
    uint8_t *class_order = malloc(call_count);
    uint64_t *elapsed_nanoseconds = calloc(call_count, sizeof(*elapsed_nanoseconds));
    uint8_t secret_inputs[2][PLATFORM_M4_INPUT_BYTES];
    uint8_t candidate_inputs[2][PLATFORM_M4_INPUT_BYTES];
    uint64_t order_state = order_seed;
    if (class_order == NULL || elapsed_nanoseconds == NULL ||
        m4_prepare_class_order(class_order, call_count, &order_state) != 0 ||
        m4_prepare_case(0U, secret_inputs[0], candidate_inputs[0]) != 0 ||
        m4_prepare_case(1U, secret_inputs[1], candidate_inputs[1]) != 0) {
        free(class_order);
        free(elapsed_nanoseconds);
        return 1;
    }
    char metadata_path[4096];
    int path_bytes = snprintf(metadata_path, sizeof(metadata_path), "%s.meta", argument_values[2]);
    if (path_bytes < 0 || (size_t)path_bytes >= sizeof(metadata_path)) {
        free(class_order);
        free(elapsed_nanoseconds);
        return 2;
    }
    FILE *raw_file = fopen(argument_values[2], "wx");
    FILE *metadata_file = fopen(metadata_path, "wx");
    if (raw_file == NULL || metadata_file == NULL) {
        if (raw_file != NULL) {
            fclose(raw_file);
        }
        if (metadata_file != NULL) {
            fclose(metadata_file);
        }
        free(class_order);
        free(elapsed_nanoseconds);
        return 1;
    }
    int collection_status = 0;
    size_t completed_calls = 0U;
    uint8_t working_secret[PLATFORM_M4_INPUT_BYTES];
    for (size_t sample_index = 0U; sample_index < call_count; sample_index++) {
        uint8_t class_label = class_order[sample_index];
        memcpy(working_secret, secret_inputs[class_label], sizeof(working_secret));
        int is_equal = 0;
        uint64_t start_nanoseconds;
        uint64_t finish_nanoseconds;
        atomic_signal_fence(memory_order_seq_cst);
        if (read_nanoseconds(&start_nanoseconds) != 0) {
            collection_status = 1;
            break;
        }
        int compare_status = m4_compare_checked(working_secret,
            PLATFORM_M4_INPUT_BYTES,
            candidate_inputs[0],
            PLATFORM_M4_INPUT_BYTES,
            &is_equal);
        atomic_signal_fence(memory_order_seq_cst);
        if (read_nanoseconds(&finish_nanoseconds) != 0 || finish_nanoseconds < start_nanoseconds) {
            collection_status = 1;
            break;
        }
        elapsed_nanoseconds[sample_index] = finish_nanoseconds - start_nanoseconds;
        completed_calls++;
        observed_result ^= (unsigned)is_equal;
        if (compare_status != 0 || is_equal != 0) {
            collection_status = 1;
            break;
        }
    }
    int output_status = fputs("run_id,implementation,input_category,sample_index,"
                              "elapsed_nanoseconds,time_unit\n",
                            raw_file) < 0;
    for (size_t sample_index = 0U; sample_index < completed_calls; sample_index++) {
        if (fprintf(raw_file,
                "%s,m4-%s,%s,%zu,%" PRIu64 ",ns\n",
                argument_values[5],
                M4_VARIANT_NAME,
                class_order[sample_index] == 0U ? "mismatch-first" : "mismatch-last",
                sample_index,
                elapsed_nanoseconds[sample_index]) < 0) {
            output_status = 1;
        }
    }
    if (fprintf(metadata_file,
            "module=M4\ncase=artificial_compare\nboundary=complete_checked_compare\n"
            "variant=%s\nclock=%s\nunit=ns\norder=balanced_adjacent_pair_splitmix64\n"
            "seed=%" PRIu64 "\nrequested_calls=%zu\ncompleted_calls=%zu\n"
            "collection_status=%d\nfrequency_control=external_controller_required\n",
            M4_VARIANT_NAME,
            M4_CLOCK_NAME,
            order_seed,
            call_count,
            completed_calls,
            collection_status) < 0) {
        output_status = 1;
    }
    output_status |= fclose(raw_file) != 0;
    output_status |= fclose(metadata_file) != 0;
    free(class_order);
    free(elapsed_nanoseconds);
    return collection_status || output_status;
}

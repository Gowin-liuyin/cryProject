file(REMOVE_RECURSE
  "libmem_lut_on_kernel.a"
)

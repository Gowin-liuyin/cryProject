# Empty dependencies file for mem_lut_off_kernel.
# This may be replaced when dependencies are built.

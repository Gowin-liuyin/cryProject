# Empty dependencies file for mem_lut_leak_off.
# This may be replaced when dependencies are built.

file(REMOVE_RECURSE
  "CMakeFiles/mem_lut_off_kernel.dir/mem_lut.c.o"
  "CMakeFiles/mem_lut_off_kernel.dir/mem_lut.c.o.d"
  "libmem_lut_off_kernel.a"
  "libmem_lut_off_kernel.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mem_lut_off_kernel.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

file(REMOVE_RECURSE
  "CMakeFiles/mem_lut_leak_off.dir/main.c.o"
  "CMakeFiles/mem_lut_leak_off.dir/main.c.o.d"
  "mem_lut_leak_off"
  "mem_lut_leak_off.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mem_lut_leak_off.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()


# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/mem_lut_leak/main.c" "fixtures/mem_lut_leak/CMakeFiles/mem_lut_leak_on.dir/main.c.o" "gcc" "fixtures/mem_lut_leak/CMakeFiles/mem_lut_leak_on.dir/main.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

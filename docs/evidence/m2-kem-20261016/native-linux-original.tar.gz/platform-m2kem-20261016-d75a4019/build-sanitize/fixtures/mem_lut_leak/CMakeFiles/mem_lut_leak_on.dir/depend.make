# Empty dependencies file for mem_lut_leak_on.
# This may be replaced when dependencies are built.

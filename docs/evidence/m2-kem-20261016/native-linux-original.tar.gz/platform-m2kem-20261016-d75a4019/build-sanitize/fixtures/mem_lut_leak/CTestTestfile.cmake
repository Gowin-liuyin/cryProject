# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/mem_lut_leak
# Build directory: /home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/mem_lut_leak
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[mem_lut_on_selftest]=] "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/mem_lut_leak/mem_lut_leak_on" "--selftest")
set_tests_properties([=[mem_lut_on_selftest]=] PROPERTIES  LABELS "fixture;mem_lut" _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/mem_lut_leak/CMakeLists.txt;71;add_test;/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/mem_lut_leak/CMakeLists.txt;0;")
add_test([=[mem_lut_off_selftest]=] "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/mem_lut_leak/mem_lut_leak_off" "--selftest")
set_tests_properties([=[mem_lut_off_selftest]=] PROPERTIES  LABELS "fixture;mem_lut" _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/mem_lut_leak/CMakeLists.txt;71;add_test;/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/mem_lut_leak/CMakeLists.txt;0;")

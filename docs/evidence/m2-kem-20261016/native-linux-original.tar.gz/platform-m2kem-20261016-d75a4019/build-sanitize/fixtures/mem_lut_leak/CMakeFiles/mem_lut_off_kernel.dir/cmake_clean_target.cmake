file(REMOVE_RECURSE
  "libmem_lut_off_kernel.a"
)

file(REMOVE_RECURSE
  "CMakeFiles/mem_lut_leak_on.dir/main.c.o"
  "CMakeFiles/mem_lut_leak_on.dir/main.c.o.d"
  "mem_lut_leak_on"
  "mem_lut_leak_on.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mem_lut_leak_on.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

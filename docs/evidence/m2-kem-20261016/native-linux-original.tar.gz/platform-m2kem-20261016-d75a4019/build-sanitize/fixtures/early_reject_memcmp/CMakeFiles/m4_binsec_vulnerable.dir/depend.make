# Empty dependencies file for m4_binsec_vulnerable.
# This may be replaced when dependencies are built.

file(REMOVE_RECURSE
  "CMakeFiles/m4_compare_ct.dir/compare_checked.c.o"
  "CMakeFiles/m4_compare_ct.dir/compare_checked.c.o.d"
  "CMakeFiles/m4_compare_ct.dir/compare_ct.c.o"
  "CMakeFiles/m4_compare_ct.dir/compare_ct.c.o.d"
  "CMakeFiles/m4_compare_ct.dir/driver.c.o"
  "CMakeFiles/m4_compare_ct.dir/driver.c.o.d"
  "CMakeFiles/m4_compare_ct.dir/self_test.c.o"
  "CMakeFiles/m4_compare_ct.dir/self_test.c.o.d"
  "m4_compare_ct"
  "m4_compare_ct.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/m4_compare_ct.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

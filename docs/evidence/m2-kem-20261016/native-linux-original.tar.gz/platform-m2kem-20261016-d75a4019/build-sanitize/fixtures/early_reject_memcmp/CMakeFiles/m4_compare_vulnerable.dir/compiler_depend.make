# Empty compiler generated dependencies file for m4_compare_vulnerable.
# This may be replaced when dependencies are built.

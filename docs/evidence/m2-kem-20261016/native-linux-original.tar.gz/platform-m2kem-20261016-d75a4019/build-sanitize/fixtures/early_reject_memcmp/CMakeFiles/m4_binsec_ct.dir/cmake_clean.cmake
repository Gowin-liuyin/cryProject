file(REMOVE_RECURSE
  "CMakeFiles/m4_binsec_ct.dir/binsec_harness.c.o"
  "CMakeFiles/m4_binsec_ct.dir/binsec_harness.c.o.d"
  "CMakeFiles/m4_binsec_ct.dir/compare_ct.c.o"
  "CMakeFiles/m4_binsec_ct.dir/compare_ct.c.o.d"
  "m4_binsec_ct"
  "m4_binsec_ct.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/m4_binsec_ct.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

# Empty dependencies file for m4_compare_ct.
# This may be replaced when dependencies are built.

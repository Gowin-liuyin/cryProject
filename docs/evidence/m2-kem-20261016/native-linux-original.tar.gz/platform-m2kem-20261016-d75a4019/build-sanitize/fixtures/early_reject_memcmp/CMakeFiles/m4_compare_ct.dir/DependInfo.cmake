
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/compare_checked.c" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/compare_checked.c.o" "gcc" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/compare_checked.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/compare_ct.c" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/compare_ct.c.o" "gcc" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/compare_ct.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/driver.c" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/driver.c.o" "gcc" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/driver.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/self_test.c" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/self_test.c.o" "gcc" "fixtures/early_reject_memcmp/CMakeFiles/m4_compare_ct.dir/self_test.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

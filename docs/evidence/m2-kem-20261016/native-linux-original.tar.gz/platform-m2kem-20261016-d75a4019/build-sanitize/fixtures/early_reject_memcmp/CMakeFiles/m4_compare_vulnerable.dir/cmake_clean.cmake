file(REMOVE_RECURSE
  "CMakeFiles/m4_compare_vulnerable.dir/compare_checked.c.o"
  "CMakeFiles/m4_compare_vulnerable.dir/compare_checked.c.o.d"
  "CMakeFiles/m4_compare_vulnerable.dir/compare_early.c.o"
  "CMakeFiles/m4_compare_vulnerable.dir/compare_early.c.o.d"
  "CMakeFiles/m4_compare_vulnerable.dir/driver.c.o"
  "CMakeFiles/m4_compare_vulnerable.dir/driver.c.o.d"
  "CMakeFiles/m4_compare_vulnerable.dir/self_test.c.o"
  "CMakeFiles/m4_compare_vulnerable.dir/self_test.c.o.d"
  "m4_compare_vulnerable"
  "m4_compare_vulnerable.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/m4_compare_vulnerable.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp
# Build directory: /home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/early_reject_memcmp
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[m4_vulnerable_self_test]=] "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/early_reject_memcmp/m4_compare_vulnerable" "--self-test")
set_tests_properties([=[m4_vulnerable_self_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;61;add_test;/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")
add_test([=[m4_vulnerable_probe_smoke]=] "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/early_reject_memcmp/m4_compare_vulnerable" "--probe")
set_tests_properties([=[m4_vulnerable_probe_smoke]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;64;add_test;/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")
add_test([=[m4_ct_self_test]=] "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/early_reject_memcmp/m4_compare_ct" "--self-test")
set_tests_properties([=[m4_ct_self_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;61;add_test;/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")
add_test([=[m4_ct_probe_smoke]=] "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/build-sanitize/fixtures/early_reject_memcmp/m4_compare_ct" "--probe")
set_tests_properties([=[m4_ct_probe_smoke]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;64;add_test;/home/nss-marker/yhr/Cry/platform-m2kem-20261016-d75a4019/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")

file(REMOVE_RECURSE
  "CMakeFiles/deployable"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/deployable.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

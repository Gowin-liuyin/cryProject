file(REMOVE_RECURSE
  "CMakeFiles/hardened_test_random_failure.dir/tests/test_random_failure.c.o"
  "CMakeFiles/hardened_test_random_failure.dir/tests/test_random_failure.c.o.d"
  "hardened/test_random_failure"
  "hardened/test_random_failure.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/hardened_test_random_failure.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

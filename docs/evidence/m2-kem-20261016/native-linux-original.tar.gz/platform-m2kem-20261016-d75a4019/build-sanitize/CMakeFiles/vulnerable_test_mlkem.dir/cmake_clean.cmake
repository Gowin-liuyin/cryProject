file(REMOVE_RECURSE
  "CMakeFiles/vulnerable_test_mlkem.dir/tests/test_mlkem.c.o"
  "CMakeFiles/vulnerable_test_mlkem.dir/tests/test_mlkem.c.o.d"
  "vulnerable/test_mlkem"
  "vulnerable/test_mlkem.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/vulnerable_test_mlkem.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

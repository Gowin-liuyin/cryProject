# Empty compiler generated dependencies file for vulnerable_test_mlkem.
# This may be replaced when dependencies are built.

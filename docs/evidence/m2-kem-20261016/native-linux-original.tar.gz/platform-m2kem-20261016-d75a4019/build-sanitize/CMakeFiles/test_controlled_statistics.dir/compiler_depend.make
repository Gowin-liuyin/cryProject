# Empty compiler generated dependencies file for test_controlled_statistics.
# This may be replaced when dependencies are built.

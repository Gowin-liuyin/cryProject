file(REMOVE_RECURSE
  "CMakeFiles/test_controlled_statistics.dir/tests/test_controlled_statistics.c.o"
  "CMakeFiles/test_controlled_statistics.dir/tests/test_controlled_statistics.c.o.d"
  "test_controlled_statistics"
  "test_controlled_statistics.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_controlled_statistics.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

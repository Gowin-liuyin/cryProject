file(REMOVE_RECURSE
  "CMakeFiles/deployable_benchmark.dir/src/measure.c.o"
  "CMakeFiles/deployable_benchmark.dir/src/measure.c.o.d"
  "deployable/benchmark"
  "deployable/benchmark.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/deployable_benchmark.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

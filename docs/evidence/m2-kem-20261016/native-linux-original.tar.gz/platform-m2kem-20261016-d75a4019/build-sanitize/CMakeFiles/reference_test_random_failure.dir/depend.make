# Empty dependencies file for reference_test_random_failure.
# This may be replaced when dependencies are built.

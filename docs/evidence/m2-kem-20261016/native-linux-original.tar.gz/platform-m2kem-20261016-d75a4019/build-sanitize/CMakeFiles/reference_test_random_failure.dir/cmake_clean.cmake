file(REMOVE_RECURSE
  "CMakeFiles/reference_test_random_failure.dir/tests/test_random_failure.c.o"
  "CMakeFiles/reference_test_random_failure.dir/tests/test_random_failure.c.o.d"
  "reference/test_random_failure"
  "reference/test_random_failure.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/reference_test_random_failure.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

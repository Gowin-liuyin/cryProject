file(REMOVE_RECURSE
  "CMakeFiles/test_paired_runner.dir/tests/test_paired_runner.c.o"
  "CMakeFiles/test_paired_runner.dir/tests/test_paired_runner.c.o.d"
  "test_paired_runner"
  "test_paired_runner.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_paired_runner.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

file(REMOVE_RECURSE
  "CMakeFiles/reference_baseline.dir/src/main.c.o"
  "CMakeFiles/reference_baseline.dir/src/main.c.o.d"
  "reference/baseline"
  "reference/baseline.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/reference_baseline.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

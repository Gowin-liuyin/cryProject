file(REMOVE_RECURSE
  "CMakeFiles/encoder_mask_test_mlkem.dir/tests/test_mlkem.c.o"
  "CMakeFiles/encoder_mask_test_mlkem.dir/tests/test_mlkem.c.o.d"
  "encoder_mask/test_mlkem"
  "encoder_mask/test_mlkem.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/encoder_mask_test_mlkem.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

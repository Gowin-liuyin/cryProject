file(REMOVE_RECURSE
  "CMakeFiles/build_identity"
  "generated/RelWithDebInfo/build_identity.h"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/build_identity.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

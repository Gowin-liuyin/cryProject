from pathlib import Path
import fcntl,hashlib,json,os,shutil,signal,subprocess,time
repo=Path('/Users/yin/code/cryProject')
work=Path(__file__).resolve().parent
original=repo/'build/aris-g2-timing-description-20261010/software/run-20261010T040826Z'
evidence=repo/'docs/evidence/frequency-window-20261010/run-0ba4cd7'
source=repo/'docs/research/aris-frequency-window-analysis-20261010'
repair_contract=repo/'docs/research/aris-g2-timing-description-20261010/SOFTWARE_REPAIR.md'
started=time.monotonic()
def digest(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def save(name,value):
    (work/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
for name in ('logs','outputs','ctest','tmp','cache','module-cache','ccache'):
    (work/name).mkdir()
original_manifest=json.loads((original/'manifest.json').read_text())
def original_manifest_matches():
    return all((original/item['path']).stat().st_size==item['bytes'] and digest(original/item['path'])==item['sha256'] for item in original_manifest)
assert original_manifest_matches()
env=json.loads((original/'environment.json').read_text())
env.update({'TMPDIR':str(work/'tmp'),'TMP':str(work/'tmp'),'TEMP':str(work/'tmp'),'XDG_CACHE_HOME':str(work/'cache'),'CLANG_MODULE_CACHE_PATH':str(work/'module-cache'),'CCACHE_DIR':str(work/'ccache'),'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1'})
save('environment.json',env)
normal_binary=original/'build-normal/analyze_windows'
sanitized_binary=original/'build-sanitize/analyze_windows'
source_sha=digest(source/'analyze_windows.c')
cmake_sha=digest(source/'CMakeLists.txt')
assert source_sha=='81565a4502b1212c9d33466be3747632025b6fcdc222f58d032ee0b5f85e6bd9'
assert cmake_sha=='57c4060a6a41b6110999a8c729ed4e156c14975f3ecb53aef907640e4076596c'
normal_sha=digest(normal_binary); sanitized_sha=digest(sanitized_binary)
assert normal_sha=='3b235081eeec4be6d2e774fcab758e2312b654893e12fe7cb3f83a4f824fccfa'
assert sanitized_sha=='35fa8f91a3a68e5e73847a2256dcabbb9da43c32e2bf18464a17e70ee51ad074'
shutil.copyfile(repair_contract,work/'SOFTWARE_REPAIR.md')
shutil.copyfile(original/'build-sanitize/CTestTestfile.cmake',work/'ctest/CTestTestfile.cmake')
assert digest(work/'ctest/CTestTestfile.cmake')==digest(original/'build-sanitize/CTestTestfile.cmake')
commands=[]
status={'status':'running','original_directory':str(original),'source_sha256':source_sha,'cmake_sha256':cmake_sha,'normal_binary_sha256':normal_sha,'sanitized_binary_sha256':sanitized_sha,'repair_contract_sha256':digest(repair_contract),'correction':{'ASAN_OPTIONS_before':'detect_leaks=1:halt_on_error=1','ASAN_OPTIONS_after':'detect_leaks=0:halt_on_error=1','ASan_retained':True,'UBSan_retained':True,'LSan_coverage_claimed':False},'builds_repeated':0,'ordinary_ctest_repeated':0,'sanitized_ctest_repair_executions':0,'new_hardware_collection':False,'new_cryptographic_calls':0,'new_timing_description_real_input_runs':0,'legacy_mode_real_input_runs':0,'additional_stdout_failure_fixture_runs':0,'original_manifest_unchanged_before':True,'ctest_registration_copied_byte_identical':True,'bounds_seconds':{'repair_ctest':60,'each_legacy_or_output_failure':30,'repair_total':150}}
save('repair-results.json',status)
def run(name,argv,timeout,expected_exit,stdout=None,readonly_stdout=False):
    remaining=150-(time.monotonic()-started)
    if remaining<=0: raise RuntimeError('repair_budget_expired')
    timeout=min(timeout,remaining)
    stdout=stdout or work/'logs'/(name+'.stdout.log')
    stderr=work/'logs'/(name+'.stderr.log')
    begin=time.monotonic()
    record={'name':name,'argv':[str(item) for item in argv],'cwd':str(repo),'timeout_seconds':timeout,'stdout':str(stdout.relative_to(work)),'stderr':str(stderr.relative_to(work)),'expected_exit':expected_exit,'readonly_stdout_descriptor':readonly_stdout}
    commands.append(record); save('commands.json',commands)
    out=open(stdout,'rb' if readonly_stdout else 'wb')
    if readonly_stdout:
        record['stdout_F_GETFL_access_mode']=fcntl.fcntl(out.fileno(),fcntl.F_GETFL)&os.O_ACCMODE
        assert record['stdout_F_GETFL_access_mode']==os.O_RDONLY
    with out,stderr.open('wb') as err:
        process=subprocess.Popen(record['argv'],cwd=repo,env=env,stdout=out,stderr=err,start_new_session=True)
        record['pid']=process.pid
        try:
            record['exit_code']=process.wait(timeout=timeout); record['timed_out']=False
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL)
            record['exit_code']=process.wait(); record['timed_out']=True
    record['elapsed_seconds']=time.monotonic()-begin
    record['stdout_target_sha256']=digest(stdout)
    record['stderr_sha256']=digest(stderr)
    save('commands.json',commands)
    if record['timed_out'] or record['exit_code']!=expected_exit: raise RuntimeError(name+'_exit_or_timeout')
    return record
try:
    ctest=shutil.which('ctest',path=env['PATH']); assert ctest
    run('sanitize-ctest-repair',[ctest,'--test-dir',work/'ctest','--output-on-failure','--no-tests=error','--timeout','30'],60,0)
    status['sanitized_ctest_repair_executions']=1
    status['sanitized_ctest_expected_count']=2
    save('repair-results.json',status)
    comparison=[]
    input_records={}
    for name,expected_exit in (('normal',0),('parent-loss',1)):
        original_input=evidence/'originals'/name/'worker.stdout.jsonl'
        before={'sha256':digest(original_input),'bytes':original_input.stat().st_size}
        if name=='normal': assert before['sha256']=='c29a9ca0e28ffad53aaeb0e0c0097fd560d048f5eee4803885cb56850a989028'
        else: assert before['bytes']==0
        csv=work/'outputs'/(name+'-windows.csv')
        run('legacy-'+name,[normal_binary,original_input],30,expected_exit,stdout=csv)
        status['legacy_mode_real_input_runs']+=1
        summary=work/'outputs'/(name+'-summary.json')
        shutil.copyfile(work/'logs'/('legacy-'+name+'.stderr.log'),summary)
        for path in (csv,summary):
            frozen=evidence/'analysis'/path.name
            same=path.read_bytes()==frozen.read_bytes()
            comparison.append({'output':str(path.relative_to(work)),'frozen':str(frozen.relative_to(repo)),'bytes':path.stat().st_size,'sha256':digest(path),'frozen_sha256':digest(frozen),'byte_identical':same})
            assert same,path.name
        after={'sha256':digest(original_input),'bytes':original_input.stat().st_size}
        input_records[name]={'before':before,'after':after,'unchanged':before==after}
        assert before==after
    save('legacy-byte-comparison.json',comparison)
    save('inputs.json',input_records)
    target=work/'readonly-stdout-target.bin'
    target.write_bytes(b'read-only stdout descriptor software fixture\n')
    target_before=digest(target)
    run('readonly-stdout-fixture',[normal_binary,'--timing-selfcheck'],30,1,stdout=target,readonly_stdout=True)
    status['additional_stdout_failure_fixture_runs']=1
    status['readonly_stdout_target_unchanged']=digest(target)==target_before
    assert status['readonly_stdout_target_unchanged']
    assert digest(source/'analyze_windows.c')==source_sha and digest(source/'CMakeLists.txt')==cmake_sha
    assert digest(normal_binary)==normal_sha and digest(sanitized_binary)==sanitized_sha
    assert original_manifest_matches()
    status.update({'status':'passed','sanitized_ctest_exit':0,'legacy_normal_exit':0,'legacy_parent_loss_exit':1,'readonly_stdout_fixture_exit':1,'all_four_legacy_outputs_byte_identical':True,'source_and_binaries_unchanged':True,'original_manifest_unchanged_after':True,'total_elapsed_seconds':time.monotonic()-started})
except BaseException as error:
    status.update({'status':'failed','failure':str(error),'total_elapsed_seconds':time.monotonic()-started})
    save('repair-results.json',status)
    print(json.dumps(status,ensure_ascii=False))
    raise
save('repair-results.json',status)
manifest=[{'path':str(path.relative_to(work)),'bytes':path.stat().st_size,'sha256':digest(path)} for path in sorted(work.rglob('*')) if path.is_file() and path.name!='manifest.json']
save('manifest.json',manifest)
print(json.dumps({'work':str(work),'results':status,'manifest_files':len(manifest),'manifest_bytes':sum(item['bytes'] for item in manifest)},ensure_ascii=False,indent=2))

# CMake generated Testfile for 
# Source directory: /Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/source
# Build directory: /Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/build-normal
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[frequency_analysis_selfcheck]=] "/Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/build-normal/analyze_windows" "--selfcheck")
set_tests_properties([=[frequency_analysis_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/source/CMakeLists.txt;41;add_test;/Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/source/CMakeLists.txt;0;")
add_test([=[frequency_timing_description_selfcheck]=] "/Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/build-normal/analyze_windows" "--timing-selfcheck")
set_tests_properties([=[frequency_timing_description_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/source/CMakeLists.txt;42;add_test;/Users/yin/code/cryProject/build/aris-g2-timing-description-20261010/software/run-20261010T040826Z/source/CMakeLists.txt;0;")

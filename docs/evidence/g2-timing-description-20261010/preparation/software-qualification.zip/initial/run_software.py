from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,signal,subprocess,time
repo=Path('/Users/yin/code/cryProject')
work=Path(__file__).resolve().parent
started=time.monotonic()
source=repo/'docs/research/aris-frequency-window-analysis-20261010'
evidence=repo/'docs/evidence/frequency-window-20261010/run-0ba4cd7'
plan=repo/'docs/research/aris-g2-timing-description-20261010/EXPERIMENT_PLAN.md'
expected_plan='eb2d57f21eaa4859dfe28988c9aeaea6e95d956a3675520f70aefeed41b16eb4'
expected_source='81565a4502b1212c9d33466be3747632025b6fcdc222f58d032ee0b5f85e6bd9'
expected_cmake='57c4060a6a41b6110999a8c729ed4e156c14975f3ecb53aef907640e4076596c'
expected_input='c29a9ca0e28ffad53aaeb0e0c0097fd560d048f5eee4803885cb56850a989028'
def digest(path):
    return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def write_json(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
for name in ('source','logs','outputs','artifacts','tmp','cache','module-cache','ccache'):
    (work/name).mkdir()
env={key:os.environ[key] for key in ('PATH','HOME') if key in os.environ}
env.update({'LANG':'C','LC_ALL':'C','TZ':'UTC','TMPDIR':str(work/'tmp'),'TMP':str(work/'tmp'),'TEMP':str(work/'tmp'),'XDG_CACHE_HOME':str(work/'cache'),'CLANG_MODULE_CACHE_PATH':str(work/'module-cache'),'CCACHE_DIR':str(work/'ccache'),'CTEST_PARALLEL_LEVEL':'1','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
write_json(work/'environment.json',env)
commands=[]
status={'classification':'CPU_only_software_qualification','new_hardware_collection':False,'new_cryptographic_calls':0,'new_timing_description_real_input_runs':0,'legacy_mode_real_input_runs':0,'timeouts_seconds':{'per_configure_and_build':60,'per_ctest_or_legacy_check':30,'total':300},'checks':{},'status':'running'}
def run(name,argv,timeout=30,expected_exit=0,stdout=None,stderr=None):
    remaining=300-(time.monotonic()-started)
    if remaining<=0: raise RuntimeError('total_software_budget_expired')
    timeout=min(timeout,remaining)
    stdout=stdout or work/'logs'/(name+'.stdout.log')
    stderr=stderr or work/'logs'/(name+'.stderr.log')
    begin=time.monotonic()
    record={'name':name,'argv':[str(item) for item in argv],'cwd':str(repo),'timeout_seconds':timeout,'stdout':str(stdout.relative_to(work)),'stderr':str(stderr.relative_to(work)),'expected_exit':expected_exit}
    commands.append(record)
    write_json(work/'commands.json',commands)
    with stdout.open('wb') as out,stderr.open('wb') as err:
        process=subprocess.Popen(record['argv'],cwd=repo,env=env,stdout=out,stderr=err,start_new_session=True)
        record['pid']=process.pid
        try:
            record['exit_code']=process.wait(timeout=timeout)
            record['timed_out']=False
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL)
            record['exit_code']=process.wait()
            record['timed_out']=True
    record['elapsed_seconds']=time.monotonic()-begin
    record['stdout_sha256']=digest(stdout)
    record['stderr_sha256']=digest(stderr)
    write_json(work/'commands.json',commands)
    if record['timed_out'] or record['exit_code']!=expected_exit:
        raise RuntimeError(name+'_exit_or_timeout')
    return record
try:
    assert digest(plan)==expected_plan
    assert digest(source/'analyze_windows.c')==expected_source
    assert digest(source/'CMakeLists.txt')==expected_cmake
    qualification=json.loads((repo/'build/aris-g2-timing-description-20261010/qualification/preflight.json').read_text())
    assert qualification['compute_available'] and qualification['GPU_required'] is False
    shutil.copyfile(repo/'build/aris-g2-timing-description-20261010/qualification/preflight.json',work/'preflight.json')
    shutil.copyfile(plan,work/'source'/'EXPERIMENT_PLAN.md')
    for name in ('analyze_windows.c','CMakeLists.txt'):
        shutil.copyfile(source/name,work/'source'/name)
    shutil.copyfile(repo/'docs/research/aris-g2-timing-description-20261010/README.md',work/'source'/'README.md')
    run('git-head',['git','rev-parse','HEAD'])
    run('git-status',['git','status','--short'])
    run('git-module-diff',['git','diff','--','docs/research/aris-frequency-window-analysis-20261010/analyze_windows.c','docs/research/aris-frequency-window-analysis-20261010/CMakeLists.txt'])
    status['uncommitted_source_diff_sha256']=digest(work/'logs'/'git-module-diff.stdout.log')
    normal_input=evidence/'originals/normal/worker.stdout.jsonl'
    empty_input=evidence/'originals/parent-loss/worker.stdout.jsonl'
    input_before={str(path.relative_to(repo)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in (normal_input,empty_input)}
    assert input_before[str(normal_input.relative_to(repo))]['sha256']==expected_input
    assert empty_input.stat().st_size==0
    write_json(work/'inputs-before.json',input_before)
    compiler=shutil.which('cc',path=env['PATH'])
    cmake=shutil.which('cmake',path=env['PATH'])
    ctest=shutil.which('ctest',path=env['PATH'])
    assert compiler and cmake and ctest
    run('compiler-version',[compiler,'--version'])
    run('cmake-version',[cmake,'--version'])
    run('machine',['uname','-a'])
    status['host_machine']=platform.machine()
    for configuration,is_sanitized in (('normal',False),('sanitize',True)):
        build=work/('build-'+configuration)
        config_started=time.monotonic()
        run(configuration+'-configure',[cmake,'-S',work/'source','-B',build,'-G','Unix Makefiles','-DCMAKE_C_COMPILER='+compiler,'-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DBUILD_TESTING=ON','-DFREQUENCY_ANALYSIS_SANITIZERS='+('ON' if is_sanitized else 'OFF')],timeout=60)
        run(configuration+'-build',[cmake,'--build',build,'--parallel','1'],timeout=60-(time.monotonic()-config_started))
        run(configuration+'-ctest',[ctest,'--test-dir',build,'--output-on-failure','--timeout','30'],timeout=30)
        binary=build/'analyze_windows'
        binary_copy=work/'artifacts'/('analyze_windows-macos-arm64-'+configuration)
        shutil.copyfile(binary,binary_copy)
        run(configuration+'-binary-type',['file',binary_copy])
        compiler_dir=work/'artifacts'/('compiler-'+configuration)
        compiler_dir.mkdir()
        for origin,destination in ((build/'CMakeFiles/analyze_windows.dir/flags.make','flags.make'),(build/'CMakeFiles/analyze_windows.dir/link.txt','link.txt')):
            shutil.copyfile(origin,compiler_dir/destination)
        compiler_files=list((build/'CMakeFiles').glob('*/CMakeCCompiler.cmake'))
        assert len(compiler_files)==1
        shutil.copyfile(compiler_files[0],compiler_dir/'CMakeCCompiler.cmake')
        status['checks'][configuration]={'ctest_expected_count':2,'binary_sha256':digest(binary_copy),'binary_bytes':binary_copy.stat().st_size,'configuration':'ASan_UBSan' if is_sanitized else 'ordinary','ctest_executions':1}
        write_json(work/'software-results.json',status)
    binary=work/'build-normal/analyze_windows'
    compatibility=[]
    for name,input_path,exit_code in (('normal',normal_input,0),('parent-loss',empty_input,1)):
        csv=work/'outputs'/(name+'-windows.csv')
        summary=work/'outputs'/(name+'-summary.json')
        run('legacy-'+name,[binary,input_path],timeout=30,expected_exit=exit_code,stdout=csv,stderr=summary)
        status['legacy_mode_real_input_runs']+=1
        for output in (csv,summary):
            frozen=evidence/'analysis'/output.name
            same=output.read_bytes()==frozen.read_bytes()
            compatibility.append({'output':str(output.relative_to(work)),'frozen':str(frozen.relative_to(repo)),'bytes':output.stat().st_size,'sha256':digest(output),'frozen_sha256':digest(frozen),'byte_identical':same})
            assert same,output.name
    write_json(work/'legacy-byte-comparison.json',compatibility)
    input_after={str(path.relative_to(repo)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in (normal_input,empty_input)}
    write_json(work/'inputs-after.json',input_after)
    assert input_before==input_after
    assert digest(source/'analyze_windows.c')==expected_source and digest(source/'CMakeLists.txt')==expected_cmake
    assert digest(plan)==expected_plan
    status.update({'status':'passed','all_four_legacy_outputs_byte_identical':True,'original_inputs_unchanged':True,'source_sha256':expected_source,'cmake_sha256':expected_cmake,'plan_sha256':expected_plan,'total_elapsed_seconds':time.monotonic()-started})
except BaseException as error:
    status.update({'status':'failed','failure':str(error),'total_elapsed_seconds':time.monotonic()-started})
    write_json(work/'software-results.json',status)
    print(json.dumps(status,ensure_ascii=False))
    raise
write_json(work/'software-results.json',status)
manifest=[]
for path in sorted(work.rglob('*')):
    if path.is_file() and path.name!='manifest.json':
        manifest.append({'path':str(path.relative_to(work)),'bytes':path.stat().st_size,'sha256':digest(path)})
write_json(work/'manifest.json',manifest)
print(json.dumps({'work':str(work),'results':status,'manifest_files':len(manifest),'manifest_bytes':sum(item['bytes'] for item in manifest)},ensure_ascii=False,indent=2))

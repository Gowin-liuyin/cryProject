# M5 原生定位与时序确认计划 v1（2026-10-16）

对象为固定 mlkem-native `b3ba7b32773e657dd37f6f87bce82528459ad8a4` 的 portable C
ML-KEM-768 reference 路径，命名空间 baseline_native，根 include/baseline_config.h 不变。
不使用 vulnerable/hardened/deployable 人工补丁，不修改上游快照与 M1 证据。

本文件新增时未提交。**本路只执行软件资格与非计时动态定位，不启动时序采集**。
主控必须先提交本文件及采集执行清单，绑定固定源/ELF/工具/runner摘要，才可按第3节采数。
原生 online dudect 只构建与 --self-test，--collect 明确留给主控。

## 1. 资格与定位

1. 普通与 ASan/UBSan 独立构建；既有独立 NIST FIPS203 向量、错误长度/空指针、篡改/随机密文、
   系统随机源失败检查按 reference 适用测试执行。公开 NIST 原向量不得改写。
2. 新秘密标记 harness 通过完整 `mlkem_decapsulate`，使用测试种子31337与424242，各执行
   valid、bit-flipped、random、message-zero、message-ones五类，总10次。
3. 输入先确定生成、先计算未标记的对应输出，再标记秘密并完整解封装。
   动态输出与私钥在比较/消费前恢复defined；不打印密钥、共享秘密、消息或验证中间状态。
4. ML-KEM-768 decapsulation key 的PKE秘密部分 `[0,1152)` 与拒绝秘密z `[2368,2400)` 标记undefined；
   内嵌公开key `[1152,2336)`、其公开hash `[2336,2368)` 保持defined。
   密文是攻击者可见的公开输入，不作为秘密标记；其解密消息通过秘密PKE key传播taint。
   库的公开key/hash检查分支不应被错误标成秘密依赖。
5. x86_64普通ELF分别使用发行版Memcheck、S3固定补丁工具varlat=no与varlat=yes；
   配置 --track-origins=yes --error-exitcode=99 --vgdb=no，工具/日志/tmp均在Cry边界内。
   没有Valgrind或秘密标记未实际运行时必须报unavailable/77，不能写0命中。
6. 保存同ELF反汇编、目标符号、编译参数、源导出清单、工具/ELF摘要及完整日志。
   意外命中先保全，再按数据流定位；不为取得阴性删poison、改密码路径或屏蔽错误。

动态定位使用普通产物，不把sanitizer产物当计时产物；无命中只覆盖本固定路径/输入/编译器/工具能力。

## 2. 原生 online dudect 合同

- 复用钉版上游 `third_party/dudect/src/dudect.h`；其rdtsc计时与measure的CLOCK_MONOTONIC分列。
- 类0/1分别为真实message-zero/message-ones密文，使用本仓库reference生成器。
  固定测试key seed对应一个固定key；每类密文固定，不能把重复调用当作不同key/消息总体。
- 每批10000完整decap，最多21批；首批为上游预热/分位阈值阶段。
  使用原上游100个裁剪与二阶辅助检验及 t>10 门限；首个泄漏状态立即停止，不追加预算。
- 类别顺序由公开seed+batch编号的SHAKE256独立域5确定，输入复制/分配在窗口外；
  callback仅执行完整decap、记录公开返回状态和固定索引更新。
  共享秘密保留到整批计时结束才消费并清零，避免在被测窗口中额外做输出消费/擦除。
- 自检只验证输入准备与同callback完整decap，不调用dudect_main或读钟。
  collector无显式 --collect --seed N --raw NEW.csv 时拒绝计时。
- 保存完整原日志、预算/实际批次/状态、seed、类计数、源/ELF与环境。
  最大t不转换成可进Holm的伪p；未检出不构成恒时或等价性证明。

## 3. 留给主控的正式采集合同（本路不执行）

| run_id | seed | CPU | 每类measure样本数 | online dudect |
|---|---:|---:|---:|---|
| m5_primary | 31337 | 2 | 10000 | 最多21批×10000 |
| m5_seed_repeat | 424242 | 2 | 10000 | 最多21批×10000 |
| m5_cpu_repeat | 31337 | 6 | 10000 | 最多21批×10000 |

完整 `reference/measure RUN_ID SEED 10000 RAW.csv META.txt` 每次产生五类各10000调用，
主比较预先固定message-zero−message-ones；其他类别保留原值但不进入本参数族。
所有主比较CI使用未截尾全部10000+10000原值；不减读钟成本，不删除普通长尾。

参数族 `m5_reference_end_to_end_v1` 恰含上述3个主类对Welch大样本正态近似p，
Holm FWER α=.05。每项报告95%正态近似CI、t、自由度与近似p，明确非有限样本精确Student-t。
RTLF各CSV执行一次、α=.01、bootstrap种子2026101605；原生dudect与RTLF均为族外交叉工具。
两者不从二值/最大t制造p。零值导致RTLF阻塞时保留原值与明确状态。

阴性一致性目标：三项主CI均含0且Holm均不拒绝，RTLF未检出，online dudect预算内无证据，
动态秘密标记/varlat无未解释命中。任何阳性或失败都如实保留并调查，不能自动延长样本或换类对。
此目标不是等价界/误报率/恒时认证；有限固定输入与同机重复的推广边界必须写入RESULT。

锁频采数仅由主控串行：一次任务占用CPU2或CPU6，boost关、performance、约4.30GHz、taskset；
执行前后与中途记录请求/反馈，进入与结束restore_match，异常退出必恢复。
不可把请求值称为逐调用恒频；未完成恢复不继续下一任务。

## 4. 停止与边界

软件资格/独立KAT失败、动态入口未实际instrumented、错链人工变体、路径越界、未提交PLAN、
锁频/恢复不成立时，正式时序阶段不启动。非计时定位可独立进行并保全失败日志。
不得密钥恢复、exploit、外部秘密、sleep/延迟伪阳性，亦不改旧证据结论。

原生dudect强制独占新raw CSV：整批结束保留每次begin tick、类别、相邻end tick/周期差、预热/正式阶段和原uncropped检验成员标志。
首批原始ticks不受其exec_times排序影响；每批末调用没有下一begin tick，end/duration明确为空，不补造测量。
每批完成后flush；中断时尚未完成的一批可能没有落盘，应按未知/不完整处理。

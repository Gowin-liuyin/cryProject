# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp
# Build directory: /home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/build-poison
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[m4_vulnerable_self_test]=] "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/build-poison/m4_compare_vulnerable" "--self-test")
set_tests_properties([=[m4_vulnerable_self_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;61;add_test;/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")
add_test([=[m4_vulnerable_probe_smoke]=] "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/build-poison/m4_compare_vulnerable" "--probe")
set_tests_properties([=[m4_vulnerable_probe_smoke]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;64;add_test;/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")
add_test([=[m4_ct_self_test]=] "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/build-poison/m4_compare_ct" "--self-test")
set_tests_properties([=[m4_ct_self_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;61;add_test;/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")
add_test([=[m4_ct_probe_smoke]=] "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/build-poison/m4_compare_ct" "--probe")
set_tests_properties([=[m4_ct_probe_smoke]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;64;add_test;/home/nss-marker/yhr/Cry/platform-s8-20261016-250f424b/source/fixtures/early_reject_memcmp/CMakeLists.txt;0;")

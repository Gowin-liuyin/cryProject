# Empty compiler generated dependencies file for raw_clock_calibration.
# This may be replaced when dependencies are built.

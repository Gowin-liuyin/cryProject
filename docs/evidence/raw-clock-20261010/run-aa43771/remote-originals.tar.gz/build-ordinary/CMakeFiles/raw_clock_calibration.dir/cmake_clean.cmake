file(REMOVE_RECURSE
  "CMakeFiles/raw_clock_calibration.dir/raw_clock_calibration.c.o"
  "CMakeFiles/raw_clock_calibration.dir/raw_clock_calibration.c.o.d"
  "raw_clock_calibration"
  "raw_clock_calibration.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/raw_clock_calibration.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

file(REMOVE_RECURSE
  "CMakeFiles/analyze_raw_clock.dir/analyze_raw_clock.c.o"
  "CMakeFiles/analyze_raw_clock.dir/analyze_raw_clock.c.o.d"
  "analyze_raw_clock"
  "analyze_raw_clock.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/analyze_raw_clock.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

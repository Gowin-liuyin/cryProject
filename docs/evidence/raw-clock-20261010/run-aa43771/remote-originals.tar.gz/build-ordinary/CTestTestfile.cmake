# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/source
# Build directory: /home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/build-ordinary
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[raw_clock_calibration_selfcheck]=] "/home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/build-ordinary/raw_clock_calibration" "--selfcheck")
set_tests_properties([=[raw_clock_calibration_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/source/CMakeLists.txt;71;add_test;/home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/source/CMakeLists.txt;0;")
add_test([=[raw_clock_analysis_selfcheck]=] "/home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/build-ordinary/analyze_raw_clock" "--selfcheck")
set_tests_properties([=[raw_clock_analysis_selfcheck]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/source/CMakeLists.txt;72;add_test;/home/nss-marker/yhr/Cry/raw-clock-aa43771-fe4ffb3f92f3630e/source/CMakeLists.txt;0;")

import datetime
import hashlib
import json
import os
import pathlib
import platform
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path('/Users/yin/code/cryProject')
WORK = ROOT / 'build/aris-raw-clock-20261010/software/final-local-20261010T092700Z'
MODULE = ROOT / 'docs/research/aris-raw-clock-20261010'
SOURCE = WORK / 'source'
PYTHON = '/Users/yin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
CMAKE = '/Users/yin/.local/bin/cmake'
CTEST = '/Users/yin/.local/bin/ctest'
FORMATTER = '/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang-format'
CMAKELANG_CACHE = '/Users/yin/.cache/uv/archive-v0/rgxegq1GpRnpIlNz'
SOURCE_NAMES = ('raw_clock_calibration.c', 'analyze_raw_clock.c', 'CMakeLists.txt',
                'ANALYSIS_CONTRACT.md', 'EXPERIMENT_PLAN.md', 'README.md')
EXPECTED = {
    'raw_clock_calibration.c': 'ed538f4322fba985aea9cfa78e0b2109f79caed49064e68eaa3884b4fa10f0dd',
    'analyze_raw_clock.c': 'c67d1dbd89034a75600d3d13a28aa5c7fb4a163b5649fa910c7eea624c7544e0',
    'EXPERIMENT_PLAN.md': '7499b60b7a32b0a5e82e2acbc07144b6b0062b5d1f344aeb4af9ff4208e6927a',
}
started = time.monotonic()
commands = []
source_hashes = {}
summary = {
    'status': 'running', 'platform': platform.platform(), 'machine': platform.machine(),
    'gpu_required': False, 'cpu_software_only': True, 'new_hardware_pairs': 0,
    'new_hardware_sample_clock_reads': 0, 'lsan_claimed': False, 'ssh_used': False,
    'normal_ctest_executions': 0, 'sanitize_ctest_executions': 0,
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'overall_budget_seconds': 300, 'configure_and_build_budget_seconds_per_configuration': 60,
    'ctest_budget_seconds_per_configuration': 30,
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def run_step(name, argv, environment, timeout_seconds, expected_returncode=0,
             stdout_readonly_path=None):
    remaining = 300 - (time.monotonic() - started)
    timeout_seconds = min(timeout_seconds, remaining)
    if timeout_seconds <= 0:
        raise RuntimeError('overall_budget_expired_before_' + name)
    command_start = time.monotonic()
    stdout_path = WORK / 'logs' / (name + '.stdout')
    stderr_path = WORK / 'logs' / (name + '.stderr')
    selected_environment = {key: environment[key] for key in (
        'TMPDIR', 'TMP', 'TEMP', 'XDG_CACHE_HOME', 'CCACHE_DIR', 'CLANG_MODULE_CACHE_PATH',
        'PYTHONDONTWRITEBYTECODE', 'PYTHONPYCACHEPREFIX', 'ASAN_OPTIONS', 'UBSAN_OPTIONS',
        'PYTHONPATH') if key in environment}
    entry = {
        'name': name, 'argv': argv, 'cwd': str(WORK), 'environment': selected_environment,
        'timeout_seconds': timeout_seconds, 'expected_returncode': expected_returncode,
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'stdout_file': str(stdout_path.relative_to(WORK)),
        'stderr_file': str(stderr_path.relative_to(WORK)),
    }
    commands.append(entry)
    save_json(WORK / 'commands.json', commands)
    with stdout_path.open('xb') as output_log, stderr_path.open('xb') as error_log:
        readonly_target = None
        if stdout_readonly_path is not None:
            readonly_target = stdout_readonly_path.open('rb')
            entry['stdout_redirected_to_readonly_fixture'] = str(stdout_readonly_path.relative_to(WORK))
        try:
            result = subprocess.run(argv, cwd=WORK, env=environment,
                                    stdout=readonly_target if readonly_target else output_log,
                                    stderr=error_log, timeout=timeout_seconds, check=False)
            entry['returncode'] = result.returncode
            entry['timed_out'] = False
        except subprocess.TimeoutExpired:
            entry['returncode'] = None
            entry['timed_out'] = True
            raise RuntimeError('timeout_' + name)
        finally:
            if readonly_target is not None:
                readonly_target.close()
            entry['elapsed_seconds'] = time.monotonic() - command_start
            save_json(WORK / 'commands.json', commands)
    if entry['returncode'] != expected_returncode:
        raise RuntimeError('unexpected_exit_' + name + '_' + str(entry['returncode']))
    print(name + ': exit ' + str(entry['returncode']), flush=True)
    return entry


try:
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise RuntimeError('unexpected_local_platform')
    SOURCE.mkdir()
    (WORK / 'logs').mkdir()
    (WORK / 'artifacts').mkdir()
    for source_name in SOURCE_NAMES:
        original = MODULE / source_name
        source_hashes[source_name] = digest(original)
        if source_name in EXPECTED and source_hashes[source_name] != EXPECTED[source_name]:
            raise RuntimeError('frozen_source_digest_mismatch_' + source_name)
        shutil.copy2(original, SOURCE / source_name)
    for configuration_name in ('.clang-format', '.cmake-format.json'):
        shutil.copy2(ROOT / configuration_name, SOURCE / configuration_name)
    save_json(WORK / 'source-sha256.json', source_hashes)
    shutil.copytree(ROOT / 'build/aris-raw-clock-20261010/preflight', WORK / 'preflight')
    preflight = json.loads((WORK / 'preflight/local.json').read_text())
    if not preflight['cpu_only_supported'] or preflight['GPU_required']:
        raise RuntimeError('unsupported_cpu_preflight')
    if shutil.disk_usage(WORK).free < 1024 * 1024 * 1024:
        raise RuntimeError('insufficient_space')
    save_json(WORK / 'execution-preflight.json', {
        'cpu_count': os.cpu_count(), 'disk_free_bytes': shutil.disk_usage(WORK).free,
        'plan_sha256': source_hashes['EXPERIMENT_PLAN.md'], 'gpu_required': False,
        'platform': platform.platform(), 'machine': platform.machine(),
        'source_snapshot_used_for_build': True,
    })
    for configuration_name in ('normal', 'sanitize'):
        environment = os.environ.copy()
        environment.pop('ASAN_OPTIONS', None)
        environment.pop('UBSAN_OPTIONS', None)
        runtime = WORK / configuration_name / 'runtime'
        for directory_name in ('tmp', 'cache', 'ccache', 'module-cache', 'pycache'):
            (runtime / directory_name).mkdir(parents=True)
        environment.update({
            'TMPDIR': str(runtime / 'tmp'), 'TMP': str(runtime / 'tmp'),
            'TEMP': str(runtime / 'tmp'), 'XDG_CACHE_HOME': str(runtime / 'cache'),
            'CCACHE_DIR': str(runtime / 'ccache'),
            'CLANG_MODULE_CACHE_PATH': str(runtime / 'module-cache'),
            'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPYCACHEPREFIX': str(runtime / 'pycache'),
        })
        if configuration_name == 'sanitize':
            environment['ASAN_OPTIONS'] = 'detect_leaks=0:halt_on_error=1'
            environment['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'
        build_path = WORK / configuration_name / 'build'
        configuration_start = time.monotonic()
        run_step(configuration_name + '-configure', [
            CMAKE, '-S', str(SOURCE), '-B', str(build_path), '-DCMAKE_BUILD_TYPE=RelWithDebInfo',
            '-DBUILD_TESTING=ON', '-DRAW_CLOCK_SANITIZERS=' + ('ON' if configuration_name == 'sanitize' else 'OFF'),
            '-DCLANG_FORMAT_EXECUTABLE=' + FORMATTER,
        ], environment, 60)
        run_step(configuration_name + '-build', [CMAKE, '--build', str(build_path), '--parallel', '2'],
                 environment, 60 - (time.monotonic() - configuration_start))
        run_step(configuration_name + '-test-registration', [CTEST, '--test-dir', str(build_path),
                 '--show-only=json-v1'], environment, 10)
        registered = json.loads((WORK / 'logs' / (configuration_name + '-test-registration.stdout')).read_text())
        if [test['name'] for test in registered['tests']] != [
                'raw_clock_calibration_selfcheck', 'raw_clock_analysis_selfcheck']:
            raise RuntimeError('unexpected_test_registration_' + configuration_name)
        summary[configuration_name + '_ctest_executions'] = 1
        run_step(configuration_name + '-ctest', [CTEST, '--test-dir', str(build_path),
                 '--output-on-failure', '--timeout', '30'], environment, 30)
        artifact_path = WORK / 'artifacts' / configuration_name
        artifact_path.mkdir()
        for target_name in ('raw_clock_calibration', 'analyze_raw_clock'):
            shutil.copy2(build_path / target_name, artifact_path / (target_name + '.macho'))
        for artifact_name in ('compile_commands.json', 'CMakeCache.txt'):
            shutil.copy2(build_path / artifact_name, artifact_path / artifact_name)
        shutil.copytree(build_path / 'Testing', artifact_path / 'Testing')
        run_step(configuration_name + '-binary-types', ['/usr/bin/file',
            str(artifact_path / 'raw_clock_calibration.macho'),
            str(artifact_path / 'analyze_raw_clock.macho')], environment, 10)
        if configuration_name == 'normal':
            run_step('module-format-check', [CMAKE, '--build', str(build_path), '--target', 'format-check'],
                     environment, 30)
            cmakeformat_environment = environment.copy()
            cmakeformat_environment['PYTHONPATH'] = CMAKELANG_CACHE
            run_step('cmakeformat-offline-0.6.13', [PYTHON, '-m', 'cmakelang.format', '--check',
                     '-c', str(SOURCE / '.cmake-format.json'), str(SOURCE / 'CMakeLists.txt')],
                     cmakeformat_environment, 30)
            run_step('macos-unsupported-collect', [str(build_path / 'raw_clock_calibration'), '--collect'],
                     environment, 10, expected_returncode=2)
            if (WORK / 'logs/macos-unsupported-collect.stdout').stat().st_size != 0 or (
                    WORK / 'logs/macos-unsupported-collect.stderr').read_text() != (
                    'unsupported: collection requires Linux/x86_64\n'):
                raise RuntimeError('unsupported_branch_output_mismatch')
            readonly_fixture = WORK / 'readonly-stdout.fixture'
            readonly_fixture.write_bytes(b'read-only-stdout-fixture\n')
            fixture_digest_before = digest(readonly_fixture)
            run_step('collector-selfcheck-readonly-stdout', [str(build_path / 'raw_clock_calibration'),
                     '--selfcheck'], environment, 10, expected_returncode=1,
                     stdout_readonly_path=readonly_fixture)
            if digest(readonly_fixture) != fixture_digest_before:
                raise RuntimeError('readonly_fixture_changed')
    for source_name, expected_digest in source_hashes.items():
        if digest(MODULE / source_name) != expected_digest or digest(SOURCE / source_name) != expected_digest:
            raise RuntimeError('source_changed_during_qualification_' + source_name)
    summary['status'] = 'software_qualification_passed'
    summary['normal_tests_passed'] = 2
    summary['sanitize_tests_passed'] = 2
    summary['source_originals_unchanged'] = True
except Exception as error:
    summary['status'] = 'failed_preserved_no_retry'
    summary['failure'] = str(error)
finally:
    summary['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    summary['elapsed_seconds'] = time.monotonic() - started
    summary['source_sha256'] = source_hashes
    save_json(WORK / 'qualification-summary.json', summary)
    save_json(WORK / 'commands.json', commands)
    manifest = []
    for evidence_file in sorted(WORK.rglob('*')):
        if evidence_file.is_file() and evidence_file.name != 'SHA256SUMS':
            manifest.append(digest(evidence_file) + '  ' + evidence_file.relative_to(WORK).as_posix())
    (WORK / 'SHA256SUMS').write_text('\n'.join(manifest) + '\n')
    print(json.dumps(summary, ensure_ascii=False), flush=True)
sys.exit(0 if summary['status'] == 'software_qualification_passed' else 1)

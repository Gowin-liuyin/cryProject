# CMake generated Testfile for 
# Source directory: /home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/docs/evidence/m2-kyberslash-20261016/version-audit
# Build directory: /home/nss-marker/yhr/Cry/platform-s4-20261016-7824/build-poison
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[kyberslash_unfixed_probe_smoke]=] "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/build-poison/kyberslash_unfixed_probe")
set_tests_properties([=[kyberslash_unfixed_probe_smoke]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/docs/evidence/m2-kyberslash-20261016/version-audit/CMakeLists.txt;49;add_test;/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/docs/evidence/m2-kyberslash-20261016/version-audit/CMakeLists.txt;0;")
add_test([=[kyberslash_fixed_probe_smoke]=] "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/build-poison/kyberslash_fixed_probe")
set_tests_properties([=[kyberslash_fixed_probe_smoke]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/docs/evidence/m2-kyberslash-20261016/version-audit/CMakeLists.txt;49;add_test;/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/docs/evidence/m2-kyberslash-20261016/version-audit/CMakeLists.txt;0;")

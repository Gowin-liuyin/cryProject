file(REMOVE_RECURSE
  "libkyberslash_unfixed_kernel.a"
)

# Empty dependencies file for kyberslash_fixed_probe.
# This may be replaced when dependencies are built.

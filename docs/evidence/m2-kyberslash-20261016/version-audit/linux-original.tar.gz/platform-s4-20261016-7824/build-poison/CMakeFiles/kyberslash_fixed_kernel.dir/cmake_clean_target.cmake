file(REMOVE_RECURSE
  "libkyberslash_fixed_kernel.a"
)

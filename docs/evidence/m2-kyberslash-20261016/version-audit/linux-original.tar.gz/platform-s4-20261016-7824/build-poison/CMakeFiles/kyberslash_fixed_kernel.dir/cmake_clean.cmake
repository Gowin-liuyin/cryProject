file(REMOVE_RECURSE
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/cbd.c.o"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/cbd.c.o.d"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/fips202.c.o"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/fips202.c.o.d"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/ntt.c.o"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/ntt.c.o.d"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/poly.c.o"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/poly.c.o.d"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/polyvec.c.o"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/polyvec.c.o.d"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/reduce.c.o"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/reduce.c.o.d"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/symmetric-shake.c.o"
  "CMakeFiles/kyberslash_fixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-fixed/ref/symmetric-shake.c.o.d"
  "libkyberslash_fixed_kernel.a"
  "libkyberslash_fixed_kernel.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/kyberslash_fixed_kernel.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

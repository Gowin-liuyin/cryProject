file(REMOVE_RECURSE
  "CMakeFiles/kyberslash_unfixed_probe.dir/poly_probe.c.o"
  "CMakeFiles/kyberslash_unfixed_probe.dir/poly_probe.c.o.d"
  "kyberslash_unfixed_probe"
  "kyberslash_unfixed_probe.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/kyberslash_unfixed_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

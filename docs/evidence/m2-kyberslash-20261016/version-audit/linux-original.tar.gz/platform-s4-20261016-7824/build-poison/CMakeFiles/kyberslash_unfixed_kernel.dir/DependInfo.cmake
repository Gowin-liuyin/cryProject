
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/cbd.c" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/cbd.c.o" "gcc" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/cbd.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/fips202.c" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/fips202.c.o" "gcc" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/fips202.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/ntt.c" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/ntt.c.o" "gcc" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/ntt.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/poly.c" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/poly.c.o" "gcc" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/poly.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/polyvec.c" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/polyvec.c.o" "gcc" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/polyvec.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/reduce.c" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/reduce.c.o" "gcc" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/reduce.c.o.d"
  "/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/symmetric-shake.c" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/symmetric-shake.c.o" "gcc" "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source-poison/vendor/kyber-kyberslash-unfixed/ref/symmetric-shake.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

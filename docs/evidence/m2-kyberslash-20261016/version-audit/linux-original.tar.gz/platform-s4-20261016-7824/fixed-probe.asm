
/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/build-smoke/kyberslash_fixed_probe:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 c1 3f 00 00 	mov    0x3fc1(%rip),%rax        # 4fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <puts@plt-0x10>:
    1020:	ff 35 ca 3f 00 00    	push   0x3fca(%rip)        # 4ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 3f 00 00    	jmp    *0x3fcc(%rip)        # 4ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001030 <puts@plt>:
    1030:	ff 25 ca 3f 00 00    	jmp    *0x3fca(%rip)        # 5000 <puts@GLIBC_2.2.5>
    1036:	68 00 00 00 00       	push   $0x0
    103b:	e9 e0 ff ff ff       	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001040 <__cxa_finalize@plt>:
    1040:	ff 25 9a 3f 00 00    	jmp    *0x3f9a(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1046:	66 90                	xchg   %ax,%ax

Disassembly of section .text:

0000000000001050 <_start>:
    1050:	f3 0f 1e fa          	endbr64
    1054:	31 ed                	xor    %ebp,%ebp
    1056:	49 89 d1             	mov    %rdx,%r9
    1059:	5e                   	pop    %rsi
    105a:	48 89 e2             	mov    %rsp,%rdx
    105d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    1061:	50                   	push   %rax
    1062:	54                   	push   %rsp
    1063:	45 31 c0             	xor    %r8d,%r8d
    1066:	31 c9                	xor    %ecx,%ecx
    1068:	48 8d 3d d1 00 00 00 	lea    0xd1(%rip),%rdi        # 1140 <main>
    106f:	ff 15 4b 3f 00 00    	call   *0x3f4b(%rip)        # 4fc0 <__libc_start_main@GLIBC_2.34>
    1075:	f4                   	hlt
    1076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    107d:	00 00 00 

0000000000001080 <deregister_tm_clones>:
    1080:	48 8d 3d 91 3f 00 00 	lea    0x3f91(%rip),%rdi        # 5018 <__TMC_END__>
    1087:	48 8d 05 8a 3f 00 00 	lea    0x3f8a(%rip),%rax        # 5018 <__TMC_END__>
    108e:	48 39 f8             	cmp    %rdi,%rax
    1091:	74 15                	je     10a8 <deregister_tm_clones+0x28>
    1093:	48 8b 05 2e 3f 00 00 	mov    0x3f2e(%rip),%rax        # 4fc8 <_ITM_deregisterTMCloneTable@Base>
    109a:	48 85 c0             	test   %rax,%rax
    109d:	74 09                	je     10a8 <deregister_tm_clones+0x28>
    109f:	ff e0                	jmp    *%rax
    10a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010b0 <register_tm_clones>:
    10b0:	48 8d 3d 61 3f 00 00 	lea    0x3f61(%rip),%rdi        # 5018 <__TMC_END__>
    10b7:	48 8d 35 5a 3f 00 00 	lea    0x3f5a(%rip),%rsi        # 5018 <__TMC_END__>
    10be:	48 29 fe             	sub    %rdi,%rsi
    10c1:	48 89 f0             	mov    %rsi,%rax
    10c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    10c8:	48 c1 f8 03          	sar    $0x3,%rax
    10cc:	48 01 c6             	add    %rax,%rsi
    10cf:	48 d1 fe             	sar    $1,%rsi
    10d2:	74 14                	je     10e8 <register_tm_clones+0x38>
    10d4:	48 8b 05 fd 3e 00 00 	mov    0x3efd(%rip),%rax        # 4fd8 <_ITM_registerTMCloneTable@Base>
    10db:	48 85 c0             	test   %rax,%rax
    10de:	74 08                	je     10e8 <register_tm_clones+0x38>
    10e0:	ff e0                	jmp    *%rax
    10e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010f0 <__do_global_dtors_aux>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	80 3d 1d 3f 00 00 00 	cmpb   $0x0,0x3f1d(%rip)        # 5018 <__TMC_END__>
    10fb:	75 2b                	jne    1128 <__do_global_dtors_aux+0x38>
    10fd:	55                   	push   %rbp
    10fe:	48 83 3d da 3e 00 00 	cmpq   $0x0,0x3eda(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1105:	00 
    1106:	48 89 e5             	mov    %rsp,%rbp
    1109:	74 0c                	je     1117 <__do_global_dtors_aux+0x27>
    110b:	48 8b 3d fe 3e 00 00 	mov    0x3efe(%rip),%rdi        # 5010 <__dso_handle>
    1112:	e8 29 ff ff ff       	call   1040 <__cxa_finalize@plt>
    1117:	e8 64 ff ff ff       	call   1080 <deregister_tm_clones>
    111c:	c6 05 f5 3e 00 00 01 	movb   $0x1,0x3ef5(%rip)        # 5018 <__TMC_END__>
    1123:	5d                   	pop    %rbp
    1124:	c3                   	ret
    1125:	0f 1f 00             	nopl   (%rax)
    1128:	c3                   	ret
    1129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001130 <frame_dummy>:
    1130:	f3 0f 1e fa          	endbr64
    1134:	e9 77 ff ff ff       	jmp    10b0 <register_tm_clones>
    1139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001140 <main>:
    1140:	55                   	push   %rbp
    1141:	48 89 e5             	mov    %rsp,%rbp
    1144:	48 81 ec a0 0c 00 00 	sub    $0xca0,%rsp
    114b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%rbp)
    1152:	c6 85 8f f3 ff ff 00 	movb   $0x0,-0xc71(%rbp)
    1159:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
    1160:	00 00 00 00 
    1164:	48 81 bd 80 f3 ff ff 	cmpq   $0x100,-0xc80(%rbp)
    116b:	00 01 00 00 
    116f:	0f 83 9f 00 00 00    	jae    1214 <main+0xd4>
    1175:	48 6b 85 80 f3 ff ff 	imul   $0xd,-0xc80(%rbp),%rax
    117c:	0d 
    117d:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    1182:	31 d2                	xor    %edx,%edx
    1184:	48 f7 f1             	div    %rcx
    1187:	66 89 d1             	mov    %dx,%cx
    118a:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1191:	66 89 8c 45 fc fd ff 	mov    %cx,-0x204(%rbp,%rax,2)
    1198:	ff 
    1199:	48 c7 85 78 f3 ff ff 	movq   $0x0,-0xc88(%rbp)
    11a0:	00 00 00 00 
    11a4:	48 83 bd 78 f3 ff ff 	cmpq   $0x3,-0xc88(%rbp)
    11ab:	03 
    11ac:	0f 83 46 00 00 00    	jae    11f8 <main+0xb8>
    11b2:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    11b9:	66 8b 94 45 fc fd ff 	mov    -0x204(%rbp,%rax,2),%dx
    11c0:	ff 
    11c1:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    11c8:	48 8b 8d 78 f3 ff ff 	mov    -0xc88(%rbp),%rcx
    11cf:	48 c1 e1 09          	shl    $0x9,%rcx
    11d3:	48 01 c8             	add    %rcx,%rax
    11d6:	48 8b 8d 80 f3 ff ff 	mov    -0xc80(%rbp),%rcx
    11dd:	66 89 14 48          	mov    %dx,(%rax,%rcx,2)
    11e1:	48 8b 85 78 f3 ff ff 	mov    -0xc88(%rbp),%rax
    11e8:	48 83 c0 01          	add    $0x1,%rax
    11ec:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
    11f3:	e9 ac ff ff ff       	jmp    11a4 <main+0x64>
    11f8:	e9 00 00 00 00       	jmp    11fd <main+0xbd>
    11fd:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1204:	48 83 c0 01          	add    $0x1,%rax
    1208:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
    120f:	e9 50 ff ff ff       	jmp    1164 <main+0x24>
    1214:	48 8d bd d0 f7 ff ff 	lea    -0x830(%rbp),%rdi
    121b:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1222:	e8 d5 02 00 00       	call   14fc <pqcrystals_kyber768_ref_poly_tomsg>
    1227:	48 8d bd 50 f7 ff ff 	lea    -0x8b0(%rbp),%rdi
    122e:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1235:	e8 26 01 00 00       	call   1360 <pqcrystals_kyber768_ref_poly_compress>
    123a:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
    1241:	48 8d b5 fc f7 ff ff 	lea    -0x804(%rbp),%rsi
    1248:	e8 9b 04 00 00       	call   16e8 <pqcrystals_kyber768_ref_polyvec_compress>
    124d:	48 c7 85 70 f3 ff ff 	movq   $0x0,-0xc90(%rbp)
    1254:	00 00 00 00 
    1258:	48 83 bd 70 f3 ff ff 	cmpq   $0x20,-0xc90(%rbp)
    125f:	20 
    1260:	0f 83 37 00 00 00    	jae    129d <main+0x15d>
    1266:	48 8b 85 70 f3 ff ff 	mov    -0xc90(%rbp),%rax
    126d:	0f b6 8c 05 d0 f7 ff 	movzbl -0x830(%rbp,%rax,1),%ecx
    1274:	ff 
    1275:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    127b:	0f b6 c0             	movzbl %al,%eax
    127e:	31 c8                	xor    %ecx,%eax
    1280:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    1286:	48 8b 85 70 f3 ff ff 	mov    -0xc90(%rbp),%rax
    128d:	48 83 c0 01          	add    $0x1,%rax
    1291:	48 89 85 70 f3 ff ff 	mov    %rax,-0xc90(%rbp)
    1298:	e9 bb ff ff ff       	jmp    1258 <main+0x118>
    129d:	48 c7 85 68 f3 ff ff 	movq   $0x0,-0xc98(%rbp)
    12a4:	00 00 00 00 
    12a8:	48 81 bd 68 f3 ff ff 	cmpq   $0x80,-0xc98(%rbp)
    12af:	80 00 00 00 
    12b3:	0f 83 37 00 00 00    	jae    12f0 <main+0x1b0>
    12b9:	48 8b 85 68 f3 ff ff 	mov    -0xc98(%rbp),%rax
    12c0:	0f b6 8c 05 50 f7 ff 	movzbl -0x8b0(%rbp,%rax,1),%ecx
    12c7:	ff 
    12c8:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    12ce:	0f b6 c0             	movzbl %al,%eax
    12d1:	31 c8                	xor    %ecx,%eax
    12d3:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    12d9:	48 8b 85 68 f3 ff ff 	mov    -0xc98(%rbp),%rax
    12e0:	48 83 c0 01          	add    $0x1,%rax
    12e4:	48 89 85 68 f3 ff ff 	mov    %rax,-0xc98(%rbp)
    12eb:	e9 b8 ff ff ff       	jmp    12a8 <main+0x168>
    12f0:	48 c7 85 60 f3 ff ff 	movq   $0x0,-0xca0(%rbp)
    12f7:	00 00 00 00 
    12fb:	48 81 bd 60 f3 ff ff 	cmpq   $0x3c0,-0xca0(%rbp)
    1302:	c0 03 00 00 
    1306:	0f 83 37 00 00 00    	jae    1343 <main+0x203>
    130c:	48 8b 85 60 f3 ff ff 	mov    -0xca0(%rbp),%rax
    1313:	0f b6 8c 05 90 f3 ff 	movzbl -0xc70(%rbp,%rax,1),%ecx
    131a:	ff 
    131b:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1321:	0f b6 c0             	movzbl %al,%eax
    1324:	31 c8                	xor    %ecx,%eax
    1326:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    132c:	48 8b 85 60 f3 ff ff 	mov    -0xca0(%rbp),%rax
    1333:	48 83 c0 01          	add    $0x1,%rax
    1337:	48 89 85 60 f3 ff ff 	mov    %rax,-0xca0(%rbp)
    133e:	e9 b8 ff ff ff       	jmp    12fb <main+0x1bb>
    1343:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1349:	48 8d 3d b4 1c 00 00 	lea    0x1cb4(%rip),%rdi        # 3004 <_IO_stdin_used+0x4>
    1350:	e8 db fc ff ff       	call   1030 <puts@plt>
    1355:	31 c0                	xor    %eax,%eax
    1357:	48 81 c4 a0 0c 00 00 	add    $0xca0,%rsp
    135e:	5d                   	pop    %rbp
    135f:	c3                   	ret

0000000000001360 <pqcrystals_kyber768_ref_poly_compress>:
    1360:	31 c0                	xor    %eax,%eax
    1362:	48 83 f8 20          	cmp    $0x20,%rax
    1366:	0f 84 80 00 00 00    	je     13ec <pqcrystals_kyber768_ref_poly_compress+0x8c>
    136c:	31 c9                	xor    %ecx,%ecx
    136e:	48 83 f9 08          	cmp    $0x8,%rcx
    1372:	74 31                	je     13a5 <pqcrystals_kyber768_ref_poly_compress+0x45>
    1374:	0f bf 14 4e          	movswl (%rsi,%rcx,2),%edx
    1378:	41 89 d0             	mov    %edx,%r8d
    137b:	41 c1 e8 0f          	shr    $0xf,%r8d
    137f:	41 81 e0 01 0d 00 00 	and    $0xd01,%r8d
    1386:	41 01 d0             	add    %edx,%r8d
    1389:	41 0f bf d0          	movswl %r8w,%edx
    138d:	69 d2 b0 af 13 00    	imul   $0x13afb0,%edx,%edx
    1393:	81 c2 7b 9a 00 08    	add    $0x8009a7b,%edx
    1399:	c1 ea 1c             	shr    $0x1c,%edx
    139c:	88 54 0c f8          	mov    %dl,-0x8(%rsp,%rcx,1)
    13a0:	48 ff c1             	inc    %rcx
    13a3:	eb c9                	jmp    136e <pqcrystals_kyber768_ref_poly_compress+0xe>
    13a5:	8a 4c 24 f9          	mov    -0x7(%rsp),%cl
    13a9:	c0 e1 04             	shl    $0x4,%cl
    13ac:	0a 4c 24 f8          	or     -0x8(%rsp),%cl
    13b0:	88 0f                	mov    %cl,(%rdi)
    13b2:	8a 4c 24 fb          	mov    -0x5(%rsp),%cl
    13b6:	c0 e1 04             	shl    $0x4,%cl
    13b9:	0a 4c 24 fa          	or     -0x6(%rsp),%cl
    13bd:	88 4f 01             	mov    %cl,0x1(%rdi)
    13c0:	8a 4c 24 fd          	mov    -0x3(%rsp),%cl
    13c4:	c0 e1 04             	shl    $0x4,%cl
    13c7:	0a 4c 24 fc          	or     -0x4(%rsp),%cl
    13cb:	88 4f 02             	mov    %cl,0x2(%rdi)
    13ce:	8a 4c 24 ff          	mov    -0x1(%rsp),%cl
    13d2:	c0 e1 04             	shl    $0x4,%cl
    13d5:	0a 4c 24 fe          	or     -0x2(%rsp),%cl
    13d9:	88 4f 03             	mov    %cl,0x3(%rdi)
    13dc:	48 83 c7 04          	add    $0x4,%rdi
    13e0:	48 ff c0             	inc    %rax
    13e3:	48 83 c6 10          	add    $0x10,%rsi
    13e7:	e9 76 ff ff ff       	jmp    1362 <pqcrystals_kyber768_ref_poly_compress+0x2>
    13ec:	c3                   	ret

00000000000013ed <pqcrystals_kyber768_ref_poly_decompress>:
    13ed:	31 c0                	xor    %eax,%eax
    13ef:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    13f5:	74 34                	je     142b <pqcrystals_kyber768_ref_poly_decompress+0x3e>
    13f7:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    13fb:	83 e1 0f             	and    $0xf,%ecx
    13fe:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    1404:	83 c1 08             	add    $0x8,%ecx
    1407:	c1 e9 04             	shr    $0x4,%ecx
    140a:	66 89 0c 87          	mov    %cx,(%rdi,%rax,4)
    140e:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    1412:	c1 e9 04             	shr    $0x4,%ecx
    1415:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    141b:	83 c1 08             	add    $0x8,%ecx
    141e:	c1 e9 04             	shr    $0x4,%ecx
    1421:	66 89 4c 87 02       	mov    %cx,0x2(%rdi,%rax,4)
    1426:	48 ff c0             	inc    %rax
    1429:	eb c4                	jmp    13ef <pqcrystals_kyber768_ref_poly_decompress+0x2>
    142b:	c3                   	ret

000000000000142c <pqcrystals_kyber768_ref_poly_tobytes>:
    142c:	48 83 c7 02          	add    $0x2,%rdi
    1430:	31 c0                	xor    %eax,%eax
    1432:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    1437:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    143d:	74 47                	je     1486 <pqcrystals_kyber768_ref_poly_tobytes+0x5a>
    143f:	44 0f bf 04 86       	movswl (%rsi,%rax,4),%r8d
    1444:	44 89 c2             	mov    %r8d,%edx
    1447:	c1 ea 0f             	shr    $0xf,%edx
    144a:	21 ca                	and    %ecx,%edx
    144c:	44 01 c2             	add    %r8d,%edx
    144f:	44 0f bf 44 86 02    	movswl 0x2(%rsi,%rax,4),%r8d
    1455:	45 89 c1             	mov    %r8d,%r9d
    1458:	41 c1 e9 0f          	shr    $0xf,%r9d
    145c:	41 21 c9             	and    %ecx,%r9d
    145f:	45 01 c1             	add    %r8d,%r9d
    1462:	88 57 fe             	mov    %dl,-0x2(%rdi)
    1465:	0f b6 d6             	movzbl %dh,%edx
    1468:	45 89 c8             	mov    %r9d,%r8d
    146b:	41 c1 e0 04          	shl    $0x4,%r8d
    146f:	41 09 d0             	or     %edx,%r8d
    1472:	44 88 47 ff          	mov    %r8b,-0x1(%rdi)
    1476:	41 c1 e9 04          	shr    $0x4,%r9d
    147a:	44 88 0f             	mov    %r9b,(%rdi)
    147d:	48 ff c0             	inc    %rax
    1480:	48 83 c7 03          	add    $0x3,%rdi
    1484:	eb b1                	jmp    1437 <pqcrystals_kyber768_ref_poly_tobytes+0xb>
    1486:	c3                   	ret

0000000000001487 <pqcrystals_kyber768_ref_poly_frombytes>:
    1487:	48 83 c6 02          	add    $0x2,%rsi
    148b:	31 c0                	xor    %eax,%eax
    148d:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    1493:	74 31                	je     14c6 <pqcrystals_kyber768_ref_poly_frombytes+0x3f>
    1495:	0f b6 4e fe          	movzbl -0x2(%rsi),%ecx
    1499:	0f b6 56 ff          	movzbl -0x1(%rsi),%edx
    149d:	83 e2 0f             	and    $0xf,%edx
    14a0:	c1 e2 08             	shl    $0x8,%edx
    14a3:	09 ca                	or     %ecx,%edx
    14a5:	66 89 14 87          	mov    %dx,(%rdi,%rax,4)
    14a9:	0f b6 4e ff          	movzbl -0x1(%rsi),%ecx
    14ad:	c1 e9 04             	shr    $0x4,%ecx
    14b0:	0f b6 16             	movzbl (%rsi),%edx
    14b3:	c1 e2 04             	shl    $0x4,%edx
    14b6:	09 ca                	or     %ecx,%edx
    14b8:	66 89 54 87 02       	mov    %dx,0x2(%rdi,%rax,4)
    14bd:	48 ff c0             	inc    %rax
    14c0:	48 83 c6 03          	add    $0x3,%rsi
    14c4:	eb c7                	jmp    148d <pqcrystals_kyber768_ref_poly_frombytes+0x6>
    14c6:	c3                   	ret

00000000000014c7 <pqcrystals_kyber768_ref_poly_frommsg>:
    14c7:	31 c0                	xor    %eax,%eax
    14c9:	48 83 f8 20          	cmp    $0x20,%rax
    14cd:	74 2c                	je     14fb <pqcrystals_kyber768_ref_poly_frommsg+0x34>
    14cf:	31 c9                	xor    %ecx,%ecx
    14d1:	48 83 f9 08          	cmp    $0x8,%rcx
    14d5:	74 1b                	je     14f2 <pqcrystals_kyber768_ref_poly_frommsg+0x2b>
    14d7:	44 0f b6 04 06       	movzbl (%rsi,%rax,1),%r8d
    14dc:	31 d2                	xor    %edx,%edx
    14de:	41 0f a3 c8          	bt     %ecx,%r8d
    14e2:	73 05                	jae    14e9 <pqcrystals_kyber768_ref_poly_frommsg+0x22>
    14e4:	ba 81 06 00 00       	mov    $0x681,%edx
    14e9:	66 89 14 4f          	mov    %dx,(%rdi,%rcx,2)
    14ed:	48 ff c1             	inc    %rcx
    14f0:	eb df                	jmp    14d1 <pqcrystals_kyber768_ref_poly_frommsg+0xa>
    14f2:	48 ff c0             	inc    %rax
    14f5:	48 83 c7 10          	add    $0x10,%rdi
    14f9:	eb ce                	jmp    14c9 <pqcrystals_kyber768_ref_poly_frommsg+0x2>
    14fb:	c3                   	ret

00000000000014fc <pqcrystals_kyber768_ref_poly_tomsg>:
    14fc:	31 c0                	xor    %eax,%eax
    14fe:	48 83 f8 20          	cmp    $0x20,%rax
    1502:	74 40                	je     1544 <pqcrystals_kyber768_ref_poly_tomsg+0x48>
    1504:	c6 04 07 00          	movb   $0x0,(%rdi,%rax,1)
    1508:	31 c9                	xor    %ecx,%ecx
    150a:	31 d2                	xor    %edx,%edx
    150c:	48 83 f9 08          	cmp    $0x8,%rcx
    1510:	74 29                	je     153b <pqcrystals_kyber768_ref_poly_tomsg+0x3f>
    1512:	44 0f bf 04 4e       	movswl (%rsi,%rcx,2),%r8d
    1517:	45 69 c0 f6 75 02 00 	imul   $0x275f6,%r8d,%r8d
    151e:	41 81 c0 7b 9a 00 08 	add    $0x8009a7b,%r8d
    1525:	41 c1 e8 1c          	shr    $0x1c,%r8d
    1529:	41 83 e0 01          	and    $0x1,%r8d
    152d:	41 d3 e0             	shl    %cl,%r8d
    1530:	44 08 c2             	or     %r8b,%dl
    1533:	88 14 07             	mov    %dl,(%rdi,%rax,1)
    1536:	48 ff c1             	inc    %rcx
    1539:	eb d1                	jmp    150c <pqcrystals_kyber768_ref_poly_tomsg+0x10>
    153b:	48 ff c0             	inc    %rax
    153e:	48 83 c6 10          	add    $0x10,%rsi
    1542:	eb ba                	jmp    14fe <pqcrystals_kyber768_ref_poly_tomsg+0x2>
    1544:	c3                   	ret

0000000000001545 <pqcrystals_kyber768_ref_poly_getnoise_eta1>:
    1545:	41 56                	push   %r14
    1547:	53                   	push   %rbx
    1548:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    154f:	89 d1                	mov    %edx,%ecx
    1551:	48 89 f2             	mov    %rsi,%rdx
    1554:	48 89 fb             	mov    %rdi,%rbx
    1557:	49 89 e6             	mov    %rsp,%r14
    155a:	be 80 00 00 00       	mov    $0x80,%esi
    155f:	4c 89 f7             	mov    %r14,%rdi
    1562:	e8 91 07 00 00       	call   1cf8 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    1567:	48 89 df             	mov    %rbx,%rdi
    156a:	4c 89 f6             	mov    %r14,%rsi
    156d:	e8 c6 06 00 00       	call   1c38 <pqcrystals_kyber768_ref_poly_cbd_eta1>
    1572:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    1579:	5b                   	pop    %rbx
    157a:	41 5e                	pop    %r14
    157c:	c3                   	ret

000000000000157d <pqcrystals_kyber768_ref_poly_getnoise_eta2>:
    157d:	41 56                	push   %r14
    157f:	53                   	push   %rbx
    1580:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    1587:	89 d1                	mov    %edx,%ecx
    1589:	48 89 f2             	mov    %rsi,%rdx
    158c:	48 89 fb             	mov    %rdi,%rbx
    158f:	49 89 e6             	mov    %rsp,%r14
    1592:	be 80 00 00 00       	mov    $0x80,%esi
    1597:	4c 89 f7             	mov    %r14,%rdi
    159a:	e8 59 07 00 00       	call   1cf8 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    159f:	48 89 df             	mov    %rbx,%rdi
    15a2:	4c 89 f6             	mov    %r14,%rsi
    15a5:	e8 f0 06 00 00       	call   1c9a <pqcrystals_kyber768_ref_poly_cbd_eta2>
    15aa:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    15b1:	5b                   	pop    %rbx
    15b2:	41 5e                	pop    %r14
    15b4:	c3                   	ret

00000000000015b5 <pqcrystals_kyber768_ref_poly_ntt>:
    15b5:	53                   	push   %rbx
    15b6:	48 89 fb             	mov    %rdi,%rbx
    15b9:	e8 86 04 00 00       	call   1a44 <pqcrystals_kyber768_ref_ntt>
    15be:	48 89 df             	mov    %rbx,%rdi
    15c1:	5b                   	pop    %rbx
    15c2:	e9 00 00 00 00       	jmp    15c7 <pqcrystals_kyber768_ref_poly_reduce>

00000000000015c7 <pqcrystals_kyber768_ref_poly_reduce>:
    15c7:	41 56                	push   %r14
    15c9:	53                   	push   %rbx
    15ca:	50                   	push   %rax
    15cb:	48 89 fb             	mov    %rdi,%rbx
    15ce:	45 31 f6             	xor    %r14d,%r14d
    15d1:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    15d8:	74 14                	je     15ee <pqcrystals_kyber768_ref_poly_reduce+0x27>
    15da:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    15df:	e8 cd 06 00 00       	call   1cb1 <pqcrystals_kyber768_ref_barrett_reduce>
    15e4:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    15e9:	49 ff c6             	inc    %r14
    15ec:	eb e3                	jmp    15d1 <pqcrystals_kyber768_ref_poly_reduce+0xa>
    15ee:	48 83 c4 08          	add    $0x8,%rsp
    15f2:	5b                   	pop    %rbx
    15f3:	41 5e                	pop    %r14
    15f5:	c3                   	ret

00000000000015f6 <pqcrystals_kyber768_ref_poly_invntt_tomont>:
    15f6:	e9 e8 04 00 00       	jmp    1ae3 <pqcrystals_kyber768_ref_invntt>

00000000000015fb <pqcrystals_kyber768_ref_poly_basemul_montgomery>:
    15fb:	55                   	push   %rbp
    15fc:	41 57                	push   %r15
    15fe:	41 56                	push   %r14
    1600:	41 55                	push   %r13
    1602:	41 54                	push   %r12
    1604:	53                   	push   %rbx
    1605:	50                   	push   %rax
    1606:	48 89 d3             	mov    %rdx,%rbx
    1609:	49 89 f6             	mov    %rsi,%r14
    160c:	49 89 ff             	mov    %rdi,%r15
    160f:	4c 8d 25 1a 1a 00 00 	lea    0x1a1a(%rip),%r12        # 3030 <pqcrystals_kyber768_ref_zetas>
    1616:	49 83 ec 80          	sub    $0xffffffffffffff80,%r12
    161a:	45 31 ed             	xor    %r13d,%r13d
    161d:	49 81 fd 00 02 00 00 	cmp    $0x200,%r13
    1624:	74 44                	je     166a <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x6f>
    1626:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    162a:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    162e:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    1632:	41 0f bf 2c 24       	movswl (%r12),%ebp
    1637:	89 e9                	mov    %ebp,%ecx
    1639:	e8 8a 05 00 00       	call   1bc8 <pqcrystals_kyber768_ref_basemul>
    163e:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    1642:	48 83 c7 04          	add    $0x4,%rdi
    1646:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    164a:	48 83 c6 04          	add    $0x4,%rsi
    164e:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    1652:	48 83 c2 04          	add    $0x4,%rdx
    1656:	f7 dd                	neg    %ebp
    1658:	0f bf cd             	movswl %bp,%ecx
    165b:	e8 68 05 00 00       	call   1bc8 <pqcrystals_kyber768_ref_basemul>
    1660:	49 83 c5 08          	add    $0x8,%r13
    1664:	49 83 c4 02          	add    $0x2,%r12
    1668:	eb b3                	jmp    161d <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x22>
    166a:	48 83 c4 08          	add    $0x8,%rsp
    166e:	5b                   	pop    %rbx
    166f:	41 5c                	pop    %r12
    1671:	41 5d                	pop    %r13
    1673:	41 5e                	pop    %r14
    1675:	41 5f                	pop    %r15
    1677:	5d                   	pop    %rbp
    1678:	c3                   	ret

0000000000001679 <pqcrystals_kyber768_ref_poly_tomont>:
    1679:	41 56                	push   %r14
    167b:	53                   	push   %rbx
    167c:	50                   	push   %rax
    167d:	48 89 fb             	mov    %rdi,%rbx
    1680:	45 31 f6             	xor    %r14d,%r14d
    1683:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    168a:	74 1a                	je     16a6 <pqcrystals_kyber768_ref_poly_tomont+0x2d>
    168c:	42 0f bf 04 73       	movswl (%rbx,%r14,2),%eax
    1691:	69 f8 49 05 00 00    	imul   $0x549,%eax,%edi
    1697:	e8 00 06 00 00       	call   1c9c <pqcrystals_kyber768_ref_montgomery_reduce>
    169c:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    16a1:	49 ff c6             	inc    %r14
    16a4:	eb dd                	jmp    1683 <pqcrystals_kyber768_ref_poly_tomont+0xa>
    16a6:	48 83 c4 08          	add    $0x8,%rsp
    16aa:	5b                   	pop    %rbx
    16ab:	41 5e                	pop    %r14
    16ad:	c3                   	ret

00000000000016ae <pqcrystals_kyber768_ref_poly_add>:
    16ae:	31 c0                	xor    %eax,%eax
    16b0:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    16b6:	74 11                	je     16c9 <pqcrystals_kyber768_ref_poly_add+0x1b>
    16b8:	0f b7 0c 42          	movzwl (%rdx,%rax,2),%ecx
    16bc:	66 03 0c 46          	add    (%rsi,%rax,2),%cx
    16c0:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    16c4:	48 ff c0             	inc    %rax
    16c7:	eb e7                	jmp    16b0 <pqcrystals_kyber768_ref_poly_add+0x2>
    16c9:	c3                   	ret

00000000000016ca <pqcrystals_kyber768_ref_poly_sub>:
    16ca:	31 c0                	xor    %eax,%eax
    16cc:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    16d2:	74 11                	je     16e5 <pqcrystals_kyber768_ref_poly_sub+0x1b>
    16d4:	0f b7 0c 46          	movzwl (%rsi,%rax,2),%ecx
    16d8:	66 2b 0c 42          	sub    (%rdx,%rax,2),%cx
    16dc:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    16e0:	48 ff c0             	inc    %rax
    16e3:	eb e7                	jmp    16cc <pqcrystals_kyber768_ref_poly_sub+0x2>
    16e5:	c3                   	ret
    16e6:	66 90                	xchg   %ax,%ax

00000000000016e8 <pqcrystals_kyber768_ref_polyvec_compress>:
    16e8:	31 c0                	xor    %eax,%eax
    16ea:	b9 37 d5 09 80       	mov    $0x8009d537,%ecx
    16ef:	48 83 f8 03          	cmp    $0x3,%rax
    16f3:	0f 84 ce 00 00 00    	je     17c7 <pqcrystals_kyber768_ref_polyvec_compress+0xdf>
    16f9:	48 89 f2             	mov    %rsi,%rdx
    16fc:	45 31 c0             	xor    %r8d,%r8d
    16ff:	49 83 f8 40          	cmp    $0x40,%r8
    1703:	0f 84 af 00 00 00    	je     17b8 <pqcrystals_kyber768_ref_polyvec_compress+0xd0>
    1709:	45 31 c9             	xor    %r9d,%r9d
    170c:	49 83 f9 04          	cmp    $0x4,%r9
    1710:	74 3a                	je     174c <pqcrystals_kyber768_ref_polyvec_compress+0x64>
    1712:	46 0f bf 14 4a       	movswl (%rdx,%r9,2),%r10d
    1717:	45 89 d3             	mov    %r10d,%r11d
    171a:	41 c1 eb 0f          	shr    $0xf,%r11d
    171e:	41 81 e3 01 0d 00 00 	and    $0xd01,%r11d
    1725:	45 01 d3             	add    %r10d,%r11d
    1728:	45 0f b7 d3          	movzwl %r11w,%r10d
    172c:	4d 69 d2 00 dc be 4e 	imul   $0x4ebedc00,%r10,%r10
    1733:	49 01 ca             	add    %rcx,%r10
    1736:	49 c1 ea 20          	shr    $0x20,%r10
    173a:	41 81 e2 ff 03 00 00 	and    $0x3ff,%r10d
    1741:	66 46 89 54 4c f8    	mov    %r10w,-0x8(%rsp,%r9,2)
    1747:	49 ff c1             	inc    %r9
    174a:	eb c0                	jmp    170c <pqcrystals_kyber768_ref_polyvec_compress+0x24>
    174c:	44 8a 4c 24 f8       	mov    -0x8(%rsp),%r9b
    1751:	44 88 0f             	mov    %r9b,(%rdi)
    1754:	44 8a 4c 24 fa       	mov    -0x6(%rsp),%r9b
    1759:	41 c0 e1 02          	shl    $0x2,%r9b
    175d:	44 0a 4c 24 f9       	or     -0x7(%rsp),%r9b
    1762:	44 88 4f 01          	mov    %r9b,0x1(%rdi)
    1766:	44 0f b7 4c 24 fa    	movzwl -0x6(%rsp),%r9d
    176c:	41 c1 e9 06          	shr    $0x6,%r9d
    1770:	44 8a 54 24 fc       	mov    -0x4(%rsp),%r10b
    1775:	41 c0 e2 04          	shl    $0x4,%r10b
    1779:	45 08 ca             	or     %r9b,%r10b
    177c:	44 88 57 02          	mov    %r10b,0x2(%rdi)
    1780:	44 0f b7 4c 24 fc    	movzwl -0x4(%rsp),%r9d
    1786:	41 c1 e9 04          	shr    $0x4,%r9d
    178a:	44 8a 54 24 fe       	mov    -0x2(%rsp),%r10b
    178f:	41 c0 e2 06          	shl    $0x6,%r10b
    1793:	45 08 ca             	or     %r9b,%r10b
    1796:	44 88 57 03          	mov    %r10b,0x3(%rdi)
    179a:	44 0f b7 4c 24 fe    	movzwl -0x2(%rsp),%r9d
    17a0:	41 c1 e9 02          	shr    $0x2,%r9d
    17a4:	44 88 4f 04          	mov    %r9b,0x4(%rdi)
    17a8:	48 83 c7 05          	add    $0x5,%rdi
    17ac:	49 ff c0             	inc    %r8
    17af:	48 83 c2 08          	add    $0x8,%rdx
    17b3:	e9 47 ff ff ff       	jmp    16ff <pqcrystals_kyber768_ref_polyvec_compress+0x17>
    17b8:	48 ff c0             	inc    %rax
    17bb:	48 81 c6 00 02 00 00 	add    $0x200,%rsi
    17c2:	e9 28 ff ff ff       	jmp    16ef <pqcrystals_kyber768_ref_polyvec_compress+0x7>
    17c7:	c3                   	ret

00000000000017c8 <pqcrystals_kyber768_ref_polyvec_decompress>:
    17c8:	31 c0                	xor    %eax,%eax
    17ca:	48 83 f8 03          	cmp    $0x3,%rax
    17ce:	0f 84 b8 00 00 00    	je     188c <pqcrystals_kyber768_ref_polyvec_decompress+0xc4>
    17d4:	48 89 f9             	mov    %rdi,%rcx
    17d7:	31 d2                	xor    %edx,%edx
    17d9:	48 83 fa 40          	cmp    $0x40,%rdx
    17dd:	0f 84 9a 00 00 00    	je     187d <pqcrystals_kyber768_ref_polyvec_decompress+0xb5>
    17e3:	44 0f b7 06          	movzwl (%rsi),%r8d
    17e7:	66 44 89 44 24 f8    	mov    %r8w,-0x8(%rsp)
    17ed:	44 0f b6 46 01       	movzbl 0x1(%rsi),%r8d
    17f2:	41 c1 e8 02          	shr    $0x2,%r8d
    17f6:	44 0f b6 4e 02       	movzbl 0x2(%rsi),%r9d
    17fb:	41 c1 e1 06          	shl    $0x6,%r9d
    17ff:	45 09 c1             	or     %r8d,%r9d
    1802:	66 44 89 4c 24 fa    	mov    %r9w,-0x6(%rsp)
    1808:	44 0f b6 46 02       	movzbl 0x2(%rsi),%r8d
    180d:	41 c1 e8 04          	shr    $0x4,%r8d
    1811:	44 0f b6 4e 03       	movzbl 0x3(%rsi),%r9d
    1816:	41 c1 e1 04          	shl    $0x4,%r9d
    181a:	45 09 c1             	or     %r8d,%r9d
    181d:	66 44 89 4c 24 fc    	mov    %r9w,-0x4(%rsp)
    1823:	44 0f b6 46 03       	movzbl 0x3(%rsi),%r8d
    1828:	41 c1 e8 06          	shr    $0x6,%r8d
    182c:	44 0f b6 4e 04       	movzbl 0x4(%rsi),%r9d
    1831:	47 8d 04 88          	lea    (%r8,%r9,4),%r8d
    1835:	66 44 89 44 24 fe    	mov    %r8w,-0x2(%rsp)
    183b:	45 31 c0             	xor    %r8d,%r8d
    183e:	49 83 f8 04          	cmp    $0x4,%r8
    1842:	74 29                	je     186d <pqcrystals_kyber768_ref_polyvec_decompress+0xa5>
    1844:	46 0f b7 4c 44 f8    	movzwl -0x8(%rsp,%r8,2),%r9d
    184a:	41 81 e1 ff 03 00 00 	and    $0x3ff,%r9d
    1851:	45 69 c9 01 0d 00 00 	imul   $0xd01,%r9d,%r9d
    1858:	41 81 c1 00 02 00 00 	add    $0x200,%r9d
    185f:	41 c1 e9 0a          	shr    $0xa,%r9d
    1863:	66 46 89 0c 41       	mov    %r9w,(%rcx,%r8,2)
    1868:	49 ff c0             	inc    %r8
    186b:	eb d1                	jmp    183e <pqcrystals_kyber768_ref_polyvec_decompress+0x76>
    186d:	48 83 c6 05          	add    $0x5,%rsi
    1871:	48 ff c2             	inc    %rdx
    1874:	48 83 c1 08          	add    $0x8,%rcx
    1878:	e9 5c ff ff ff       	jmp    17d9 <pqcrystals_kyber768_ref_polyvec_decompress+0x11>
    187d:	48 ff c0             	inc    %rax
    1880:	48 81 c7 00 02 00 00 	add    $0x200,%rdi
    1887:	e9 3e ff ff ff       	jmp    17ca <pqcrystals_kyber768_ref_polyvec_decompress+0x2>
    188c:	c3                   	ret

000000000000188d <pqcrystals_kyber768_ref_polyvec_tobytes>:
    188d:	41 57                	push   %r15
    188f:	41 56                	push   %r14
    1891:	53                   	push   %rbx
    1892:	48 89 f3             	mov    %rsi,%rbx
    1895:	49 89 fe             	mov    %rdi,%r14
    1898:	45 31 ff             	xor    %r15d,%r15d
    189b:	49 81 ff 00 06 00 00 	cmp    $0x600,%r15
    18a2:	74 1c                	je     18c0 <pqcrystals_kyber768_ref_polyvec_tobytes+0x33>
    18a4:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    18a8:	4c 89 f7             	mov    %r14,%rdi
    18ab:	e8 7c fb ff ff       	call   142c <pqcrystals_kyber768_ref_poly_tobytes>
    18b0:	49 81 c7 00 02 00 00 	add    $0x200,%r15
    18b7:	49 81 c6 80 01 00 00 	add    $0x180,%r14
    18be:	eb db                	jmp    189b <pqcrystals_kyber768_ref_polyvec_tobytes+0xe>
    18c0:	5b                   	pop    %rbx
    18c1:	41 5e                	pop    %r14
    18c3:	41 5f                	pop    %r15
    18c5:	c3                   	ret

00000000000018c6 <pqcrystals_kyber768_ref_polyvec_frombytes>:
    18c6:	41 57                	push   %r15
    18c8:	41 56                	push   %r14
    18ca:	53                   	push   %rbx
    18cb:	48 89 f3             	mov    %rsi,%rbx
    18ce:	49 89 fe             	mov    %rdi,%r14
    18d1:	45 31 ff             	xor    %r15d,%r15d
    18d4:	49 81 ff 80 04 00 00 	cmp    $0x480,%r15
    18db:	74 1c                	je     18f9 <pqcrystals_kyber768_ref_polyvec_frombytes+0x33>
    18dd:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    18e1:	4c 89 f7             	mov    %r14,%rdi
    18e4:	e8 9e fb ff ff       	call   1487 <pqcrystals_kyber768_ref_poly_frombytes>
    18e9:	49 81 c7 80 01 00 00 	add    $0x180,%r15
    18f0:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    18f7:	eb db                	jmp    18d4 <pqcrystals_kyber768_ref_polyvec_frombytes+0xe>
    18f9:	5b                   	pop    %rbx
    18fa:	41 5e                	pop    %r14
    18fc:	41 5f                	pop    %r15
    18fe:	c3                   	ret

00000000000018ff <pqcrystals_kyber768_ref_polyvec_ntt>:
    18ff:	41 56                	push   %r14
    1901:	53                   	push   %rbx
    1902:	50                   	push   %rax
    1903:	48 89 fb             	mov    %rdi,%rbx
    1906:	45 31 f6             	xor    %r14d,%r14d
    1909:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1910:	74 12                	je     1924 <pqcrystals_kyber768_ref_polyvec_ntt+0x25>
    1912:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1916:	e8 9a fc ff ff       	call   15b5 <pqcrystals_kyber768_ref_poly_ntt>
    191b:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1922:	eb e5                	jmp    1909 <pqcrystals_kyber768_ref_polyvec_ntt+0xa>
    1924:	48 83 c4 08          	add    $0x8,%rsp
    1928:	5b                   	pop    %rbx
    1929:	41 5e                	pop    %r14
    192b:	c3                   	ret

000000000000192c <pqcrystals_kyber768_ref_polyvec_invntt_tomont>:
    192c:	41 56                	push   %r14
    192e:	53                   	push   %rbx
    192f:	50                   	push   %rax
    1930:	48 89 fb             	mov    %rdi,%rbx
    1933:	45 31 f6             	xor    %r14d,%r14d
    1936:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    193d:	74 12                	je     1951 <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0x25>
    193f:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1943:	e8 ae fc ff ff       	call   15f6 <pqcrystals_kyber768_ref_poly_invntt_tomont>
    1948:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    194f:	eb e5                	jmp    1936 <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0xa>
    1951:	48 83 c4 08          	add    $0x8,%rsp
    1955:	5b                   	pop    %rbx
    1956:	41 5e                	pop    %r14
    1958:	c3                   	ret

0000000000001959 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery>:
    1959:	41 57                	push   %r15
    195b:	41 56                	push   %r14
    195d:	41 55                	push   %r13
    195f:	41 54                	push   %r12
    1961:	53                   	push   %rbx
    1962:	48 81 ec 00 02 00 00 	sub    $0x200,%rsp
    1969:	49 89 d6             	mov    %rdx,%r14
    196c:	49 89 f7             	mov    %rsi,%r15
    196f:	48 89 fb             	mov    %rdi,%rbx
    1972:	e8 84 fc ff ff       	call   15fb <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    1977:	b8 00 02 00 00       	mov    $0x200,%eax
    197c:	49 01 c7             	add    %rax,%r15
    197f:	49 01 c6             	add    %rax,%r14
    1982:	45 31 ed             	xor    %r13d,%r13d
    1985:	49 89 e4             	mov    %rsp,%r12
    1988:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
    198f:	74 27                	je     19b8 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x5f>
    1991:	4b 8d 34 2f          	lea    (%r15,%r13,1),%rsi
    1995:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
    1999:	4c 89 e7             	mov    %r12,%rdi
    199c:	e8 5a fc ff ff       	call   15fb <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    19a1:	48 89 df             	mov    %rbx,%rdi
    19a4:	48 89 de             	mov    %rbx,%rsi
    19a7:	4c 89 e2             	mov    %r12,%rdx
    19aa:	e8 ff fc ff ff       	call   16ae <pqcrystals_kyber768_ref_poly_add>
    19af:	49 81 c5 00 02 00 00 	add    $0x200,%r13
    19b6:	eb d0                	jmp    1988 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x2f>
    19b8:	48 89 df             	mov    %rbx,%rdi
    19bb:	e8 07 fc ff ff       	call   15c7 <pqcrystals_kyber768_ref_poly_reduce>
    19c0:	48 81 c4 00 02 00 00 	add    $0x200,%rsp
    19c7:	5b                   	pop    %rbx
    19c8:	41 5c                	pop    %r12
    19ca:	41 5d                	pop    %r13
    19cc:	41 5e                	pop    %r14
    19ce:	41 5f                	pop    %r15
    19d0:	c3                   	ret

00000000000019d1 <pqcrystals_kyber768_ref_polyvec_reduce>:
    19d1:	41 56                	push   %r14
    19d3:	53                   	push   %rbx
    19d4:	50                   	push   %rax
    19d5:	48 89 fb             	mov    %rdi,%rbx
    19d8:	45 31 f6             	xor    %r14d,%r14d
    19db:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    19e2:	74 12                	je     19f6 <pqcrystals_kyber768_ref_polyvec_reduce+0x25>
    19e4:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    19e8:	e8 da fb ff ff       	call   15c7 <pqcrystals_kyber768_ref_poly_reduce>
    19ed:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    19f4:	eb e5                	jmp    19db <pqcrystals_kyber768_ref_polyvec_reduce+0xa>
    19f6:	48 83 c4 08          	add    $0x8,%rsp
    19fa:	5b                   	pop    %rbx
    19fb:	41 5e                	pop    %r14
    19fd:	c3                   	ret

00000000000019fe <pqcrystals_kyber768_ref_polyvec_add>:
    19fe:	41 57                	push   %r15
    1a00:	41 56                	push   %r14
    1a02:	41 54                	push   %r12
    1a04:	53                   	push   %rbx
    1a05:	50                   	push   %rax
    1a06:	48 89 d3             	mov    %rdx,%rbx
    1a09:	49 89 f6             	mov    %rsi,%r14
    1a0c:	49 89 ff             	mov    %rdi,%r15
    1a0f:	45 31 e4             	xor    %r12d,%r12d
    1a12:	49 81 fc 00 06 00 00 	cmp    $0x600,%r12
    1a19:	74 1a                	je     1a35 <pqcrystals_kyber768_ref_polyvec_add+0x37>
    1a1b:	4b 8d 3c 27          	lea    (%r15,%r12,1),%rdi
    1a1f:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    1a23:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
    1a27:	e8 82 fc ff ff       	call   16ae <pqcrystals_kyber768_ref_poly_add>
    1a2c:	49 81 c4 00 02 00 00 	add    $0x200,%r12
    1a33:	eb dd                	jmp    1a12 <pqcrystals_kyber768_ref_polyvec_add+0x14>
    1a35:	48 83 c4 08          	add    $0x8,%rsp
    1a39:	5b                   	pop    %rbx
    1a3a:	41 5c                	pop    %r12
    1a3c:	41 5e                	pop    %r14
    1a3e:	41 5f                	pop    %r15
    1a40:	c3                   	ret
    1a41:	0f 1f 00             	nopl   (%rax)

0000000000001a44 <pqcrystals_kyber768_ref_ntt>:
    1a44:	55                   	push   %rbp
    1a45:	41 57                	push   %r15
    1a47:	41 56                	push   %r14
    1a49:	41 55                	push   %r13
    1a4b:	41 54                	push   %r12
    1a4d:	53                   	push   %rbx
    1a4e:	50                   	push   %rax
    1a4f:	48 89 fb             	mov    %rdi,%rbx
    1a52:	b9 80 00 00 00       	mov    $0x80,%ecx
    1a57:	6a 01                	push   $0x1
    1a59:	58                   	pop    %rax
    1a5a:	83 f9 02             	cmp    $0x2,%ecx
    1a5d:	72 6d                	jb     1acc <pqcrystals_kyber768_ref_ntt+0x88>
    1a5f:	41 89 cd             	mov    %ecx,%r13d
    1a62:	45 31 f6             	xor    %r14d,%r14d
    1a65:	89 0c 24             	mov    %ecx,(%rsp)
    1a68:	41 81 fe ff 00 00 00 	cmp    $0xff,%r14d
    1a6f:	77 57                	ja     1ac8 <pqcrystals_kyber768_ref_ntt+0x84>
    1a71:	89 44 24 04          	mov    %eax,0x4(%rsp)
    1a75:	89 c0                	mov    %eax,%eax
    1a77:	45 89 f4             	mov    %r14d,%r12d
    1a7a:	41 01 ce             	add    %ecx,%r14d
    1a7d:	48 8d 0d ac 15 00 00 	lea    0x15ac(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1a84:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1a88:	4d 39 f4             	cmp    %r14,%r12
    1a8b:	73 2a                	jae    1ab7 <pqcrystals_kyber768_ref_ntt+0x73>
    1a8d:	47 8d 3c 2c          	lea    (%r12,%r13,1),%r15d
    1a91:	42 0f bf 34 7b       	movswl (%rbx,%r15,2),%esi
    1a96:	89 ef                	mov    %ebp,%edi
    1a98:	e8 3e 00 00 00       	call   1adb <fqmul>
    1a9d:	42 0f b7 0c 63       	movzwl (%rbx,%r12,2),%ecx
    1aa2:	89 ca                	mov    %ecx,%edx
    1aa4:	29 c2                	sub    %eax,%edx
    1aa6:	66 42 89 14 7b       	mov    %dx,(%rbx,%r15,2)
    1aab:	01 c1                	add    %eax,%ecx
    1aad:	66 42 89 0c 63       	mov    %cx,(%rbx,%r12,2)
    1ab2:	49 ff c4             	inc    %r12
    1ab5:	eb d1                	jmp    1a88 <pqcrystals_kyber768_ref_ntt+0x44>
    1ab7:	8b 44 24 04          	mov    0x4(%rsp),%eax
    1abb:	ff c0                	inc    %eax
    1abd:	45 01 ec             	add    %r13d,%r12d
    1ac0:	45 89 e6             	mov    %r12d,%r14d
    1ac3:	8b 0c 24             	mov    (%rsp),%ecx
    1ac6:	eb a0                	jmp    1a68 <pqcrystals_kyber768_ref_ntt+0x24>
    1ac8:	d1 e9                	shr    $1,%ecx
    1aca:	eb 8e                	jmp    1a5a <pqcrystals_kyber768_ref_ntt+0x16>
    1acc:	48 83 c4 08          	add    $0x8,%rsp
    1ad0:	5b                   	pop    %rbx
    1ad1:	41 5c                	pop    %r12
    1ad3:	41 5d                	pop    %r13
    1ad5:	41 5e                	pop    %r14
    1ad7:	41 5f                	pop    %r15
    1ad9:	5d                   	pop    %rbp
    1ada:	c3                   	ret

0000000000001adb <fqmul>:
    1adb:	0f af fe             	imul   %esi,%edi
    1ade:	e9 b9 01 00 00       	jmp    1c9c <pqcrystals_kyber768_ref_montgomery_reduce>

0000000000001ae3 <pqcrystals_kyber768_ref_invntt>:
    1ae3:	55                   	push   %rbp
    1ae4:	41 57                	push   %r15
    1ae6:	41 56                	push   %r14
    1ae8:	41 55                	push   %r13
    1aea:	41 54                	push   %r12
    1aec:	53                   	push   %rbx
    1aed:	48 83 ec 18          	sub    $0x18,%rsp
    1af1:	48 89 fb             	mov    %rdi,%rbx
    1af4:	6a 02                	push   $0x2
    1af6:	59                   	pop    %rcx
    1af7:	6a 7f                	push   $0x7f
    1af9:	58                   	pop    %rax
    1afa:	81 f9 81 00 00 00    	cmp    $0x81,%ecx
    1b00:	0f 83 8e 00 00 00    	jae    1b94 <pqcrystals_kyber768_ref_invntt+0xb1>
    1b06:	89 ca                	mov    %ecx,%edx
    1b08:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    1b0d:	4c 8d 24 53          	lea    (%rbx,%rdx,2),%r12
    1b11:	45 31 ed             	xor    %r13d,%r13d
    1b14:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
    1b18:	41 81 fd ff 00 00 00 	cmp    $0xff,%r13d
    1b1f:	77 6c                	ja     1b8d <pqcrystals_kyber768_ref_invntt+0xaa>
    1b21:	89 44 24 0c          	mov    %eax,0xc(%rsp)
    1b25:	89 c0                	mov    %eax,%eax
    1b27:	45 89 ee             	mov    %r13d,%r14d
    1b2a:	41 01 cd             	add    %ecx,%r13d
    1b2d:	48 8d 0d fc 14 00 00 	lea    0x14fc(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1b34:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1b38:	4d 39 ee             	cmp    %r13,%r14
    1b3b:	73 3c                	jae    1b79 <pqcrystals_kyber768_ref_invntt+0x96>
    1b3d:	46 0f b7 3c 73       	movzwl (%rbx,%r14,2),%r15d
    1b42:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1b47:	66 44 01 f8          	add    %r15w,%ax
    1b4b:	0f bf f8             	movswl %ax,%edi
    1b4e:	e8 5e 01 00 00       	call   1cb1 <pqcrystals_kyber768_ref_barrett_reduce>
    1b53:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1b58:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1b5d:	44 29 f8             	sub    %r15d,%eax
    1b60:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1b65:	0f bf f0             	movswl %ax,%esi
    1b68:	89 ef                	mov    %ebp,%edi
    1b6a:	e8 6c ff ff ff       	call   1adb <fqmul>
    1b6f:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1b74:	49 ff c6             	inc    %r14
    1b77:	eb bf                	jmp    1b38 <pqcrystals_kyber768_ref_invntt+0x55>
    1b79:	8b 44 24 0c          	mov    0xc(%rsp),%eax
    1b7d:	ff c8                	dec    %eax
    1b7f:	44 03 74 24 10       	add    0x10(%rsp),%r14d
    1b84:	45 89 f5             	mov    %r14d,%r13d
    1b87:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
    1b8b:	eb 8b                	jmp    1b18 <pqcrystals_kyber768_ref_invntt+0x35>
    1b8d:	01 c9                	add    %ecx,%ecx
    1b8f:	e9 66 ff ff ff       	jmp    1afa <pqcrystals_kyber768_ref_invntt+0x17>
    1b94:	45 31 f6             	xor    %r14d,%r14d
    1b97:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    1b9e:	74 19                	je     1bb9 <pqcrystals_kyber768_ref_invntt+0xd6>
    1ba0:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    1ba5:	be a1 05 00 00       	mov    $0x5a1,%esi
    1baa:	e8 2c ff ff ff       	call   1adb <fqmul>
    1baf:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1bb4:	49 ff c6             	inc    %r14
    1bb7:	eb de                	jmp    1b97 <pqcrystals_kyber768_ref_invntt+0xb4>
    1bb9:	48 83 c4 18          	add    $0x18,%rsp
    1bbd:	5b                   	pop    %rbx
    1bbe:	41 5c                	pop    %r12
    1bc0:	41 5d                	pop    %r13
    1bc2:	41 5e                	pop    %r14
    1bc4:	41 5f                	pop    %r15
    1bc6:	5d                   	pop    %rbp
    1bc7:	c3                   	ret

0000000000001bc8 <pqcrystals_kyber768_ref_basemul>:
    1bc8:	55                   	push   %rbp
    1bc9:	41 57                	push   %r15
    1bcb:	41 56                	push   %r14
    1bcd:	53                   	push   %rbx
    1bce:	50                   	push   %rax
    1bcf:	89 cd                	mov    %ecx,%ebp
    1bd1:	49 89 d6             	mov    %rdx,%r14
    1bd4:	49 89 f7             	mov    %rsi,%r15
    1bd7:	48 89 fb             	mov    %rdi,%rbx
    1bda:	0f bf 7e 02          	movswl 0x2(%rsi),%edi
    1bde:	0f bf 72 02          	movswl 0x2(%rdx),%esi
    1be2:	e8 f4 fe ff ff       	call   1adb <fqmul>
    1be7:	66 89 03             	mov    %ax,(%rbx)
    1bea:	0f bf f8             	movswl %ax,%edi
    1bed:	89 ee                	mov    %ebp,%esi
    1bef:	e8 e7 fe ff ff       	call   1adb <fqmul>
    1bf4:	66 89 03             	mov    %ax,(%rbx)
    1bf7:	41 0f bf 3f          	movswl (%r15),%edi
    1bfb:	41 0f bf 36          	movswl (%r14),%esi
    1bff:	e8 d7 fe ff ff       	call   1adb <fqmul>
    1c04:	66 01 03             	add    %ax,(%rbx)
    1c07:	41 0f bf 3f          	movswl (%r15),%edi
    1c0b:	41 0f bf 76 02       	movswl 0x2(%r14),%esi
    1c10:	e8 c6 fe ff ff       	call   1adb <fqmul>
    1c15:	66 89 43 02          	mov    %ax,0x2(%rbx)
    1c19:	41 0f bf 7f 02       	movswl 0x2(%r15),%edi
    1c1e:	41 0f bf 36          	movswl (%r14),%esi
    1c22:	e8 b4 fe ff ff       	call   1adb <fqmul>
    1c27:	66 01 43 02          	add    %ax,0x2(%rbx)
    1c2b:	48 83 c4 08          	add    $0x8,%rsp
    1c2f:	5b                   	pop    %rbx
    1c30:	41 5e                	pop    %r14
    1c32:	41 5f                	pop    %r15
    1c34:	5d                   	pop    %rbp
    1c35:	c3                   	ret
    1c36:	66 90                	xchg   %ax,%ax

0000000000001c38 <pqcrystals_kyber768_ref_poly_cbd_eta1>:
    1c38:	eb 00                	jmp    1c3a <cbd2>

0000000000001c3a <cbd2>:
    1c3a:	53                   	push   %rbx
    1c3b:	31 d2                	xor    %edx,%edx
    1c3d:	41 b8 55 55 55 55    	mov    $0x55555555,%r8d
    1c43:	48 83 fa 20          	cmp    $0x20,%rdx
    1c47:	74 4f                	je     1c98 <cbd2+0x5e>
    1c49:	44 8b 0c 96          	mov    (%rsi,%rdx,4),%r9d
    1c4d:	44 89 c8             	mov    %r9d,%eax
    1c50:	44 21 c0             	and    %r8d,%eax
    1c53:	41 d1 e9             	shr    $1,%r9d
    1c56:	45 21 c1             	and    %r8d,%r9d
    1c59:	41 01 c1             	add    %eax,%r9d
    1c5c:	49 89 fa             	mov    %rdi,%r10
    1c5f:	31 c0                	xor    %eax,%eax
    1c61:	48 83 f8 20          	cmp    $0x20,%rax
    1c65:	74 28                	je     1c8f <cbd2+0x55>
    1c67:	45 89 cb             	mov    %r9d,%r11d
    1c6a:	89 c1                	mov    %eax,%ecx
    1c6c:	41 d3 eb             	shr    %cl,%r11d
    1c6f:	41 83 e3 03          	and    $0x3,%r11d
    1c73:	8d 48 02             	lea    0x2(%rax),%ecx
    1c76:	44 89 cb             	mov    %r9d,%ebx
    1c79:	d3 eb                	shr    %cl,%ebx
    1c7b:	83 e3 03             	and    $0x3,%ebx
    1c7e:	41 29 db             	sub    %ebx,%r11d
    1c81:	66 45 89 1a          	mov    %r11w,(%r10)
    1c85:	48 83 c0 04          	add    $0x4,%rax
    1c89:	49 83 c2 02          	add    $0x2,%r10
    1c8d:	eb d2                	jmp    1c61 <cbd2+0x27>
    1c8f:	48 ff c2             	inc    %rdx
    1c92:	48 83 c7 10          	add    $0x10,%rdi
    1c96:	eb ab                	jmp    1c43 <cbd2+0x9>
    1c98:	5b                   	pop    %rbx
    1c99:	c3                   	ret

0000000000001c9a <pqcrystals_kyber768_ref_poly_cbd_eta2>:
    1c9a:	eb 9e                	jmp    1c3a <cbd2>

0000000000001c9c <pqcrystals_kyber768_ref_montgomery_reduce>:
    1c9c:	69 c7 00 00 01 f3    	imul   $0xf3010000,%edi,%eax
    1ca2:	c1 f8 10             	sar    $0x10,%eax
    1ca5:	69 c0 ff f2 ff ff    	imul   $0xfffff2ff,%eax,%eax
    1cab:	01 f8                	add    %edi,%eax
    1cad:	c1 e8 10             	shr    $0x10,%eax
    1cb0:	c3                   	ret

0000000000001cb1 <pqcrystals_kyber768_ref_barrett_reduce>:
    1cb1:	89 f8                	mov    %edi,%eax
    1cb3:	69 cf bf 4e 00 00    	imul   $0x4ebf,%edi,%ecx
    1cb9:	81 c1 00 00 00 02    	add    $0x2000000,%ecx
    1cbf:	c1 f9 1a             	sar    $0x1a,%ecx
    1cc2:	69 c9 00 00 01 0d    	imul   $0xd010000,%ecx,%ecx
    1cc8:	c1 e9 10             	shr    $0x10,%ecx
    1ccb:	29 c8                	sub    %ecx,%eax
    1ccd:	c3                   	ret
    1cce:	66 90                	xchg   %ax,%ax

0000000000001cd0 <pqcrystals_kyber768_ref_kyber_shake128_absorb>:
    1cd0:	48 83 ec 28          	sub    $0x28,%rsp
    1cd4:	0f 10 06             	movups (%rsi),%xmm0
    1cd7:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
    1cdb:	48 89 e6             	mov    %rsp,%rsi
    1cde:	0f 29 4e 10          	movaps %xmm1,0x10(%rsi)
    1ce2:	0f 29 06             	movaps %xmm0,(%rsi)
    1ce5:	88 56 20             	mov    %dl,0x20(%rsi)
    1ce8:	88 4e 21             	mov    %cl,0x21(%rsi)
    1ceb:	6a 22                	push   $0x22
    1ced:	5a                   	pop    %rdx
    1cee:	e8 d0 01 00 00       	call   1ec3 <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    1cf3:	48 83 c4 28          	add    $0x28,%rsp
    1cf7:	c3                   	ret

0000000000001cf8 <pqcrystals_kyber768_ref_kyber_shake256_prf>:
    1cf8:	48 83 ec 28          	sub    $0x28,%rsp
    1cfc:	0f 10 02             	movups (%rdx),%xmm0
    1cff:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
    1d03:	48 89 e2             	mov    %rsp,%rdx
    1d06:	0f 29 4a 10          	movaps %xmm1,0x10(%rdx)
    1d0a:	0f 29 02             	movaps %xmm0,(%rdx)
    1d0d:	88 4a 20             	mov    %cl,0x20(%rdx)
    1d10:	6a 21                	push   $0x21
    1d12:	59                   	pop    %rcx
    1d13:	e8 22 04 00 00       	call   213a <pqcrystals_kyber_fips202_ref_shake256>
    1d18:	48 83 c4 28          	add    $0x28,%rsp
    1d1c:	c3                   	ret
    1d1d:	0f 1f 00             	nopl   (%rax)

0000000000001d20 <pqcrystals_kyber_fips202_ref_shake128_init>:
    1d20:	53                   	push   %rbx
    1d21:	48 89 fb             	mov    %rdi,%rbx
    1d24:	e8 09 00 00 00       	call   1d32 <keccak_init>
    1d29:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    1d30:	5b                   	pop    %rbx
    1d31:	c3                   	ret

0000000000001d32 <keccak_init>:
    1d32:	31 c0                	xor    %eax,%eax
    1d34:	48 83 f8 19          	cmp    $0x19,%rax
    1d38:	74 0a                	je     1d44 <keccak_init+0x12>
    1d3a:	48 83 24 c7 00       	andq   $0x0,(%rdi,%rax,8)
    1d3f:	48 ff c0             	inc    %rax
    1d42:	eb f0                	jmp    1d34 <keccak_init+0x2>
    1d44:	c3                   	ret

0000000000001d45 <pqcrystals_kyber_fips202_ref_shake128_absorb>:
    1d45:	53                   	push   %rbx
    1d46:	49 89 d0             	mov    %rdx,%r8
    1d49:	48 89 f1             	mov    %rsi,%rcx
    1d4c:	48 89 fb             	mov    %rdi,%rbx
    1d4f:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    1d55:	ba a8 00 00 00       	mov    $0xa8,%edx
    1d5a:	e8 08 00 00 00       	call   1d67 <keccak_absorb>
    1d5f:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    1d65:	5b                   	pop    %rbx
    1d66:	c3                   	ret

0000000000001d67 <keccak_absorb>:
    1d67:	55                   	push   %rbp
    1d68:	41 57                	push   %r15
    1d6a:	41 56                	push   %r14
    1d6c:	41 54                	push   %r12
    1d6e:	53                   	push   %rbx
    1d6f:	4d 89 c7             	mov    %r8,%r15
    1d72:	48 89 cb             	mov    %rcx,%rbx
    1d75:	89 d5                	mov    %edx,%ebp
    1d77:	89 f0                	mov    %esi,%eax
    1d79:	49 89 fe             	mov    %rdi,%r14
    1d7c:	41 89 d4             	mov    %edx,%r12d
    1d7f:	89 c2                	mov    %eax,%edx
    1d81:	4c 01 fa             	add    %r15,%rdx
    1d84:	4c 39 e2             	cmp    %r12,%rdx
    1d87:	72 3e                	jb     1dc7 <keccak_absorb+0x60>
    1d89:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
    1d90:	89 c6                	mov    %eax,%esi
    1d92:	39 ee                	cmp    %ebp,%esi
    1d94:	73 1e                	jae    1db4 <keccak_absorb+0x4d>
    1d96:	0f b6 3b             	movzbl (%rbx),%edi
    1d99:	89 d1                	mov    %edx,%ecx
    1d9b:	80 e1 38             	and    $0x38,%cl
    1d9e:	48 d3 e7             	shl    %cl,%rdi
    1da1:	89 f1                	mov    %esi,%ecx
    1da3:	83 e1 f8             	and    $0xfffffff8,%ecx
    1da6:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    1daa:	48 ff c3             	inc    %rbx
    1dad:	ff c6                	inc    %esi
    1daf:	83 c2 08             	add    $0x8,%edx
    1db2:	eb de                	jmp    1d92 <keccak_absorb+0x2b>
    1db4:	89 e9                	mov    %ebp,%ecx
    1db6:	29 c1                	sub    %eax,%ecx
    1db8:	49 29 cf             	sub    %rcx,%r15
    1dbb:	4c 89 f7             	mov    %r14,%rdi
    1dbe:	e8 39 04 00 00       	call   21fc <KeccakF1600_StatePermute>
    1dc3:	31 c0                	xor    %eax,%eax
    1dc5:	eb b8                	jmp    1d7f <keccak_absorb+0x18>
    1dc7:	8d 34 c5 00 00 00 00 	lea    0x0(,%rax,8),%esi
    1dce:	89 c1                	mov    %eax,%ecx
    1dd0:	48 39 ca             	cmp    %rcx,%rdx
    1dd3:	76 1e                	jbe    1df3 <keccak_absorb+0x8c>
    1dd5:	0f b6 3b             	movzbl (%rbx),%edi
    1dd8:	89 f1                	mov    %esi,%ecx
    1dda:	80 e1 38             	and    $0x38,%cl
    1ddd:	48 d3 e7             	shl    %cl,%rdi
    1de0:	89 c1                	mov    %eax,%ecx
    1de2:	83 e1 f8             	and    $0xfffffff8,%ecx
    1de5:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    1de9:	48 ff c3             	inc    %rbx
    1dec:	ff c0                	inc    %eax
    1dee:	83 c6 08             	add    $0x8,%esi
    1df1:	eb db                	jmp    1dce <keccak_absorb+0x67>
    1df3:	5b                   	pop    %rbx
    1df4:	41 5c                	pop    %r12
    1df6:	41 5e                	pop    %r14
    1df8:	41 5f                	pop    %r15
    1dfa:	5d                   	pop    %rbp
    1dfb:	c3                   	ret

0000000000001dfc <pqcrystals_kyber_fips202_ref_shake128_finalize>:
    1dfc:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    1e02:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    1e09:	6a 1f                	push   $0x1f
    1e0b:	5a                   	pop    %rdx
    1e0c:	48 d3 e2             	shl    %cl,%rdx
    1e0f:	83 e0 f8             	and    $0xfffffff8,%eax
    1e12:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    1e16:	80 b7 a7 00 00 00 80 	xorb   $0x80,0xa7(%rdi)
    1e1d:	c7 87 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rdi)
    1e24:	00 00 00 
    1e27:	c3                   	ret

0000000000001e28 <pqcrystals_kyber_fips202_ref_shake128_squeeze>:
    1e28:	53                   	push   %rbx
    1e29:	48 89 d3             	mov    %rdx,%rbx
    1e2c:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    1e32:	41 b8 a8 00 00 00    	mov    $0xa8,%r8d
    1e38:	e8 08 00 00 00       	call   1e45 <keccak_squeeze>
    1e3d:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    1e43:	5b                   	pop    %rbx
    1e44:	c3                   	ret

0000000000001e45 <keccak_squeeze>:
    1e45:	41 57                	push   %r15
    1e47:	41 56                	push   %r14
    1e49:	41 55                	push   %r13
    1e4b:	41 54                	push   %r12
    1e4d:	53                   	push   %rbx
    1e4e:	44 89 c3             	mov    %r8d,%ebx
    1e51:	89 c8                	mov    %ecx,%eax
    1e53:	49 89 d6             	mov    %rdx,%r14
    1e56:	49 89 f7             	mov    %rsi,%r15
    1e59:	49 89 fc             	mov    %rdi,%r12
    1e5c:	45 89 c5             	mov    %r8d,%r13d
    1e5f:	4d 85 ff             	test   %r15,%r15
    1e62:	74 55                	je     1eb9 <keccak_squeeze+0x74>
    1e64:	39 d8                	cmp    %ebx,%eax
    1e66:	75 0a                	jne    1e72 <keccak_squeeze+0x2d>
    1e68:	4c 89 f7             	mov    %r14,%rdi
    1e6b:	e8 8c 03 00 00       	call   21fc <KeccakF1600_StatePermute>
    1e70:	31 c0                	xor    %eax,%eax
    1e72:	89 c0                	mov    %eax,%eax
    1e74:	49 8d 34 07          	lea    (%r15,%rax,1),%rsi
    1e78:	49 39 f5             	cmp    %rsi,%r13
    1e7b:	49 0f 42 f5          	cmovb  %r13,%rsi
    1e7f:	48 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%rdi
    1e86:	00 
    1e87:	31 d2                	xor    %edx,%edx
    1e89:	48 39 f0             	cmp    %rsi,%rax
    1e8c:	73 21                	jae    1eaf <keccak_squeeze+0x6a>
    1e8e:	89 c1                	mov    %eax,%ecx
    1e90:	83 e1 f8             	and    $0xfffffff8,%ecx
    1e93:	4d 8b 04 0e          	mov    (%r14,%rcx,1),%r8
    1e97:	89 f9                	mov    %edi,%ecx
    1e99:	80 e1 38             	and    $0x38,%cl
    1e9c:	49 d3 e8             	shr    %cl,%r8
    1e9f:	45 88 04 14          	mov    %r8b,(%r12,%rdx,1)
    1ea3:	48 ff c0             	inc    %rax
    1ea6:	48 ff c2             	inc    %rdx
    1ea9:	48 83 c7 08          	add    $0x8,%rdi
    1ead:	eb da                	jmp    1e89 <keccak_squeeze+0x44>
    1eaf:	89 d1                	mov    %edx,%ecx
    1eb1:	49 29 cf             	sub    %rcx,%r15
    1eb4:	49 01 d4             	add    %rdx,%r12
    1eb7:	eb a6                	jmp    1e5f <keccak_squeeze+0x1a>
    1eb9:	5b                   	pop    %rbx
    1eba:	41 5c                	pop    %r12
    1ebc:	41 5d                	pop    %r13
    1ebe:	41 5e                	pop    %r14
    1ec0:	41 5f                	pop    %r15
    1ec2:	c3                   	ret

0000000000001ec3 <pqcrystals_kyber_fips202_ref_shake128_absorb_once>:
    1ec3:	53                   	push   %rbx
    1ec4:	48 89 d1             	mov    %rdx,%rcx
    1ec7:	48 89 f2             	mov    %rsi,%rdx
    1eca:	48 89 fb             	mov    %rdi,%rbx
    1ecd:	6a 1f                	push   $0x1f
    1ecf:	41 58                	pop    %r8
    1ed1:	be a8 00 00 00       	mov    $0xa8,%esi
    1ed6:	e8 0c 00 00 00       	call   1ee7 <keccak_absorb_once>
    1edb:	c7 83 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rbx)
    1ee2:	00 00 00 
    1ee5:	5b                   	pop    %rbx
    1ee6:	c3                   	ret

0000000000001ee7 <keccak_absorb_once>:
    1ee7:	55                   	push   %rbp
    1ee8:	41 57                	push   %r15
    1eea:	41 56                	push   %r14
    1eec:	41 55                	push   %r13
    1eee:	41 54                	push   %r12
    1ef0:	53                   	push   %rbx
    1ef1:	50                   	push   %rax
    1ef2:	44 89 44 24 04       	mov    %r8d,0x4(%rsp)
    1ef7:	48 89 c8             	mov    %rcx,%rax
    1efa:	49 89 d7             	mov    %rdx,%r15
    1efd:	89 f3                	mov    %esi,%ebx
    1eff:	49 89 fe             	mov    %rdi,%r14
    1f02:	31 c9                	xor    %ecx,%ecx
    1f04:	48 83 f9 19          	cmp    $0x19,%rcx
    1f08:	74 0a                	je     1f14 <keccak_absorb_once+0x2d>
    1f0a:	49 83 24 ce 00       	andq   $0x0,(%r14,%rcx,8)
    1f0f:	48 ff c1             	inc    %rcx
    1f12:	eb f0                	jmp    1f04 <keccak_absorb_once+0x1d>
    1f14:	41 89 dc             	mov    %ebx,%r12d
    1f17:	41 89 dd             	mov    %ebx,%r13d
    1f1a:	41 c1 ed 03          	shr    $0x3,%r13d
    1f1e:	48 89 c5             	mov    %rax,%rbp
    1f21:	4c 29 e5             	sub    %r12,%rbp
    1f24:	72 47                	jb     1f6d <keccak_absorb_once+0x86>
    1f26:	4c 89 f8             	mov    %r15,%rax
    1f29:	31 d2                	xor    %edx,%edx
    1f2b:	4c 39 ea             	cmp    %r13,%rdx
    1f2e:	74 2d                	je     1f5d <keccak_absorb_once+0x76>
    1f30:	48 89 c6             	mov    %rax,%rsi
    1f33:	31 c9                	xor    %ecx,%ecx
    1f35:	31 ff                	xor    %edi,%edi
    1f37:	48 83 f9 40          	cmp    $0x40,%rcx
    1f3b:	74 13                	je     1f50 <keccak_absorb_once+0x69>
    1f3d:	44 0f b6 06          	movzbl (%rsi),%r8d
    1f41:	49 d3 e0             	shl    %cl,%r8
    1f44:	4c 09 c7             	or     %r8,%rdi
    1f47:	48 83 c1 08          	add    $0x8,%rcx
    1f4b:	48 ff c6             	inc    %rsi
    1f4e:	eb e7                	jmp    1f37 <keccak_absorb_once+0x50>
    1f50:	49 31 3c d6          	xor    %rdi,(%r14,%rdx,8)
    1f54:	48 ff c2             	inc    %rdx
    1f57:	48 83 c0 08          	add    $0x8,%rax
    1f5b:	eb ce                	jmp    1f2b <keccak_absorb_once+0x44>
    1f5d:	4d 01 e7             	add    %r12,%r15
    1f60:	4c 89 f7             	mov    %r14,%rdi
    1f63:	e8 94 02 00 00       	call   21fc <KeccakF1600_StatePermute>
    1f68:	48 89 e8             	mov    %rbp,%rax
    1f6b:	eb b4                	jmp    1f21 <keccak_absorb_once+0x3a>
    1f6d:	31 d2                	xor    %edx,%edx
    1f6f:	31 c9                	xor    %ecx,%ecx
    1f71:	89 ce                	mov    %ecx,%esi
    1f73:	48 39 f0             	cmp    %rsi,%rax
    1f76:	76 1e                	jbe    1f96 <keccak_absorb_once+0xaf>
    1f78:	41 0f b6 3c 37       	movzbl (%r15,%rsi,1),%edi
    1f7d:	89 d1                	mov    %edx,%ecx
    1f7f:	80 e1 38             	and    $0x38,%cl
    1f82:	48 d3 e7             	shl    %cl,%rdi
    1f85:	89 f1                	mov    %esi,%ecx
    1f87:	83 e1 f8             	and    $0xfffffff8,%ecx
    1f8a:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    1f8e:	8d 4e 01             	lea    0x1(%rsi),%ecx
    1f91:	83 c2 08             	add    $0x8,%edx
    1f94:	eb db                	jmp    1f71 <keccak_absorb_once+0x8a>
    1f96:	0f b6 44 24 04       	movzbl 0x4(%rsp),%eax
    1f9b:	80 e2 38             	and    $0x38,%dl
    1f9e:	89 d1                	mov    %edx,%ecx
    1fa0:	48 d3 e0             	shl    %cl,%rax
    1fa3:	83 e6 f8             	and    $0xfffffff8,%esi
    1fa6:	49 31 04 36          	xor    %rax,(%r14,%rsi,1)
    1faa:	ff cb                	dec    %ebx
    1fac:	83 e3 f8             	and    $0xfffffff8,%ebx
    1faf:	41 80 74 1e 07 80    	xorb   $0x80,0x7(%r14,%rbx,1)
    1fb5:	48 83 c4 08          	add    $0x8,%rsp
    1fb9:	5b                   	pop    %rbx
    1fba:	41 5c                	pop    %r12
    1fbc:	41 5d                	pop    %r13
    1fbe:	41 5e                	pop    %r14
    1fc0:	41 5f                	pop    %r15
    1fc2:	5d                   	pop    %rbp
    1fc3:	c3                   	ret

0000000000001fc4 <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>:
    1fc4:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    1fc9:	eb 00                	jmp    1fcb <keccak_squeezeblocks>

0000000000001fcb <keccak_squeezeblocks>:
    1fcb:	55                   	push   %rbp
    1fcc:	41 57                	push   %r15
    1fce:	41 56                	push   %r14
    1fd0:	41 55                	push   %r13
    1fd2:	41 54                	push   %r12
    1fd4:	53                   	push   %rbx
    1fd5:	50                   	push   %rax
    1fd6:	89 cb                	mov    %ecx,%ebx
    1fd8:	49 89 d6             	mov    %rdx,%r14
    1fdb:	49 89 f7             	mov    %rsi,%r15
    1fde:	49 89 fc             	mov    %rdi,%r12
    1fe1:	41 89 cd             	mov    %ecx,%r13d
    1fe4:	83 e3 f8             	and    $0xfffffff8,%ebx
    1fe7:	49 83 ef 01          	sub    $0x1,%r15
    1feb:	72 27                	jb     2014 <keccak_squeezeblocks+0x49>
    1fed:	4c 89 f7             	mov    %r14,%rdi
    1ff0:	e8 07 02 00 00       	call   21fc <KeccakF1600_StatePermute>
    1ff5:	31 ed                	xor    %ebp,%ebp
    1ff7:	48 39 eb             	cmp    %rbp,%rbx
    1ffa:	74 13                	je     200f <keccak_squeezeblocks+0x44>
    1ffc:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
    2000:	49 8b 34 2e          	mov    (%r14,%rbp,1),%rsi
    2004:	e8 ac 0a 00 00       	call   2ab5 <store64>
    2009:	48 83 c5 08          	add    $0x8,%rbp
    200d:	eb e8                	jmp    1ff7 <keccak_squeezeblocks+0x2c>
    200f:	4d 01 ec             	add    %r13,%r12
    2012:	eb d3                	jmp    1fe7 <keccak_squeezeblocks+0x1c>
    2014:	48 83 c4 08          	add    $0x8,%rsp
    2018:	5b                   	pop    %rbx
    2019:	41 5c                	pop    %r12
    201b:	41 5d                	pop    %r13
    201d:	41 5e                	pop    %r14
    201f:	41 5f                	pop    %r15
    2021:	5d                   	pop    %rbp
    2022:	c3                   	ret

0000000000002023 <pqcrystals_kyber_fips202_ref_shake256_init>:
    2023:	53                   	push   %rbx
    2024:	48 89 fb             	mov    %rdi,%rbx
    2027:	e8 06 fd ff ff       	call   1d32 <keccak_init>
    202c:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    2033:	5b                   	pop    %rbx
    2034:	c3                   	ret

0000000000002035 <pqcrystals_kyber_fips202_ref_shake256_absorb>:
    2035:	53                   	push   %rbx
    2036:	49 89 d0             	mov    %rdx,%r8
    2039:	48 89 f1             	mov    %rsi,%rcx
    203c:	48 89 fb             	mov    %rdi,%rbx
    203f:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    2045:	ba 88 00 00 00       	mov    $0x88,%edx
    204a:	e8 18 fd ff ff       	call   1d67 <keccak_absorb>
    204f:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    2055:	5b                   	pop    %rbx
    2056:	c3                   	ret

0000000000002057 <pqcrystals_kyber_fips202_ref_shake256_finalize>:
    2057:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    205d:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    2064:	6a 1f                	push   $0x1f
    2066:	5a                   	pop    %rdx
    2067:	48 d3 e2             	shl    %cl,%rdx
    206a:	83 e0 f8             	and    $0xfffffff8,%eax
    206d:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    2071:	80 b7 87 00 00 00 80 	xorb   $0x80,0x87(%rdi)
    2078:	c7 87 c8 00 00 00 88 	movl   $0x88,0xc8(%rdi)
    207f:	00 00 00 
    2082:	c3                   	ret

0000000000002083 <pqcrystals_kyber_fips202_ref_shake256_squeeze>:
    2083:	53                   	push   %rbx
    2084:	48 89 d3             	mov    %rdx,%rbx
    2087:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    208d:	41 b8 88 00 00 00    	mov    $0x88,%r8d
    2093:	e8 ad fd ff ff       	call   1e45 <keccak_squeeze>
    2098:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    209e:	5b                   	pop    %rbx
    209f:	c3                   	ret

00000000000020a0 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>:
    20a0:	53                   	push   %rbx
    20a1:	48 89 d1             	mov    %rdx,%rcx
    20a4:	48 89 f2             	mov    %rsi,%rdx
    20a7:	48 89 fb             	mov    %rdi,%rbx
    20aa:	6a 1f                	push   $0x1f
    20ac:	41 58                	pop    %r8
    20ae:	be 88 00 00 00       	mov    $0x88,%esi
    20b3:	e8 2f fe ff ff       	call   1ee7 <keccak_absorb_once>
    20b8:	c7 83 c8 00 00 00 88 	movl   $0x88,0xc8(%rbx)
    20bf:	00 00 00 
    20c2:	5b                   	pop    %rbx
    20c3:	c3                   	ret

00000000000020c4 <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>:
    20c4:	b9 88 00 00 00       	mov    $0x88,%ecx
    20c9:	e9 fd fe ff ff       	jmp    1fcb <keccak_squeezeblocks>

00000000000020ce <pqcrystals_kyber_fips202_ref_shake128>:
    20ce:	41 57                	push   %r15
    20d0:	41 56                	push   %r14
    20d2:	41 54                	push   %r12
    20d4:	53                   	push   %rbx
    20d5:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    20dc:	48 89 f3             	mov    %rsi,%rbx
    20df:	49 89 fe             	mov    %rdi,%r14
    20e2:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    20e7:	4c 89 ff             	mov    %r15,%rdi
    20ea:	48 89 d6             	mov    %rdx,%rsi
    20ed:	48 89 ca             	mov    %rcx,%rdx
    20f0:	e8 ce fd ff ff       	call   1ec3 <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    20f5:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    20fa:	48 89 d8             	mov    %rbx,%rax
    20fd:	31 d2                	xor    %edx,%edx
    20ff:	48 f7 f1             	div    %rcx
    2102:	48 89 d3             	mov    %rdx,%rbx
    2105:	49 89 c4             	mov    %rax,%r12
    2108:	4c 89 f7             	mov    %r14,%rdi
    210b:	48 89 c6             	mov    %rax,%rsi
    210e:	4c 89 fa             	mov    %r15,%rdx
    2111:	e8 ae fe ff ff       	call   1fc4 <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>
    2116:	49 69 fc a8 00 00 00 	imul   $0xa8,%r12,%rdi
    211d:	4c 01 f7             	add    %r14,%rdi
    2120:	48 89 de             	mov    %rbx,%rsi
    2123:	4c 89 fa             	mov    %r15,%rdx
    2126:	e8 fd fc ff ff       	call   1e28 <pqcrystals_kyber_fips202_ref_shake128_squeeze>
    212b:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    2132:	5b                   	pop    %rbx
    2133:	41 5c                	pop    %r12
    2135:	41 5e                	pop    %r14
    2137:	41 5f                	pop    %r15
    2139:	c3                   	ret

000000000000213a <pqcrystals_kyber_fips202_ref_shake256>:
    213a:	41 57                	push   %r15
    213c:	41 56                	push   %r14
    213e:	41 54                	push   %r12
    2140:	53                   	push   %rbx
    2141:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    2148:	48 89 f3             	mov    %rsi,%rbx
    214b:	49 89 fe             	mov    %rdi,%r14
    214e:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    2153:	4c 89 ff             	mov    %r15,%rdi
    2156:	48 89 d6             	mov    %rdx,%rsi
    2159:	48 89 ca             	mov    %rcx,%rdx
    215c:	e8 3f ff ff ff       	call   20a0 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>
    2161:	b9 88 00 00 00       	mov    $0x88,%ecx
    2166:	48 89 d8             	mov    %rbx,%rax
    2169:	31 d2                	xor    %edx,%edx
    216b:	48 f7 f1             	div    %rcx
    216e:	48 89 d3             	mov    %rdx,%rbx
    2171:	49 89 c4             	mov    %rax,%r12
    2174:	4c 89 f7             	mov    %r14,%rdi
    2177:	48 89 c6             	mov    %rax,%rsi
    217a:	4c 89 fa             	mov    %r15,%rdx
    217d:	e8 42 ff ff ff       	call   20c4 <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>
    2182:	49 69 fc 88 00 00 00 	imul   $0x88,%r12,%rdi
    2189:	4c 01 f7             	add    %r14,%rdi
    218c:	48 89 de             	mov    %rbx,%rsi
    218f:	4c 89 fa             	mov    %r15,%rdx
    2192:	e8 ec fe ff ff       	call   2083 <pqcrystals_kyber_fips202_ref_shake256_squeeze>
    2197:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    219e:	5b                   	pop    %rbx
    219f:	41 5c                	pop    %r12
    21a1:	41 5e                	pop    %r14
    21a3:	41 5f                	pop    %r15
    21a5:	c3                   	ret

00000000000021a6 <pqcrystals_kyber_fips202_ref_sha3_256>:
    21a6:	41 56                	push   %r14
    21a8:	53                   	push   %rbx
    21a9:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    21b0:	48 89 d1             	mov    %rdx,%rcx
    21b3:	48 89 f2             	mov    %rsi,%rdx
    21b6:	48 89 fb             	mov    %rdi,%rbx
    21b9:	49 89 e6             	mov    %rsp,%r14
    21bc:	6a 06                	push   $0x6
    21be:	41 58                	pop    %r8
    21c0:	4c 89 f7             	mov    %r14,%rdi
    21c3:	be 88 00 00 00       	mov    $0x88,%esi
    21c8:	e8 1a fd ff ff       	call   1ee7 <keccak_absorb_once>
    21cd:	4c 89 f7             	mov    %r14,%rdi
    21d0:	e8 27 00 00 00       	call   21fc <KeccakF1600_StatePermute>
    21d5:	45 31 f6             	xor    %r14d,%r14d
    21d8:	49 83 fe 20          	cmp    $0x20,%r14
    21dc:	74 13                	je     21f1 <pqcrystals_kyber_fips202_ref_sha3_256+0x4b>
    21de:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    21e2:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    21e6:	e8 ca 08 00 00       	call   2ab5 <store64>
    21eb:	49 83 c6 08          	add    $0x8,%r14
    21ef:	eb e7                	jmp    21d8 <pqcrystals_kyber_fips202_ref_sha3_256+0x32>
    21f1:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    21f8:	5b                   	pop    %rbx
    21f9:	41 5e                	pop    %r14
    21fb:	c3                   	ret

00000000000021fc <KeccakF1600_StatePermute>:
    21fc:	55                   	push   %rbp
    21fd:	41 57                	push   %r15
    21ff:	41 56                	push   %r14
    2201:	41 55                	push   %r13
    2203:	41 54                	push   %r12
    2205:	53                   	push   %rbx
    2206:	48 83 ec 68          	sub    $0x68,%rsp
    220a:	48 8b 07             	mov    (%rdi),%rax
    220d:	48 89 44 24 80       	mov    %rax,-0x80(%rsp)
    2212:	48 8b 6f 08          	mov    0x8(%rdi),%rbp
    2216:	48 8b 47 10          	mov    0x10(%rdi),%rax
    221a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    221f:	48 8b 47 18          	mov    0x18(%rdi),%rax
    2223:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    2228:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    222c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    2230:	48 89 04 24          	mov    %rax,(%rsp)
    2234:	48 8b 47 30          	mov    0x30(%rdi),%rax
    2238:	48 89 44 24 98       	mov    %rax,-0x68(%rsp)
    223d:	48 8b 47 38          	mov    0x38(%rdi),%rax
    2241:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    2246:	48 8b 47 40          	mov    0x40(%rdi),%rax
    224a:	48 89 44 24 f8       	mov    %rax,-0x8(%rsp)
    224f:	4c 8b 7f 48          	mov    0x48(%rdi),%r15
    2253:	48 8b 47 50          	mov    0x50(%rdi),%rax
    2257:	48 89 44 24 90       	mov    %rax,-0x70(%rsp)
    225c:	48 8b 47 58          	mov    0x58(%rdi),%rax
    2260:	48 89 44 24 f0       	mov    %rax,-0x10(%rsp)
    2265:	48 8b 47 60          	mov    0x60(%rdi),%rax
    2269:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    226e:	48 8b 47 68          	mov    0x68(%rdi),%rax
    2272:	48 89 44 24 a0       	mov    %rax,-0x60(%rsp)
    2277:	4c 8b 77 70          	mov    0x70(%rdi),%r14
    227b:	48 8b 47 78          	mov    0x78(%rdi),%rax
    227f:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    2284:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
    228b:	48 89 44 24 88       	mov    %rax,-0x78(%rsp)
    2290:	48 8b 87 88 00 00 00 	mov    0x88(%rdi),%rax
    2297:	48 89 44 24 c8       	mov    %rax,-0x38(%rsp)
    229c:	4c 8b a7 90 00 00 00 	mov    0x90(%rdi),%r12
    22a3:	4c 8b 87 98 00 00 00 	mov    0x98(%rdi),%r8
    22aa:	4c 8b af a0 00 00 00 	mov    0xa0(%rdi),%r13
    22b1:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    22b8:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    22bf:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    22c6:	48 89 4c 24 c0       	mov    %rcx,-0x40(%rsp)
    22cb:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    22d0:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    22d7:	48 89 4c 24 b0       	mov    %rcx,-0x50(%rsp)
    22dc:	31 c9                	xor    %ecx,%ecx
    22de:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    22e3:	48 83 7c 24 10 17    	cmpq   $0x17,0x10(%rsp)
    22e9:	0f 87 e5 06 00 00    	ja     29d4 <KeccakF1600_StatePermute+0x7d8>
    22ef:	48 8b 4c 24 d0       	mov    -0x30(%rsp),%rcx
    22f4:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    22f9:	4c 31 e9             	xor    %r13,%rcx
    22fc:	4c 89 d7             	mov    %r10,%rdi
    22ff:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    2304:	4c 8b 54 24 90       	mov    -0x70(%rsp),%r10
    2309:	4c 33 14 24          	xor    (%rsp),%r10
    230d:	49 31 ca             	xor    %rcx,%r10
    2310:	48 8b 4c 24 88       	mov    -0x78(%rsp),%rcx
    2315:	48 31 f9             	xor    %rdi,%rcx
    2318:	4c 89 fb             	mov    %r15,%rbx
    231b:	4d 89 f5             	mov    %r14,%r13
    231e:	4c 8b 74 24 f0       	mov    -0x10(%rsp),%r14
    2323:	4c 33 74 24 98       	xor    -0x68(%rsp),%r14
    2328:	49 31 ce             	xor    %rcx,%r14
    232b:	48 8b 4c 24 c8       	mov    -0x38(%rsp),%rcx
    2330:	48 31 c1             	xor    %rax,%rcx
    2333:	49 89 d7             	mov    %rdx,%r15
    2336:	4d 89 c3             	mov    %r8,%r11
    2339:	4c 89 44 24 e0       	mov    %r8,-0x20(%rsp)
    233e:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
    2343:	4c 89 c2             	mov    %r8,%rdx
    2346:	48 33 54 24 a8       	xor    -0x58(%rsp),%rdx
    234b:	48 31 ca             	xor    %rcx,%rdx
    234e:	48 89 6c 24 d8       	mov    %rbp,-0x28(%rsp)
    2353:	4d 89 e1             	mov    %r12,%r9
    2356:	4c 33 4c 24 c0       	xor    -0x40(%rsp),%r9
    235b:	48 8b 4c 24 a0       	mov    -0x60(%rsp),%rcx
    2360:	48 33 4c 24 f8       	xor    -0x8(%rsp),%rcx
    2365:	4c 31 c9             	xor    %r9,%rcx
    2368:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    236d:	49 31 fb             	xor    %rdi,%r11
    2370:	4d 89 e9             	mov    %r13,%r9
    2373:	49 31 d9             	xor    %rbx,%r9
    2376:	48 89 de             	mov    %rbx,%rsi
    2379:	4d 31 d9             	xor    %r11,%r9
    237c:	4c 33 54 24 80       	xor    -0x80(%rsp),%r10
    2381:	49 31 ee             	xor    %rbp,%r14
    2384:	48 33 54 24 08       	xor    0x8(%rsp),%rdx
    2389:	4c 8b 5c 24 b8       	mov    -0x48(%rsp),%r11
    238e:	4c 31 d9             	xor    %r11,%rcx
    2391:	48 89 cd             	mov    %rcx,%rbp
    2394:	48 d1 c5             	rol    $1,%rbp
    2397:	4c 31 f5             	xor    %r14,%rbp
    239a:	49 d1 c6             	rol    $1,%r14
    239d:	4d 31 f9             	xor    %r15,%r9
    23a0:	4d 31 ce             	xor    %r9,%r14
    23a3:	49 d1 c1             	rol    $1,%r9
    23a6:	49 31 d1             	xor    %rdx,%r9
    23a9:	48 89 d3             	mov    %rdx,%rbx
    23ac:	48 d1 c3             	rol    $1,%rbx
    23af:	4c 31 d3             	xor    %r10,%rbx
    23b2:	49 d1 c2             	rol    $1,%r10
    23b5:	49 31 ca             	xor    %rcx,%r10
    23b8:	4c 31 d7             	xor    %r10,%rdi
    23bb:	4c 31 d6             	xor    %r10,%rsi
    23be:	48 89 74 24 b0       	mov    %rsi,-0x50(%rsp)
    23c3:	4c 31 54 24 e0       	xor    %r10,-0x20(%rsp)
    23c8:	4d 31 d7             	xor    %r10,%r15
    23cb:	4c 89 7c 24 e8       	mov    %r15,-0x18(%rsp)
    23d0:	4d 31 ea             	xor    %r13,%r10
    23d3:	4c 89 54 24 60       	mov    %r10,0x60(%rsp)
    23d8:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    23dd:	48 31 da             	xor    %rbx,%rdx
    23e0:	48 c1 c2 2c          	rol    $0x2c,%rdx
    23e4:	49 31 e8             	xor    %rbp,%r8
    23e7:	49 c1 c0 2b          	rol    $0x2b,%r8
    23eb:	4d 31 cc             	xor    %r9,%r12
    23ee:	49 c1 c4 15          	rol    $0x15,%r12
    23f2:	48 c1 c7 0e          	rol    $0xe,%rdi
    23f6:	4c 8b 7c 24 80       	mov    -0x80(%rsp),%r15
    23fb:	4d 31 f7             	xor    %r14,%r15
    23fe:	48 89 d6             	mov    %rdx,%rsi
    2401:	48 f7 d6             	not    %rsi
    2404:	4c 21 c6             	and    %r8,%rsi
    2407:	4c 8d 15 22 0d 00 00 	lea    0xd22(%rip),%r10        # 3130 <KeccakF_RoundConstants>
    240e:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
    2413:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    2418:	49 33 34 ca          	xor    (%r10,%rcx,8),%rsi
    241c:	4c 89 e1             	mov    %r12,%rcx
    241f:	48 f7 d1             	not    %rcx
    2422:	48 21 f9             	and    %rdi,%rcx
    2425:	4c 31 c1             	xor    %r8,%rcx
    2428:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    242d:	49 f7 d0             	not    %r8
    2430:	4d 21 e0             	and    %r12,%r8
    2433:	48 89 f9             	mov    %rdi,%rcx
    2436:	48 f7 d1             	not    %rcx
    2439:	4c 21 f9             	and    %r15,%rcx
    243c:	4c 31 e1             	xor    %r12,%rcx
    243f:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    2444:	4c 31 fe             	xor    %r15,%rsi
    2447:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    244c:	49 31 d0             	xor    %rdx,%r8
    244f:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
    2454:	4d 31 cb             	xor    %r9,%r11
    2457:	49 c1 c3 1c          	rol    $0x1c,%r11
    245b:	48 89 f9             	mov    %rdi,%rcx
    245e:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
    2463:	48 c1 c6 14          	rol    $0x14,%rsi
    2467:	49 f7 d7             	not    %r15
    246a:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
    246f:	4c 31 f7             	xor    %r14,%rdi
    2472:	48 c1 c7 03          	rol    $0x3,%rdi
    2476:	49 21 d7             	and    %rdx,%r15
    2479:	4c 8b 44 24 88       	mov    -0x78(%rsp),%r8
    247e:	49 31 d8             	xor    %rbx,%r8
    2481:	49 c1 c0 2d          	rol    $0x2d,%r8
    2485:	49 31 cf             	xor    %rcx,%r15
    2488:	4c 89 7c 24 80       	mov    %r15,-0x80(%rsp)
    248d:	48 31 e8             	xor    %rbp,%rax
    2490:	48 c1 c0 3d          	rol    $0x3d,%rax
    2494:	48 89 f1             	mov    %rsi,%rcx
    2497:	49 89 f7             	mov    %rsi,%r15
    249a:	48 f7 d1             	not    %rcx
    249d:	48 21 f9             	and    %rdi,%rcx
    24a0:	48 89 ce             	mov    %rcx,%rsi
    24a3:	4c 89 c1             	mov    %r8,%rcx
    24a6:	48 f7 d1             	not    %rcx
    24a9:	48 21 c1             	and    %rax,%rcx
    24ac:	48 31 f9             	xor    %rdi,%rcx
    24af:	48 89 4c 24 90       	mov    %rcx,-0x70(%rsp)
    24b4:	48 89 fa             	mov    %rdi,%rdx
    24b7:	48 f7 d2             	not    %rdx
    24ba:	4c 21 c2             	and    %r8,%rdx
    24bd:	48 89 c1             	mov    %rax,%rcx
    24c0:	48 f7 d1             	not    %rcx
    24c3:	4c 21 d9             	and    %r11,%rcx
    24c6:	4c 31 c1             	xor    %r8,%rcx
    24c9:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    24ce:	4c 31 de             	xor    %r11,%rsi
    24d1:	48 89 74 24 88       	mov    %rsi,-0x78(%rsp)
    24d6:	4c 31 fa             	xor    %r15,%rdx
    24d9:	48 89 54 24 98       	mov    %rdx,-0x68(%rsp)
    24de:	49 f7 d3             	not    %r11
    24e1:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    24e6:	48 31 de             	xor    %rbx,%rsi
    24e9:	48 d1 c6             	rol    $1,%rsi
    24ec:	4c 8b 44 24 a8       	mov    -0x58(%rsp),%r8
    24f1:	49 31 e8             	xor    %rbp,%r8
    24f4:	49 c1 c0 06          	rol    $0x6,%r8
    24f8:	4c 8b 64 24 a0       	mov    -0x60(%rsp),%r12
    24fd:	4d 31 cc             	xor    %r9,%r12
    2500:	49 c1 c4 19          	rol    $0x19,%r12
    2504:	48 8b 7c 24 e0       	mov    -0x20(%rsp),%rdi
    2509:	48 c1 c7 08          	rol    $0x8,%rdi
    250d:	4d 21 fb             	and    %r15,%r11
    2510:	4d 31 f5             	xor    %r14,%r13
    2513:	49 c1 c5 12          	rol    $0x12,%r13
    2517:	49 31 c3             	xor    %rax,%r11
    251a:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    251f:	4c 89 c0             	mov    %r8,%rax
    2522:	48 f7 d0             	not    %rax
    2525:	4c 21 e0             	and    %r12,%rax
    2528:	48 89 c1             	mov    %rax,%rcx
    252b:	49 89 ff             	mov    %rdi,%r15
    252e:	49 f7 d7             	not    %r15
    2531:	4d 21 ef             	and    %r13,%r15
    2534:	4d 31 e7             	xor    %r12,%r15
    2537:	4c 89 e0             	mov    %r12,%rax
    253a:	48 f7 d0             	not    %rax
    253d:	48 21 f8             	and    %rdi,%rax
    2540:	49 89 fb             	mov    %rdi,%r11
    2543:	4c 89 ef             	mov    %r13,%rdi
    2546:	48 f7 d7             	not    %rdi
    2549:	48 21 f7             	and    %rsi,%rdi
    254c:	4c 31 df             	xor    %r11,%rdi
    254f:	48 89 7c 24 a0       	mov    %rdi,-0x60(%rsp)
    2554:	48 31 f1             	xor    %rsi,%rcx
    2557:	48 89 4c 24 a8       	mov    %rcx,-0x58(%rsp)
    255c:	4c 31 c0             	xor    %r8,%rax
    255f:	48 89 44 24 e0       	mov    %rax,-0x20(%rsp)
    2564:	48 f7 d6             	not    %rsi
    2567:	48 8b 7c 24 e8       	mov    -0x18(%rsp),%rdi
    256c:	48 c1 c7 1b          	rol    $0x1b,%rdi
    2570:	4c 21 c6             	and    %r8,%rsi
    2573:	48 8b 0c 24          	mov    (%rsp),%rcx
    2577:	4c 31 f1             	xor    %r14,%rcx
    257a:	48 c1 c1 24          	rol    $0x24,%rcx
    257e:	4c 31 ee             	xor    %r13,%rsi
    2581:	48 89 74 24 d8       	mov    %rsi,-0x28(%rsp)
    2586:	4c 8b 6c 24 f0       	mov    -0x10(%rsp),%r13
    258b:	49 31 dd             	xor    %rbx,%r13
    258e:	49 c1 c5 0a          	rol    $0xa,%r13
    2592:	4c 8b 44 24 c8       	mov    -0x38(%rsp),%r8
    2597:	49 31 e8             	xor    %rbp,%r8
    259a:	49 c1 c0 0f          	rol    $0xf,%r8
    259e:	4c 8b 64 24 c0       	mov    -0x40(%rsp),%r12
    25a3:	4d 31 cc             	xor    %r9,%r12
    25a6:	4c 89 ca             	mov    %r9,%rdx
    25a9:	49 c1 c4 38          	rol    $0x38,%r12
    25ad:	49 89 c9             	mov    %rcx,%r9
    25b0:	49 f7 d1             	not    %r9
    25b3:	4d 21 e9             	and    %r13,%r9
    25b6:	4d 89 c3             	mov    %r8,%r11
    25b9:	49 f7 d3             	not    %r11
    25bc:	4d 21 e3             	and    %r12,%r11
    25bf:	4d 31 eb             	xor    %r13,%r11
    25c2:	4c 89 5c 24 c8       	mov    %r11,-0x38(%rsp)
    25c7:	49 f7 d5             	not    %r13
    25ca:	4d 21 c5             	and    %r8,%r13
    25cd:	4c 89 e6             	mov    %r12,%rsi
    25d0:	48 f7 d6             	not    %rsi
    25d3:	48 21 fe             	and    %rdi,%rsi
    25d6:	4c 31 c6             	xor    %r8,%rsi
    25d9:	49 31 f9             	xor    %rdi,%r9
    25dc:	4c 89 4c 24 c0       	mov    %r9,-0x40(%rsp)
    25e1:	49 31 cd             	xor    %rcx,%r13
    25e4:	48 f7 d7             	not    %rdi
    25e7:	48 21 cf             	and    %rcx,%rdi
    25ea:	4c 31 e7             	xor    %r12,%rdi
    25ed:	48 89 7c 24 e8       	mov    %rdi,-0x18(%rsp)
    25f2:	48 33 6c 24 08       	xor    0x8(%rsp),%rbp
    25f7:	48 89 d0             	mov    %rdx,%rax
    25fa:	48 33 44 24 f8       	xor    -0x8(%rsp),%rax
    25ff:	4c 33 74 24 d0       	xor    -0x30(%rsp),%r14
    2604:	48 c1 c5 3e          	rol    $0x3e,%rbp
    2608:	48 c1 c0 37          	rol    $0x37,%rax
    260c:	4c 8b 54 24 60       	mov    0x60(%rsp),%r10
    2611:	49 c1 c2 27          	rol    $0x27,%r10
    2615:	49 c1 c6 29          	rol    $0x29,%r14
    2619:	48 33 5c 24 38       	xor    0x38(%rsp),%rbx
    261e:	48 c1 c3 02          	rol    $0x2,%rbx
    2622:	48 89 c7             	mov    %rax,%rdi
    2625:	48 89 c2             	mov    %rax,%rdx
    2628:	48 f7 d7             	not    %rdi
    262b:	4c 21 d7             	and    %r10,%rdi
    262e:	4c 89 d0             	mov    %r10,%rax
    2631:	4d 89 f4             	mov    %r14,%r12
    2634:	49 f7 d4             	not    %r12
    2637:	49 21 dc             	and    %rbx,%r12
    263a:	4d 31 d4             	xor    %r10,%r12
    263d:	48 f7 d0             	not    %rax
    2640:	4c 21 f0             	and    %r14,%rax
    2643:	49 89 da             	mov    %rbx,%r10
    2646:	49 f7 d2             	not    %r10
    2649:	49 21 ea             	and    %rbp,%r10
    264c:	4d 31 f2             	xor    %r14,%r10
    264f:	4d 89 d6             	mov    %r10,%r14
    2652:	4c 89 54 24 d0       	mov    %r10,-0x30(%rsp)
    2657:	48 31 ef             	xor    %rbp,%rdi
    265a:	48 31 d0             	xor    %rdx,%rax
    265d:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    2662:	48 f7 d5             	not    %rbp
    2665:	48 21 d5             	and    %rdx,%rbp
    2668:	48 31 dd             	xor    %rbx,%rbp
    266b:	4c 33 4c 24 a8       	xor    -0x58(%rsp),%r9
    2670:	4c 8b 54 24 88       	mov    -0x78(%rsp),%r10
    2675:	49 31 fa             	xor    %rdi,%r10
    2678:	4d 31 ca             	xor    %r9,%r10
    267b:	4c 8b 4c 24 98       	mov    -0x68(%rsp),%r9
    2680:	4c 33 4c 24 28       	xor    0x28(%rsp),%r9
    2685:	4c 89 ea             	mov    %r13,%rdx
    2688:	48 33 54 24 e0       	xor    -0x20(%rsp),%rdx
    268d:	4c 31 ca             	xor    %r9,%rdx
    2690:	4c 8b 4c 24 90       	mov    -0x70(%rsp),%r9
    2695:	4d 31 d9             	xor    %r11,%r9
    2698:	4c 89 e3             	mov    %r12,%rbx
    269b:	48 33 5c 24 50       	xor    0x50(%rsp),%rbx
    26a0:	4c 31 cb             	xor    %r9,%rbx
    26a3:	4c 8b 4c 24 a0       	mov    -0x60(%rsp),%r9
    26a8:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    26ad:	4d 89 f3             	mov    %r14,%r11
    26b0:	4c 33 5c 24 20       	xor    0x20(%rsp),%r11
    26b5:	4d 31 cb             	xor    %r9,%r11
    26b8:	4c 8b 74 24 80       	mov    -0x80(%rsp),%r14
    26bd:	49 31 ee             	xor    %rbp,%r14
    26c0:	4c 8b 4c 24 d8       	mov    -0x28(%rsp),%r9
    26c5:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    26ca:	49 31 c9             	xor    %rcx,%r9
    26cd:	4d 31 f1             	xor    %r14,%r9
    26d0:	4c 33 54 24 18       	xor    0x18(%rsp),%r10
    26d5:	48 31 c2             	xor    %rax,%rdx
    26d8:	4c 31 fb             	xor    %r15,%rbx
    26db:	49 31 f3             	xor    %rsi,%r11
    26de:	4c 33 4c 24 e8       	xor    -0x18(%rsp),%r9
    26e3:	4c 89 d8             	mov    %r11,%rax
    26e6:	48 d1 c0             	rol    $1,%rax
    26e9:	48 31 d0             	xor    %rdx,%rax
    26ec:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    26f1:	49 89 d6             	mov    %rdx,%r14
    26f4:	49 d1 c6             	rol    $1,%r14
    26f7:	4d 31 ce             	xor    %r9,%r14
    26fa:	48 89 da             	mov    %rbx,%rdx
    26fd:	48 d1 c2             	rol    $1,%rdx
    2700:	4c 31 d2             	xor    %r10,%rdx
    2703:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    2708:	49 d1 c1             	rol    $1,%r9
    270b:	49 d1 c2             	rol    $1,%r10
    270e:	49 31 d9             	xor    %rbx,%r9
    2711:	4c 8b 44 24 98       	mov    -0x68(%rsp),%r8
    2716:	49 31 d0             	xor    %rdx,%r8
    2719:	49 c1 c0 2c          	rol    $0x2c,%r8
    271d:	4d 31 da             	xor    %r11,%r10
    2720:	49 31 c7             	xor    %rax,%r15
    2723:	49 c1 c7 2b          	rol    $0x2b,%r15
    2727:	4c 31 d5             	xor    %r10,%rbp
    272a:	4c 31 d1             	xor    %r10,%rcx
    272d:	48 89 4c 24 b8       	mov    %rcx,-0x48(%rsp)
    2732:	4c 31 54 24 e8       	xor    %r10,-0x18(%rsp)
    2737:	4c 31 54 24 80       	xor    %r10,-0x80(%rsp)
    273c:	4c 33 54 24 d8       	xor    -0x28(%rsp),%r10
    2741:	4c 31 ce             	xor    %r9,%rsi
    2744:	48 c1 c6 15          	rol    $0x15,%rsi
    2748:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    274d:	4c 31 f1             	xor    %r14,%rcx
    2750:	48 c1 c5 0e          	rol    $0xe,%rbp
    2754:	4c 89 c3             	mov    %r8,%rbx
    2757:	48 f7 d3             	not    %rbx
    275a:	4c 21 fb             	and    %r15,%rbx
    275d:	49 89 f3             	mov    %rsi,%r11
    2760:	49 f7 d3             	not    %r11
    2763:	49 21 eb             	and    %rbp,%r11
    2766:	4d 31 fb             	xor    %r15,%r11
    2769:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    276e:	49 f7 d7             	not    %r15
    2771:	49 21 f7             	and    %rsi,%r15
    2774:	49 89 eb             	mov    %rbp,%r11
    2777:	49 f7 d3             	not    %r11
    277a:	49 21 cb             	and    %rcx,%r11
    277d:	49 31 f3             	xor    %rsi,%r11
    2780:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    2785:	48 8d 05 a4 09 00 00 	lea    0x9a4(%rip),%rax        # 3130 <KeccakF_RoundConstants>
    278c:	48 33 5c f0 08       	xor    0x8(%rax,%rsi,8),%rbx
    2791:	48 89 ce             	mov    %rcx,%rsi
    2794:	48 31 cb             	xor    %rcx,%rbx
    2797:	4d 31 c7             	xor    %r8,%r15
    279a:	4c 89 7c 24 d8       	mov    %r15,-0x28(%rsp)
    279f:	48 f7 d6             	not    %rsi
    27a2:	4c 21 c6             	and    %r8,%rsi
    27a5:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    27aa:	4c 31 ca             	xor    %r9,%rdx
    27ad:	48 c1 c2 1c          	rol    $0x1c,%rdx
    27b1:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    27b6:	48 c1 c1 14          	rol    $0x14,%rcx
    27ba:	48 31 ee             	xor    %rbp,%rsi
    27bd:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    27c2:	48 8b 74 24 a8       	mov    -0x58(%rsp),%rsi
    27c7:	4c 31 f6             	xor    %r14,%rsi
    27ca:	48 c1 c6 03          	rol    $0x3,%rsi
    27ce:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    27d3:	49 31 c5             	xor    %rax,%r13
    27d6:	49 c1 c5 2d          	rol    $0x2d,%r13
    27da:	4c 8b 7c 24 b0       	mov    -0x50(%rsp),%r15
    27df:	4d 31 fc             	xor    %r15,%r12
    27e2:	49 c1 c4 3d          	rol    $0x3d,%r12
    27e6:	49 89 c8             	mov    %rcx,%r8
    27e9:	49 f7 d0             	not    %r8
    27ec:	49 21 f0             	and    %rsi,%r8
    27ef:	4c 89 ed             	mov    %r13,%rbp
    27f2:	48 f7 d5             	not    %rbp
    27f5:	4c 21 e5             	and    %r12,%rbp
    27f8:	48 31 f5             	xor    %rsi,%rbp
    27fb:	48 89 6c 24 a8       	mov    %rbp,-0x58(%rsp)
    2800:	48 f7 d6             	not    %rsi
    2803:	4c 21 ee             	and    %r13,%rsi
    2806:	4c 89 e5             	mov    %r12,%rbp
    2809:	48 f7 d5             	not    %rbp
    280c:	48 21 d5             	and    %rdx,%rbp
    280f:	4c 31 ed             	xor    %r13,%rbp
    2812:	48 89 6c 24 f8       	mov    %rbp,-0x8(%rsp)
    2817:	49 31 d0             	xor    %rdx,%r8
    281a:	4c 89 04 24          	mov    %r8,(%rsp)
    281e:	48 31 ce             	xor    %rcx,%rsi
    2821:	48 89 74 24 98       	mov    %rsi,-0x68(%rsp)
    2826:	48 f7 d2             	not    %rdx
    2829:	48 21 ca             	and    %rcx,%rdx
    282c:	4c 31 e2             	xor    %r12,%rdx
    282f:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    2834:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
    2839:	48 31 c5             	xor    %rax,%rbp
    283c:	48 89 c2             	mov    %rax,%rdx
    283f:	48 d1 c5             	rol    $1,%rbp
    2842:	4c 8b 44 24 90       	mov    -0x70(%rsp),%r8
    2847:	4d 31 f8             	xor    %r15,%r8
    284a:	49 c1 c0 06          	rol    $0x6,%r8
    284e:	48 8b 44 24 a0       	mov    -0x60(%rsp),%rax
    2853:	4c 31 c8             	xor    %r9,%rax
    2856:	48 c1 c0 19          	rol    $0x19,%rax
    285a:	48 8b 4c 24 e8       	mov    -0x18(%rsp),%rcx
    285f:	48 c1 c1 08          	rol    $0x8,%rcx
    2863:	4c 31 f7             	xor    %r14,%rdi
    2866:	48 c1 c7 12          	rol    $0x12,%rdi
    286a:	4c 89 c6             	mov    %r8,%rsi
    286d:	48 f7 d6             	not    %rsi
    2870:	48 21 c6             	and    %rax,%rsi
    2873:	49 89 cc             	mov    %rcx,%r12
    2876:	49 f7 d4             	not    %r12
    2879:	49 21 fc             	and    %rdi,%r12
    287c:	49 31 c4             	xor    %rax,%r12
    287f:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    2884:	49 89 c4             	mov    %rax,%r12
    2887:	49 f7 d4             	not    %r12
    288a:	49 21 cc             	and    %rcx,%r12
    288d:	49 89 fd             	mov    %rdi,%r13
    2890:	49 f7 d5             	not    %r13
    2893:	49 21 ed             	and    %rbp,%r13
    2896:	49 31 cd             	xor    %rcx,%r13
    2899:	4c 89 6c 24 a0       	mov    %r13,-0x60(%rsp)
    289e:	48 31 ee             	xor    %rbp,%rsi
    28a1:	48 89 74 24 90       	mov    %rsi,-0x70(%rsp)
    28a6:	4d 31 c4             	xor    %r8,%r12
    28a9:	4c 89 64 24 f0       	mov    %r12,-0x10(%rsp)
    28ae:	48 f7 d5             	not    %rbp
    28b1:	4c 21 c5             	and    %r8,%rbp
    28b4:	4c 8b 6c 24 88       	mov    -0x78(%rsp),%r13
    28b9:	4d 31 f5             	xor    %r14,%r13
    28bc:	49 c1 c5 24          	rol    $0x24,%r13
    28c0:	48 31 fd             	xor    %rdi,%rbp
    28c3:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
    28c8:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
    28cd:	48 31 d6             	xor    %rdx,%rsi
    28d0:	48 89 d5             	mov    %rdx,%rbp
    28d3:	48 c1 c6 0a          	rol    $0xa,%rsi
    28d7:	48 8b 7c 24 c8       	mov    -0x38(%rsp),%rdi
    28dc:	4c 31 ff             	xor    %r15,%rdi
    28df:	48 c1 c7 0f          	rol    $0xf,%rdi
    28e3:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    28e8:	4c 31 ca             	xor    %r9,%rdx
    28eb:	48 c1 c2 38          	rol    $0x38,%rdx
    28ef:	4c 89 e8             	mov    %r13,%rax
    28f2:	48 f7 d0             	not    %rax
    28f5:	48 21 f0             	and    %rsi,%rax
    28f8:	49 89 fc             	mov    %rdi,%r12
    28fb:	49 f7 d4             	not    %r12
    28fe:	49 21 d4             	and    %rdx,%r12
    2901:	49 31 f4             	xor    %rsi,%r12
    2904:	4c 89 64 24 c8       	mov    %r12,-0x38(%rsp)
    2909:	48 89 f1             	mov    %rsi,%rcx
    290c:	4c 8b 44 24 80       	mov    -0x80(%rsp),%r8
    2911:	49 c1 c0 1b          	rol    $0x1b,%r8
    2915:	48 f7 d1             	not    %rcx
    2918:	48 21 f9             	and    %rdi,%rcx
    291b:	49 89 d4             	mov    %rdx,%r12
    291e:	49 f7 d4             	not    %r12
    2921:	4d 21 c4             	and    %r8,%r12
    2924:	49 31 fc             	xor    %rdi,%r12
    2927:	4c 31 c0             	xor    %r8,%rax
    292a:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    292f:	4c 31 e9             	xor    %r13,%rcx
    2932:	48 89 4c 24 88       	mov    %rcx,-0x78(%rsp)
    2937:	49 f7 d0             	not    %r8
    293a:	4d 21 e8             	and    %r13,%r8
    293d:	4c 33 7c 24 50       	xor    0x50(%rsp),%r15
    2942:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    2947:	4c 33 74 24 c0       	xor    -0x40(%rsp),%r14
    294c:	48 33 6c 24 38       	xor    0x38(%rsp),%rbp
    2951:	49 c1 c7 3e          	rol    $0x3e,%r15
    2955:	49 c1 c1 37          	rol    $0x37,%r9
    2959:	49 c1 c2 27          	rol    $0x27,%r10
    295d:	49 c1 c6 29          	rol    $0x29,%r14
    2961:	48 c1 c5 02          	rol    $0x2,%rbp
    2965:	49 31 d0             	xor    %rdx,%r8
    2968:	4c 89 ca             	mov    %r9,%rdx
    296b:	48 f7 d2             	not    %rdx
    296e:	4c 21 d2             	and    %r10,%rdx
    2971:	4c 89 f0             	mov    %r14,%rax
    2974:	48 f7 d0             	not    %rax
    2977:	48 21 e8             	and    %rbp,%rax
    297a:	4c 31 d0             	xor    %r10,%rax
    297d:	49 f7 d2             	not    %r10
    2980:	4d 21 f2             	and    %r14,%r10
    2983:	48 89 ef             	mov    %rbp,%rdi
    2986:	48 f7 d7             	not    %rdi
    2989:	4c 21 ff             	and    %r15,%rdi
    298c:	4c 31 f7             	xor    %r14,%rdi
    298f:	48 89 7c 24 c0       	mov    %rdi,-0x40(%rsp)
    2994:	4c 31 fa             	xor    %r15,%rdx
    2997:	49 89 d5             	mov    %rdx,%r13
    299a:	4d 31 ca             	xor    %r9,%r10
    299d:	49 f7 d7             	not    %r15
    29a0:	4d 21 cf             	and    %r9,%r15
    29a3:	49 31 ef             	xor    %rbp,%r15
    29a6:	4c 89 7c 24 b0       	mov    %r15,-0x50(%rsp)
    29ab:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
    29b0:	48 83 44 24 10 02    	addq   $0x2,0x10(%rsp)
    29b6:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
    29bb:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    29c0:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    29c5:	48 8b 6c 24 d8       	mov    -0x28(%rsp),%rbp
    29ca:	48 89 5c 24 80       	mov    %rbx,-0x80(%rsp)
    29cf:	e9 0f f9 ff ff       	jmp    22e3 <KeccakF1600_StatePermute+0xe7>
    29d4:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    29d9:	48 8b 7c 24 80       	mov    -0x80(%rsp),%rdi
    29de:	48 89 39             	mov    %rdi,(%rcx)
    29e1:	48 89 69 08          	mov    %rbp,0x8(%rcx)
    29e5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    29ea:	48 89 79 10          	mov    %rdi,0x10(%rcx)
    29ee:	48 8b 74 24 b8       	mov    -0x48(%rsp),%rsi
    29f3:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    29f7:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    29fb:	48 8b 14 24          	mov    (%rsp),%rdx
    29ff:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    2a03:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    2a08:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    2a0c:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
    2a11:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    2a15:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
    2a1a:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    2a1e:	4c 89 79 48          	mov    %r15,0x48(%rcx)
    2a22:	48 8b 54 24 90       	mov    -0x70(%rsp),%rdx
    2a27:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2a2b:	48 8b 54 24 f0       	mov    -0x10(%rsp),%rdx
    2a30:	48 89 51 58          	mov    %rdx,0x58(%rcx)
    2a34:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    2a39:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    2a3d:	48 8b 54 24 a0       	mov    -0x60(%rsp),%rdx
    2a42:	48 89 51 68          	mov    %rdx,0x68(%rcx)
    2a46:	4c 89 71 70          	mov    %r14,0x70(%rcx)
    2a4a:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    2a4f:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    2a53:	48 8b 54 24 88       	mov    -0x78(%rsp),%rdx
    2a58:	48 89 91 80 00 00 00 	mov    %rdx,0x80(%rcx)
    2a5f:	48 8b 54 24 c8       	mov    -0x38(%rsp),%rdx
    2a64:	48 89 91 88 00 00 00 	mov    %rdx,0x88(%rcx)
    2a6b:	4c 89 a1 90 00 00 00 	mov    %r12,0x90(%rcx)
    2a72:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2a79:	4c 89 a9 a0 00 00 00 	mov    %r13,0xa0(%rcx)
    2a80:	4c 89 91 a8 00 00 00 	mov    %r10,0xa8(%rcx)
    2a87:	48 89 81 b0 00 00 00 	mov    %rax,0xb0(%rcx)
    2a8e:	48 8b 44 24 c0       	mov    -0x40(%rsp),%rax
    2a93:	48 89 81 b8 00 00 00 	mov    %rax,0xb8(%rcx)
    2a9a:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    2a9f:	48 89 81 c0 00 00 00 	mov    %rax,0xc0(%rcx)
    2aa6:	48 83 c4 68          	add    $0x68,%rsp
    2aaa:	5b                   	pop    %rbx
    2aab:	41 5c                	pop    %r12
    2aad:	41 5d                	pop    %r13
    2aaf:	41 5e                	pop    %r14
    2ab1:	41 5f                	pop    %r15
    2ab3:	5d                   	pop    %rbp
    2ab4:	c3                   	ret

0000000000002ab5 <store64>:
    2ab5:	31 c9                	xor    %ecx,%ecx
    2ab7:	48 83 f9 40          	cmp    $0x40,%rcx
    2abb:	74 11                	je     2ace <store64+0x19>
    2abd:	48 89 f0             	mov    %rsi,%rax
    2ac0:	48 d3 e8             	shr    %cl,%rax
    2ac3:	88 07                	mov    %al,(%rdi)
    2ac5:	48 83 c1 08          	add    $0x8,%rcx
    2ac9:	48 ff c7             	inc    %rdi
    2acc:	eb e9                	jmp    2ab7 <store64+0x2>
    2ace:	c3                   	ret

0000000000002acf <pqcrystals_kyber_fips202_ref_sha3_512>:
    2acf:	41 56                	push   %r14
    2ad1:	53                   	push   %rbx
    2ad2:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    2ad9:	48 89 d1             	mov    %rdx,%rcx
    2adc:	48 89 f2             	mov    %rsi,%rdx
    2adf:	48 89 fb             	mov    %rdi,%rbx
    2ae2:	49 89 e6             	mov    %rsp,%r14
    2ae5:	6a 48                	push   $0x48
    2ae7:	5e                   	pop    %rsi
    2ae8:	6a 06                	push   $0x6
    2aea:	41 58                	pop    %r8
    2aec:	4c 89 f7             	mov    %r14,%rdi
    2aef:	e8 f3 f3 ff ff       	call   1ee7 <keccak_absorb_once>
    2af4:	4c 89 f7             	mov    %r14,%rdi
    2af7:	e8 00 f7 ff ff       	call   21fc <KeccakF1600_StatePermute>
    2afc:	45 31 f6             	xor    %r14d,%r14d
    2aff:	49 83 fe 40          	cmp    $0x40,%r14
    2b03:	74 13                	je     2b18 <pqcrystals_kyber_fips202_ref_sha3_512+0x49>
    2b05:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    2b09:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    2b0d:	e8 a3 ff ff ff       	call   2ab5 <store64>
    2b12:	49 83 c6 08          	add    $0x8,%r14
    2b16:	eb e7                	jmp    2aff <pqcrystals_kyber_fips202_ref_sha3_512+0x30>
    2b18:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    2b1f:	5b                   	pop    %rbx
    2b20:	41 5e                	pop    %r14
    2b22:	c3                   	ret

Disassembly of section .fini:

0000000000002b24 <_fini>:
    2b24:	f3 0f 1e fa          	endbr64
    2b28:	48 83 ec 08          	sub    $0x8,%rsp
    2b2c:	48 83 c4 08          	add    $0x8,%rsp
    2b30:	c3                   	ret

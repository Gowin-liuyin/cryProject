
build-poison/kyberslash_unfixed_probe:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 c1 3f 00 00 	mov    0x3fc1(%rip),%rax        # 4fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <puts@plt-0x10>:
    1020:	ff 35 ca 3f 00 00    	push   0x3fca(%rip)        # 4ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 3f 00 00    	jmp    *0x3fcc(%rip)        # 4ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001030 <puts@plt>:
    1030:	ff 25 ca 3f 00 00    	jmp    *0x3fca(%rip)        # 5000 <puts@GLIBC_2.2.5>
    1036:	68 00 00 00 00       	push   $0x0
    103b:	e9 e0 ff ff ff       	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001040 <__cxa_finalize@plt>:
    1040:	ff 25 9a 3f 00 00    	jmp    *0x3f9a(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1046:	66 90                	xchg   %ax,%ax

Disassembly of section .text:

0000000000001050 <_start>:
    1050:	f3 0f 1e fa          	endbr64
    1054:	31 ed                	xor    %ebp,%ebp
    1056:	49 89 d1             	mov    %rdx,%r9
    1059:	5e                   	pop    %rsi
    105a:	48 89 e2             	mov    %rsp,%rdx
    105d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    1061:	50                   	push   %rax
    1062:	54                   	push   %rsp
    1063:	45 31 c0             	xor    %r8d,%r8d
    1066:	31 c9                	xor    %ecx,%ecx
    1068:	48 8d 3d d1 00 00 00 	lea    0xd1(%rip),%rdi        # 1140 <main>
    106f:	ff 15 4b 3f 00 00    	call   *0x3f4b(%rip)        # 4fc0 <__libc_start_main@GLIBC_2.34>
    1075:	f4                   	hlt
    1076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    107d:	00 00 00 

0000000000001080 <deregister_tm_clones>:
    1080:	48 8d 3d 91 3f 00 00 	lea    0x3f91(%rip),%rdi        # 5018 <__TMC_END__>
    1087:	48 8d 05 8a 3f 00 00 	lea    0x3f8a(%rip),%rax        # 5018 <__TMC_END__>
    108e:	48 39 f8             	cmp    %rdi,%rax
    1091:	74 15                	je     10a8 <deregister_tm_clones+0x28>
    1093:	48 8b 05 2e 3f 00 00 	mov    0x3f2e(%rip),%rax        # 4fc8 <_ITM_deregisterTMCloneTable@Base>
    109a:	48 85 c0             	test   %rax,%rax
    109d:	74 09                	je     10a8 <deregister_tm_clones+0x28>
    109f:	ff e0                	jmp    *%rax
    10a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010b0 <register_tm_clones>:
    10b0:	48 8d 3d 61 3f 00 00 	lea    0x3f61(%rip),%rdi        # 5018 <__TMC_END__>
    10b7:	48 8d 35 5a 3f 00 00 	lea    0x3f5a(%rip),%rsi        # 5018 <__TMC_END__>
    10be:	48 29 fe             	sub    %rdi,%rsi
    10c1:	48 89 f0             	mov    %rsi,%rax
    10c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    10c8:	48 c1 f8 03          	sar    $0x3,%rax
    10cc:	48 01 c6             	add    %rax,%rsi
    10cf:	48 d1 fe             	sar    $1,%rsi
    10d2:	74 14                	je     10e8 <register_tm_clones+0x38>
    10d4:	48 8b 05 fd 3e 00 00 	mov    0x3efd(%rip),%rax        # 4fd8 <_ITM_registerTMCloneTable@Base>
    10db:	48 85 c0             	test   %rax,%rax
    10de:	74 08                	je     10e8 <register_tm_clones+0x38>
    10e0:	ff e0                	jmp    *%rax
    10e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010f0 <__do_global_dtors_aux>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	80 3d 1d 3f 00 00 00 	cmpb   $0x0,0x3f1d(%rip)        # 5018 <__TMC_END__>
    10fb:	75 2b                	jne    1128 <__do_global_dtors_aux+0x38>
    10fd:	55                   	push   %rbp
    10fe:	48 83 3d da 3e 00 00 	cmpq   $0x0,0x3eda(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1105:	00 
    1106:	48 89 e5             	mov    %rsp,%rbp
    1109:	74 0c                	je     1117 <__do_global_dtors_aux+0x27>
    110b:	48 8b 3d fe 3e 00 00 	mov    0x3efe(%rip),%rdi        # 5010 <__dso_handle>
    1112:	e8 29 ff ff ff       	call   1040 <__cxa_finalize@plt>
    1117:	e8 64 ff ff ff       	call   1080 <deregister_tm_clones>
    111c:	c6 05 f5 3e 00 00 01 	movb   $0x1,0x3ef5(%rip)        # 5018 <__TMC_END__>
    1123:	5d                   	pop    %rbp
    1124:	c3                   	ret
    1125:	0f 1f 00             	nopl   (%rax)
    1128:	c3                   	ret
    1129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001130 <frame_dummy>:
    1130:	f3 0f 1e fa          	endbr64
    1134:	e9 77 ff ff ff       	jmp    10b0 <register_tm_clones>
    1139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001140 <main>:
    1140:	55                   	push   %rbp
    1141:	48 89 e5             	mov    %rsp,%rbp
    1144:	48 81 ec 70 0e 00 00 	sub    $0xe70,%rsp
    114b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%rbp)
    1152:	c6 85 8f f3 ff ff 00 	movb   $0x0,-0xc71(%rbp)
    1159:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
    1160:	00 00 00 00 
    1164:	48 81 bd 80 f3 ff ff 	cmpq   $0x100,-0xc80(%rbp)
    116b:	00 01 00 00 
    116f:	0f 83 9f 00 00 00    	jae    1214 <main+0xd4>
    1175:	48 6b 85 80 f3 ff ff 	imul   $0xd,-0xc80(%rbp),%rax
    117c:	0d 
    117d:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    1182:	31 d2                	xor    %edx,%edx
    1184:	48 f7 f1             	div    %rcx
    1187:	66 89 d1             	mov    %dx,%cx
    118a:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1191:	66 89 8c 45 fc fd ff 	mov    %cx,-0x204(%rbp,%rax,2)
    1198:	ff 
    1199:	48 c7 85 78 f3 ff ff 	movq   $0x0,-0xc88(%rbp)
    11a0:	00 00 00 00 
    11a4:	48 83 bd 78 f3 ff ff 	cmpq   $0x3,-0xc88(%rbp)
    11ab:	03 
    11ac:	0f 83 46 00 00 00    	jae    11f8 <main+0xb8>
    11b2:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    11b9:	66 8b 94 45 fc fd ff 	mov    -0x204(%rbp,%rax,2),%dx
    11c0:	ff 
    11c1:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    11c8:	48 8b 8d 78 f3 ff ff 	mov    -0xc88(%rbp),%rcx
    11cf:	48 c1 e1 09          	shl    $0x9,%rcx
    11d3:	48 01 c8             	add    %rcx,%rax
    11d6:	48 8b 8d 80 f3 ff ff 	mov    -0xc80(%rbp),%rcx
    11dd:	66 89 14 48          	mov    %dx,(%rax,%rcx,2)
    11e1:	48 8b 85 78 f3 ff ff 	mov    -0xc88(%rbp),%rax
    11e8:	48 83 c0 01          	add    $0x1,%rax
    11ec:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
    11f3:	e9 ac ff ff ff       	jmp    11a4 <main+0x64>
    11f8:	e9 00 00 00 00       	jmp    11fd <main+0xbd>
    11fd:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1204:	48 83 c0 01          	add    $0x1,%rax
    1208:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
    120f:	e9 50 ff ff ff       	jmp    1164 <main+0x24>
    1214:	48 c7 85 40 f3 ff ff 	movq   $0x4d430001,-0xcc0(%rbp)
    121b:	01 00 43 4d 
    121f:	48 8d 85 fc fd ff ff 	lea    -0x204(%rbp),%rax
    1226:	48 89 85 48 f3 ff ff 	mov    %rax,-0xcb8(%rbp)
    122d:	48 c7 85 50 f3 ff ff 	movq   $0x200,-0xcb0(%rbp)
    1234:	00 02 00 00 
    1238:	48 c7 85 58 f3 ff ff 	movq   $0x0,-0xca8(%rbp)
    123f:	00 00 00 00 
    1243:	48 c7 85 60 f3 ff ff 	movq   $0x0,-0xca0(%rbp)
    124a:	00 00 00 00 
    124e:	48 c7 85 68 f3 ff ff 	movq   $0x0,-0xc98(%rbp)
    1255:	00 00 00 00 
    1259:	48 8d 85 40 f3 ff ff 	lea    -0xcc0(%rbp),%rax
    1260:	31 c9                	xor    %ecx,%ecx
    1262:	89 ca                	mov    %ecx,%edx
    1264:	48 c1 c7 03          	rol    $0x3,%rdi
    1268:	48 c1 c7 0d          	rol    $0xd,%rdi
    126c:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1270:	48 c1 c7 33          	rol    $0x33,%rdi
    1274:	48 87 db             	xchg   %rbx,%rbx
    1277:	48 89 95 38 f3 ff ff 	mov    %rdx,-0xcc8(%rbp)
    127e:	48 8b 85 38 f3 ff ff 	mov    -0xcc8(%rbp),%rax
    1285:	48 89 85 30 f3 ff ff 	mov    %rax,-0xcd0(%rbp)
    128c:	48 c7 85 00 f3 ff ff 	movq   $0x4d430001,-0xd00(%rbp)
    1293:	01 00 43 4d 
    1297:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    129e:	48 89 85 08 f3 ff ff 	mov    %rax,-0xcf8(%rbp)
    12a5:	48 c7 85 10 f3 ff ff 	movq   $0x600,-0xcf0(%rbp)
    12ac:	00 06 00 00 
    12b0:	48 c7 85 18 f3 ff ff 	movq   $0x0,-0xce8(%rbp)
    12b7:	00 00 00 00 
    12bb:	48 c7 85 20 f3 ff ff 	movq   $0x0,-0xce0(%rbp)
    12c2:	00 00 00 00 
    12c6:	48 c7 85 28 f3 ff ff 	movq   $0x0,-0xcd8(%rbp)
    12cd:	00 00 00 00 
    12d1:	48 8d 85 00 f3 ff ff 	lea    -0xd00(%rbp),%rax
    12d8:	31 c9                	xor    %ecx,%ecx
    12da:	89 ca                	mov    %ecx,%edx
    12dc:	48 c1 c7 03          	rol    $0x3,%rdi
    12e0:	48 c1 c7 0d          	rol    $0xd,%rdi
    12e4:	48 c1 c7 3d          	rol    $0x3d,%rdi
    12e8:	48 c1 c7 33          	rol    $0x33,%rdi
    12ec:	48 87 db             	xchg   %rbx,%rbx
    12ef:	48 89 95 f8 f2 ff ff 	mov    %rdx,-0xd08(%rbp)
    12f6:	48 8b 85 f8 f2 ff ff 	mov    -0xd08(%rbp),%rax
    12fd:	48 89 85 f0 f2 ff ff 	mov    %rax,-0xd10(%rbp)
    1304:	48 8d bd d0 f7 ff ff 	lea    -0x830(%rbp),%rdi
    130b:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1312:	e8 27 05 00 00       	call   183e <pqcrystals_kyber768_ref_poly_tomsg>
    1317:	48 8d bd 50 f7 ff ff 	lea    -0x8b0(%rbp),%rdi
    131e:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1325:	e8 7e 03 00 00       	call   16a8 <pqcrystals_kyber768_ref_poly_compress>
    132a:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
    1331:	48 8d b5 fc f7 ff ff 	lea    -0x804(%rbp),%rsi
    1338:	e8 fb 06 00 00       	call   1a38 <pqcrystals_kyber768_ref_polyvec_compress>
    133d:	48 c7 85 c0 f2 ff ff 	movq   $0x4d430002,-0xd40(%rbp)
    1344:	02 00 43 4d 
    1348:	48 8d 85 fc fd ff ff 	lea    -0x204(%rbp),%rax
    134f:	48 89 85 c8 f2 ff ff 	mov    %rax,-0xd38(%rbp)
    1356:	48 c7 85 d0 f2 ff ff 	movq   $0x200,-0xd30(%rbp)
    135d:	00 02 00 00 
    1361:	48 c7 85 d8 f2 ff ff 	movq   $0x0,-0xd28(%rbp)
    1368:	00 00 00 00 
    136c:	48 c7 85 e0 f2 ff ff 	movq   $0x0,-0xd20(%rbp)
    1373:	00 00 00 00 
    1377:	48 c7 85 e8 f2 ff ff 	movq   $0x0,-0xd18(%rbp)
    137e:	00 00 00 00 
    1382:	48 8d 85 c0 f2 ff ff 	lea    -0xd40(%rbp),%rax
    1389:	31 c9                	xor    %ecx,%ecx
    138b:	89 ca                	mov    %ecx,%edx
    138d:	48 c1 c7 03          	rol    $0x3,%rdi
    1391:	48 c1 c7 0d          	rol    $0xd,%rdi
    1395:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1399:	48 c1 c7 33          	rol    $0x33,%rdi
    139d:	48 87 db             	xchg   %rbx,%rbx
    13a0:	48 89 95 b8 f2 ff ff 	mov    %rdx,-0xd48(%rbp)
    13a7:	48 8b 85 b8 f2 ff ff 	mov    -0xd48(%rbp),%rax
    13ae:	48 89 85 b0 f2 ff ff 	mov    %rax,-0xd50(%rbp)
    13b5:	48 c7 85 80 f2 ff ff 	movq   $0x4d430002,-0xd80(%rbp)
    13bc:	02 00 43 4d 
    13c0:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    13c7:	48 89 85 88 f2 ff ff 	mov    %rax,-0xd78(%rbp)
    13ce:	48 c7 85 90 f2 ff ff 	movq   $0x600,-0xd70(%rbp)
    13d5:	00 06 00 00 
    13d9:	48 c7 85 98 f2 ff ff 	movq   $0x0,-0xd68(%rbp)
    13e0:	00 00 00 00 
    13e4:	48 c7 85 a0 f2 ff ff 	movq   $0x0,-0xd60(%rbp)
    13eb:	00 00 00 00 
    13ef:	48 c7 85 a8 f2 ff ff 	movq   $0x0,-0xd58(%rbp)
    13f6:	00 00 00 00 
    13fa:	48 8d 85 80 f2 ff ff 	lea    -0xd80(%rbp),%rax
    1401:	31 c9                	xor    %ecx,%ecx
    1403:	89 ca                	mov    %ecx,%edx
    1405:	48 c1 c7 03          	rol    $0x3,%rdi
    1409:	48 c1 c7 0d          	rol    $0xd,%rdi
    140d:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1411:	48 c1 c7 33          	rol    $0x33,%rdi
    1415:	48 87 db             	xchg   %rbx,%rbx
    1418:	48 89 95 78 f2 ff ff 	mov    %rdx,-0xd88(%rbp)
    141f:	48 8b 85 78 f2 ff ff 	mov    -0xd88(%rbp),%rax
    1426:	48 89 85 70 f2 ff ff 	mov    %rax,-0xd90(%rbp)
    142d:	48 c7 85 40 f2 ff ff 	movq   $0x4d430002,-0xdc0(%rbp)
    1434:	02 00 43 4d 
    1438:	48 8d 85 d0 f7 ff ff 	lea    -0x830(%rbp),%rax
    143f:	48 89 85 48 f2 ff ff 	mov    %rax,-0xdb8(%rbp)
    1446:	48 c7 85 50 f2 ff ff 	movq   $0x20,-0xdb0(%rbp)
    144d:	20 00 00 00 
    1451:	48 c7 85 58 f2 ff ff 	movq   $0x0,-0xda8(%rbp)
    1458:	00 00 00 00 
    145c:	48 c7 85 60 f2 ff ff 	movq   $0x0,-0xda0(%rbp)
    1463:	00 00 00 00 
    1467:	48 c7 85 68 f2 ff ff 	movq   $0x0,-0xd98(%rbp)
    146e:	00 00 00 00 
    1472:	48 8d 85 40 f2 ff ff 	lea    -0xdc0(%rbp),%rax
    1479:	31 c9                	xor    %ecx,%ecx
    147b:	89 ca                	mov    %ecx,%edx
    147d:	48 c1 c7 03          	rol    $0x3,%rdi
    1481:	48 c1 c7 0d          	rol    $0xd,%rdi
    1485:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1489:	48 c1 c7 33          	rol    $0x33,%rdi
    148d:	48 87 db             	xchg   %rbx,%rbx
    1490:	48 89 95 38 f2 ff ff 	mov    %rdx,-0xdc8(%rbp)
    1497:	48 8b 85 38 f2 ff ff 	mov    -0xdc8(%rbp),%rax
    149e:	48 89 85 30 f2 ff ff 	mov    %rax,-0xdd0(%rbp)
    14a5:	48 c7 85 00 f2 ff ff 	movq   $0x4d430002,-0xe00(%rbp)
    14ac:	02 00 43 4d 
    14b0:	48 8d 85 50 f7 ff ff 	lea    -0x8b0(%rbp),%rax
    14b7:	48 89 85 08 f2 ff ff 	mov    %rax,-0xdf8(%rbp)
    14be:	48 c7 85 10 f2 ff ff 	movq   $0x80,-0xdf0(%rbp)
    14c5:	80 00 00 00 
    14c9:	48 c7 85 18 f2 ff ff 	movq   $0x0,-0xde8(%rbp)
    14d0:	00 00 00 00 
    14d4:	48 c7 85 20 f2 ff ff 	movq   $0x0,-0xde0(%rbp)
    14db:	00 00 00 00 
    14df:	48 c7 85 28 f2 ff ff 	movq   $0x0,-0xdd8(%rbp)
    14e6:	00 00 00 00 
    14ea:	48 8d 85 00 f2 ff ff 	lea    -0xe00(%rbp),%rax
    14f1:	31 c9                	xor    %ecx,%ecx
    14f3:	89 ca                	mov    %ecx,%edx
    14f5:	48 c1 c7 03          	rol    $0x3,%rdi
    14f9:	48 c1 c7 0d          	rol    $0xd,%rdi
    14fd:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1501:	48 c1 c7 33          	rol    $0x33,%rdi
    1505:	48 87 db             	xchg   %rbx,%rbx
    1508:	48 89 95 f8 f1 ff ff 	mov    %rdx,-0xe08(%rbp)
    150f:	48 8b 85 f8 f1 ff ff 	mov    -0xe08(%rbp),%rax
    1516:	48 89 85 f0 f1 ff ff 	mov    %rax,-0xe10(%rbp)
    151d:	48 c7 85 c0 f1 ff ff 	movq   $0x4d430002,-0xe40(%rbp)
    1524:	02 00 43 4d 
    1528:	48 8d 85 90 f3 ff ff 	lea    -0xc70(%rbp),%rax
    152f:	48 89 85 c8 f1 ff ff 	mov    %rax,-0xe38(%rbp)
    1536:	48 c7 85 d0 f1 ff ff 	movq   $0x3c0,-0xe30(%rbp)
    153d:	c0 03 00 00 
    1541:	48 c7 85 d8 f1 ff ff 	movq   $0x0,-0xe28(%rbp)
    1548:	00 00 00 00 
    154c:	48 c7 85 e0 f1 ff ff 	movq   $0x0,-0xe20(%rbp)
    1553:	00 00 00 00 
    1557:	48 c7 85 e8 f1 ff ff 	movq   $0x0,-0xe18(%rbp)
    155e:	00 00 00 00 
    1562:	48 8d 85 c0 f1 ff ff 	lea    -0xe40(%rbp),%rax
    1569:	31 c9                	xor    %ecx,%ecx
    156b:	89 ca                	mov    %ecx,%edx
    156d:	48 c1 c7 03          	rol    $0x3,%rdi
    1571:	48 c1 c7 0d          	rol    $0xd,%rdi
    1575:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1579:	48 c1 c7 33          	rol    $0x33,%rdi
    157d:	48 87 db             	xchg   %rbx,%rbx
    1580:	48 89 95 b8 f1 ff ff 	mov    %rdx,-0xe48(%rbp)
    1587:	48 8b 85 b8 f1 ff ff 	mov    -0xe48(%rbp),%rax
    158e:	48 89 85 b0 f1 ff ff 	mov    %rax,-0xe50(%rbp)
    1595:	48 c7 85 a8 f1 ff ff 	movq   $0x0,-0xe58(%rbp)
    159c:	00 00 00 00 
    15a0:	48 83 bd a8 f1 ff ff 	cmpq   $0x20,-0xe58(%rbp)
    15a7:	20 
    15a8:	0f 83 37 00 00 00    	jae    15e5 <main+0x4a5>
    15ae:	48 8b 85 a8 f1 ff ff 	mov    -0xe58(%rbp),%rax
    15b5:	0f b6 8c 05 d0 f7 ff 	movzbl -0x830(%rbp,%rax,1),%ecx
    15bc:	ff 
    15bd:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    15c3:	0f b6 c0             	movzbl %al,%eax
    15c6:	31 c8                	xor    %ecx,%eax
    15c8:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    15ce:	48 8b 85 a8 f1 ff ff 	mov    -0xe58(%rbp),%rax
    15d5:	48 83 c0 01          	add    $0x1,%rax
    15d9:	48 89 85 a8 f1 ff ff 	mov    %rax,-0xe58(%rbp)
    15e0:	e9 bb ff ff ff       	jmp    15a0 <main+0x460>
    15e5:	48 c7 85 a0 f1 ff ff 	movq   $0x0,-0xe60(%rbp)
    15ec:	00 00 00 00 
    15f0:	48 81 bd a0 f1 ff ff 	cmpq   $0x80,-0xe60(%rbp)
    15f7:	80 00 00 00 
    15fb:	0f 83 37 00 00 00    	jae    1638 <main+0x4f8>
    1601:	48 8b 85 a0 f1 ff ff 	mov    -0xe60(%rbp),%rax
    1608:	0f b6 8c 05 50 f7 ff 	movzbl -0x8b0(%rbp,%rax,1),%ecx
    160f:	ff 
    1610:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1616:	0f b6 c0             	movzbl %al,%eax
    1619:	31 c8                	xor    %ecx,%eax
    161b:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    1621:	48 8b 85 a0 f1 ff ff 	mov    -0xe60(%rbp),%rax
    1628:	48 83 c0 01          	add    $0x1,%rax
    162c:	48 89 85 a0 f1 ff ff 	mov    %rax,-0xe60(%rbp)
    1633:	e9 b8 ff ff ff       	jmp    15f0 <main+0x4b0>
    1638:	48 c7 85 98 f1 ff ff 	movq   $0x0,-0xe68(%rbp)
    163f:	00 00 00 00 
    1643:	48 81 bd 98 f1 ff ff 	cmpq   $0x3c0,-0xe68(%rbp)
    164a:	c0 03 00 00 
    164e:	0f 83 37 00 00 00    	jae    168b <main+0x54b>
    1654:	48 8b 85 98 f1 ff ff 	mov    -0xe68(%rbp),%rax
    165b:	0f b6 8c 05 90 f3 ff 	movzbl -0xc70(%rbp,%rax,1),%ecx
    1662:	ff 
    1663:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1669:	0f b6 c0             	movzbl %al,%eax
    166c:	31 c8                	xor    %ecx,%eax
    166e:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    1674:	48 8b 85 98 f1 ff ff 	mov    -0xe68(%rbp),%rax
    167b:	48 83 c0 01          	add    $0x1,%rax
    167f:	48 89 85 98 f1 ff ff 	mov    %rax,-0xe68(%rbp)
    1686:	e9 b8 ff ff ff       	jmp    1643 <main+0x503>
    168b:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1691:	48 8d 3d 6c 19 00 00 	lea    0x196c(%rip),%rdi        # 3004 <_IO_stdin_used+0x4>
    1698:	e8 93 f9 ff ff       	call   1030 <puts@plt>
    169d:	31 c0                	xor    %eax,%eax
    169f:	48 81 c4 70 0e 00 00 	add    $0xe70,%rsp
    16a6:	5d                   	pop    %rbp
    16a7:	c3                   	ret

00000000000016a8 <pqcrystals_kyber768_ref_poly_compress>:
    16a8:	31 c9                	xor    %ecx,%ecx
    16aa:	41 b8 01 0d 00 00    	mov    $0xd01,%r8d
    16b0:	48 83 f9 20          	cmp    $0x20,%rcx
    16b4:	74 78                	je     172e <pqcrystals_kyber768_ref_poly_compress+0x86>
    16b6:	45 31 c9             	xor    %r9d,%r9d
    16b9:	49 83 f9 08          	cmp    $0x8,%r9
    16bd:	74 2b                	je     16ea <pqcrystals_kyber768_ref_poly_compress+0x42>
    16bf:	42 0f bf 04 4e       	movswl (%rsi,%r9,2),%eax
    16c4:	89 c2                	mov    %eax,%edx
    16c6:	c1 ea 0f             	shr    $0xf,%edx
    16c9:	44 21 c2             	and    %r8d,%edx
    16cc:	01 c2                	add    %eax,%edx
    16ce:	0f b7 c2             	movzwl %dx,%eax
    16d1:	c1 e0 04             	shl    $0x4,%eax
    16d4:	05 80 06 00 00       	add    $0x680,%eax
    16d9:	31 d2                	xor    %edx,%edx
    16db:	41 f7 f0             	div    %r8d
    16de:	24 0f                	and    $0xf,%al
    16e0:	42 88 44 0c f8       	mov    %al,-0x8(%rsp,%r9,1)
    16e5:	49 ff c1             	inc    %r9
    16e8:	eb cf                	jmp    16b9 <pqcrystals_kyber768_ref_poly_compress+0x11>
    16ea:	8a 44 24 f9          	mov    -0x7(%rsp),%al
    16ee:	c0 e0 04             	shl    $0x4,%al
    16f1:	0a 44 24 f8          	or     -0x8(%rsp),%al
    16f5:	88 07                	mov    %al,(%rdi)
    16f7:	8a 44 24 fb          	mov    -0x5(%rsp),%al
    16fb:	c0 e0 04             	shl    $0x4,%al
    16fe:	0a 44 24 fa          	or     -0x6(%rsp),%al
    1702:	88 47 01             	mov    %al,0x1(%rdi)
    1705:	8a 44 24 fd          	mov    -0x3(%rsp),%al
    1709:	c0 e0 04             	shl    $0x4,%al
    170c:	0a 44 24 fc          	or     -0x4(%rsp),%al
    1710:	88 47 02             	mov    %al,0x2(%rdi)
    1713:	8a 44 24 ff          	mov    -0x1(%rsp),%al
    1717:	c0 e0 04             	shl    $0x4,%al
    171a:	0a 44 24 fe          	or     -0x2(%rsp),%al
    171e:	88 47 03             	mov    %al,0x3(%rdi)
    1721:	48 83 c7 04          	add    $0x4,%rdi
    1725:	48 ff c1             	inc    %rcx
    1728:	48 83 c6 10          	add    $0x10,%rsi
    172c:	eb 82                	jmp    16b0 <pqcrystals_kyber768_ref_poly_compress+0x8>
    172e:	c3                   	ret

000000000000172f <pqcrystals_kyber768_ref_poly_decompress>:
    172f:	31 c0                	xor    %eax,%eax
    1731:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    1737:	74 34                	je     176d <pqcrystals_kyber768_ref_poly_decompress+0x3e>
    1739:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    173d:	83 e1 0f             	and    $0xf,%ecx
    1740:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    1746:	83 c1 08             	add    $0x8,%ecx
    1749:	c1 e9 04             	shr    $0x4,%ecx
    174c:	66 89 0c 87          	mov    %cx,(%rdi,%rax,4)
    1750:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    1754:	c1 e9 04             	shr    $0x4,%ecx
    1757:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    175d:	83 c1 08             	add    $0x8,%ecx
    1760:	c1 e9 04             	shr    $0x4,%ecx
    1763:	66 89 4c 87 02       	mov    %cx,0x2(%rdi,%rax,4)
    1768:	48 ff c0             	inc    %rax
    176b:	eb c4                	jmp    1731 <pqcrystals_kyber768_ref_poly_decompress+0x2>
    176d:	c3                   	ret

000000000000176e <pqcrystals_kyber768_ref_poly_tobytes>:
    176e:	48 83 c7 02          	add    $0x2,%rdi
    1772:	31 c0                	xor    %eax,%eax
    1774:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    1779:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    177f:	74 47                	je     17c8 <pqcrystals_kyber768_ref_poly_tobytes+0x5a>
    1781:	44 0f bf 04 86       	movswl (%rsi,%rax,4),%r8d
    1786:	44 89 c2             	mov    %r8d,%edx
    1789:	c1 ea 0f             	shr    $0xf,%edx
    178c:	21 ca                	and    %ecx,%edx
    178e:	44 01 c2             	add    %r8d,%edx
    1791:	44 0f bf 44 86 02    	movswl 0x2(%rsi,%rax,4),%r8d
    1797:	45 89 c1             	mov    %r8d,%r9d
    179a:	41 c1 e9 0f          	shr    $0xf,%r9d
    179e:	41 21 c9             	and    %ecx,%r9d
    17a1:	45 01 c1             	add    %r8d,%r9d
    17a4:	88 57 fe             	mov    %dl,-0x2(%rdi)
    17a7:	0f b6 d6             	movzbl %dh,%edx
    17aa:	45 89 c8             	mov    %r9d,%r8d
    17ad:	41 c1 e0 04          	shl    $0x4,%r8d
    17b1:	41 09 d0             	or     %edx,%r8d
    17b4:	44 88 47 ff          	mov    %r8b,-0x1(%rdi)
    17b8:	41 c1 e9 04          	shr    $0x4,%r9d
    17bc:	44 88 0f             	mov    %r9b,(%rdi)
    17bf:	48 ff c0             	inc    %rax
    17c2:	48 83 c7 03          	add    $0x3,%rdi
    17c6:	eb b1                	jmp    1779 <pqcrystals_kyber768_ref_poly_tobytes+0xb>
    17c8:	c3                   	ret

00000000000017c9 <pqcrystals_kyber768_ref_poly_frombytes>:
    17c9:	48 83 c6 02          	add    $0x2,%rsi
    17cd:	31 c0                	xor    %eax,%eax
    17cf:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    17d5:	74 31                	je     1808 <pqcrystals_kyber768_ref_poly_frombytes+0x3f>
    17d7:	0f b6 4e fe          	movzbl -0x2(%rsi),%ecx
    17db:	0f b6 56 ff          	movzbl -0x1(%rsi),%edx
    17df:	83 e2 0f             	and    $0xf,%edx
    17e2:	c1 e2 08             	shl    $0x8,%edx
    17e5:	09 ca                	or     %ecx,%edx
    17e7:	66 89 14 87          	mov    %dx,(%rdi,%rax,4)
    17eb:	0f b6 4e ff          	movzbl -0x1(%rsi),%ecx
    17ef:	c1 e9 04             	shr    $0x4,%ecx
    17f2:	0f b6 16             	movzbl (%rsi),%edx
    17f5:	c1 e2 04             	shl    $0x4,%edx
    17f8:	09 ca                	or     %ecx,%edx
    17fa:	66 89 54 87 02       	mov    %dx,0x2(%rdi,%rax,4)
    17ff:	48 ff c0             	inc    %rax
    1802:	48 83 c6 03          	add    $0x3,%rsi
    1806:	eb c7                	jmp    17cf <pqcrystals_kyber768_ref_poly_frombytes+0x6>
    1808:	c3                   	ret

0000000000001809 <pqcrystals_kyber768_ref_poly_frommsg>:
    1809:	31 c0                	xor    %eax,%eax
    180b:	48 83 f8 20          	cmp    $0x20,%rax
    180f:	74 2c                	je     183d <pqcrystals_kyber768_ref_poly_frommsg+0x34>
    1811:	31 c9                	xor    %ecx,%ecx
    1813:	48 83 f9 08          	cmp    $0x8,%rcx
    1817:	74 1b                	je     1834 <pqcrystals_kyber768_ref_poly_frommsg+0x2b>
    1819:	44 0f b6 04 06       	movzbl (%rsi,%rax,1),%r8d
    181e:	31 d2                	xor    %edx,%edx
    1820:	41 0f a3 c8          	bt     %ecx,%r8d
    1824:	73 05                	jae    182b <pqcrystals_kyber768_ref_poly_frommsg+0x22>
    1826:	ba 81 06 00 00       	mov    $0x681,%edx
    182b:	66 89 14 4f          	mov    %dx,(%rdi,%rcx,2)
    182f:	48 ff c1             	inc    %rcx
    1832:	eb df                	jmp    1813 <pqcrystals_kyber768_ref_poly_frommsg+0xa>
    1834:	48 ff c0             	inc    %rax
    1837:	48 83 c7 10          	add    $0x10,%rdi
    183b:	eb ce                	jmp    180b <pqcrystals_kyber768_ref_poly_frommsg+0x2>
    183d:	c3                   	ret

000000000000183e <pqcrystals_kyber768_ref_poly_tomsg>:
    183e:	45 31 c0             	xor    %r8d,%r8d
    1841:	41 b9 01 0d 00 00    	mov    $0xd01,%r9d
    1847:	49 83 f8 20          	cmp    $0x20,%r8
    184b:	74 47                	je     1894 <pqcrystals_kyber768_ref_poly_tomsg+0x56>
    184d:	42 c6 04 07 00       	movb   $0x0,(%rdi,%r8,1)
    1852:	31 c9                	xor    %ecx,%ecx
    1854:	45 31 d2             	xor    %r10d,%r10d
    1857:	48 83 f9 08          	cmp    $0x8,%rcx
    185b:	74 2e                	je     188b <pqcrystals_kyber768_ref_poly_tomsg+0x4d>
    185d:	0f bf 04 4e          	movswl (%rsi,%rcx,2),%eax
    1861:	89 c2                	mov    %eax,%edx
    1863:	c1 ea 0f             	shr    $0xf,%edx
    1866:	44 21 ca             	and    %r9d,%edx
    1869:	01 c2                	add    %eax,%edx
    186b:	0f b7 c2             	movzwl %dx,%eax
    186e:	8d 04 45 80 06 00 00 	lea    0x680(,%rax,2),%eax
    1875:	31 d2                	xor    %edx,%edx
    1877:	41 f7 f1             	div    %r9d
    187a:	83 e0 01             	and    $0x1,%eax
    187d:	d3 e0                	shl    %cl,%eax
    187f:	41 08 c2             	or     %al,%r10b
    1882:	46 88 14 07          	mov    %r10b,(%rdi,%r8,1)
    1886:	48 ff c1             	inc    %rcx
    1889:	eb cc                	jmp    1857 <pqcrystals_kyber768_ref_poly_tomsg+0x19>
    188b:	49 ff c0             	inc    %r8
    188e:	48 83 c6 10          	add    $0x10,%rsi
    1892:	eb b3                	jmp    1847 <pqcrystals_kyber768_ref_poly_tomsg+0x9>
    1894:	c3                   	ret

0000000000001895 <pqcrystals_kyber768_ref_poly_getnoise_eta1>:
    1895:	41 56                	push   %r14
    1897:	53                   	push   %rbx
    1898:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    189f:	89 d1                	mov    %edx,%ecx
    18a1:	48 89 f2             	mov    %rsi,%rdx
    18a4:	48 89 fb             	mov    %rdi,%rbx
    18a7:	49 89 e6             	mov    %rsp,%r14
    18aa:	be 80 00 00 00       	mov    $0x80,%esi
    18af:	4c 89 f7             	mov    %r14,%rdi
    18b2:	e8 71 07 00 00       	call   2028 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    18b7:	48 89 df             	mov    %rbx,%rdi
    18ba:	4c 89 f6             	mov    %r14,%rsi
    18bd:	e8 a6 06 00 00       	call   1f68 <pqcrystals_kyber768_ref_poly_cbd_eta1>
    18c2:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    18c9:	5b                   	pop    %rbx
    18ca:	41 5e                	pop    %r14
    18cc:	c3                   	ret

00000000000018cd <pqcrystals_kyber768_ref_poly_getnoise_eta2>:
    18cd:	41 56                	push   %r14
    18cf:	53                   	push   %rbx
    18d0:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    18d7:	89 d1                	mov    %edx,%ecx
    18d9:	48 89 f2             	mov    %rsi,%rdx
    18dc:	48 89 fb             	mov    %rdi,%rbx
    18df:	49 89 e6             	mov    %rsp,%r14
    18e2:	be 80 00 00 00       	mov    $0x80,%esi
    18e7:	4c 89 f7             	mov    %r14,%rdi
    18ea:	e8 39 07 00 00       	call   2028 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    18ef:	48 89 df             	mov    %rbx,%rdi
    18f2:	4c 89 f6             	mov    %r14,%rsi
    18f5:	e8 d0 06 00 00       	call   1fca <pqcrystals_kyber768_ref_poly_cbd_eta2>
    18fa:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    1901:	5b                   	pop    %rbx
    1902:	41 5e                	pop    %r14
    1904:	c3                   	ret

0000000000001905 <pqcrystals_kyber768_ref_poly_ntt>:
    1905:	53                   	push   %rbx
    1906:	48 89 fb             	mov    %rdi,%rbx
    1909:	e8 66 04 00 00       	call   1d74 <pqcrystals_kyber768_ref_ntt>
    190e:	48 89 df             	mov    %rbx,%rdi
    1911:	5b                   	pop    %rbx
    1912:	e9 00 00 00 00       	jmp    1917 <pqcrystals_kyber768_ref_poly_reduce>

0000000000001917 <pqcrystals_kyber768_ref_poly_reduce>:
    1917:	41 56                	push   %r14
    1919:	53                   	push   %rbx
    191a:	50                   	push   %rax
    191b:	48 89 fb             	mov    %rdi,%rbx
    191e:	45 31 f6             	xor    %r14d,%r14d
    1921:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    1928:	74 14                	je     193e <pqcrystals_kyber768_ref_poly_reduce+0x27>
    192a:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    192f:	e8 ad 06 00 00       	call   1fe1 <pqcrystals_kyber768_ref_barrett_reduce>
    1934:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1939:	49 ff c6             	inc    %r14
    193c:	eb e3                	jmp    1921 <pqcrystals_kyber768_ref_poly_reduce+0xa>
    193e:	48 83 c4 08          	add    $0x8,%rsp
    1942:	5b                   	pop    %rbx
    1943:	41 5e                	pop    %r14
    1945:	c3                   	ret

0000000000001946 <pqcrystals_kyber768_ref_poly_invntt_tomont>:
    1946:	e9 c8 04 00 00       	jmp    1e13 <pqcrystals_kyber768_ref_invntt>

000000000000194b <pqcrystals_kyber768_ref_poly_basemul_montgomery>:
    194b:	55                   	push   %rbp
    194c:	41 57                	push   %r15
    194e:	41 56                	push   %r14
    1950:	41 55                	push   %r13
    1952:	41 54                	push   %r12
    1954:	53                   	push   %rbx
    1955:	50                   	push   %rax
    1956:	48 89 d3             	mov    %rdx,%rbx
    1959:	49 89 f6             	mov    %rsi,%r14
    195c:	49 89 ff             	mov    %rdi,%r15
    195f:	4c 8d 25 ca 16 00 00 	lea    0x16ca(%rip),%r12        # 3030 <pqcrystals_kyber768_ref_zetas>
    1966:	49 83 ec 80          	sub    $0xffffffffffffff80,%r12
    196a:	45 31 ed             	xor    %r13d,%r13d
    196d:	49 81 fd 00 02 00 00 	cmp    $0x200,%r13
    1974:	74 44                	je     19ba <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x6f>
    1976:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    197a:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    197e:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    1982:	41 0f bf 2c 24       	movswl (%r12),%ebp
    1987:	89 e9                	mov    %ebp,%ecx
    1989:	e8 6a 05 00 00       	call   1ef8 <pqcrystals_kyber768_ref_basemul>
    198e:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    1992:	48 83 c7 04          	add    $0x4,%rdi
    1996:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    199a:	48 83 c6 04          	add    $0x4,%rsi
    199e:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    19a2:	48 83 c2 04          	add    $0x4,%rdx
    19a6:	f7 dd                	neg    %ebp
    19a8:	0f bf cd             	movswl %bp,%ecx
    19ab:	e8 48 05 00 00       	call   1ef8 <pqcrystals_kyber768_ref_basemul>
    19b0:	49 83 c5 08          	add    $0x8,%r13
    19b4:	49 83 c4 02          	add    $0x2,%r12
    19b8:	eb b3                	jmp    196d <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x22>
    19ba:	48 83 c4 08          	add    $0x8,%rsp
    19be:	5b                   	pop    %rbx
    19bf:	41 5c                	pop    %r12
    19c1:	41 5d                	pop    %r13
    19c3:	41 5e                	pop    %r14
    19c5:	41 5f                	pop    %r15
    19c7:	5d                   	pop    %rbp
    19c8:	c3                   	ret

00000000000019c9 <pqcrystals_kyber768_ref_poly_tomont>:
    19c9:	41 56                	push   %r14
    19cb:	53                   	push   %rbx
    19cc:	50                   	push   %rax
    19cd:	48 89 fb             	mov    %rdi,%rbx
    19d0:	45 31 f6             	xor    %r14d,%r14d
    19d3:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    19da:	74 1a                	je     19f6 <pqcrystals_kyber768_ref_poly_tomont+0x2d>
    19dc:	42 0f bf 04 73       	movswl (%rbx,%r14,2),%eax
    19e1:	69 f8 49 05 00 00    	imul   $0x549,%eax,%edi
    19e7:	e8 e0 05 00 00       	call   1fcc <pqcrystals_kyber768_ref_montgomery_reduce>
    19ec:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    19f1:	49 ff c6             	inc    %r14
    19f4:	eb dd                	jmp    19d3 <pqcrystals_kyber768_ref_poly_tomont+0xa>
    19f6:	48 83 c4 08          	add    $0x8,%rsp
    19fa:	5b                   	pop    %rbx
    19fb:	41 5e                	pop    %r14
    19fd:	c3                   	ret

00000000000019fe <pqcrystals_kyber768_ref_poly_add>:
    19fe:	31 c0                	xor    %eax,%eax
    1a00:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    1a06:	74 11                	je     1a19 <pqcrystals_kyber768_ref_poly_add+0x1b>
    1a08:	0f b7 0c 42          	movzwl (%rdx,%rax,2),%ecx
    1a0c:	66 03 0c 46          	add    (%rsi,%rax,2),%cx
    1a10:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    1a14:	48 ff c0             	inc    %rax
    1a17:	eb e7                	jmp    1a00 <pqcrystals_kyber768_ref_poly_add+0x2>
    1a19:	c3                   	ret

0000000000001a1a <pqcrystals_kyber768_ref_poly_sub>:
    1a1a:	31 c0                	xor    %eax,%eax
    1a1c:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    1a22:	74 11                	je     1a35 <pqcrystals_kyber768_ref_poly_sub+0x1b>
    1a24:	0f b7 0c 46          	movzwl (%rsi,%rax,2),%ecx
    1a28:	66 2b 0c 42          	sub    (%rdx,%rax,2),%cx
    1a2c:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    1a30:	48 ff c0             	inc    %rax
    1a33:	eb e7                	jmp    1a1c <pqcrystals_kyber768_ref_poly_sub+0x2>
    1a35:	c3                   	ret
    1a36:	66 90                	xchg   %ax,%ax

0000000000001a38 <pqcrystals_kyber768_ref_polyvec_compress>:
    1a38:	31 c9                	xor    %ecx,%ecx
    1a3a:	41 b8 01 0d 00 00    	mov    $0xd01,%r8d
    1a40:	48 83 f9 03          	cmp    $0x3,%rcx
    1a44:	0f 84 ae 00 00 00    	je     1af8 <pqcrystals_kyber768_ref_polyvec_compress+0xc0>
    1a4a:	49 89 f1             	mov    %rsi,%r9
    1a4d:	45 31 d2             	xor    %r10d,%r10d
    1a50:	49 83 fa 40          	cmp    $0x40,%r10
    1a54:	0f 84 8f 00 00 00    	je     1ae9 <pqcrystals_kyber768_ref_polyvec_compress+0xb1>
    1a5a:	45 31 db             	xor    %r11d,%r11d
    1a5d:	49 83 fb 04          	cmp    $0x4,%r11
    1a61:	74 2f                	je     1a92 <pqcrystals_kyber768_ref_polyvec_compress+0x5a>
    1a63:	43 0f bf 04 59       	movswl (%r9,%r11,2),%eax
    1a68:	89 c2                	mov    %eax,%edx
    1a6a:	c1 ea 0f             	shr    $0xf,%edx
    1a6d:	44 21 c2             	and    %r8d,%edx
    1a70:	01 c2                	add    %eax,%edx
    1a72:	0f b7 c2             	movzwl %dx,%eax
    1a75:	c1 e0 0a             	shl    $0xa,%eax
    1a78:	05 80 06 00 00       	add    $0x680,%eax
    1a7d:	31 d2                	xor    %edx,%edx
    1a7f:	41 f7 f0             	div    %r8d
    1a82:	25 ff 03 00 00       	and    $0x3ff,%eax
    1a87:	66 42 89 44 5c f8    	mov    %ax,-0x8(%rsp,%r11,2)
    1a8d:	49 ff c3             	inc    %r11
    1a90:	eb cb                	jmp    1a5d <pqcrystals_kyber768_ref_polyvec_compress+0x25>
    1a92:	8a 44 24 f8          	mov    -0x8(%rsp),%al
    1a96:	88 07                	mov    %al,(%rdi)
    1a98:	8a 44 24 fa          	mov    -0x6(%rsp),%al
    1a9c:	c0 e0 02             	shl    $0x2,%al
    1a9f:	0a 44 24 f9          	or     -0x7(%rsp),%al
    1aa3:	88 47 01             	mov    %al,0x1(%rdi)
    1aa6:	0f b7 44 24 fa       	movzwl -0x6(%rsp),%eax
    1aab:	c1 e8 06             	shr    $0x6,%eax
    1aae:	8a 54 24 fc          	mov    -0x4(%rsp),%dl
    1ab2:	c0 e2 04             	shl    $0x4,%dl
    1ab5:	08 c2                	or     %al,%dl
    1ab7:	88 57 02             	mov    %dl,0x2(%rdi)
    1aba:	0f b7 44 24 fc       	movzwl -0x4(%rsp),%eax
    1abf:	c1 e8 04             	shr    $0x4,%eax
    1ac2:	8a 54 24 fe          	mov    -0x2(%rsp),%dl
    1ac6:	c0 e2 06             	shl    $0x6,%dl
    1ac9:	08 c2                	or     %al,%dl
    1acb:	88 57 03             	mov    %dl,0x3(%rdi)
    1ace:	0f b7 44 24 fe       	movzwl -0x2(%rsp),%eax
    1ad3:	c1 e8 02             	shr    $0x2,%eax
    1ad6:	88 47 04             	mov    %al,0x4(%rdi)
    1ad9:	48 83 c7 05          	add    $0x5,%rdi
    1add:	49 ff c2             	inc    %r10
    1ae0:	49 83 c1 08          	add    $0x8,%r9
    1ae4:	e9 67 ff ff ff       	jmp    1a50 <pqcrystals_kyber768_ref_polyvec_compress+0x18>
    1ae9:	48 ff c1             	inc    %rcx
    1aec:	48 81 c6 00 02 00 00 	add    $0x200,%rsi
    1af3:	e9 48 ff ff ff       	jmp    1a40 <pqcrystals_kyber768_ref_polyvec_compress+0x8>
    1af8:	c3                   	ret

0000000000001af9 <pqcrystals_kyber768_ref_polyvec_decompress>:
    1af9:	31 c0                	xor    %eax,%eax
    1afb:	48 83 f8 03          	cmp    $0x3,%rax
    1aff:	0f 84 b8 00 00 00    	je     1bbd <pqcrystals_kyber768_ref_polyvec_decompress+0xc4>
    1b05:	48 89 f9             	mov    %rdi,%rcx
    1b08:	31 d2                	xor    %edx,%edx
    1b0a:	48 83 fa 40          	cmp    $0x40,%rdx
    1b0e:	0f 84 9a 00 00 00    	je     1bae <pqcrystals_kyber768_ref_polyvec_decompress+0xb5>
    1b14:	44 0f b7 06          	movzwl (%rsi),%r8d
    1b18:	66 44 89 44 24 f8    	mov    %r8w,-0x8(%rsp)
    1b1e:	44 0f b6 46 01       	movzbl 0x1(%rsi),%r8d
    1b23:	41 c1 e8 02          	shr    $0x2,%r8d
    1b27:	44 0f b6 4e 02       	movzbl 0x2(%rsi),%r9d
    1b2c:	41 c1 e1 06          	shl    $0x6,%r9d
    1b30:	45 09 c1             	or     %r8d,%r9d
    1b33:	66 44 89 4c 24 fa    	mov    %r9w,-0x6(%rsp)
    1b39:	44 0f b6 46 02       	movzbl 0x2(%rsi),%r8d
    1b3e:	41 c1 e8 04          	shr    $0x4,%r8d
    1b42:	44 0f b6 4e 03       	movzbl 0x3(%rsi),%r9d
    1b47:	41 c1 e1 04          	shl    $0x4,%r9d
    1b4b:	45 09 c1             	or     %r8d,%r9d
    1b4e:	66 44 89 4c 24 fc    	mov    %r9w,-0x4(%rsp)
    1b54:	44 0f b6 46 03       	movzbl 0x3(%rsi),%r8d
    1b59:	41 c1 e8 06          	shr    $0x6,%r8d
    1b5d:	44 0f b6 4e 04       	movzbl 0x4(%rsi),%r9d
    1b62:	47 8d 04 88          	lea    (%r8,%r9,4),%r8d
    1b66:	66 44 89 44 24 fe    	mov    %r8w,-0x2(%rsp)
    1b6c:	45 31 c0             	xor    %r8d,%r8d
    1b6f:	49 83 f8 04          	cmp    $0x4,%r8
    1b73:	74 29                	je     1b9e <pqcrystals_kyber768_ref_polyvec_decompress+0xa5>
    1b75:	46 0f b7 4c 44 f8    	movzwl -0x8(%rsp,%r8,2),%r9d
    1b7b:	41 81 e1 ff 03 00 00 	and    $0x3ff,%r9d
    1b82:	45 69 c9 01 0d 00 00 	imul   $0xd01,%r9d,%r9d
    1b89:	41 81 c1 00 02 00 00 	add    $0x200,%r9d
    1b90:	41 c1 e9 0a          	shr    $0xa,%r9d
    1b94:	66 46 89 0c 41       	mov    %r9w,(%rcx,%r8,2)
    1b99:	49 ff c0             	inc    %r8
    1b9c:	eb d1                	jmp    1b6f <pqcrystals_kyber768_ref_polyvec_decompress+0x76>
    1b9e:	48 83 c6 05          	add    $0x5,%rsi
    1ba2:	48 ff c2             	inc    %rdx
    1ba5:	48 83 c1 08          	add    $0x8,%rcx
    1ba9:	e9 5c ff ff ff       	jmp    1b0a <pqcrystals_kyber768_ref_polyvec_decompress+0x11>
    1bae:	48 ff c0             	inc    %rax
    1bb1:	48 81 c7 00 02 00 00 	add    $0x200,%rdi
    1bb8:	e9 3e ff ff ff       	jmp    1afb <pqcrystals_kyber768_ref_polyvec_decompress+0x2>
    1bbd:	c3                   	ret

0000000000001bbe <pqcrystals_kyber768_ref_polyvec_tobytes>:
    1bbe:	41 57                	push   %r15
    1bc0:	41 56                	push   %r14
    1bc2:	53                   	push   %rbx
    1bc3:	48 89 f3             	mov    %rsi,%rbx
    1bc6:	49 89 fe             	mov    %rdi,%r14
    1bc9:	45 31 ff             	xor    %r15d,%r15d
    1bcc:	49 81 ff 00 06 00 00 	cmp    $0x600,%r15
    1bd3:	74 1c                	je     1bf1 <pqcrystals_kyber768_ref_polyvec_tobytes+0x33>
    1bd5:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    1bd9:	4c 89 f7             	mov    %r14,%rdi
    1bdc:	e8 8d fb ff ff       	call   176e <pqcrystals_kyber768_ref_poly_tobytes>
    1be1:	49 81 c7 00 02 00 00 	add    $0x200,%r15
    1be8:	49 81 c6 80 01 00 00 	add    $0x180,%r14
    1bef:	eb db                	jmp    1bcc <pqcrystals_kyber768_ref_polyvec_tobytes+0xe>
    1bf1:	5b                   	pop    %rbx
    1bf2:	41 5e                	pop    %r14
    1bf4:	41 5f                	pop    %r15
    1bf6:	c3                   	ret

0000000000001bf7 <pqcrystals_kyber768_ref_polyvec_frombytes>:
    1bf7:	41 57                	push   %r15
    1bf9:	41 56                	push   %r14
    1bfb:	53                   	push   %rbx
    1bfc:	48 89 f3             	mov    %rsi,%rbx
    1bff:	49 89 fe             	mov    %rdi,%r14
    1c02:	45 31 ff             	xor    %r15d,%r15d
    1c05:	49 81 ff 80 04 00 00 	cmp    $0x480,%r15
    1c0c:	74 1c                	je     1c2a <pqcrystals_kyber768_ref_polyvec_frombytes+0x33>
    1c0e:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    1c12:	4c 89 f7             	mov    %r14,%rdi
    1c15:	e8 af fb ff ff       	call   17c9 <pqcrystals_kyber768_ref_poly_frombytes>
    1c1a:	49 81 c7 80 01 00 00 	add    $0x180,%r15
    1c21:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1c28:	eb db                	jmp    1c05 <pqcrystals_kyber768_ref_polyvec_frombytes+0xe>
    1c2a:	5b                   	pop    %rbx
    1c2b:	41 5e                	pop    %r14
    1c2d:	41 5f                	pop    %r15
    1c2f:	c3                   	ret

0000000000001c30 <pqcrystals_kyber768_ref_polyvec_ntt>:
    1c30:	41 56                	push   %r14
    1c32:	53                   	push   %rbx
    1c33:	50                   	push   %rax
    1c34:	48 89 fb             	mov    %rdi,%rbx
    1c37:	45 31 f6             	xor    %r14d,%r14d
    1c3a:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1c41:	74 12                	je     1c55 <pqcrystals_kyber768_ref_polyvec_ntt+0x25>
    1c43:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1c47:	e8 b9 fc ff ff       	call   1905 <pqcrystals_kyber768_ref_poly_ntt>
    1c4c:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1c53:	eb e5                	jmp    1c3a <pqcrystals_kyber768_ref_polyvec_ntt+0xa>
    1c55:	48 83 c4 08          	add    $0x8,%rsp
    1c59:	5b                   	pop    %rbx
    1c5a:	41 5e                	pop    %r14
    1c5c:	c3                   	ret

0000000000001c5d <pqcrystals_kyber768_ref_polyvec_invntt_tomont>:
    1c5d:	41 56                	push   %r14
    1c5f:	53                   	push   %rbx
    1c60:	50                   	push   %rax
    1c61:	48 89 fb             	mov    %rdi,%rbx
    1c64:	45 31 f6             	xor    %r14d,%r14d
    1c67:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1c6e:	74 12                	je     1c82 <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0x25>
    1c70:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1c74:	e8 cd fc ff ff       	call   1946 <pqcrystals_kyber768_ref_poly_invntt_tomont>
    1c79:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1c80:	eb e5                	jmp    1c67 <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0xa>
    1c82:	48 83 c4 08          	add    $0x8,%rsp
    1c86:	5b                   	pop    %rbx
    1c87:	41 5e                	pop    %r14
    1c89:	c3                   	ret

0000000000001c8a <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery>:
    1c8a:	41 57                	push   %r15
    1c8c:	41 56                	push   %r14
    1c8e:	41 55                	push   %r13
    1c90:	41 54                	push   %r12
    1c92:	53                   	push   %rbx
    1c93:	48 81 ec 00 02 00 00 	sub    $0x200,%rsp
    1c9a:	49 89 d6             	mov    %rdx,%r14
    1c9d:	49 89 f7             	mov    %rsi,%r15
    1ca0:	48 89 fb             	mov    %rdi,%rbx
    1ca3:	e8 a3 fc ff ff       	call   194b <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    1ca8:	b8 00 02 00 00       	mov    $0x200,%eax
    1cad:	49 01 c7             	add    %rax,%r15
    1cb0:	49 01 c6             	add    %rax,%r14
    1cb3:	45 31 ed             	xor    %r13d,%r13d
    1cb6:	49 89 e4             	mov    %rsp,%r12
    1cb9:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
    1cc0:	74 27                	je     1ce9 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x5f>
    1cc2:	4b 8d 34 2f          	lea    (%r15,%r13,1),%rsi
    1cc6:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
    1cca:	4c 89 e7             	mov    %r12,%rdi
    1ccd:	e8 79 fc ff ff       	call   194b <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    1cd2:	48 89 df             	mov    %rbx,%rdi
    1cd5:	48 89 de             	mov    %rbx,%rsi
    1cd8:	4c 89 e2             	mov    %r12,%rdx
    1cdb:	e8 1e fd ff ff       	call   19fe <pqcrystals_kyber768_ref_poly_add>
    1ce0:	49 81 c5 00 02 00 00 	add    $0x200,%r13
    1ce7:	eb d0                	jmp    1cb9 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x2f>
    1ce9:	48 89 df             	mov    %rbx,%rdi
    1cec:	e8 26 fc ff ff       	call   1917 <pqcrystals_kyber768_ref_poly_reduce>
    1cf1:	48 81 c4 00 02 00 00 	add    $0x200,%rsp
    1cf8:	5b                   	pop    %rbx
    1cf9:	41 5c                	pop    %r12
    1cfb:	41 5d                	pop    %r13
    1cfd:	41 5e                	pop    %r14
    1cff:	41 5f                	pop    %r15
    1d01:	c3                   	ret

0000000000001d02 <pqcrystals_kyber768_ref_polyvec_reduce>:
    1d02:	41 56                	push   %r14
    1d04:	53                   	push   %rbx
    1d05:	50                   	push   %rax
    1d06:	48 89 fb             	mov    %rdi,%rbx
    1d09:	45 31 f6             	xor    %r14d,%r14d
    1d0c:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1d13:	74 12                	je     1d27 <pqcrystals_kyber768_ref_polyvec_reduce+0x25>
    1d15:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1d19:	e8 f9 fb ff ff       	call   1917 <pqcrystals_kyber768_ref_poly_reduce>
    1d1e:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1d25:	eb e5                	jmp    1d0c <pqcrystals_kyber768_ref_polyvec_reduce+0xa>
    1d27:	48 83 c4 08          	add    $0x8,%rsp
    1d2b:	5b                   	pop    %rbx
    1d2c:	41 5e                	pop    %r14
    1d2e:	c3                   	ret

0000000000001d2f <pqcrystals_kyber768_ref_polyvec_add>:
    1d2f:	41 57                	push   %r15
    1d31:	41 56                	push   %r14
    1d33:	41 54                	push   %r12
    1d35:	53                   	push   %rbx
    1d36:	50                   	push   %rax
    1d37:	48 89 d3             	mov    %rdx,%rbx
    1d3a:	49 89 f6             	mov    %rsi,%r14
    1d3d:	49 89 ff             	mov    %rdi,%r15
    1d40:	45 31 e4             	xor    %r12d,%r12d
    1d43:	49 81 fc 00 06 00 00 	cmp    $0x600,%r12
    1d4a:	74 1a                	je     1d66 <pqcrystals_kyber768_ref_polyvec_add+0x37>
    1d4c:	4b 8d 3c 27          	lea    (%r15,%r12,1),%rdi
    1d50:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    1d54:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
    1d58:	e8 a1 fc ff ff       	call   19fe <pqcrystals_kyber768_ref_poly_add>
    1d5d:	49 81 c4 00 02 00 00 	add    $0x200,%r12
    1d64:	eb dd                	jmp    1d43 <pqcrystals_kyber768_ref_polyvec_add+0x14>
    1d66:	48 83 c4 08          	add    $0x8,%rsp
    1d6a:	5b                   	pop    %rbx
    1d6b:	41 5c                	pop    %r12
    1d6d:	41 5e                	pop    %r14
    1d6f:	41 5f                	pop    %r15
    1d71:	c3                   	ret
    1d72:	66 90                	xchg   %ax,%ax

0000000000001d74 <pqcrystals_kyber768_ref_ntt>:
    1d74:	55                   	push   %rbp
    1d75:	41 57                	push   %r15
    1d77:	41 56                	push   %r14
    1d79:	41 55                	push   %r13
    1d7b:	41 54                	push   %r12
    1d7d:	53                   	push   %rbx
    1d7e:	50                   	push   %rax
    1d7f:	48 89 fb             	mov    %rdi,%rbx
    1d82:	b9 80 00 00 00       	mov    $0x80,%ecx
    1d87:	6a 01                	push   $0x1
    1d89:	58                   	pop    %rax
    1d8a:	83 f9 02             	cmp    $0x2,%ecx
    1d8d:	72 6d                	jb     1dfc <pqcrystals_kyber768_ref_ntt+0x88>
    1d8f:	41 89 cd             	mov    %ecx,%r13d
    1d92:	45 31 f6             	xor    %r14d,%r14d
    1d95:	89 0c 24             	mov    %ecx,(%rsp)
    1d98:	41 81 fe ff 00 00 00 	cmp    $0xff,%r14d
    1d9f:	77 57                	ja     1df8 <pqcrystals_kyber768_ref_ntt+0x84>
    1da1:	89 44 24 04          	mov    %eax,0x4(%rsp)
    1da5:	89 c0                	mov    %eax,%eax
    1da7:	45 89 f4             	mov    %r14d,%r12d
    1daa:	41 01 ce             	add    %ecx,%r14d
    1dad:	48 8d 0d 7c 12 00 00 	lea    0x127c(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1db4:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1db8:	4d 39 f4             	cmp    %r14,%r12
    1dbb:	73 2a                	jae    1de7 <pqcrystals_kyber768_ref_ntt+0x73>
    1dbd:	47 8d 3c 2c          	lea    (%r12,%r13,1),%r15d
    1dc1:	42 0f bf 34 7b       	movswl (%rbx,%r15,2),%esi
    1dc6:	89 ef                	mov    %ebp,%edi
    1dc8:	e8 3e 00 00 00       	call   1e0b <fqmul>
    1dcd:	42 0f b7 0c 63       	movzwl (%rbx,%r12,2),%ecx
    1dd2:	89 ca                	mov    %ecx,%edx
    1dd4:	29 c2                	sub    %eax,%edx
    1dd6:	66 42 89 14 7b       	mov    %dx,(%rbx,%r15,2)
    1ddb:	01 c1                	add    %eax,%ecx
    1ddd:	66 42 89 0c 63       	mov    %cx,(%rbx,%r12,2)
    1de2:	49 ff c4             	inc    %r12
    1de5:	eb d1                	jmp    1db8 <pqcrystals_kyber768_ref_ntt+0x44>
    1de7:	8b 44 24 04          	mov    0x4(%rsp),%eax
    1deb:	ff c0                	inc    %eax
    1ded:	45 01 ec             	add    %r13d,%r12d
    1df0:	45 89 e6             	mov    %r12d,%r14d
    1df3:	8b 0c 24             	mov    (%rsp),%ecx
    1df6:	eb a0                	jmp    1d98 <pqcrystals_kyber768_ref_ntt+0x24>
    1df8:	d1 e9                	shr    $1,%ecx
    1dfa:	eb 8e                	jmp    1d8a <pqcrystals_kyber768_ref_ntt+0x16>
    1dfc:	48 83 c4 08          	add    $0x8,%rsp
    1e00:	5b                   	pop    %rbx
    1e01:	41 5c                	pop    %r12
    1e03:	41 5d                	pop    %r13
    1e05:	41 5e                	pop    %r14
    1e07:	41 5f                	pop    %r15
    1e09:	5d                   	pop    %rbp
    1e0a:	c3                   	ret

0000000000001e0b <fqmul>:
    1e0b:	0f af fe             	imul   %esi,%edi
    1e0e:	e9 b9 01 00 00       	jmp    1fcc <pqcrystals_kyber768_ref_montgomery_reduce>

0000000000001e13 <pqcrystals_kyber768_ref_invntt>:
    1e13:	55                   	push   %rbp
    1e14:	41 57                	push   %r15
    1e16:	41 56                	push   %r14
    1e18:	41 55                	push   %r13
    1e1a:	41 54                	push   %r12
    1e1c:	53                   	push   %rbx
    1e1d:	48 83 ec 18          	sub    $0x18,%rsp
    1e21:	48 89 fb             	mov    %rdi,%rbx
    1e24:	6a 02                	push   $0x2
    1e26:	59                   	pop    %rcx
    1e27:	6a 7f                	push   $0x7f
    1e29:	58                   	pop    %rax
    1e2a:	81 f9 81 00 00 00    	cmp    $0x81,%ecx
    1e30:	0f 83 8e 00 00 00    	jae    1ec4 <pqcrystals_kyber768_ref_invntt+0xb1>
    1e36:	89 ca                	mov    %ecx,%edx
    1e38:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    1e3d:	4c 8d 24 53          	lea    (%rbx,%rdx,2),%r12
    1e41:	45 31 ed             	xor    %r13d,%r13d
    1e44:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
    1e48:	41 81 fd ff 00 00 00 	cmp    $0xff,%r13d
    1e4f:	77 6c                	ja     1ebd <pqcrystals_kyber768_ref_invntt+0xaa>
    1e51:	89 44 24 0c          	mov    %eax,0xc(%rsp)
    1e55:	89 c0                	mov    %eax,%eax
    1e57:	45 89 ee             	mov    %r13d,%r14d
    1e5a:	41 01 cd             	add    %ecx,%r13d
    1e5d:	48 8d 0d cc 11 00 00 	lea    0x11cc(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1e64:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1e68:	4d 39 ee             	cmp    %r13,%r14
    1e6b:	73 3c                	jae    1ea9 <pqcrystals_kyber768_ref_invntt+0x96>
    1e6d:	46 0f b7 3c 73       	movzwl (%rbx,%r14,2),%r15d
    1e72:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1e77:	66 44 01 f8          	add    %r15w,%ax
    1e7b:	0f bf f8             	movswl %ax,%edi
    1e7e:	e8 5e 01 00 00       	call   1fe1 <pqcrystals_kyber768_ref_barrett_reduce>
    1e83:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1e88:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1e8d:	44 29 f8             	sub    %r15d,%eax
    1e90:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1e95:	0f bf f0             	movswl %ax,%esi
    1e98:	89 ef                	mov    %ebp,%edi
    1e9a:	e8 6c ff ff ff       	call   1e0b <fqmul>
    1e9f:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1ea4:	49 ff c6             	inc    %r14
    1ea7:	eb bf                	jmp    1e68 <pqcrystals_kyber768_ref_invntt+0x55>
    1ea9:	8b 44 24 0c          	mov    0xc(%rsp),%eax
    1ead:	ff c8                	dec    %eax
    1eaf:	44 03 74 24 10       	add    0x10(%rsp),%r14d
    1eb4:	45 89 f5             	mov    %r14d,%r13d
    1eb7:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
    1ebb:	eb 8b                	jmp    1e48 <pqcrystals_kyber768_ref_invntt+0x35>
    1ebd:	01 c9                	add    %ecx,%ecx
    1ebf:	e9 66 ff ff ff       	jmp    1e2a <pqcrystals_kyber768_ref_invntt+0x17>
    1ec4:	45 31 f6             	xor    %r14d,%r14d
    1ec7:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    1ece:	74 19                	je     1ee9 <pqcrystals_kyber768_ref_invntt+0xd6>
    1ed0:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    1ed5:	be a1 05 00 00       	mov    $0x5a1,%esi
    1eda:	e8 2c ff ff ff       	call   1e0b <fqmul>
    1edf:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1ee4:	49 ff c6             	inc    %r14
    1ee7:	eb de                	jmp    1ec7 <pqcrystals_kyber768_ref_invntt+0xb4>
    1ee9:	48 83 c4 18          	add    $0x18,%rsp
    1eed:	5b                   	pop    %rbx
    1eee:	41 5c                	pop    %r12
    1ef0:	41 5d                	pop    %r13
    1ef2:	41 5e                	pop    %r14
    1ef4:	41 5f                	pop    %r15
    1ef6:	5d                   	pop    %rbp
    1ef7:	c3                   	ret

0000000000001ef8 <pqcrystals_kyber768_ref_basemul>:
    1ef8:	55                   	push   %rbp
    1ef9:	41 57                	push   %r15
    1efb:	41 56                	push   %r14
    1efd:	53                   	push   %rbx
    1efe:	50                   	push   %rax
    1eff:	89 cd                	mov    %ecx,%ebp
    1f01:	49 89 d6             	mov    %rdx,%r14
    1f04:	49 89 f7             	mov    %rsi,%r15
    1f07:	48 89 fb             	mov    %rdi,%rbx
    1f0a:	0f bf 7e 02          	movswl 0x2(%rsi),%edi
    1f0e:	0f bf 72 02          	movswl 0x2(%rdx),%esi
    1f12:	e8 f4 fe ff ff       	call   1e0b <fqmul>
    1f17:	66 89 03             	mov    %ax,(%rbx)
    1f1a:	0f bf f8             	movswl %ax,%edi
    1f1d:	89 ee                	mov    %ebp,%esi
    1f1f:	e8 e7 fe ff ff       	call   1e0b <fqmul>
    1f24:	66 89 03             	mov    %ax,(%rbx)
    1f27:	41 0f bf 3f          	movswl (%r15),%edi
    1f2b:	41 0f bf 36          	movswl (%r14),%esi
    1f2f:	e8 d7 fe ff ff       	call   1e0b <fqmul>
    1f34:	66 01 03             	add    %ax,(%rbx)
    1f37:	41 0f bf 3f          	movswl (%r15),%edi
    1f3b:	41 0f bf 76 02       	movswl 0x2(%r14),%esi
    1f40:	e8 c6 fe ff ff       	call   1e0b <fqmul>
    1f45:	66 89 43 02          	mov    %ax,0x2(%rbx)
    1f49:	41 0f bf 7f 02       	movswl 0x2(%r15),%edi
    1f4e:	41 0f bf 36          	movswl (%r14),%esi
    1f52:	e8 b4 fe ff ff       	call   1e0b <fqmul>
    1f57:	66 01 43 02          	add    %ax,0x2(%rbx)
    1f5b:	48 83 c4 08          	add    $0x8,%rsp
    1f5f:	5b                   	pop    %rbx
    1f60:	41 5e                	pop    %r14
    1f62:	41 5f                	pop    %r15
    1f64:	5d                   	pop    %rbp
    1f65:	c3                   	ret
    1f66:	66 90                	xchg   %ax,%ax

0000000000001f68 <pqcrystals_kyber768_ref_poly_cbd_eta1>:
    1f68:	eb 00                	jmp    1f6a <cbd2>

0000000000001f6a <cbd2>:
    1f6a:	53                   	push   %rbx
    1f6b:	31 d2                	xor    %edx,%edx
    1f6d:	41 b8 55 55 55 55    	mov    $0x55555555,%r8d
    1f73:	48 83 fa 20          	cmp    $0x20,%rdx
    1f77:	74 4f                	je     1fc8 <cbd2+0x5e>
    1f79:	44 8b 0c 96          	mov    (%rsi,%rdx,4),%r9d
    1f7d:	44 89 c8             	mov    %r9d,%eax
    1f80:	44 21 c0             	and    %r8d,%eax
    1f83:	41 d1 e9             	shr    $1,%r9d
    1f86:	45 21 c1             	and    %r8d,%r9d
    1f89:	41 01 c1             	add    %eax,%r9d
    1f8c:	49 89 fa             	mov    %rdi,%r10
    1f8f:	31 c0                	xor    %eax,%eax
    1f91:	48 83 f8 20          	cmp    $0x20,%rax
    1f95:	74 28                	je     1fbf <cbd2+0x55>
    1f97:	45 89 cb             	mov    %r9d,%r11d
    1f9a:	89 c1                	mov    %eax,%ecx
    1f9c:	41 d3 eb             	shr    %cl,%r11d
    1f9f:	41 83 e3 03          	and    $0x3,%r11d
    1fa3:	8d 48 02             	lea    0x2(%rax),%ecx
    1fa6:	44 89 cb             	mov    %r9d,%ebx
    1fa9:	d3 eb                	shr    %cl,%ebx
    1fab:	83 e3 03             	and    $0x3,%ebx
    1fae:	41 29 db             	sub    %ebx,%r11d
    1fb1:	66 45 89 1a          	mov    %r11w,(%r10)
    1fb5:	48 83 c0 04          	add    $0x4,%rax
    1fb9:	49 83 c2 02          	add    $0x2,%r10
    1fbd:	eb d2                	jmp    1f91 <cbd2+0x27>
    1fbf:	48 ff c2             	inc    %rdx
    1fc2:	48 83 c7 10          	add    $0x10,%rdi
    1fc6:	eb ab                	jmp    1f73 <cbd2+0x9>
    1fc8:	5b                   	pop    %rbx
    1fc9:	c3                   	ret

0000000000001fca <pqcrystals_kyber768_ref_poly_cbd_eta2>:
    1fca:	eb 9e                	jmp    1f6a <cbd2>

0000000000001fcc <pqcrystals_kyber768_ref_montgomery_reduce>:
    1fcc:	69 c7 00 00 01 f3    	imul   $0xf3010000,%edi,%eax
    1fd2:	c1 f8 10             	sar    $0x10,%eax
    1fd5:	69 c0 ff f2 ff ff    	imul   $0xfffff2ff,%eax,%eax
    1fdb:	01 f8                	add    %edi,%eax
    1fdd:	c1 e8 10             	shr    $0x10,%eax
    1fe0:	c3                   	ret

0000000000001fe1 <pqcrystals_kyber768_ref_barrett_reduce>:
    1fe1:	89 f8                	mov    %edi,%eax
    1fe3:	69 cf bf 4e 00 00    	imul   $0x4ebf,%edi,%ecx
    1fe9:	81 c1 00 00 00 02    	add    $0x2000000,%ecx
    1fef:	c1 f9 1a             	sar    $0x1a,%ecx
    1ff2:	69 c9 00 00 01 0d    	imul   $0xd010000,%ecx,%ecx
    1ff8:	c1 e9 10             	shr    $0x10,%ecx
    1ffb:	29 c8                	sub    %ecx,%eax
    1ffd:	c3                   	ret
    1ffe:	66 90                	xchg   %ax,%ax

0000000000002000 <pqcrystals_kyber768_ref_kyber_shake128_absorb>:
    2000:	48 83 ec 28          	sub    $0x28,%rsp
    2004:	0f 10 06             	movups (%rsi),%xmm0
    2007:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
    200b:	48 89 e6             	mov    %rsp,%rsi
    200e:	0f 29 4e 10          	movaps %xmm1,0x10(%rsi)
    2012:	0f 29 06             	movaps %xmm0,(%rsi)
    2015:	88 56 20             	mov    %dl,0x20(%rsi)
    2018:	88 4e 21             	mov    %cl,0x21(%rsi)
    201b:	6a 22                	push   $0x22
    201d:	5a                   	pop    %rdx
    201e:	e8 d0 01 00 00       	call   21f3 <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    2023:	48 83 c4 28          	add    $0x28,%rsp
    2027:	c3                   	ret

0000000000002028 <pqcrystals_kyber768_ref_kyber_shake256_prf>:
    2028:	48 83 ec 28          	sub    $0x28,%rsp
    202c:	0f 10 02             	movups (%rdx),%xmm0
    202f:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
    2033:	48 89 e2             	mov    %rsp,%rdx
    2036:	0f 29 4a 10          	movaps %xmm1,0x10(%rdx)
    203a:	0f 29 02             	movaps %xmm0,(%rdx)
    203d:	88 4a 20             	mov    %cl,0x20(%rdx)
    2040:	6a 21                	push   $0x21
    2042:	59                   	pop    %rcx
    2043:	e8 22 04 00 00       	call   246a <pqcrystals_kyber_fips202_ref_shake256>
    2048:	48 83 c4 28          	add    $0x28,%rsp
    204c:	c3                   	ret
    204d:	0f 1f 00             	nopl   (%rax)

0000000000002050 <pqcrystals_kyber_fips202_ref_shake128_init>:
    2050:	53                   	push   %rbx
    2051:	48 89 fb             	mov    %rdi,%rbx
    2054:	e8 09 00 00 00       	call   2062 <keccak_init>
    2059:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    2060:	5b                   	pop    %rbx
    2061:	c3                   	ret

0000000000002062 <keccak_init>:
    2062:	31 c0                	xor    %eax,%eax
    2064:	48 83 f8 19          	cmp    $0x19,%rax
    2068:	74 0a                	je     2074 <keccak_init+0x12>
    206a:	48 83 24 c7 00       	andq   $0x0,(%rdi,%rax,8)
    206f:	48 ff c0             	inc    %rax
    2072:	eb f0                	jmp    2064 <keccak_init+0x2>
    2074:	c3                   	ret

0000000000002075 <pqcrystals_kyber_fips202_ref_shake128_absorb>:
    2075:	53                   	push   %rbx
    2076:	49 89 d0             	mov    %rdx,%r8
    2079:	48 89 f1             	mov    %rsi,%rcx
    207c:	48 89 fb             	mov    %rdi,%rbx
    207f:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    2085:	ba a8 00 00 00       	mov    $0xa8,%edx
    208a:	e8 08 00 00 00       	call   2097 <keccak_absorb>
    208f:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    2095:	5b                   	pop    %rbx
    2096:	c3                   	ret

0000000000002097 <keccak_absorb>:
    2097:	55                   	push   %rbp
    2098:	41 57                	push   %r15
    209a:	41 56                	push   %r14
    209c:	41 54                	push   %r12
    209e:	53                   	push   %rbx
    209f:	4d 89 c7             	mov    %r8,%r15
    20a2:	48 89 cb             	mov    %rcx,%rbx
    20a5:	89 d5                	mov    %edx,%ebp
    20a7:	89 f0                	mov    %esi,%eax
    20a9:	49 89 fe             	mov    %rdi,%r14
    20ac:	41 89 d4             	mov    %edx,%r12d
    20af:	89 c2                	mov    %eax,%edx
    20b1:	4c 01 fa             	add    %r15,%rdx
    20b4:	4c 39 e2             	cmp    %r12,%rdx
    20b7:	72 3e                	jb     20f7 <keccak_absorb+0x60>
    20b9:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
    20c0:	89 c6                	mov    %eax,%esi
    20c2:	39 ee                	cmp    %ebp,%esi
    20c4:	73 1e                	jae    20e4 <keccak_absorb+0x4d>
    20c6:	0f b6 3b             	movzbl (%rbx),%edi
    20c9:	89 d1                	mov    %edx,%ecx
    20cb:	80 e1 38             	and    $0x38,%cl
    20ce:	48 d3 e7             	shl    %cl,%rdi
    20d1:	89 f1                	mov    %esi,%ecx
    20d3:	83 e1 f8             	and    $0xfffffff8,%ecx
    20d6:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    20da:	48 ff c3             	inc    %rbx
    20dd:	ff c6                	inc    %esi
    20df:	83 c2 08             	add    $0x8,%edx
    20e2:	eb de                	jmp    20c2 <keccak_absorb+0x2b>
    20e4:	89 e9                	mov    %ebp,%ecx
    20e6:	29 c1                	sub    %eax,%ecx
    20e8:	49 29 cf             	sub    %rcx,%r15
    20eb:	4c 89 f7             	mov    %r14,%rdi
    20ee:	e8 39 04 00 00       	call   252c <KeccakF1600_StatePermute>
    20f3:	31 c0                	xor    %eax,%eax
    20f5:	eb b8                	jmp    20af <keccak_absorb+0x18>
    20f7:	8d 34 c5 00 00 00 00 	lea    0x0(,%rax,8),%esi
    20fe:	89 c1                	mov    %eax,%ecx
    2100:	48 39 ca             	cmp    %rcx,%rdx
    2103:	76 1e                	jbe    2123 <keccak_absorb+0x8c>
    2105:	0f b6 3b             	movzbl (%rbx),%edi
    2108:	89 f1                	mov    %esi,%ecx
    210a:	80 e1 38             	and    $0x38,%cl
    210d:	48 d3 e7             	shl    %cl,%rdi
    2110:	89 c1                	mov    %eax,%ecx
    2112:	83 e1 f8             	and    $0xfffffff8,%ecx
    2115:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    2119:	48 ff c3             	inc    %rbx
    211c:	ff c0                	inc    %eax
    211e:	83 c6 08             	add    $0x8,%esi
    2121:	eb db                	jmp    20fe <keccak_absorb+0x67>
    2123:	5b                   	pop    %rbx
    2124:	41 5c                	pop    %r12
    2126:	41 5e                	pop    %r14
    2128:	41 5f                	pop    %r15
    212a:	5d                   	pop    %rbp
    212b:	c3                   	ret

000000000000212c <pqcrystals_kyber_fips202_ref_shake128_finalize>:
    212c:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    2132:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    2139:	6a 1f                	push   $0x1f
    213b:	5a                   	pop    %rdx
    213c:	48 d3 e2             	shl    %cl,%rdx
    213f:	83 e0 f8             	and    $0xfffffff8,%eax
    2142:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    2146:	80 b7 a7 00 00 00 80 	xorb   $0x80,0xa7(%rdi)
    214d:	c7 87 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rdi)
    2154:	00 00 00 
    2157:	c3                   	ret

0000000000002158 <pqcrystals_kyber_fips202_ref_shake128_squeeze>:
    2158:	53                   	push   %rbx
    2159:	48 89 d3             	mov    %rdx,%rbx
    215c:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    2162:	41 b8 a8 00 00 00    	mov    $0xa8,%r8d
    2168:	e8 08 00 00 00       	call   2175 <keccak_squeeze>
    216d:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    2173:	5b                   	pop    %rbx
    2174:	c3                   	ret

0000000000002175 <keccak_squeeze>:
    2175:	41 57                	push   %r15
    2177:	41 56                	push   %r14
    2179:	41 55                	push   %r13
    217b:	41 54                	push   %r12
    217d:	53                   	push   %rbx
    217e:	44 89 c3             	mov    %r8d,%ebx
    2181:	89 c8                	mov    %ecx,%eax
    2183:	49 89 d6             	mov    %rdx,%r14
    2186:	49 89 f7             	mov    %rsi,%r15
    2189:	49 89 fc             	mov    %rdi,%r12
    218c:	45 89 c5             	mov    %r8d,%r13d
    218f:	4d 85 ff             	test   %r15,%r15
    2192:	74 55                	je     21e9 <keccak_squeeze+0x74>
    2194:	39 d8                	cmp    %ebx,%eax
    2196:	75 0a                	jne    21a2 <keccak_squeeze+0x2d>
    2198:	4c 89 f7             	mov    %r14,%rdi
    219b:	e8 8c 03 00 00       	call   252c <KeccakF1600_StatePermute>
    21a0:	31 c0                	xor    %eax,%eax
    21a2:	89 c0                	mov    %eax,%eax
    21a4:	49 8d 34 07          	lea    (%r15,%rax,1),%rsi
    21a8:	49 39 f5             	cmp    %rsi,%r13
    21ab:	49 0f 42 f5          	cmovb  %r13,%rsi
    21af:	48 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%rdi
    21b6:	00 
    21b7:	31 d2                	xor    %edx,%edx
    21b9:	48 39 f0             	cmp    %rsi,%rax
    21bc:	73 21                	jae    21df <keccak_squeeze+0x6a>
    21be:	89 c1                	mov    %eax,%ecx
    21c0:	83 e1 f8             	and    $0xfffffff8,%ecx
    21c3:	4d 8b 04 0e          	mov    (%r14,%rcx,1),%r8
    21c7:	89 f9                	mov    %edi,%ecx
    21c9:	80 e1 38             	and    $0x38,%cl
    21cc:	49 d3 e8             	shr    %cl,%r8
    21cf:	45 88 04 14          	mov    %r8b,(%r12,%rdx,1)
    21d3:	48 ff c0             	inc    %rax
    21d6:	48 ff c2             	inc    %rdx
    21d9:	48 83 c7 08          	add    $0x8,%rdi
    21dd:	eb da                	jmp    21b9 <keccak_squeeze+0x44>
    21df:	89 d1                	mov    %edx,%ecx
    21e1:	49 29 cf             	sub    %rcx,%r15
    21e4:	49 01 d4             	add    %rdx,%r12
    21e7:	eb a6                	jmp    218f <keccak_squeeze+0x1a>
    21e9:	5b                   	pop    %rbx
    21ea:	41 5c                	pop    %r12
    21ec:	41 5d                	pop    %r13
    21ee:	41 5e                	pop    %r14
    21f0:	41 5f                	pop    %r15
    21f2:	c3                   	ret

00000000000021f3 <pqcrystals_kyber_fips202_ref_shake128_absorb_once>:
    21f3:	53                   	push   %rbx
    21f4:	48 89 d1             	mov    %rdx,%rcx
    21f7:	48 89 f2             	mov    %rsi,%rdx
    21fa:	48 89 fb             	mov    %rdi,%rbx
    21fd:	6a 1f                	push   $0x1f
    21ff:	41 58                	pop    %r8
    2201:	be a8 00 00 00       	mov    $0xa8,%esi
    2206:	e8 0c 00 00 00       	call   2217 <keccak_absorb_once>
    220b:	c7 83 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rbx)
    2212:	00 00 00 
    2215:	5b                   	pop    %rbx
    2216:	c3                   	ret

0000000000002217 <keccak_absorb_once>:
    2217:	55                   	push   %rbp
    2218:	41 57                	push   %r15
    221a:	41 56                	push   %r14
    221c:	41 55                	push   %r13
    221e:	41 54                	push   %r12
    2220:	53                   	push   %rbx
    2221:	50                   	push   %rax
    2222:	44 89 44 24 04       	mov    %r8d,0x4(%rsp)
    2227:	48 89 c8             	mov    %rcx,%rax
    222a:	49 89 d7             	mov    %rdx,%r15
    222d:	89 f3                	mov    %esi,%ebx
    222f:	49 89 fe             	mov    %rdi,%r14
    2232:	31 c9                	xor    %ecx,%ecx
    2234:	48 83 f9 19          	cmp    $0x19,%rcx
    2238:	74 0a                	je     2244 <keccak_absorb_once+0x2d>
    223a:	49 83 24 ce 00       	andq   $0x0,(%r14,%rcx,8)
    223f:	48 ff c1             	inc    %rcx
    2242:	eb f0                	jmp    2234 <keccak_absorb_once+0x1d>
    2244:	41 89 dc             	mov    %ebx,%r12d
    2247:	41 89 dd             	mov    %ebx,%r13d
    224a:	41 c1 ed 03          	shr    $0x3,%r13d
    224e:	48 89 c5             	mov    %rax,%rbp
    2251:	4c 29 e5             	sub    %r12,%rbp
    2254:	72 47                	jb     229d <keccak_absorb_once+0x86>
    2256:	4c 89 f8             	mov    %r15,%rax
    2259:	31 d2                	xor    %edx,%edx
    225b:	4c 39 ea             	cmp    %r13,%rdx
    225e:	74 2d                	je     228d <keccak_absorb_once+0x76>
    2260:	48 89 c6             	mov    %rax,%rsi
    2263:	31 c9                	xor    %ecx,%ecx
    2265:	31 ff                	xor    %edi,%edi
    2267:	48 83 f9 40          	cmp    $0x40,%rcx
    226b:	74 13                	je     2280 <keccak_absorb_once+0x69>
    226d:	44 0f b6 06          	movzbl (%rsi),%r8d
    2271:	49 d3 e0             	shl    %cl,%r8
    2274:	4c 09 c7             	or     %r8,%rdi
    2277:	48 83 c1 08          	add    $0x8,%rcx
    227b:	48 ff c6             	inc    %rsi
    227e:	eb e7                	jmp    2267 <keccak_absorb_once+0x50>
    2280:	49 31 3c d6          	xor    %rdi,(%r14,%rdx,8)
    2284:	48 ff c2             	inc    %rdx
    2287:	48 83 c0 08          	add    $0x8,%rax
    228b:	eb ce                	jmp    225b <keccak_absorb_once+0x44>
    228d:	4d 01 e7             	add    %r12,%r15
    2290:	4c 89 f7             	mov    %r14,%rdi
    2293:	e8 94 02 00 00       	call   252c <KeccakF1600_StatePermute>
    2298:	48 89 e8             	mov    %rbp,%rax
    229b:	eb b4                	jmp    2251 <keccak_absorb_once+0x3a>
    229d:	31 d2                	xor    %edx,%edx
    229f:	31 c9                	xor    %ecx,%ecx
    22a1:	89 ce                	mov    %ecx,%esi
    22a3:	48 39 f0             	cmp    %rsi,%rax
    22a6:	76 1e                	jbe    22c6 <keccak_absorb_once+0xaf>
    22a8:	41 0f b6 3c 37       	movzbl (%r15,%rsi,1),%edi
    22ad:	89 d1                	mov    %edx,%ecx
    22af:	80 e1 38             	and    $0x38,%cl
    22b2:	48 d3 e7             	shl    %cl,%rdi
    22b5:	89 f1                	mov    %esi,%ecx
    22b7:	83 e1 f8             	and    $0xfffffff8,%ecx
    22ba:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    22be:	8d 4e 01             	lea    0x1(%rsi),%ecx
    22c1:	83 c2 08             	add    $0x8,%edx
    22c4:	eb db                	jmp    22a1 <keccak_absorb_once+0x8a>
    22c6:	0f b6 44 24 04       	movzbl 0x4(%rsp),%eax
    22cb:	80 e2 38             	and    $0x38,%dl
    22ce:	89 d1                	mov    %edx,%ecx
    22d0:	48 d3 e0             	shl    %cl,%rax
    22d3:	83 e6 f8             	and    $0xfffffff8,%esi
    22d6:	49 31 04 36          	xor    %rax,(%r14,%rsi,1)
    22da:	ff cb                	dec    %ebx
    22dc:	83 e3 f8             	and    $0xfffffff8,%ebx
    22df:	41 80 74 1e 07 80    	xorb   $0x80,0x7(%r14,%rbx,1)
    22e5:	48 83 c4 08          	add    $0x8,%rsp
    22e9:	5b                   	pop    %rbx
    22ea:	41 5c                	pop    %r12
    22ec:	41 5d                	pop    %r13
    22ee:	41 5e                	pop    %r14
    22f0:	41 5f                	pop    %r15
    22f2:	5d                   	pop    %rbp
    22f3:	c3                   	ret

00000000000022f4 <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>:
    22f4:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    22f9:	eb 00                	jmp    22fb <keccak_squeezeblocks>

00000000000022fb <keccak_squeezeblocks>:
    22fb:	55                   	push   %rbp
    22fc:	41 57                	push   %r15
    22fe:	41 56                	push   %r14
    2300:	41 55                	push   %r13
    2302:	41 54                	push   %r12
    2304:	53                   	push   %rbx
    2305:	50                   	push   %rax
    2306:	89 cb                	mov    %ecx,%ebx
    2308:	49 89 d6             	mov    %rdx,%r14
    230b:	49 89 f7             	mov    %rsi,%r15
    230e:	49 89 fc             	mov    %rdi,%r12
    2311:	41 89 cd             	mov    %ecx,%r13d
    2314:	83 e3 f8             	and    $0xfffffff8,%ebx
    2317:	49 83 ef 01          	sub    $0x1,%r15
    231b:	72 27                	jb     2344 <keccak_squeezeblocks+0x49>
    231d:	4c 89 f7             	mov    %r14,%rdi
    2320:	e8 07 02 00 00       	call   252c <KeccakF1600_StatePermute>
    2325:	31 ed                	xor    %ebp,%ebp
    2327:	48 39 eb             	cmp    %rbp,%rbx
    232a:	74 13                	je     233f <keccak_squeezeblocks+0x44>
    232c:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
    2330:	49 8b 34 2e          	mov    (%r14,%rbp,1),%rsi
    2334:	e8 ac 0a 00 00       	call   2de5 <store64>
    2339:	48 83 c5 08          	add    $0x8,%rbp
    233d:	eb e8                	jmp    2327 <keccak_squeezeblocks+0x2c>
    233f:	4d 01 ec             	add    %r13,%r12
    2342:	eb d3                	jmp    2317 <keccak_squeezeblocks+0x1c>
    2344:	48 83 c4 08          	add    $0x8,%rsp
    2348:	5b                   	pop    %rbx
    2349:	41 5c                	pop    %r12
    234b:	41 5d                	pop    %r13
    234d:	41 5e                	pop    %r14
    234f:	41 5f                	pop    %r15
    2351:	5d                   	pop    %rbp
    2352:	c3                   	ret

0000000000002353 <pqcrystals_kyber_fips202_ref_shake256_init>:
    2353:	53                   	push   %rbx
    2354:	48 89 fb             	mov    %rdi,%rbx
    2357:	e8 06 fd ff ff       	call   2062 <keccak_init>
    235c:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    2363:	5b                   	pop    %rbx
    2364:	c3                   	ret

0000000000002365 <pqcrystals_kyber_fips202_ref_shake256_absorb>:
    2365:	53                   	push   %rbx
    2366:	49 89 d0             	mov    %rdx,%r8
    2369:	48 89 f1             	mov    %rsi,%rcx
    236c:	48 89 fb             	mov    %rdi,%rbx
    236f:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    2375:	ba 88 00 00 00       	mov    $0x88,%edx
    237a:	e8 18 fd ff ff       	call   2097 <keccak_absorb>
    237f:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    2385:	5b                   	pop    %rbx
    2386:	c3                   	ret

0000000000002387 <pqcrystals_kyber_fips202_ref_shake256_finalize>:
    2387:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    238d:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    2394:	6a 1f                	push   $0x1f
    2396:	5a                   	pop    %rdx
    2397:	48 d3 e2             	shl    %cl,%rdx
    239a:	83 e0 f8             	and    $0xfffffff8,%eax
    239d:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    23a1:	80 b7 87 00 00 00 80 	xorb   $0x80,0x87(%rdi)
    23a8:	c7 87 c8 00 00 00 88 	movl   $0x88,0xc8(%rdi)
    23af:	00 00 00 
    23b2:	c3                   	ret

00000000000023b3 <pqcrystals_kyber_fips202_ref_shake256_squeeze>:
    23b3:	53                   	push   %rbx
    23b4:	48 89 d3             	mov    %rdx,%rbx
    23b7:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    23bd:	41 b8 88 00 00 00    	mov    $0x88,%r8d
    23c3:	e8 ad fd ff ff       	call   2175 <keccak_squeeze>
    23c8:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    23ce:	5b                   	pop    %rbx
    23cf:	c3                   	ret

00000000000023d0 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>:
    23d0:	53                   	push   %rbx
    23d1:	48 89 d1             	mov    %rdx,%rcx
    23d4:	48 89 f2             	mov    %rsi,%rdx
    23d7:	48 89 fb             	mov    %rdi,%rbx
    23da:	6a 1f                	push   $0x1f
    23dc:	41 58                	pop    %r8
    23de:	be 88 00 00 00       	mov    $0x88,%esi
    23e3:	e8 2f fe ff ff       	call   2217 <keccak_absorb_once>
    23e8:	c7 83 c8 00 00 00 88 	movl   $0x88,0xc8(%rbx)
    23ef:	00 00 00 
    23f2:	5b                   	pop    %rbx
    23f3:	c3                   	ret

00000000000023f4 <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>:
    23f4:	b9 88 00 00 00       	mov    $0x88,%ecx
    23f9:	e9 fd fe ff ff       	jmp    22fb <keccak_squeezeblocks>

00000000000023fe <pqcrystals_kyber_fips202_ref_shake128>:
    23fe:	41 57                	push   %r15
    2400:	41 56                	push   %r14
    2402:	41 54                	push   %r12
    2404:	53                   	push   %rbx
    2405:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    240c:	48 89 f3             	mov    %rsi,%rbx
    240f:	49 89 fe             	mov    %rdi,%r14
    2412:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    2417:	4c 89 ff             	mov    %r15,%rdi
    241a:	48 89 d6             	mov    %rdx,%rsi
    241d:	48 89 ca             	mov    %rcx,%rdx
    2420:	e8 ce fd ff ff       	call   21f3 <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    2425:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    242a:	48 89 d8             	mov    %rbx,%rax
    242d:	31 d2                	xor    %edx,%edx
    242f:	48 f7 f1             	div    %rcx
    2432:	48 89 d3             	mov    %rdx,%rbx
    2435:	49 89 c4             	mov    %rax,%r12
    2438:	4c 89 f7             	mov    %r14,%rdi
    243b:	48 89 c6             	mov    %rax,%rsi
    243e:	4c 89 fa             	mov    %r15,%rdx
    2441:	e8 ae fe ff ff       	call   22f4 <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>
    2446:	49 69 fc a8 00 00 00 	imul   $0xa8,%r12,%rdi
    244d:	4c 01 f7             	add    %r14,%rdi
    2450:	48 89 de             	mov    %rbx,%rsi
    2453:	4c 89 fa             	mov    %r15,%rdx
    2456:	e8 fd fc ff ff       	call   2158 <pqcrystals_kyber_fips202_ref_shake128_squeeze>
    245b:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    2462:	5b                   	pop    %rbx
    2463:	41 5c                	pop    %r12
    2465:	41 5e                	pop    %r14
    2467:	41 5f                	pop    %r15
    2469:	c3                   	ret

000000000000246a <pqcrystals_kyber_fips202_ref_shake256>:
    246a:	41 57                	push   %r15
    246c:	41 56                	push   %r14
    246e:	41 54                	push   %r12
    2470:	53                   	push   %rbx
    2471:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    2478:	48 89 f3             	mov    %rsi,%rbx
    247b:	49 89 fe             	mov    %rdi,%r14
    247e:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    2483:	4c 89 ff             	mov    %r15,%rdi
    2486:	48 89 d6             	mov    %rdx,%rsi
    2489:	48 89 ca             	mov    %rcx,%rdx
    248c:	e8 3f ff ff ff       	call   23d0 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>
    2491:	b9 88 00 00 00       	mov    $0x88,%ecx
    2496:	48 89 d8             	mov    %rbx,%rax
    2499:	31 d2                	xor    %edx,%edx
    249b:	48 f7 f1             	div    %rcx
    249e:	48 89 d3             	mov    %rdx,%rbx
    24a1:	49 89 c4             	mov    %rax,%r12
    24a4:	4c 89 f7             	mov    %r14,%rdi
    24a7:	48 89 c6             	mov    %rax,%rsi
    24aa:	4c 89 fa             	mov    %r15,%rdx
    24ad:	e8 42 ff ff ff       	call   23f4 <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>
    24b2:	49 69 fc 88 00 00 00 	imul   $0x88,%r12,%rdi
    24b9:	4c 01 f7             	add    %r14,%rdi
    24bc:	48 89 de             	mov    %rbx,%rsi
    24bf:	4c 89 fa             	mov    %r15,%rdx
    24c2:	e8 ec fe ff ff       	call   23b3 <pqcrystals_kyber_fips202_ref_shake256_squeeze>
    24c7:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    24ce:	5b                   	pop    %rbx
    24cf:	41 5c                	pop    %r12
    24d1:	41 5e                	pop    %r14
    24d3:	41 5f                	pop    %r15
    24d5:	c3                   	ret

00000000000024d6 <pqcrystals_kyber_fips202_ref_sha3_256>:
    24d6:	41 56                	push   %r14
    24d8:	53                   	push   %rbx
    24d9:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    24e0:	48 89 d1             	mov    %rdx,%rcx
    24e3:	48 89 f2             	mov    %rsi,%rdx
    24e6:	48 89 fb             	mov    %rdi,%rbx
    24e9:	49 89 e6             	mov    %rsp,%r14
    24ec:	6a 06                	push   $0x6
    24ee:	41 58                	pop    %r8
    24f0:	4c 89 f7             	mov    %r14,%rdi
    24f3:	be 88 00 00 00       	mov    $0x88,%esi
    24f8:	e8 1a fd ff ff       	call   2217 <keccak_absorb_once>
    24fd:	4c 89 f7             	mov    %r14,%rdi
    2500:	e8 27 00 00 00       	call   252c <KeccakF1600_StatePermute>
    2505:	45 31 f6             	xor    %r14d,%r14d
    2508:	49 83 fe 20          	cmp    $0x20,%r14
    250c:	74 13                	je     2521 <pqcrystals_kyber_fips202_ref_sha3_256+0x4b>
    250e:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    2512:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    2516:	e8 ca 08 00 00       	call   2de5 <store64>
    251b:	49 83 c6 08          	add    $0x8,%r14
    251f:	eb e7                	jmp    2508 <pqcrystals_kyber_fips202_ref_sha3_256+0x32>
    2521:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    2528:	5b                   	pop    %rbx
    2529:	41 5e                	pop    %r14
    252b:	c3                   	ret

000000000000252c <KeccakF1600_StatePermute>:
    252c:	55                   	push   %rbp
    252d:	41 57                	push   %r15
    252f:	41 56                	push   %r14
    2531:	41 55                	push   %r13
    2533:	41 54                	push   %r12
    2535:	53                   	push   %rbx
    2536:	48 83 ec 68          	sub    $0x68,%rsp
    253a:	48 8b 07             	mov    (%rdi),%rax
    253d:	48 89 44 24 80       	mov    %rax,-0x80(%rsp)
    2542:	48 8b 6f 08          	mov    0x8(%rdi),%rbp
    2546:	48 8b 47 10          	mov    0x10(%rdi),%rax
    254a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    254f:	48 8b 47 18          	mov    0x18(%rdi),%rax
    2553:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    2558:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    255c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    2560:	48 89 04 24          	mov    %rax,(%rsp)
    2564:	48 8b 47 30          	mov    0x30(%rdi),%rax
    2568:	48 89 44 24 98       	mov    %rax,-0x68(%rsp)
    256d:	48 8b 47 38          	mov    0x38(%rdi),%rax
    2571:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    2576:	48 8b 47 40          	mov    0x40(%rdi),%rax
    257a:	48 89 44 24 f8       	mov    %rax,-0x8(%rsp)
    257f:	4c 8b 7f 48          	mov    0x48(%rdi),%r15
    2583:	48 8b 47 50          	mov    0x50(%rdi),%rax
    2587:	48 89 44 24 90       	mov    %rax,-0x70(%rsp)
    258c:	48 8b 47 58          	mov    0x58(%rdi),%rax
    2590:	48 89 44 24 f0       	mov    %rax,-0x10(%rsp)
    2595:	48 8b 47 60          	mov    0x60(%rdi),%rax
    2599:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    259e:	48 8b 47 68          	mov    0x68(%rdi),%rax
    25a2:	48 89 44 24 a0       	mov    %rax,-0x60(%rsp)
    25a7:	4c 8b 77 70          	mov    0x70(%rdi),%r14
    25ab:	48 8b 47 78          	mov    0x78(%rdi),%rax
    25af:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    25b4:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
    25bb:	48 89 44 24 88       	mov    %rax,-0x78(%rsp)
    25c0:	48 8b 87 88 00 00 00 	mov    0x88(%rdi),%rax
    25c7:	48 89 44 24 c8       	mov    %rax,-0x38(%rsp)
    25cc:	4c 8b a7 90 00 00 00 	mov    0x90(%rdi),%r12
    25d3:	4c 8b 87 98 00 00 00 	mov    0x98(%rdi),%r8
    25da:	4c 8b af a0 00 00 00 	mov    0xa0(%rdi),%r13
    25e1:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    25e8:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    25ef:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    25f6:	48 89 4c 24 c0       	mov    %rcx,-0x40(%rsp)
    25fb:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    2600:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    2607:	48 89 4c 24 b0       	mov    %rcx,-0x50(%rsp)
    260c:	31 c9                	xor    %ecx,%ecx
    260e:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    2613:	48 83 7c 24 10 17    	cmpq   $0x17,0x10(%rsp)
    2619:	0f 87 e5 06 00 00    	ja     2d04 <KeccakF1600_StatePermute+0x7d8>
    261f:	48 8b 4c 24 d0       	mov    -0x30(%rsp),%rcx
    2624:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    2629:	4c 31 e9             	xor    %r13,%rcx
    262c:	4c 89 d7             	mov    %r10,%rdi
    262f:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    2634:	4c 8b 54 24 90       	mov    -0x70(%rsp),%r10
    2639:	4c 33 14 24          	xor    (%rsp),%r10
    263d:	49 31 ca             	xor    %rcx,%r10
    2640:	48 8b 4c 24 88       	mov    -0x78(%rsp),%rcx
    2645:	48 31 f9             	xor    %rdi,%rcx
    2648:	4c 89 fb             	mov    %r15,%rbx
    264b:	4d 89 f5             	mov    %r14,%r13
    264e:	4c 8b 74 24 f0       	mov    -0x10(%rsp),%r14
    2653:	4c 33 74 24 98       	xor    -0x68(%rsp),%r14
    2658:	49 31 ce             	xor    %rcx,%r14
    265b:	48 8b 4c 24 c8       	mov    -0x38(%rsp),%rcx
    2660:	48 31 c1             	xor    %rax,%rcx
    2663:	49 89 d7             	mov    %rdx,%r15
    2666:	4d 89 c3             	mov    %r8,%r11
    2669:	4c 89 44 24 e0       	mov    %r8,-0x20(%rsp)
    266e:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
    2673:	4c 89 c2             	mov    %r8,%rdx
    2676:	48 33 54 24 a8       	xor    -0x58(%rsp),%rdx
    267b:	48 31 ca             	xor    %rcx,%rdx
    267e:	48 89 6c 24 d8       	mov    %rbp,-0x28(%rsp)
    2683:	4d 89 e1             	mov    %r12,%r9
    2686:	4c 33 4c 24 c0       	xor    -0x40(%rsp),%r9
    268b:	48 8b 4c 24 a0       	mov    -0x60(%rsp),%rcx
    2690:	48 33 4c 24 f8       	xor    -0x8(%rsp),%rcx
    2695:	4c 31 c9             	xor    %r9,%rcx
    2698:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    269d:	49 31 fb             	xor    %rdi,%r11
    26a0:	4d 89 e9             	mov    %r13,%r9
    26a3:	49 31 d9             	xor    %rbx,%r9
    26a6:	48 89 de             	mov    %rbx,%rsi
    26a9:	4d 31 d9             	xor    %r11,%r9
    26ac:	4c 33 54 24 80       	xor    -0x80(%rsp),%r10
    26b1:	49 31 ee             	xor    %rbp,%r14
    26b4:	48 33 54 24 08       	xor    0x8(%rsp),%rdx
    26b9:	4c 8b 5c 24 b8       	mov    -0x48(%rsp),%r11
    26be:	4c 31 d9             	xor    %r11,%rcx
    26c1:	48 89 cd             	mov    %rcx,%rbp
    26c4:	48 d1 c5             	rol    $1,%rbp
    26c7:	4c 31 f5             	xor    %r14,%rbp
    26ca:	49 d1 c6             	rol    $1,%r14
    26cd:	4d 31 f9             	xor    %r15,%r9
    26d0:	4d 31 ce             	xor    %r9,%r14
    26d3:	49 d1 c1             	rol    $1,%r9
    26d6:	49 31 d1             	xor    %rdx,%r9
    26d9:	48 89 d3             	mov    %rdx,%rbx
    26dc:	48 d1 c3             	rol    $1,%rbx
    26df:	4c 31 d3             	xor    %r10,%rbx
    26e2:	49 d1 c2             	rol    $1,%r10
    26e5:	49 31 ca             	xor    %rcx,%r10
    26e8:	4c 31 d7             	xor    %r10,%rdi
    26eb:	4c 31 d6             	xor    %r10,%rsi
    26ee:	48 89 74 24 b0       	mov    %rsi,-0x50(%rsp)
    26f3:	4c 31 54 24 e0       	xor    %r10,-0x20(%rsp)
    26f8:	4d 31 d7             	xor    %r10,%r15
    26fb:	4c 89 7c 24 e8       	mov    %r15,-0x18(%rsp)
    2700:	4d 31 ea             	xor    %r13,%r10
    2703:	4c 89 54 24 60       	mov    %r10,0x60(%rsp)
    2708:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    270d:	48 31 da             	xor    %rbx,%rdx
    2710:	48 c1 c2 2c          	rol    $0x2c,%rdx
    2714:	49 31 e8             	xor    %rbp,%r8
    2717:	49 c1 c0 2b          	rol    $0x2b,%r8
    271b:	4d 31 cc             	xor    %r9,%r12
    271e:	49 c1 c4 15          	rol    $0x15,%r12
    2722:	48 c1 c7 0e          	rol    $0xe,%rdi
    2726:	4c 8b 7c 24 80       	mov    -0x80(%rsp),%r15
    272b:	4d 31 f7             	xor    %r14,%r15
    272e:	48 89 d6             	mov    %rdx,%rsi
    2731:	48 f7 d6             	not    %rsi
    2734:	4c 21 c6             	and    %r8,%rsi
    2737:	4c 8d 15 f2 09 00 00 	lea    0x9f2(%rip),%r10        # 3130 <KeccakF_RoundConstants>
    273e:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
    2743:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    2748:	49 33 34 ca          	xor    (%r10,%rcx,8),%rsi
    274c:	4c 89 e1             	mov    %r12,%rcx
    274f:	48 f7 d1             	not    %rcx
    2752:	48 21 f9             	and    %rdi,%rcx
    2755:	4c 31 c1             	xor    %r8,%rcx
    2758:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    275d:	49 f7 d0             	not    %r8
    2760:	4d 21 e0             	and    %r12,%r8
    2763:	48 89 f9             	mov    %rdi,%rcx
    2766:	48 f7 d1             	not    %rcx
    2769:	4c 21 f9             	and    %r15,%rcx
    276c:	4c 31 e1             	xor    %r12,%rcx
    276f:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    2774:	4c 31 fe             	xor    %r15,%rsi
    2777:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    277c:	49 31 d0             	xor    %rdx,%r8
    277f:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
    2784:	4d 31 cb             	xor    %r9,%r11
    2787:	49 c1 c3 1c          	rol    $0x1c,%r11
    278b:	48 89 f9             	mov    %rdi,%rcx
    278e:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
    2793:	48 c1 c6 14          	rol    $0x14,%rsi
    2797:	49 f7 d7             	not    %r15
    279a:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
    279f:	4c 31 f7             	xor    %r14,%rdi
    27a2:	48 c1 c7 03          	rol    $0x3,%rdi
    27a6:	49 21 d7             	and    %rdx,%r15
    27a9:	4c 8b 44 24 88       	mov    -0x78(%rsp),%r8
    27ae:	49 31 d8             	xor    %rbx,%r8
    27b1:	49 c1 c0 2d          	rol    $0x2d,%r8
    27b5:	49 31 cf             	xor    %rcx,%r15
    27b8:	4c 89 7c 24 80       	mov    %r15,-0x80(%rsp)
    27bd:	48 31 e8             	xor    %rbp,%rax
    27c0:	48 c1 c0 3d          	rol    $0x3d,%rax
    27c4:	48 89 f1             	mov    %rsi,%rcx
    27c7:	49 89 f7             	mov    %rsi,%r15
    27ca:	48 f7 d1             	not    %rcx
    27cd:	48 21 f9             	and    %rdi,%rcx
    27d0:	48 89 ce             	mov    %rcx,%rsi
    27d3:	4c 89 c1             	mov    %r8,%rcx
    27d6:	48 f7 d1             	not    %rcx
    27d9:	48 21 c1             	and    %rax,%rcx
    27dc:	48 31 f9             	xor    %rdi,%rcx
    27df:	48 89 4c 24 90       	mov    %rcx,-0x70(%rsp)
    27e4:	48 89 fa             	mov    %rdi,%rdx
    27e7:	48 f7 d2             	not    %rdx
    27ea:	4c 21 c2             	and    %r8,%rdx
    27ed:	48 89 c1             	mov    %rax,%rcx
    27f0:	48 f7 d1             	not    %rcx
    27f3:	4c 21 d9             	and    %r11,%rcx
    27f6:	4c 31 c1             	xor    %r8,%rcx
    27f9:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    27fe:	4c 31 de             	xor    %r11,%rsi
    2801:	48 89 74 24 88       	mov    %rsi,-0x78(%rsp)
    2806:	4c 31 fa             	xor    %r15,%rdx
    2809:	48 89 54 24 98       	mov    %rdx,-0x68(%rsp)
    280e:	49 f7 d3             	not    %r11
    2811:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    2816:	48 31 de             	xor    %rbx,%rsi
    2819:	48 d1 c6             	rol    $1,%rsi
    281c:	4c 8b 44 24 a8       	mov    -0x58(%rsp),%r8
    2821:	49 31 e8             	xor    %rbp,%r8
    2824:	49 c1 c0 06          	rol    $0x6,%r8
    2828:	4c 8b 64 24 a0       	mov    -0x60(%rsp),%r12
    282d:	4d 31 cc             	xor    %r9,%r12
    2830:	49 c1 c4 19          	rol    $0x19,%r12
    2834:	48 8b 7c 24 e0       	mov    -0x20(%rsp),%rdi
    2839:	48 c1 c7 08          	rol    $0x8,%rdi
    283d:	4d 21 fb             	and    %r15,%r11
    2840:	4d 31 f5             	xor    %r14,%r13
    2843:	49 c1 c5 12          	rol    $0x12,%r13
    2847:	49 31 c3             	xor    %rax,%r11
    284a:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    284f:	4c 89 c0             	mov    %r8,%rax
    2852:	48 f7 d0             	not    %rax
    2855:	4c 21 e0             	and    %r12,%rax
    2858:	48 89 c1             	mov    %rax,%rcx
    285b:	49 89 ff             	mov    %rdi,%r15
    285e:	49 f7 d7             	not    %r15
    2861:	4d 21 ef             	and    %r13,%r15
    2864:	4d 31 e7             	xor    %r12,%r15
    2867:	4c 89 e0             	mov    %r12,%rax
    286a:	48 f7 d0             	not    %rax
    286d:	48 21 f8             	and    %rdi,%rax
    2870:	49 89 fb             	mov    %rdi,%r11
    2873:	4c 89 ef             	mov    %r13,%rdi
    2876:	48 f7 d7             	not    %rdi
    2879:	48 21 f7             	and    %rsi,%rdi
    287c:	4c 31 df             	xor    %r11,%rdi
    287f:	48 89 7c 24 a0       	mov    %rdi,-0x60(%rsp)
    2884:	48 31 f1             	xor    %rsi,%rcx
    2887:	48 89 4c 24 a8       	mov    %rcx,-0x58(%rsp)
    288c:	4c 31 c0             	xor    %r8,%rax
    288f:	48 89 44 24 e0       	mov    %rax,-0x20(%rsp)
    2894:	48 f7 d6             	not    %rsi
    2897:	48 8b 7c 24 e8       	mov    -0x18(%rsp),%rdi
    289c:	48 c1 c7 1b          	rol    $0x1b,%rdi
    28a0:	4c 21 c6             	and    %r8,%rsi
    28a3:	48 8b 0c 24          	mov    (%rsp),%rcx
    28a7:	4c 31 f1             	xor    %r14,%rcx
    28aa:	48 c1 c1 24          	rol    $0x24,%rcx
    28ae:	4c 31 ee             	xor    %r13,%rsi
    28b1:	48 89 74 24 d8       	mov    %rsi,-0x28(%rsp)
    28b6:	4c 8b 6c 24 f0       	mov    -0x10(%rsp),%r13
    28bb:	49 31 dd             	xor    %rbx,%r13
    28be:	49 c1 c5 0a          	rol    $0xa,%r13
    28c2:	4c 8b 44 24 c8       	mov    -0x38(%rsp),%r8
    28c7:	49 31 e8             	xor    %rbp,%r8
    28ca:	49 c1 c0 0f          	rol    $0xf,%r8
    28ce:	4c 8b 64 24 c0       	mov    -0x40(%rsp),%r12
    28d3:	4d 31 cc             	xor    %r9,%r12
    28d6:	4c 89 ca             	mov    %r9,%rdx
    28d9:	49 c1 c4 38          	rol    $0x38,%r12
    28dd:	49 89 c9             	mov    %rcx,%r9
    28e0:	49 f7 d1             	not    %r9
    28e3:	4d 21 e9             	and    %r13,%r9
    28e6:	4d 89 c3             	mov    %r8,%r11
    28e9:	49 f7 d3             	not    %r11
    28ec:	4d 21 e3             	and    %r12,%r11
    28ef:	4d 31 eb             	xor    %r13,%r11
    28f2:	4c 89 5c 24 c8       	mov    %r11,-0x38(%rsp)
    28f7:	49 f7 d5             	not    %r13
    28fa:	4d 21 c5             	and    %r8,%r13
    28fd:	4c 89 e6             	mov    %r12,%rsi
    2900:	48 f7 d6             	not    %rsi
    2903:	48 21 fe             	and    %rdi,%rsi
    2906:	4c 31 c6             	xor    %r8,%rsi
    2909:	49 31 f9             	xor    %rdi,%r9
    290c:	4c 89 4c 24 c0       	mov    %r9,-0x40(%rsp)
    2911:	49 31 cd             	xor    %rcx,%r13
    2914:	48 f7 d7             	not    %rdi
    2917:	48 21 cf             	and    %rcx,%rdi
    291a:	4c 31 e7             	xor    %r12,%rdi
    291d:	48 89 7c 24 e8       	mov    %rdi,-0x18(%rsp)
    2922:	48 33 6c 24 08       	xor    0x8(%rsp),%rbp
    2927:	48 89 d0             	mov    %rdx,%rax
    292a:	48 33 44 24 f8       	xor    -0x8(%rsp),%rax
    292f:	4c 33 74 24 d0       	xor    -0x30(%rsp),%r14
    2934:	48 c1 c5 3e          	rol    $0x3e,%rbp
    2938:	48 c1 c0 37          	rol    $0x37,%rax
    293c:	4c 8b 54 24 60       	mov    0x60(%rsp),%r10
    2941:	49 c1 c2 27          	rol    $0x27,%r10
    2945:	49 c1 c6 29          	rol    $0x29,%r14
    2949:	48 33 5c 24 38       	xor    0x38(%rsp),%rbx
    294e:	48 c1 c3 02          	rol    $0x2,%rbx
    2952:	48 89 c7             	mov    %rax,%rdi
    2955:	48 89 c2             	mov    %rax,%rdx
    2958:	48 f7 d7             	not    %rdi
    295b:	4c 21 d7             	and    %r10,%rdi
    295e:	4c 89 d0             	mov    %r10,%rax
    2961:	4d 89 f4             	mov    %r14,%r12
    2964:	49 f7 d4             	not    %r12
    2967:	49 21 dc             	and    %rbx,%r12
    296a:	4d 31 d4             	xor    %r10,%r12
    296d:	48 f7 d0             	not    %rax
    2970:	4c 21 f0             	and    %r14,%rax
    2973:	49 89 da             	mov    %rbx,%r10
    2976:	49 f7 d2             	not    %r10
    2979:	49 21 ea             	and    %rbp,%r10
    297c:	4d 31 f2             	xor    %r14,%r10
    297f:	4d 89 d6             	mov    %r10,%r14
    2982:	4c 89 54 24 d0       	mov    %r10,-0x30(%rsp)
    2987:	48 31 ef             	xor    %rbp,%rdi
    298a:	48 31 d0             	xor    %rdx,%rax
    298d:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    2992:	48 f7 d5             	not    %rbp
    2995:	48 21 d5             	and    %rdx,%rbp
    2998:	48 31 dd             	xor    %rbx,%rbp
    299b:	4c 33 4c 24 a8       	xor    -0x58(%rsp),%r9
    29a0:	4c 8b 54 24 88       	mov    -0x78(%rsp),%r10
    29a5:	49 31 fa             	xor    %rdi,%r10
    29a8:	4d 31 ca             	xor    %r9,%r10
    29ab:	4c 8b 4c 24 98       	mov    -0x68(%rsp),%r9
    29b0:	4c 33 4c 24 28       	xor    0x28(%rsp),%r9
    29b5:	4c 89 ea             	mov    %r13,%rdx
    29b8:	48 33 54 24 e0       	xor    -0x20(%rsp),%rdx
    29bd:	4c 31 ca             	xor    %r9,%rdx
    29c0:	4c 8b 4c 24 90       	mov    -0x70(%rsp),%r9
    29c5:	4d 31 d9             	xor    %r11,%r9
    29c8:	4c 89 e3             	mov    %r12,%rbx
    29cb:	48 33 5c 24 50       	xor    0x50(%rsp),%rbx
    29d0:	4c 31 cb             	xor    %r9,%rbx
    29d3:	4c 8b 4c 24 a0       	mov    -0x60(%rsp),%r9
    29d8:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    29dd:	4d 89 f3             	mov    %r14,%r11
    29e0:	4c 33 5c 24 20       	xor    0x20(%rsp),%r11
    29e5:	4d 31 cb             	xor    %r9,%r11
    29e8:	4c 8b 74 24 80       	mov    -0x80(%rsp),%r14
    29ed:	49 31 ee             	xor    %rbp,%r14
    29f0:	4c 8b 4c 24 d8       	mov    -0x28(%rsp),%r9
    29f5:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    29fa:	49 31 c9             	xor    %rcx,%r9
    29fd:	4d 31 f1             	xor    %r14,%r9
    2a00:	4c 33 54 24 18       	xor    0x18(%rsp),%r10
    2a05:	48 31 c2             	xor    %rax,%rdx
    2a08:	4c 31 fb             	xor    %r15,%rbx
    2a0b:	49 31 f3             	xor    %rsi,%r11
    2a0e:	4c 33 4c 24 e8       	xor    -0x18(%rsp),%r9
    2a13:	4c 89 d8             	mov    %r11,%rax
    2a16:	48 d1 c0             	rol    $1,%rax
    2a19:	48 31 d0             	xor    %rdx,%rax
    2a1c:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    2a21:	49 89 d6             	mov    %rdx,%r14
    2a24:	49 d1 c6             	rol    $1,%r14
    2a27:	4d 31 ce             	xor    %r9,%r14
    2a2a:	48 89 da             	mov    %rbx,%rdx
    2a2d:	48 d1 c2             	rol    $1,%rdx
    2a30:	4c 31 d2             	xor    %r10,%rdx
    2a33:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    2a38:	49 d1 c1             	rol    $1,%r9
    2a3b:	49 d1 c2             	rol    $1,%r10
    2a3e:	49 31 d9             	xor    %rbx,%r9
    2a41:	4c 8b 44 24 98       	mov    -0x68(%rsp),%r8
    2a46:	49 31 d0             	xor    %rdx,%r8
    2a49:	49 c1 c0 2c          	rol    $0x2c,%r8
    2a4d:	4d 31 da             	xor    %r11,%r10
    2a50:	49 31 c7             	xor    %rax,%r15
    2a53:	49 c1 c7 2b          	rol    $0x2b,%r15
    2a57:	4c 31 d5             	xor    %r10,%rbp
    2a5a:	4c 31 d1             	xor    %r10,%rcx
    2a5d:	48 89 4c 24 b8       	mov    %rcx,-0x48(%rsp)
    2a62:	4c 31 54 24 e8       	xor    %r10,-0x18(%rsp)
    2a67:	4c 31 54 24 80       	xor    %r10,-0x80(%rsp)
    2a6c:	4c 33 54 24 d8       	xor    -0x28(%rsp),%r10
    2a71:	4c 31 ce             	xor    %r9,%rsi
    2a74:	48 c1 c6 15          	rol    $0x15,%rsi
    2a78:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2a7d:	4c 31 f1             	xor    %r14,%rcx
    2a80:	48 c1 c5 0e          	rol    $0xe,%rbp
    2a84:	4c 89 c3             	mov    %r8,%rbx
    2a87:	48 f7 d3             	not    %rbx
    2a8a:	4c 21 fb             	and    %r15,%rbx
    2a8d:	49 89 f3             	mov    %rsi,%r11
    2a90:	49 f7 d3             	not    %r11
    2a93:	49 21 eb             	and    %rbp,%r11
    2a96:	4d 31 fb             	xor    %r15,%r11
    2a99:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    2a9e:	49 f7 d7             	not    %r15
    2aa1:	49 21 f7             	and    %rsi,%r15
    2aa4:	49 89 eb             	mov    %rbp,%r11
    2aa7:	49 f7 d3             	not    %r11
    2aaa:	49 21 cb             	and    %rcx,%r11
    2aad:	49 31 f3             	xor    %rsi,%r11
    2ab0:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    2ab5:	48 8d 05 74 06 00 00 	lea    0x674(%rip),%rax        # 3130 <KeccakF_RoundConstants>
    2abc:	48 33 5c f0 08       	xor    0x8(%rax,%rsi,8),%rbx
    2ac1:	48 89 ce             	mov    %rcx,%rsi
    2ac4:	48 31 cb             	xor    %rcx,%rbx
    2ac7:	4d 31 c7             	xor    %r8,%r15
    2aca:	4c 89 7c 24 d8       	mov    %r15,-0x28(%rsp)
    2acf:	48 f7 d6             	not    %rsi
    2ad2:	4c 21 c6             	and    %r8,%rsi
    2ad5:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    2ada:	4c 31 ca             	xor    %r9,%rdx
    2add:	48 c1 c2 1c          	rol    $0x1c,%rdx
    2ae1:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    2ae6:	48 c1 c1 14          	rol    $0x14,%rcx
    2aea:	48 31 ee             	xor    %rbp,%rsi
    2aed:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    2af2:	48 8b 74 24 a8       	mov    -0x58(%rsp),%rsi
    2af7:	4c 31 f6             	xor    %r14,%rsi
    2afa:	48 c1 c6 03          	rol    $0x3,%rsi
    2afe:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    2b03:	49 31 c5             	xor    %rax,%r13
    2b06:	49 c1 c5 2d          	rol    $0x2d,%r13
    2b0a:	4c 8b 7c 24 b0       	mov    -0x50(%rsp),%r15
    2b0f:	4d 31 fc             	xor    %r15,%r12
    2b12:	49 c1 c4 3d          	rol    $0x3d,%r12
    2b16:	49 89 c8             	mov    %rcx,%r8
    2b19:	49 f7 d0             	not    %r8
    2b1c:	49 21 f0             	and    %rsi,%r8
    2b1f:	4c 89 ed             	mov    %r13,%rbp
    2b22:	48 f7 d5             	not    %rbp
    2b25:	4c 21 e5             	and    %r12,%rbp
    2b28:	48 31 f5             	xor    %rsi,%rbp
    2b2b:	48 89 6c 24 a8       	mov    %rbp,-0x58(%rsp)
    2b30:	48 f7 d6             	not    %rsi
    2b33:	4c 21 ee             	and    %r13,%rsi
    2b36:	4c 89 e5             	mov    %r12,%rbp
    2b39:	48 f7 d5             	not    %rbp
    2b3c:	48 21 d5             	and    %rdx,%rbp
    2b3f:	4c 31 ed             	xor    %r13,%rbp
    2b42:	48 89 6c 24 f8       	mov    %rbp,-0x8(%rsp)
    2b47:	49 31 d0             	xor    %rdx,%r8
    2b4a:	4c 89 04 24          	mov    %r8,(%rsp)
    2b4e:	48 31 ce             	xor    %rcx,%rsi
    2b51:	48 89 74 24 98       	mov    %rsi,-0x68(%rsp)
    2b56:	48 f7 d2             	not    %rdx
    2b59:	48 21 ca             	and    %rcx,%rdx
    2b5c:	4c 31 e2             	xor    %r12,%rdx
    2b5f:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    2b64:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
    2b69:	48 31 c5             	xor    %rax,%rbp
    2b6c:	48 89 c2             	mov    %rax,%rdx
    2b6f:	48 d1 c5             	rol    $1,%rbp
    2b72:	4c 8b 44 24 90       	mov    -0x70(%rsp),%r8
    2b77:	4d 31 f8             	xor    %r15,%r8
    2b7a:	49 c1 c0 06          	rol    $0x6,%r8
    2b7e:	48 8b 44 24 a0       	mov    -0x60(%rsp),%rax
    2b83:	4c 31 c8             	xor    %r9,%rax
    2b86:	48 c1 c0 19          	rol    $0x19,%rax
    2b8a:	48 8b 4c 24 e8       	mov    -0x18(%rsp),%rcx
    2b8f:	48 c1 c1 08          	rol    $0x8,%rcx
    2b93:	4c 31 f7             	xor    %r14,%rdi
    2b96:	48 c1 c7 12          	rol    $0x12,%rdi
    2b9a:	4c 89 c6             	mov    %r8,%rsi
    2b9d:	48 f7 d6             	not    %rsi
    2ba0:	48 21 c6             	and    %rax,%rsi
    2ba3:	49 89 cc             	mov    %rcx,%r12
    2ba6:	49 f7 d4             	not    %r12
    2ba9:	49 21 fc             	and    %rdi,%r12
    2bac:	49 31 c4             	xor    %rax,%r12
    2baf:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    2bb4:	49 89 c4             	mov    %rax,%r12
    2bb7:	49 f7 d4             	not    %r12
    2bba:	49 21 cc             	and    %rcx,%r12
    2bbd:	49 89 fd             	mov    %rdi,%r13
    2bc0:	49 f7 d5             	not    %r13
    2bc3:	49 21 ed             	and    %rbp,%r13
    2bc6:	49 31 cd             	xor    %rcx,%r13
    2bc9:	4c 89 6c 24 a0       	mov    %r13,-0x60(%rsp)
    2bce:	48 31 ee             	xor    %rbp,%rsi
    2bd1:	48 89 74 24 90       	mov    %rsi,-0x70(%rsp)
    2bd6:	4d 31 c4             	xor    %r8,%r12
    2bd9:	4c 89 64 24 f0       	mov    %r12,-0x10(%rsp)
    2bde:	48 f7 d5             	not    %rbp
    2be1:	4c 21 c5             	and    %r8,%rbp
    2be4:	4c 8b 6c 24 88       	mov    -0x78(%rsp),%r13
    2be9:	4d 31 f5             	xor    %r14,%r13
    2bec:	49 c1 c5 24          	rol    $0x24,%r13
    2bf0:	48 31 fd             	xor    %rdi,%rbp
    2bf3:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
    2bf8:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
    2bfd:	48 31 d6             	xor    %rdx,%rsi
    2c00:	48 89 d5             	mov    %rdx,%rbp
    2c03:	48 c1 c6 0a          	rol    $0xa,%rsi
    2c07:	48 8b 7c 24 c8       	mov    -0x38(%rsp),%rdi
    2c0c:	4c 31 ff             	xor    %r15,%rdi
    2c0f:	48 c1 c7 0f          	rol    $0xf,%rdi
    2c13:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    2c18:	4c 31 ca             	xor    %r9,%rdx
    2c1b:	48 c1 c2 38          	rol    $0x38,%rdx
    2c1f:	4c 89 e8             	mov    %r13,%rax
    2c22:	48 f7 d0             	not    %rax
    2c25:	48 21 f0             	and    %rsi,%rax
    2c28:	49 89 fc             	mov    %rdi,%r12
    2c2b:	49 f7 d4             	not    %r12
    2c2e:	49 21 d4             	and    %rdx,%r12
    2c31:	49 31 f4             	xor    %rsi,%r12
    2c34:	4c 89 64 24 c8       	mov    %r12,-0x38(%rsp)
    2c39:	48 89 f1             	mov    %rsi,%rcx
    2c3c:	4c 8b 44 24 80       	mov    -0x80(%rsp),%r8
    2c41:	49 c1 c0 1b          	rol    $0x1b,%r8
    2c45:	48 f7 d1             	not    %rcx
    2c48:	48 21 f9             	and    %rdi,%rcx
    2c4b:	49 89 d4             	mov    %rdx,%r12
    2c4e:	49 f7 d4             	not    %r12
    2c51:	4d 21 c4             	and    %r8,%r12
    2c54:	49 31 fc             	xor    %rdi,%r12
    2c57:	4c 31 c0             	xor    %r8,%rax
    2c5a:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    2c5f:	4c 31 e9             	xor    %r13,%rcx
    2c62:	48 89 4c 24 88       	mov    %rcx,-0x78(%rsp)
    2c67:	49 f7 d0             	not    %r8
    2c6a:	4d 21 e8             	and    %r13,%r8
    2c6d:	4c 33 7c 24 50       	xor    0x50(%rsp),%r15
    2c72:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    2c77:	4c 33 74 24 c0       	xor    -0x40(%rsp),%r14
    2c7c:	48 33 6c 24 38       	xor    0x38(%rsp),%rbp
    2c81:	49 c1 c7 3e          	rol    $0x3e,%r15
    2c85:	49 c1 c1 37          	rol    $0x37,%r9
    2c89:	49 c1 c2 27          	rol    $0x27,%r10
    2c8d:	49 c1 c6 29          	rol    $0x29,%r14
    2c91:	48 c1 c5 02          	rol    $0x2,%rbp
    2c95:	49 31 d0             	xor    %rdx,%r8
    2c98:	4c 89 ca             	mov    %r9,%rdx
    2c9b:	48 f7 d2             	not    %rdx
    2c9e:	4c 21 d2             	and    %r10,%rdx
    2ca1:	4c 89 f0             	mov    %r14,%rax
    2ca4:	48 f7 d0             	not    %rax
    2ca7:	48 21 e8             	and    %rbp,%rax
    2caa:	4c 31 d0             	xor    %r10,%rax
    2cad:	49 f7 d2             	not    %r10
    2cb0:	4d 21 f2             	and    %r14,%r10
    2cb3:	48 89 ef             	mov    %rbp,%rdi
    2cb6:	48 f7 d7             	not    %rdi
    2cb9:	4c 21 ff             	and    %r15,%rdi
    2cbc:	4c 31 f7             	xor    %r14,%rdi
    2cbf:	48 89 7c 24 c0       	mov    %rdi,-0x40(%rsp)
    2cc4:	4c 31 fa             	xor    %r15,%rdx
    2cc7:	49 89 d5             	mov    %rdx,%r13
    2cca:	4d 31 ca             	xor    %r9,%r10
    2ccd:	49 f7 d7             	not    %r15
    2cd0:	4d 21 cf             	and    %r9,%r15
    2cd3:	49 31 ef             	xor    %rbp,%r15
    2cd6:	4c 89 7c 24 b0       	mov    %r15,-0x50(%rsp)
    2cdb:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
    2ce0:	48 83 44 24 10 02    	addq   $0x2,0x10(%rsp)
    2ce6:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
    2ceb:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2cf0:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    2cf5:	48 8b 6c 24 d8       	mov    -0x28(%rsp),%rbp
    2cfa:	48 89 5c 24 80       	mov    %rbx,-0x80(%rsp)
    2cff:	e9 0f f9 ff ff       	jmp    2613 <KeccakF1600_StatePermute+0xe7>
    2d04:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    2d09:	48 8b 7c 24 80       	mov    -0x80(%rsp),%rdi
    2d0e:	48 89 39             	mov    %rdi,(%rcx)
    2d11:	48 89 69 08          	mov    %rbp,0x8(%rcx)
    2d15:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    2d1a:	48 89 79 10          	mov    %rdi,0x10(%rcx)
    2d1e:	48 8b 74 24 b8       	mov    -0x48(%rsp),%rsi
    2d23:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    2d27:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    2d2b:	48 8b 14 24          	mov    (%rsp),%rdx
    2d2f:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    2d33:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    2d38:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    2d3c:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
    2d41:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    2d45:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
    2d4a:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    2d4e:	4c 89 79 48          	mov    %r15,0x48(%rcx)
    2d52:	48 8b 54 24 90       	mov    -0x70(%rsp),%rdx
    2d57:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2d5b:	48 8b 54 24 f0       	mov    -0x10(%rsp),%rdx
    2d60:	48 89 51 58          	mov    %rdx,0x58(%rcx)
    2d64:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    2d69:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    2d6d:	48 8b 54 24 a0       	mov    -0x60(%rsp),%rdx
    2d72:	48 89 51 68          	mov    %rdx,0x68(%rcx)
    2d76:	4c 89 71 70          	mov    %r14,0x70(%rcx)
    2d7a:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    2d7f:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    2d83:	48 8b 54 24 88       	mov    -0x78(%rsp),%rdx
    2d88:	48 89 91 80 00 00 00 	mov    %rdx,0x80(%rcx)
    2d8f:	48 8b 54 24 c8       	mov    -0x38(%rsp),%rdx
    2d94:	48 89 91 88 00 00 00 	mov    %rdx,0x88(%rcx)
    2d9b:	4c 89 a1 90 00 00 00 	mov    %r12,0x90(%rcx)
    2da2:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2da9:	4c 89 a9 a0 00 00 00 	mov    %r13,0xa0(%rcx)
    2db0:	4c 89 91 a8 00 00 00 	mov    %r10,0xa8(%rcx)
    2db7:	48 89 81 b0 00 00 00 	mov    %rax,0xb0(%rcx)
    2dbe:	48 8b 44 24 c0       	mov    -0x40(%rsp),%rax
    2dc3:	48 89 81 b8 00 00 00 	mov    %rax,0xb8(%rcx)
    2dca:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    2dcf:	48 89 81 c0 00 00 00 	mov    %rax,0xc0(%rcx)
    2dd6:	48 83 c4 68          	add    $0x68,%rsp
    2dda:	5b                   	pop    %rbx
    2ddb:	41 5c                	pop    %r12
    2ddd:	41 5d                	pop    %r13
    2ddf:	41 5e                	pop    %r14
    2de1:	41 5f                	pop    %r15
    2de3:	5d                   	pop    %rbp
    2de4:	c3                   	ret

0000000000002de5 <store64>:
    2de5:	31 c9                	xor    %ecx,%ecx
    2de7:	48 83 f9 40          	cmp    $0x40,%rcx
    2deb:	74 11                	je     2dfe <store64+0x19>
    2ded:	48 89 f0             	mov    %rsi,%rax
    2df0:	48 d3 e8             	shr    %cl,%rax
    2df3:	88 07                	mov    %al,(%rdi)
    2df5:	48 83 c1 08          	add    $0x8,%rcx
    2df9:	48 ff c7             	inc    %rdi
    2dfc:	eb e9                	jmp    2de7 <store64+0x2>
    2dfe:	c3                   	ret

0000000000002dff <pqcrystals_kyber_fips202_ref_sha3_512>:
    2dff:	41 56                	push   %r14
    2e01:	53                   	push   %rbx
    2e02:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    2e09:	48 89 d1             	mov    %rdx,%rcx
    2e0c:	48 89 f2             	mov    %rsi,%rdx
    2e0f:	48 89 fb             	mov    %rdi,%rbx
    2e12:	49 89 e6             	mov    %rsp,%r14
    2e15:	6a 48                	push   $0x48
    2e17:	5e                   	pop    %rsi
    2e18:	6a 06                	push   $0x6
    2e1a:	41 58                	pop    %r8
    2e1c:	4c 89 f7             	mov    %r14,%rdi
    2e1f:	e8 f3 f3 ff ff       	call   2217 <keccak_absorb_once>
    2e24:	4c 89 f7             	mov    %r14,%rdi
    2e27:	e8 00 f7 ff ff       	call   252c <KeccakF1600_StatePermute>
    2e2c:	45 31 f6             	xor    %r14d,%r14d
    2e2f:	49 83 fe 40          	cmp    $0x40,%r14
    2e33:	74 13                	je     2e48 <pqcrystals_kyber_fips202_ref_sha3_512+0x49>
    2e35:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    2e39:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    2e3d:	e8 a3 ff ff ff       	call   2de5 <store64>
    2e42:	49 83 c6 08          	add    $0x8,%r14
    2e46:	eb e7                	jmp    2e2f <pqcrystals_kyber_fips202_ref_sha3_512+0x30>
    2e48:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    2e4f:	5b                   	pop    %rbx
    2e50:	41 5e                	pop    %r14
    2e52:	c3                   	ret

Disassembly of section .fini:

0000000000002e54 <_fini>:
    2e54:	f3 0f 1e fa          	endbr64
    2e58:	48 83 ec 08          	sub    $0x8,%rsp
    2e5c:	48 83 c4 08          	add    $0x8,%rsp
    2e60:	c3                   	ret

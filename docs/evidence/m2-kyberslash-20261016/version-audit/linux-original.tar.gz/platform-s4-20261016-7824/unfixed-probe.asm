
/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/build-smoke/kyberslash_unfixed_probe:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 c1 3f 00 00 	mov    0x3fc1(%rip),%rax        # 4fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <puts@plt-0x10>:
    1020:	ff 35 ca 3f 00 00    	push   0x3fca(%rip)        # 4ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 3f 00 00    	jmp    *0x3fcc(%rip)        # 4ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001030 <puts@plt>:
    1030:	ff 25 ca 3f 00 00    	jmp    *0x3fca(%rip)        # 5000 <puts@GLIBC_2.2.5>
    1036:	68 00 00 00 00       	push   $0x0
    103b:	e9 e0 ff ff ff       	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001040 <__cxa_finalize@plt>:
    1040:	ff 25 9a 3f 00 00    	jmp    *0x3f9a(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1046:	66 90                	xchg   %ax,%ax

Disassembly of section .text:

0000000000001050 <_start>:
    1050:	f3 0f 1e fa          	endbr64
    1054:	31 ed                	xor    %ebp,%ebp
    1056:	49 89 d1             	mov    %rdx,%r9
    1059:	5e                   	pop    %rsi
    105a:	48 89 e2             	mov    %rsp,%rdx
    105d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    1061:	50                   	push   %rax
    1062:	54                   	push   %rsp
    1063:	45 31 c0             	xor    %r8d,%r8d
    1066:	31 c9                	xor    %ecx,%ecx
    1068:	48 8d 3d d1 00 00 00 	lea    0xd1(%rip),%rdi        # 1140 <main>
    106f:	ff 15 4b 3f 00 00    	call   *0x3f4b(%rip)        # 4fc0 <__libc_start_main@GLIBC_2.34>
    1075:	f4                   	hlt
    1076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    107d:	00 00 00 

0000000000001080 <deregister_tm_clones>:
    1080:	48 8d 3d 91 3f 00 00 	lea    0x3f91(%rip),%rdi        # 5018 <__TMC_END__>
    1087:	48 8d 05 8a 3f 00 00 	lea    0x3f8a(%rip),%rax        # 5018 <__TMC_END__>
    108e:	48 39 f8             	cmp    %rdi,%rax
    1091:	74 15                	je     10a8 <deregister_tm_clones+0x28>
    1093:	48 8b 05 2e 3f 00 00 	mov    0x3f2e(%rip),%rax        # 4fc8 <_ITM_deregisterTMCloneTable@Base>
    109a:	48 85 c0             	test   %rax,%rax
    109d:	74 09                	je     10a8 <deregister_tm_clones+0x28>
    109f:	ff e0                	jmp    *%rax
    10a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010b0 <register_tm_clones>:
    10b0:	48 8d 3d 61 3f 00 00 	lea    0x3f61(%rip),%rdi        # 5018 <__TMC_END__>
    10b7:	48 8d 35 5a 3f 00 00 	lea    0x3f5a(%rip),%rsi        # 5018 <__TMC_END__>
    10be:	48 29 fe             	sub    %rdi,%rsi
    10c1:	48 89 f0             	mov    %rsi,%rax
    10c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    10c8:	48 c1 f8 03          	sar    $0x3,%rax
    10cc:	48 01 c6             	add    %rax,%rsi
    10cf:	48 d1 fe             	sar    $1,%rsi
    10d2:	74 14                	je     10e8 <register_tm_clones+0x38>
    10d4:	48 8b 05 fd 3e 00 00 	mov    0x3efd(%rip),%rax        # 4fd8 <_ITM_registerTMCloneTable@Base>
    10db:	48 85 c0             	test   %rax,%rax
    10de:	74 08                	je     10e8 <register_tm_clones+0x38>
    10e0:	ff e0                	jmp    *%rax
    10e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010f0 <__do_global_dtors_aux>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	80 3d 1d 3f 00 00 00 	cmpb   $0x0,0x3f1d(%rip)        # 5018 <__TMC_END__>
    10fb:	75 2b                	jne    1128 <__do_global_dtors_aux+0x38>
    10fd:	55                   	push   %rbp
    10fe:	48 83 3d da 3e 00 00 	cmpq   $0x0,0x3eda(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1105:	00 
    1106:	48 89 e5             	mov    %rsp,%rbp
    1109:	74 0c                	je     1117 <__do_global_dtors_aux+0x27>
    110b:	48 8b 3d fe 3e 00 00 	mov    0x3efe(%rip),%rdi        # 5010 <__dso_handle>
    1112:	e8 29 ff ff ff       	call   1040 <__cxa_finalize@plt>
    1117:	e8 64 ff ff ff       	call   1080 <deregister_tm_clones>
    111c:	c6 05 f5 3e 00 00 01 	movb   $0x1,0x3ef5(%rip)        # 5018 <__TMC_END__>
    1123:	5d                   	pop    %rbp
    1124:	c3                   	ret
    1125:	0f 1f 00             	nopl   (%rax)
    1128:	c3                   	ret
    1129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001130 <frame_dummy>:
    1130:	f3 0f 1e fa          	endbr64
    1134:	e9 77 ff ff ff       	jmp    10b0 <register_tm_clones>
    1139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001140 <main>:
    1140:	55                   	push   %rbp
    1141:	48 89 e5             	mov    %rsp,%rbp
    1144:	48 81 ec a0 0c 00 00 	sub    $0xca0,%rsp
    114b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%rbp)
    1152:	c6 85 8f f3 ff ff 00 	movb   $0x0,-0xc71(%rbp)
    1159:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
    1160:	00 00 00 00 
    1164:	48 81 bd 80 f3 ff ff 	cmpq   $0x100,-0xc80(%rbp)
    116b:	00 01 00 00 
    116f:	0f 83 9f 00 00 00    	jae    1214 <main+0xd4>
    1175:	48 6b 85 80 f3 ff ff 	imul   $0xd,-0xc80(%rbp),%rax
    117c:	0d 
    117d:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    1182:	31 d2                	xor    %edx,%edx
    1184:	48 f7 f1             	div    %rcx
    1187:	66 89 d1             	mov    %dx,%cx
    118a:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1191:	66 89 8c 45 fc fd ff 	mov    %cx,-0x204(%rbp,%rax,2)
    1198:	ff 
    1199:	48 c7 85 78 f3 ff ff 	movq   $0x0,-0xc88(%rbp)
    11a0:	00 00 00 00 
    11a4:	48 83 bd 78 f3 ff ff 	cmpq   $0x3,-0xc88(%rbp)
    11ab:	03 
    11ac:	0f 83 46 00 00 00    	jae    11f8 <main+0xb8>
    11b2:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    11b9:	66 8b 94 45 fc fd ff 	mov    -0x204(%rbp,%rax,2),%dx
    11c0:	ff 
    11c1:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    11c8:	48 8b 8d 78 f3 ff ff 	mov    -0xc88(%rbp),%rcx
    11cf:	48 c1 e1 09          	shl    $0x9,%rcx
    11d3:	48 01 c8             	add    %rcx,%rax
    11d6:	48 8b 8d 80 f3 ff ff 	mov    -0xc80(%rbp),%rcx
    11dd:	66 89 14 48          	mov    %dx,(%rax,%rcx,2)
    11e1:	48 8b 85 78 f3 ff ff 	mov    -0xc88(%rbp),%rax
    11e8:	48 83 c0 01          	add    $0x1,%rax
    11ec:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
    11f3:	e9 ac ff ff ff       	jmp    11a4 <main+0x64>
    11f8:	e9 00 00 00 00       	jmp    11fd <main+0xbd>
    11fd:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1204:	48 83 c0 01          	add    $0x1,%rax
    1208:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
    120f:	e9 50 ff ff ff       	jmp    1164 <main+0x24>
    1214:	48 8d bd d0 f7 ff ff 	lea    -0x830(%rbp),%rdi
    121b:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1222:	e8 cf 02 00 00       	call   14f6 <pqcrystals_kyber768_ref_poly_tomsg>
    1227:	48 8d bd 50 f7 ff ff 	lea    -0x8b0(%rbp),%rdi
    122e:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1235:	e8 26 01 00 00       	call   1360 <pqcrystals_kyber768_ref_poly_compress>
    123a:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
    1241:	48 8d b5 fc f7 ff ff 	lea    -0x804(%rbp),%rsi
    1248:	e8 a3 04 00 00       	call   16f0 <pqcrystals_kyber768_ref_polyvec_compress>
    124d:	48 c7 85 70 f3 ff ff 	movq   $0x0,-0xc90(%rbp)
    1254:	00 00 00 00 
    1258:	48 83 bd 70 f3 ff ff 	cmpq   $0x20,-0xc90(%rbp)
    125f:	20 
    1260:	0f 83 37 00 00 00    	jae    129d <main+0x15d>
    1266:	48 8b 85 70 f3 ff ff 	mov    -0xc90(%rbp),%rax
    126d:	0f b6 8c 05 d0 f7 ff 	movzbl -0x830(%rbp,%rax,1),%ecx
    1274:	ff 
    1275:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    127b:	0f b6 c0             	movzbl %al,%eax
    127e:	31 c8                	xor    %ecx,%eax
    1280:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    1286:	48 8b 85 70 f3 ff ff 	mov    -0xc90(%rbp),%rax
    128d:	48 83 c0 01          	add    $0x1,%rax
    1291:	48 89 85 70 f3 ff ff 	mov    %rax,-0xc90(%rbp)
    1298:	e9 bb ff ff ff       	jmp    1258 <main+0x118>
    129d:	48 c7 85 68 f3 ff ff 	movq   $0x0,-0xc98(%rbp)
    12a4:	00 00 00 00 
    12a8:	48 81 bd 68 f3 ff ff 	cmpq   $0x80,-0xc98(%rbp)
    12af:	80 00 00 00 
    12b3:	0f 83 37 00 00 00    	jae    12f0 <main+0x1b0>
    12b9:	48 8b 85 68 f3 ff ff 	mov    -0xc98(%rbp),%rax
    12c0:	0f b6 8c 05 50 f7 ff 	movzbl -0x8b0(%rbp,%rax,1),%ecx
    12c7:	ff 
    12c8:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    12ce:	0f b6 c0             	movzbl %al,%eax
    12d1:	31 c8                	xor    %ecx,%eax
    12d3:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    12d9:	48 8b 85 68 f3 ff ff 	mov    -0xc98(%rbp),%rax
    12e0:	48 83 c0 01          	add    $0x1,%rax
    12e4:	48 89 85 68 f3 ff ff 	mov    %rax,-0xc98(%rbp)
    12eb:	e9 b8 ff ff ff       	jmp    12a8 <main+0x168>
    12f0:	48 c7 85 60 f3 ff ff 	movq   $0x0,-0xca0(%rbp)
    12f7:	00 00 00 00 
    12fb:	48 81 bd 60 f3 ff ff 	cmpq   $0x3c0,-0xca0(%rbp)
    1302:	c0 03 00 00 
    1306:	0f 83 37 00 00 00    	jae    1343 <main+0x203>
    130c:	48 8b 85 60 f3 ff ff 	mov    -0xca0(%rbp),%rax
    1313:	0f b6 8c 05 90 f3 ff 	movzbl -0xc70(%rbp,%rax,1),%ecx
    131a:	ff 
    131b:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1321:	0f b6 c0             	movzbl %al,%eax
    1324:	31 c8                	xor    %ecx,%eax
    1326:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    132c:	48 8b 85 60 f3 ff ff 	mov    -0xca0(%rbp),%rax
    1333:	48 83 c0 01          	add    $0x1,%rax
    1337:	48 89 85 60 f3 ff ff 	mov    %rax,-0xca0(%rbp)
    133e:	e9 b8 ff ff ff       	jmp    12fb <main+0x1bb>
    1343:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1349:	48 8d 3d b4 1c 00 00 	lea    0x1cb4(%rip),%rdi        # 3004 <_IO_stdin_used+0x4>
    1350:	e8 db fc ff ff       	call   1030 <puts@plt>
    1355:	31 c0                	xor    %eax,%eax
    1357:	48 81 c4 a0 0c 00 00 	add    $0xca0,%rsp
    135e:	5d                   	pop    %rbp
    135f:	c3                   	ret

0000000000001360 <pqcrystals_kyber768_ref_poly_compress>:
    1360:	31 c9                	xor    %ecx,%ecx
    1362:	41 b8 01 0d 00 00    	mov    $0xd01,%r8d
    1368:	48 83 f9 20          	cmp    $0x20,%rcx
    136c:	74 78                	je     13e6 <pqcrystals_kyber768_ref_poly_compress+0x86>
    136e:	45 31 c9             	xor    %r9d,%r9d
    1371:	49 83 f9 08          	cmp    $0x8,%r9
    1375:	74 2b                	je     13a2 <pqcrystals_kyber768_ref_poly_compress+0x42>
    1377:	42 0f bf 04 4e       	movswl (%rsi,%r9,2),%eax
    137c:	89 c2                	mov    %eax,%edx
    137e:	c1 ea 0f             	shr    $0xf,%edx
    1381:	44 21 c2             	and    %r8d,%edx
    1384:	01 c2                	add    %eax,%edx
    1386:	0f b7 c2             	movzwl %dx,%eax
    1389:	c1 e0 04             	shl    $0x4,%eax
    138c:	05 80 06 00 00       	add    $0x680,%eax
    1391:	31 d2                	xor    %edx,%edx
    1393:	41 f7 f0             	div    %r8d
    1396:	24 0f                	and    $0xf,%al
    1398:	42 88 44 0c f8       	mov    %al,-0x8(%rsp,%r9,1)
    139d:	49 ff c1             	inc    %r9
    13a0:	eb cf                	jmp    1371 <pqcrystals_kyber768_ref_poly_compress+0x11>
    13a2:	8a 44 24 f9          	mov    -0x7(%rsp),%al
    13a6:	c0 e0 04             	shl    $0x4,%al
    13a9:	0a 44 24 f8          	or     -0x8(%rsp),%al
    13ad:	88 07                	mov    %al,(%rdi)
    13af:	8a 44 24 fb          	mov    -0x5(%rsp),%al
    13b3:	c0 e0 04             	shl    $0x4,%al
    13b6:	0a 44 24 fa          	or     -0x6(%rsp),%al
    13ba:	88 47 01             	mov    %al,0x1(%rdi)
    13bd:	8a 44 24 fd          	mov    -0x3(%rsp),%al
    13c1:	c0 e0 04             	shl    $0x4,%al
    13c4:	0a 44 24 fc          	or     -0x4(%rsp),%al
    13c8:	88 47 02             	mov    %al,0x2(%rdi)
    13cb:	8a 44 24 ff          	mov    -0x1(%rsp),%al
    13cf:	c0 e0 04             	shl    $0x4,%al
    13d2:	0a 44 24 fe          	or     -0x2(%rsp),%al
    13d6:	88 47 03             	mov    %al,0x3(%rdi)
    13d9:	48 83 c7 04          	add    $0x4,%rdi
    13dd:	48 ff c1             	inc    %rcx
    13e0:	48 83 c6 10          	add    $0x10,%rsi
    13e4:	eb 82                	jmp    1368 <pqcrystals_kyber768_ref_poly_compress+0x8>
    13e6:	c3                   	ret

00000000000013e7 <pqcrystals_kyber768_ref_poly_decompress>:
    13e7:	31 c0                	xor    %eax,%eax
    13e9:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    13ef:	74 34                	je     1425 <pqcrystals_kyber768_ref_poly_decompress+0x3e>
    13f1:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    13f5:	83 e1 0f             	and    $0xf,%ecx
    13f8:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    13fe:	83 c1 08             	add    $0x8,%ecx
    1401:	c1 e9 04             	shr    $0x4,%ecx
    1404:	66 89 0c 87          	mov    %cx,(%rdi,%rax,4)
    1408:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    140c:	c1 e9 04             	shr    $0x4,%ecx
    140f:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    1415:	83 c1 08             	add    $0x8,%ecx
    1418:	c1 e9 04             	shr    $0x4,%ecx
    141b:	66 89 4c 87 02       	mov    %cx,0x2(%rdi,%rax,4)
    1420:	48 ff c0             	inc    %rax
    1423:	eb c4                	jmp    13e9 <pqcrystals_kyber768_ref_poly_decompress+0x2>
    1425:	c3                   	ret

0000000000001426 <pqcrystals_kyber768_ref_poly_tobytes>:
    1426:	48 83 c7 02          	add    $0x2,%rdi
    142a:	31 c0                	xor    %eax,%eax
    142c:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    1431:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    1437:	74 47                	je     1480 <pqcrystals_kyber768_ref_poly_tobytes+0x5a>
    1439:	44 0f bf 04 86       	movswl (%rsi,%rax,4),%r8d
    143e:	44 89 c2             	mov    %r8d,%edx
    1441:	c1 ea 0f             	shr    $0xf,%edx
    1444:	21 ca                	and    %ecx,%edx
    1446:	44 01 c2             	add    %r8d,%edx
    1449:	44 0f bf 44 86 02    	movswl 0x2(%rsi,%rax,4),%r8d
    144f:	45 89 c1             	mov    %r8d,%r9d
    1452:	41 c1 e9 0f          	shr    $0xf,%r9d
    1456:	41 21 c9             	and    %ecx,%r9d
    1459:	45 01 c1             	add    %r8d,%r9d
    145c:	88 57 fe             	mov    %dl,-0x2(%rdi)
    145f:	0f b6 d6             	movzbl %dh,%edx
    1462:	45 89 c8             	mov    %r9d,%r8d
    1465:	41 c1 e0 04          	shl    $0x4,%r8d
    1469:	41 09 d0             	or     %edx,%r8d
    146c:	44 88 47 ff          	mov    %r8b,-0x1(%rdi)
    1470:	41 c1 e9 04          	shr    $0x4,%r9d
    1474:	44 88 0f             	mov    %r9b,(%rdi)
    1477:	48 ff c0             	inc    %rax
    147a:	48 83 c7 03          	add    $0x3,%rdi
    147e:	eb b1                	jmp    1431 <pqcrystals_kyber768_ref_poly_tobytes+0xb>
    1480:	c3                   	ret

0000000000001481 <pqcrystals_kyber768_ref_poly_frombytes>:
    1481:	48 83 c6 02          	add    $0x2,%rsi
    1485:	31 c0                	xor    %eax,%eax
    1487:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    148d:	74 31                	je     14c0 <pqcrystals_kyber768_ref_poly_frombytes+0x3f>
    148f:	0f b6 4e fe          	movzbl -0x2(%rsi),%ecx
    1493:	0f b6 56 ff          	movzbl -0x1(%rsi),%edx
    1497:	83 e2 0f             	and    $0xf,%edx
    149a:	c1 e2 08             	shl    $0x8,%edx
    149d:	09 ca                	or     %ecx,%edx
    149f:	66 89 14 87          	mov    %dx,(%rdi,%rax,4)
    14a3:	0f b6 4e ff          	movzbl -0x1(%rsi),%ecx
    14a7:	c1 e9 04             	shr    $0x4,%ecx
    14aa:	0f b6 16             	movzbl (%rsi),%edx
    14ad:	c1 e2 04             	shl    $0x4,%edx
    14b0:	09 ca                	or     %ecx,%edx
    14b2:	66 89 54 87 02       	mov    %dx,0x2(%rdi,%rax,4)
    14b7:	48 ff c0             	inc    %rax
    14ba:	48 83 c6 03          	add    $0x3,%rsi
    14be:	eb c7                	jmp    1487 <pqcrystals_kyber768_ref_poly_frombytes+0x6>
    14c0:	c3                   	ret

00000000000014c1 <pqcrystals_kyber768_ref_poly_frommsg>:
    14c1:	31 c0                	xor    %eax,%eax
    14c3:	48 83 f8 20          	cmp    $0x20,%rax
    14c7:	74 2c                	je     14f5 <pqcrystals_kyber768_ref_poly_frommsg+0x34>
    14c9:	31 c9                	xor    %ecx,%ecx
    14cb:	48 83 f9 08          	cmp    $0x8,%rcx
    14cf:	74 1b                	je     14ec <pqcrystals_kyber768_ref_poly_frommsg+0x2b>
    14d1:	44 0f b6 04 06       	movzbl (%rsi,%rax,1),%r8d
    14d6:	31 d2                	xor    %edx,%edx
    14d8:	41 0f a3 c8          	bt     %ecx,%r8d
    14dc:	73 05                	jae    14e3 <pqcrystals_kyber768_ref_poly_frommsg+0x22>
    14de:	ba 81 06 00 00       	mov    $0x681,%edx
    14e3:	66 89 14 4f          	mov    %dx,(%rdi,%rcx,2)
    14e7:	48 ff c1             	inc    %rcx
    14ea:	eb df                	jmp    14cb <pqcrystals_kyber768_ref_poly_frommsg+0xa>
    14ec:	48 ff c0             	inc    %rax
    14ef:	48 83 c7 10          	add    $0x10,%rdi
    14f3:	eb ce                	jmp    14c3 <pqcrystals_kyber768_ref_poly_frommsg+0x2>
    14f5:	c3                   	ret

00000000000014f6 <pqcrystals_kyber768_ref_poly_tomsg>:
    14f6:	45 31 c0             	xor    %r8d,%r8d
    14f9:	41 b9 01 0d 00 00    	mov    $0xd01,%r9d
    14ff:	49 83 f8 20          	cmp    $0x20,%r8
    1503:	74 47                	je     154c <pqcrystals_kyber768_ref_poly_tomsg+0x56>
    1505:	42 c6 04 07 00       	movb   $0x0,(%rdi,%r8,1)
    150a:	31 c9                	xor    %ecx,%ecx
    150c:	45 31 d2             	xor    %r10d,%r10d
    150f:	48 83 f9 08          	cmp    $0x8,%rcx
    1513:	74 2e                	je     1543 <pqcrystals_kyber768_ref_poly_tomsg+0x4d>
    1515:	0f bf 04 4e          	movswl (%rsi,%rcx,2),%eax
    1519:	89 c2                	mov    %eax,%edx
    151b:	c1 ea 0f             	shr    $0xf,%edx
    151e:	44 21 ca             	and    %r9d,%edx
    1521:	01 c2                	add    %eax,%edx
    1523:	0f b7 c2             	movzwl %dx,%eax
    1526:	8d 04 45 80 06 00 00 	lea    0x680(,%rax,2),%eax
    152d:	31 d2                	xor    %edx,%edx
    152f:	41 f7 f1             	div    %r9d
    1532:	83 e0 01             	and    $0x1,%eax
    1535:	d3 e0                	shl    %cl,%eax
    1537:	41 08 c2             	or     %al,%r10b
    153a:	46 88 14 07          	mov    %r10b,(%rdi,%r8,1)
    153e:	48 ff c1             	inc    %rcx
    1541:	eb cc                	jmp    150f <pqcrystals_kyber768_ref_poly_tomsg+0x19>
    1543:	49 ff c0             	inc    %r8
    1546:	48 83 c6 10          	add    $0x10,%rsi
    154a:	eb b3                	jmp    14ff <pqcrystals_kyber768_ref_poly_tomsg+0x9>
    154c:	c3                   	ret

000000000000154d <pqcrystals_kyber768_ref_poly_getnoise_eta1>:
    154d:	41 56                	push   %r14
    154f:	53                   	push   %rbx
    1550:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    1557:	89 d1                	mov    %edx,%ecx
    1559:	48 89 f2             	mov    %rsi,%rdx
    155c:	48 89 fb             	mov    %rdi,%rbx
    155f:	49 89 e6             	mov    %rsp,%r14
    1562:	be 80 00 00 00       	mov    $0x80,%esi
    1567:	4c 89 f7             	mov    %r14,%rdi
    156a:	e8 71 07 00 00       	call   1ce0 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    156f:	48 89 df             	mov    %rbx,%rdi
    1572:	4c 89 f6             	mov    %r14,%rsi
    1575:	e8 a6 06 00 00       	call   1c20 <pqcrystals_kyber768_ref_poly_cbd_eta1>
    157a:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    1581:	5b                   	pop    %rbx
    1582:	41 5e                	pop    %r14
    1584:	c3                   	ret

0000000000001585 <pqcrystals_kyber768_ref_poly_getnoise_eta2>:
    1585:	41 56                	push   %r14
    1587:	53                   	push   %rbx
    1588:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    158f:	89 d1                	mov    %edx,%ecx
    1591:	48 89 f2             	mov    %rsi,%rdx
    1594:	48 89 fb             	mov    %rdi,%rbx
    1597:	49 89 e6             	mov    %rsp,%r14
    159a:	be 80 00 00 00       	mov    $0x80,%esi
    159f:	4c 89 f7             	mov    %r14,%rdi
    15a2:	e8 39 07 00 00       	call   1ce0 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    15a7:	48 89 df             	mov    %rbx,%rdi
    15aa:	4c 89 f6             	mov    %r14,%rsi
    15ad:	e8 d0 06 00 00       	call   1c82 <pqcrystals_kyber768_ref_poly_cbd_eta2>
    15b2:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    15b9:	5b                   	pop    %rbx
    15ba:	41 5e                	pop    %r14
    15bc:	c3                   	ret

00000000000015bd <pqcrystals_kyber768_ref_poly_ntt>:
    15bd:	53                   	push   %rbx
    15be:	48 89 fb             	mov    %rdi,%rbx
    15c1:	e8 66 04 00 00       	call   1a2c <pqcrystals_kyber768_ref_ntt>
    15c6:	48 89 df             	mov    %rbx,%rdi
    15c9:	5b                   	pop    %rbx
    15ca:	e9 00 00 00 00       	jmp    15cf <pqcrystals_kyber768_ref_poly_reduce>

00000000000015cf <pqcrystals_kyber768_ref_poly_reduce>:
    15cf:	41 56                	push   %r14
    15d1:	53                   	push   %rbx
    15d2:	50                   	push   %rax
    15d3:	48 89 fb             	mov    %rdi,%rbx
    15d6:	45 31 f6             	xor    %r14d,%r14d
    15d9:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    15e0:	74 14                	je     15f6 <pqcrystals_kyber768_ref_poly_reduce+0x27>
    15e2:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    15e7:	e8 ad 06 00 00       	call   1c99 <pqcrystals_kyber768_ref_barrett_reduce>
    15ec:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    15f1:	49 ff c6             	inc    %r14
    15f4:	eb e3                	jmp    15d9 <pqcrystals_kyber768_ref_poly_reduce+0xa>
    15f6:	48 83 c4 08          	add    $0x8,%rsp
    15fa:	5b                   	pop    %rbx
    15fb:	41 5e                	pop    %r14
    15fd:	c3                   	ret

00000000000015fe <pqcrystals_kyber768_ref_poly_invntt_tomont>:
    15fe:	e9 c8 04 00 00       	jmp    1acb <pqcrystals_kyber768_ref_invntt>

0000000000001603 <pqcrystals_kyber768_ref_poly_basemul_montgomery>:
    1603:	55                   	push   %rbp
    1604:	41 57                	push   %r15
    1606:	41 56                	push   %r14
    1608:	41 55                	push   %r13
    160a:	41 54                	push   %r12
    160c:	53                   	push   %rbx
    160d:	50                   	push   %rax
    160e:	48 89 d3             	mov    %rdx,%rbx
    1611:	49 89 f6             	mov    %rsi,%r14
    1614:	49 89 ff             	mov    %rdi,%r15
    1617:	4c 8d 25 12 1a 00 00 	lea    0x1a12(%rip),%r12        # 3030 <pqcrystals_kyber768_ref_zetas>
    161e:	49 83 ec 80          	sub    $0xffffffffffffff80,%r12
    1622:	45 31 ed             	xor    %r13d,%r13d
    1625:	49 81 fd 00 02 00 00 	cmp    $0x200,%r13
    162c:	74 44                	je     1672 <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x6f>
    162e:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    1632:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    1636:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    163a:	41 0f bf 2c 24       	movswl (%r12),%ebp
    163f:	89 e9                	mov    %ebp,%ecx
    1641:	e8 6a 05 00 00       	call   1bb0 <pqcrystals_kyber768_ref_basemul>
    1646:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    164a:	48 83 c7 04          	add    $0x4,%rdi
    164e:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    1652:	48 83 c6 04          	add    $0x4,%rsi
    1656:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    165a:	48 83 c2 04          	add    $0x4,%rdx
    165e:	f7 dd                	neg    %ebp
    1660:	0f bf cd             	movswl %bp,%ecx
    1663:	e8 48 05 00 00       	call   1bb0 <pqcrystals_kyber768_ref_basemul>
    1668:	49 83 c5 08          	add    $0x8,%r13
    166c:	49 83 c4 02          	add    $0x2,%r12
    1670:	eb b3                	jmp    1625 <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x22>
    1672:	48 83 c4 08          	add    $0x8,%rsp
    1676:	5b                   	pop    %rbx
    1677:	41 5c                	pop    %r12
    1679:	41 5d                	pop    %r13
    167b:	41 5e                	pop    %r14
    167d:	41 5f                	pop    %r15
    167f:	5d                   	pop    %rbp
    1680:	c3                   	ret

0000000000001681 <pqcrystals_kyber768_ref_poly_tomont>:
    1681:	41 56                	push   %r14
    1683:	53                   	push   %rbx
    1684:	50                   	push   %rax
    1685:	48 89 fb             	mov    %rdi,%rbx
    1688:	45 31 f6             	xor    %r14d,%r14d
    168b:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    1692:	74 1a                	je     16ae <pqcrystals_kyber768_ref_poly_tomont+0x2d>
    1694:	42 0f bf 04 73       	movswl (%rbx,%r14,2),%eax
    1699:	69 f8 49 05 00 00    	imul   $0x549,%eax,%edi
    169f:	e8 e0 05 00 00       	call   1c84 <pqcrystals_kyber768_ref_montgomery_reduce>
    16a4:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    16a9:	49 ff c6             	inc    %r14
    16ac:	eb dd                	jmp    168b <pqcrystals_kyber768_ref_poly_tomont+0xa>
    16ae:	48 83 c4 08          	add    $0x8,%rsp
    16b2:	5b                   	pop    %rbx
    16b3:	41 5e                	pop    %r14
    16b5:	c3                   	ret

00000000000016b6 <pqcrystals_kyber768_ref_poly_add>:
    16b6:	31 c0                	xor    %eax,%eax
    16b8:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    16be:	74 11                	je     16d1 <pqcrystals_kyber768_ref_poly_add+0x1b>
    16c0:	0f b7 0c 42          	movzwl (%rdx,%rax,2),%ecx
    16c4:	66 03 0c 46          	add    (%rsi,%rax,2),%cx
    16c8:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    16cc:	48 ff c0             	inc    %rax
    16cf:	eb e7                	jmp    16b8 <pqcrystals_kyber768_ref_poly_add+0x2>
    16d1:	c3                   	ret

00000000000016d2 <pqcrystals_kyber768_ref_poly_sub>:
    16d2:	31 c0                	xor    %eax,%eax
    16d4:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    16da:	74 11                	je     16ed <pqcrystals_kyber768_ref_poly_sub+0x1b>
    16dc:	0f b7 0c 46          	movzwl (%rsi,%rax,2),%ecx
    16e0:	66 2b 0c 42          	sub    (%rdx,%rax,2),%cx
    16e4:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    16e8:	48 ff c0             	inc    %rax
    16eb:	eb e7                	jmp    16d4 <pqcrystals_kyber768_ref_poly_sub+0x2>
    16ed:	c3                   	ret
    16ee:	66 90                	xchg   %ax,%ax

00000000000016f0 <pqcrystals_kyber768_ref_polyvec_compress>:
    16f0:	31 c9                	xor    %ecx,%ecx
    16f2:	41 b8 01 0d 00 00    	mov    $0xd01,%r8d
    16f8:	48 83 f9 03          	cmp    $0x3,%rcx
    16fc:	0f 84 ae 00 00 00    	je     17b0 <pqcrystals_kyber768_ref_polyvec_compress+0xc0>
    1702:	49 89 f1             	mov    %rsi,%r9
    1705:	45 31 d2             	xor    %r10d,%r10d
    1708:	49 83 fa 40          	cmp    $0x40,%r10
    170c:	0f 84 8f 00 00 00    	je     17a1 <pqcrystals_kyber768_ref_polyvec_compress+0xb1>
    1712:	45 31 db             	xor    %r11d,%r11d
    1715:	49 83 fb 04          	cmp    $0x4,%r11
    1719:	74 2f                	je     174a <pqcrystals_kyber768_ref_polyvec_compress+0x5a>
    171b:	43 0f bf 04 59       	movswl (%r9,%r11,2),%eax
    1720:	89 c2                	mov    %eax,%edx
    1722:	c1 ea 0f             	shr    $0xf,%edx
    1725:	44 21 c2             	and    %r8d,%edx
    1728:	01 c2                	add    %eax,%edx
    172a:	0f b7 c2             	movzwl %dx,%eax
    172d:	c1 e0 0a             	shl    $0xa,%eax
    1730:	05 80 06 00 00       	add    $0x680,%eax
    1735:	31 d2                	xor    %edx,%edx
    1737:	41 f7 f0             	div    %r8d
    173a:	25 ff 03 00 00       	and    $0x3ff,%eax
    173f:	66 42 89 44 5c f8    	mov    %ax,-0x8(%rsp,%r11,2)
    1745:	49 ff c3             	inc    %r11
    1748:	eb cb                	jmp    1715 <pqcrystals_kyber768_ref_polyvec_compress+0x25>
    174a:	8a 44 24 f8          	mov    -0x8(%rsp),%al
    174e:	88 07                	mov    %al,(%rdi)
    1750:	8a 44 24 fa          	mov    -0x6(%rsp),%al
    1754:	c0 e0 02             	shl    $0x2,%al
    1757:	0a 44 24 f9          	or     -0x7(%rsp),%al
    175b:	88 47 01             	mov    %al,0x1(%rdi)
    175e:	0f b7 44 24 fa       	movzwl -0x6(%rsp),%eax
    1763:	c1 e8 06             	shr    $0x6,%eax
    1766:	8a 54 24 fc          	mov    -0x4(%rsp),%dl
    176a:	c0 e2 04             	shl    $0x4,%dl
    176d:	08 c2                	or     %al,%dl
    176f:	88 57 02             	mov    %dl,0x2(%rdi)
    1772:	0f b7 44 24 fc       	movzwl -0x4(%rsp),%eax
    1777:	c1 e8 04             	shr    $0x4,%eax
    177a:	8a 54 24 fe          	mov    -0x2(%rsp),%dl
    177e:	c0 e2 06             	shl    $0x6,%dl
    1781:	08 c2                	or     %al,%dl
    1783:	88 57 03             	mov    %dl,0x3(%rdi)
    1786:	0f b7 44 24 fe       	movzwl -0x2(%rsp),%eax
    178b:	c1 e8 02             	shr    $0x2,%eax
    178e:	88 47 04             	mov    %al,0x4(%rdi)
    1791:	48 83 c7 05          	add    $0x5,%rdi
    1795:	49 ff c2             	inc    %r10
    1798:	49 83 c1 08          	add    $0x8,%r9
    179c:	e9 67 ff ff ff       	jmp    1708 <pqcrystals_kyber768_ref_polyvec_compress+0x18>
    17a1:	48 ff c1             	inc    %rcx
    17a4:	48 81 c6 00 02 00 00 	add    $0x200,%rsi
    17ab:	e9 48 ff ff ff       	jmp    16f8 <pqcrystals_kyber768_ref_polyvec_compress+0x8>
    17b0:	c3                   	ret

00000000000017b1 <pqcrystals_kyber768_ref_polyvec_decompress>:
    17b1:	31 c0                	xor    %eax,%eax
    17b3:	48 83 f8 03          	cmp    $0x3,%rax
    17b7:	0f 84 b8 00 00 00    	je     1875 <pqcrystals_kyber768_ref_polyvec_decompress+0xc4>
    17bd:	48 89 f9             	mov    %rdi,%rcx
    17c0:	31 d2                	xor    %edx,%edx
    17c2:	48 83 fa 40          	cmp    $0x40,%rdx
    17c6:	0f 84 9a 00 00 00    	je     1866 <pqcrystals_kyber768_ref_polyvec_decompress+0xb5>
    17cc:	44 0f b7 06          	movzwl (%rsi),%r8d
    17d0:	66 44 89 44 24 f8    	mov    %r8w,-0x8(%rsp)
    17d6:	44 0f b6 46 01       	movzbl 0x1(%rsi),%r8d
    17db:	41 c1 e8 02          	shr    $0x2,%r8d
    17df:	44 0f b6 4e 02       	movzbl 0x2(%rsi),%r9d
    17e4:	41 c1 e1 06          	shl    $0x6,%r9d
    17e8:	45 09 c1             	or     %r8d,%r9d
    17eb:	66 44 89 4c 24 fa    	mov    %r9w,-0x6(%rsp)
    17f1:	44 0f b6 46 02       	movzbl 0x2(%rsi),%r8d
    17f6:	41 c1 e8 04          	shr    $0x4,%r8d
    17fa:	44 0f b6 4e 03       	movzbl 0x3(%rsi),%r9d
    17ff:	41 c1 e1 04          	shl    $0x4,%r9d
    1803:	45 09 c1             	or     %r8d,%r9d
    1806:	66 44 89 4c 24 fc    	mov    %r9w,-0x4(%rsp)
    180c:	44 0f b6 46 03       	movzbl 0x3(%rsi),%r8d
    1811:	41 c1 e8 06          	shr    $0x6,%r8d
    1815:	44 0f b6 4e 04       	movzbl 0x4(%rsi),%r9d
    181a:	47 8d 04 88          	lea    (%r8,%r9,4),%r8d
    181e:	66 44 89 44 24 fe    	mov    %r8w,-0x2(%rsp)
    1824:	45 31 c0             	xor    %r8d,%r8d
    1827:	49 83 f8 04          	cmp    $0x4,%r8
    182b:	74 29                	je     1856 <pqcrystals_kyber768_ref_polyvec_decompress+0xa5>
    182d:	46 0f b7 4c 44 f8    	movzwl -0x8(%rsp,%r8,2),%r9d
    1833:	41 81 e1 ff 03 00 00 	and    $0x3ff,%r9d
    183a:	45 69 c9 01 0d 00 00 	imul   $0xd01,%r9d,%r9d
    1841:	41 81 c1 00 02 00 00 	add    $0x200,%r9d
    1848:	41 c1 e9 0a          	shr    $0xa,%r9d
    184c:	66 46 89 0c 41       	mov    %r9w,(%rcx,%r8,2)
    1851:	49 ff c0             	inc    %r8
    1854:	eb d1                	jmp    1827 <pqcrystals_kyber768_ref_polyvec_decompress+0x76>
    1856:	48 83 c6 05          	add    $0x5,%rsi
    185a:	48 ff c2             	inc    %rdx
    185d:	48 83 c1 08          	add    $0x8,%rcx
    1861:	e9 5c ff ff ff       	jmp    17c2 <pqcrystals_kyber768_ref_polyvec_decompress+0x11>
    1866:	48 ff c0             	inc    %rax
    1869:	48 81 c7 00 02 00 00 	add    $0x200,%rdi
    1870:	e9 3e ff ff ff       	jmp    17b3 <pqcrystals_kyber768_ref_polyvec_decompress+0x2>
    1875:	c3                   	ret

0000000000001876 <pqcrystals_kyber768_ref_polyvec_tobytes>:
    1876:	41 57                	push   %r15
    1878:	41 56                	push   %r14
    187a:	53                   	push   %rbx
    187b:	48 89 f3             	mov    %rsi,%rbx
    187e:	49 89 fe             	mov    %rdi,%r14
    1881:	45 31 ff             	xor    %r15d,%r15d
    1884:	49 81 ff 00 06 00 00 	cmp    $0x600,%r15
    188b:	74 1c                	je     18a9 <pqcrystals_kyber768_ref_polyvec_tobytes+0x33>
    188d:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    1891:	4c 89 f7             	mov    %r14,%rdi
    1894:	e8 8d fb ff ff       	call   1426 <pqcrystals_kyber768_ref_poly_tobytes>
    1899:	49 81 c7 00 02 00 00 	add    $0x200,%r15
    18a0:	49 81 c6 80 01 00 00 	add    $0x180,%r14
    18a7:	eb db                	jmp    1884 <pqcrystals_kyber768_ref_polyvec_tobytes+0xe>
    18a9:	5b                   	pop    %rbx
    18aa:	41 5e                	pop    %r14
    18ac:	41 5f                	pop    %r15
    18ae:	c3                   	ret

00000000000018af <pqcrystals_kyber768_ref_polyvec_frombytes>:
    18af:	41 57                	push   %r15
    18b1:	41 56                	push   %r14
    18b3:	53                   	push   %rbx
    18b4:	48 89 f3             	mov    %rsi,%rbx
    18b7:	49 89 fe             	mov    %rdi,%r14
    18ba:	45 31 ff             	xor    %r15d,%r15d
    18bd:	49 81 ff 80 04 00 00 	cmp    $0x480,%r15
    18c4:	74 1c                	je     18e2 <pqcrystals_kyber768_ref_polyvec_frombytes+0x33>
    18c6:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    18ca:	4c 89 f7             	mov    %r14,%rdi
    18cd:	e8 af fb ff ff       	call   1481 <pqcrystals_kyber768_ref_poly_frombytes>
    18d2:	49 81 c7 80 01 00 00 	add    $0x180,%r15
    18d9:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    18e0:	eb db                	jmp    18bd <pqcrystals_kyber768_ref_polyvec_frombytes+0xe>
    18e2:	5b                   	pop    %rbx
    18e3:	41 5e                	pop    %r14
    18e5:	41 5f                	pop    %r15
    18e7:	c3                   	ret

00000000000018e8 <pqcrystals_kyber768_ref_polyvec_ntt>:
    18e8:	41 56                	push   %r14
    18ea:	53                   	push   %rbx
    18eb:	50                   	push   %rax
    18ec:	48 89 fb             	mov    %rdi,%rbx
    18ef:	45 31 f6             	xor    %r14d,%r14d
    18f2:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    18f9:	74 12                	je     190d <pqcrystals_kyber768_ref_polyvec_ntt+0x25>
    18fb:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    18ff:	e8 b9 fc ff ff       	call   15bd <pqcrystals_kyber768_ref_poly_ntt>
    1904:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    190b:	eb e5                	jmp    18f2 <pqcrystals_kyber768_ref_polyvec_ntt+0xa>
    190d:	48 83 c4 08          	add    $0x8,%rsp
    1911:	5b                   	pop    %rbx
    1912:	41 5e                	pop    %r14
    1914:	c3                   	ret

0000000000001915 <pqcrystals_kyber768_ref_polyvec_invntt_tomont>:
    1915:	41 56                	push   %r14
    1917:	53                   	push   %rbx
    1918:	50                   	push   %rax
    1919:	48 89 fb             	mov    %rdi,%rbx
    191c:	45 31 f6             	xor    %r14d,%r14d
    191f:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1926:	74 12                	je     193a <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0x25>
    1928:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    192c:	e8 cd fc ff ff       	call   15fe <pqcrystals_kyber768_ref_poly_invntt_tomont>
    1931:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1938:	eb e5                	jmp    191f <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0xa>
    193a:	48 83 c4 08          	add    $0x8,%rsp
    193e:	5b                   	pop    %rbx
    193f:	41 5e                	pop    %r14
    1941:	c3                   	ret

0000000000001942 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery>:
    1942:	41 57                	push   %r15
    1944:	41 56                	push   %r14
    1946:	41 55                	push   %r13
    1948:	41 54                	push   %r12
    194a:	53                   	push   %rbx
    194b:	48 81 ec 00 02 00 00 	sub    $0x200,%rsp
    1952:	49 89 d6             	mov    %rdx,%r14
    1955:	49 89 f7             	mov    %rsi,%r15
    1958:	48 89 fb             	mov    %rdi,%rbx
    195b:	e8 a3 fc ff ff       	call   1603 <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    1960:	b8 00 02 00 00       	mov    $0x200,%eax
    1965:	49 01 c7             	add    %rax,%r15
    1968:	49 01 c6             	add    %rax,%r14
    196b:	45 31 ed             	xor    %r13d,%r13d
    196e:	49 89 e4             	mov    %rsp,%r12
    1971:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
    1978:	74 27                	je     19a1 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x5f>
    197a:	4b 8d 34 2f          	lea    (%r15,%r13,1),%rsi
    197e:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
    1982:	4c 89 e7             	mov    %r12,%rdi
    1985:	e8 79 fc ff ff       	call   1603 <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    198a:	48 89 df             	mov    %rbx,%rdi
    198d:	48 89 de             	mov    %rbx,%rsi
    1990:	4c 89 e2             	mov    %r12,%rdx
    1993:	e8 1e fd ff ff       	call   16b6 <pqcrystals_kyber768_ref_poly_add>
    1998:	49 81 c5 00 02 00 00 	add    $0x200,%r13
    199f:	eb d0                	jmp    1971 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x2f>
    19a1:	48 89 df             	mov    %rbx,%rdi
    19a4:	e8 26 fc ff ff       	call   15cf <pqcrystals_kyber768_ref_poly_reduce>
    19a9:	48 81 c4 00 02 00 00 	add    $0x200,%rsp
    19b0:	5b                   	pop    %rbx
    19b1:	41 5c                	pop    %r12
    19b3:	41 5d                	pop    %r13
    19b5:	41 5e                	pop    %r14
    19b7:	41 5f                	pop    %r15
    19b9:	c3                   	ret

00000000000019ba <pqcrystals_kyber768_ref_polyvec_reduce>:
    19ba:	41 56                	push   %r14
    19bc:	53                   	push   %rbx
    19bd:	50                   	push   %rax
    19be:	48 89 fb             	mov    %rdi,%rbx
    19c1:	45 31 f6             	xor    %r14d,%r14d
    19c4:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    19cb:	74 12                	je     19df <pqcrystals_kyber768_ref_polyvec_reduce+0x25>
    19cd:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    19d1:	e8 f9 fb ff ff       	call   15cf <pqcrystals_kyber768_ref_poly_reduce>
    19d6:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    19dd:	eb e5                	jmp    19c4 <pqcrystals_kyber768_ref_polyvec_reduce+0xa>
    19df:	48 83 c4 08          	add    $0x8,%rsp
    19e3:	5b                   	pop    %rbx
    19e4:	41 5e                	pop    %r14
    19e6:	c3                   	ret

00000000000019e7 <pqcrystals_kyber768_ref_polyvec_add>:
    19e7:	41 57                	push   %r15
    19e9:	41 56                	push   %r14
    19eb:	41 54                	push   %r12
    19ed:	53                   	push   %rbx
    19ee:	50                   	push   %rax
    19ef:	48 89 d3             	mov    %rdx,%rbx
    19f2:	49 89 f6             	mov    %rsi,%r14
    19f5:	49 89 ff             	mov    %rdi,%r15
    19f8:	45 31 e4             	xor    %r12d,%r12d
    19fb:	49 81 fc 00 06 00 00 	cmp    $0x600,%r12
    1a02:	74 1a                	je     1a1e <pqcrystals_kyber768_ref_polyvec_add+0x37>
    1a04:	4b 8d 3c 27          	lea    (%r15,%r12,1),%rdi
    1a08:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    1a0c:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
    1a10:	e8 a1 fc ff ff       	call   16b6 <pqcrystals_kyber768_ref_poly_add>
    1a15:	49 81 c4 00 02 00 00 	add    $0x200,%r12
    1a1c:	eb dd                	jmp    19fb <pqcrystals_kyber768_ref_polyvec_add+0x14>
    1a1e:	48 83 c4 08          	add    $0x8,%rsp
    1a22:	5b                   	pop    %rbx
    1a23:	41 5c                	pop    %r12
    1a25:	41 5e                	pop    %r14
    1a27:	41 5f                	pop    %r15
    1a29:	c3                   	ret
    1a2a:	66 90                	xchg   %ax,%ax

0000000000001a2c <pqcrystals_kyber768_ref_ntt>:
    1a2c:	55                   	push   %rbp
    1a2d:	41 57                	push   %r15
    1a2f:	41 56                	push   %r14
    1a31:	41 55                	push   %r13
    1a33:	41 54                	push   %r12
    1a35:	53                   	push   %rbx
    1a36:	50                   	push   %rax
    1a37:	48 89 fb             	mov    %rdi,%rbx
    1a3a:	b9 80 00 00 00       	mov    $0x80,%ecx
    1a3f:	6a 01                	push   $0x1
    1a41:	58                   	pop    %rax
    1a42:	83 f9 02             	cmp    $0x2,%ecx
    1a45:	72 6d                	jb     1ab4 <pqcrystals_kyber768_ref_ntt+0x88>
    1a47:	41 89 cd             	mov    %ecx,%r13d
    1a4a:	45 31 f6             	xor    %r14d,%r14d
    1a4d:	89 0c 24             	mov    %ecx,(%rsp)
    1a50:	41 81 fe ff 00 00 00 	cmp    $0xff,%r14d
    1a57:	77 57                	ja     1ab0 <pqcrystals_kyber768_ref_ntt+0x84>
    1a59:	89 44 24 04          	mov    %eax,0x4(%rsp)
    1a5d:	89 c0                	mov    %eax,%eax
    1a5f:	45 89 f4             	mov    %r14d,%r12d
    1a62:	41 01 ce             	add    %ecx,%r14d
    1a65:	48 8d 0d c4 15 00 00 	lea    0x15c4(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1a6c:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1a70:	4d 39 f4             	cmp    %r14,%r12
    1a73:	73 2a                	jae    1a9f <pqcrystals_kyber768_ref_ntt+0x73>
    1a75:	47 8d 3c 2c          	lea    (%r12,%r13,1),%r15d
    1a79:	42 0f bf 34 7b       	movswl (%rbx,%r15,2),%esi
    1a7e:	89 ef                	mov    %ebp,%edi
    1a80:	e8 3e 00 00 00       	call   1ac3 <fqmul>
    1a85:	42 0f b7 0c 63       	movzwl (%rbx,%r12,2),%ecx
    1a8a:	89 ca                	mov    %ecx,%edx
    1a8c:	29 c2                	sub    %eax,%edx
    1a8e:	66 42 89 14 7b       	mov    %dx,(%rbx,%r15,2)
    1a93:	01 c1                	add    %eax,%ecx
    1a95:	66 42 89 0c 63       	mov    %cx,(%rbx,%r12,2)
    1a9a:	49 ff c4             	inc    %r12
    1a9d:	eb d1                	jmp    1a70 <pqcrystals_kyber768_ref_ntt+0x44>
    1a9f:	8b 44 24 04          	mov    0x4(%rsp),%eax
    1aa3:	ff c0                	inc    %eax
    1aa5:	45 01 ec             	add    %r13d,%r12d
    1aa8:	45 89 e6             	mov    %r12d,%r14d
    1aab:	8b 0c 24             	mov    (%rsp),%ecx
    1aae:	eb a0                	jmp    1a50 <pqcrystals_kyber768_ref_ntt+0x24>
    1ab0:	d1 e9                	shr    $1,%ecx
    1ab2:	eb 8e                	jmp    1a42 <pqcrystals_kyber768_ref_ntt+0x16>
    1ab4:	48 83 c4 08          	add    $0x8,%rsp
    1ab8:	5b                   	pop    %rbx
    1ab9:	41 5c                	pop    %r12
    1abb:	41 5d                	pop    %r13
    1abd:	41 5e                	pop    %r14
    1abf:	41 5f                	pop    %r15
    1ac1:	5d                   	pop    %rbp
    1ac2:	c3                   	ret

0000000000001ac3 <fqmul>:
    1ac3:	0f af fe             	imul   %esi,%edi
    1ac6:	e9 b9 01 00 00       	jmp    1c84 <pqcrystals_kyber768_ref_montgomery_reduce>

0000000000001acb <pqcrystals_kyber768_ref_invntt>:
    1acb:	55                   	push   %rbp
    1acc:	41 57                	push   %r15
    1ace:	41 56                	push   %r14
    1ad0:	41 55                	push   %r13
    1ad2:	41 54                	push   %r12
    1ad4:	53                   	push   %rbx
    1ad5:	48 83 ec 18          	sub    $0x18,%rsp
    1ad9:	48 89 fb             	mov    %rdi,%rbx
    1adc:	6a 02                	push   $0x2
    1ade:	59                   	pop    %rcx
    1adf:	6a 7f                	push   $0x7f
    1ae1:	58                   	pop    %rax
    1ae2:	81 f9 81 00 00 00    	cmp    $0x81,%ecx
    1ae8:	0f 83 8e 00 00 00    	jae    1b7c <pqcrystals_kyber768_ref_invntt+0xb1>
    1aee:	89 ca                	mov    %ecx,%edx
    1af0:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    1af5:	4c 8d 24 53          	lea    (%rbx,%rdx,2),%r12
    1af9:	45 31 ed             	xor    %r13d,%r13d
    1afc:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
    1b00:	41 81 fd ff 00 00 00 	cmp    $0xff,%r13d
    1b07:	77 6c                	ja     1b75 <pqcrystals_kyber768_ref_invntt+0xaa>
    1b09:	89 44 24 0c          	mov    %eax,0xc(%rsp)
    1b0d:	89 c0                	mov    %eax,%eax
    1b0f:	45 89 ee             	mov    %r13d,%r14d
    1b12:	41 01 cd             	add    %ecx,%r13d
    1b15:	48 8d 0d 14 15 00 00 	lea    0x1514(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1b1c:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1b20:	4d 39 ee             	cmp    %r13,%r14
    1b23:	73 3c                	jae    1b61 <pqcrystals_kyber768_ref_invntt+0x96>
    1b25:	46 0f b7 3c 73       	movzwl (%rbx,%r14,2),%r15d
    1b2a:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1b2f:	66 44 01 f8          	add    %r15w,%ax
    1b33:	0f bf f8             	movswl %ax,%edi
    1b36:	e8 5e 01 00 00       	call   1c99 <pqcrystals_kyber768_ref_barrett_reduce>
    1b3b:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1b40:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1b45:	44 29 f8             	sub    %r15d,%eax
    1b48:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1b4d:	0f bf f0             	movswl %ax,%esi
    1b50:	89 ef                	mov    %ebp,%edi
    1b52:	e8 6c ff ff ff       	call   1ac3 <fqmul>
    1b57:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1b5c:	49 ff c6             	inc    %r14
    1b5f:	eb bf                	jmp    1b20 <pqcrystals_kyber768_ref_invntt+0x55>
    1b61:	8b 44 24 0c          	mov    0xc(%rsp),%eax
    1b65:	ff c8                	dec    %eax
    1b67:	44 03 74 24 10       	add    0x10(%rsp),%r14d
    1b6c:	45 89 f5             	mov    %r14d,%r13d
    1b6f:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
    1b73:	eb 8b                	jmp    1b00 <pqcrystals_kyber768_ref_invntt+0x35>
    1b75:	01 c9                	add    %ecx,%ecx
    1b77:	e9 66 ff ff ff       	jmp    1ae2 <pqcrystals_kyber768_ref_invntt+0x17>
    1b7c:	45 31 f6             	xor    %r14d,%r14d
    1b7f:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    1b86:	74 19                	je     1ba1 <pqcrystals_kyber768_ref_invntt+0xd6>
    1b88:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    1b8d:	be a1 05 00 00       	mov    $0x5a1,%esi
    1b92:	e8 2c ff ff ff       	call   1ac3 <fqmul>
    1b97:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1b9c:	49 ff c6             	inc    %r14
    1b9f:	eb de                	jmp    1b7f <pqcrystals_kyber768_ref_invntt+0xb4>
    1ba1:	48 83 c4 18          	add    $0x18,%rsp
    1ba5:	5b                   	pop    %rbx
    1ba6:	41 5c                	pop    %r12
    1ba8:	41 5d                	pop    %r13
    1baa:	41 5e                	pop    %r14
    1bac:	41 5f                	pop    %r15
    1bae:	5d                   	pop    %rbp
    1baf:	c3                   	ret

0000000000001bb0 <pqcrystals_kyber768_ref_basemul>:
    1bb0:	55                   	push   %rbp
    1bb1:	41 57                	push   %r15
    1bb3:	41 56                	push   %r14
    1bb5:	53                   	push   %rbx
    1bb6:	50                   	push   %rax
    1bb7:	89 cd                	mov    %ecx,%ebp
    1bb9:	49 89 d6             	mov    %rdx,%r14
    1bbc:	49 89 f7             	mov    %rsi,%r15
    1bbf:	48 89 fb             	mov    %rdi,%rbx
    1bc2:	0f bf 7e 02          	movswl 0x2(%rsi),%edi
    1bc6:	0f bf 72 02          	movswl 0x2(%rdx),%esi
    1bca:	e8 f4 fe ff ff       	call   1ac3 <fqmul>
    1bcf:	66 89 03             	mov    %ax,(%rbx)
    1bd2:	0f bf f8             	movswl %ax,%edi
    1bd5:	89 ee                	mov    %ebp,%esi
    1bd7:	e8 e7 fe ff ff       	call   1ac3 <fqmul>
    1bdc:	66 89 03             	mov    %ax,(%rbx)
    1bdf:	41 0f bf 3f          	movswl (%r15),%edi
    1be3:	41 0f bf 36          	movswl (%r14),%esi
    1be7:	e8 d7 fe ff ff       	call   1ac3 <fqmul>
    1bec:	66 01 03             	add    %ax,(%rbx)
    1bef:	41 0f bf 3f          	movswl (%r15),%edi
    1bf3:	41 0f bf 76 02       	movswl 0x2(%r14),%esi
    1bf8:	e8 c6 fe ff ff       	call   1ac3 <fqmul>
    1bfd:	66 89 43 02          	mov    %ax,0x2(%rbx)
    1c01:	41 0f bf 7f 02       	movswl 0x2(%r15),%edi
    1c06:	41 0f bf 36          	movswl (%r14),%esi
    1c0a:	e8 b4 fe ff ff       	call   1ac3 <fqmul>
    1c0f:	66 01 43 02          	add    %ax,0x2(%rbx)
    1c13:	48 83 c4 08          	add    $0x8,%rsp
    1c17:	5b                   	pop    %rbx
    1c18:	41 5e                	pop    %r14
    1c1a:	41 5f                	pop    %r15
    1c1c:	5d                   	pop    %rbp
    1c1d:	c3                   	ret
    1c1e:	66 90                	xchg   %ax,%ax

0000000000001c20 <pqcrystals_kyber768_ref_poly_cbd_eta1>:
    1c20:	eb 00                	jmp    1c22 <cbd2>

0000000000001c22 <cbd2>:
    1c22:	53                   	push   %rbx
    1c23:	31 d2                	xor    %edx,%edx
    1c25:	41 b8 55 55 55 55    	mov    $0x55555555,%r8d
    1c2b:	48 83 fa 20          	cmp    $0x20,%rdx
    1c2f:	74 4f                	je     1c80 <cbd2+0x5e>
    1c31:	44 8b 0c 96          	mov    (%rsi,%rdx,4),%r9d
    1c35:	44 89 c8             	mov    %r9d,%eax
    1c38:	44 21 c0             	and    %r8d,%eax
    1c3b:	41 d1 e9             	shr    $1,%r9d
    1c3e:	45 21 c1             	and    %r8d,%r9d
    1c41:	41 01 c1             	add    %eax,%r9d
    1c44:	49 89 fa             	mov    %rdi,%r10
    1c47:	31 c0                	xor    %eax,%eax
    1c49:	48 83 f8 20          	cmp    $0x20,%rax
    1c4d:	74 28                	je     1c77 <cbd2+0x55>
    1c4f:	45 89 cb             	mov    %r9d,%r11d
    1c52:	89 c1                	mov    %eax,%ecx
    1c54:	41 d3 eb             	shr    %cl,%r11d
    1c57:	41 83 e3 03          	and    $0x3,%r11d
    1c5b:	8d 48 02             	lea    0x2(%rax),%ecx
    1c5e:	44 89 cb             	mov    %r9d,%ebx
    1c61:	d3 eb                	shr    %cl,%ebx
    1c63:	83 e3 03             	and    $0x3,%ebx
    1c66:	41 29 db             	sub    %ebx,%r11d
    1c69:	66 45 89 1a          	mov    %r11w,(%r10)
    1c6d:	48 83 c0 04          	add    $0x4,%rax
    1c71:	49 83 c2 02          	add    $0x2,%r10
    1c75:	eb d2                	jmp    1c49 <cbd2+0x27>
    1c77:	48 ff c2             	inc    %rdx
    1c7a:	48 83 c7 10          	add    $0x10,%rdi
    1c7e:	eb ab                	jmp    1c2b <cbd2+0x9>
    1c80:	5b                   	pop    %rbx
    1c81:	c3                   	ret

0000000000001c82 <pqcrystals_kyber768_ref_poly_cbd_eta2>:
    1c82:	eb 9e                	jmp    1c22 <cbd2>

0000000000001c84 <pqcrystals_kyber768_ref_montgomery_reduce>:
    1c84:	69 c7 00 00 01 f3    	imul   $0xf3010000,%edi,%eax
    1c8a:	c1 f8 10             	sar    $0x10,%eax
    1c8d:	69 c0 ff f2 ff ff    	imul   $0xfffff2ff,%eax,%eax
    1c93:	01 f8                	add    %edi,%eax
    1c95:	c1 e8 10             	shr    $0x10,%eax
    1c98:	c3                   	ret

0000000000001c99 <pqcrystals_kyber768_ref_barrett_reduce>:
    1c99:	89 f8                	mov    %edi,%eax
    1c9b:	69 cf bf 4e 00 00    	imul   $0x4ebf,%edi,%ecx
    1ca1:	81 c1 00 00 00 02    	add    $0x2000000,%ecx
    1ca7:	c1 f9 1a             	sar    $0x1a,%ecx
    1caa:	69 c9 00 00 01 0d    	imul   $0xd010000,%ecx,%ecx
    1cb0:	c1 e9 10             	shr    $0x10,%ecx
    1cb3:	29 c8                	sub    %ecx,%eax
    1cb5:	c3                   	ret
    1cb6:	66 90                	xchg   %ax,%ax

0000000000001cb8 <pqcrystals_kyber768_ref_kyber_shake128_absorb>:
    1cb8:	48 83 ec 28          	sub    $0x28,%rsp
    1cbc:	0f 10 06             	movups (%rsi),%xmm0
    1cbf:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
    1cc3:	48 89 e6             	mov    %rsp,%rsi
    1cc6:	0f 29 4e 10          	movaps %xmm1,0x10(%rsi)
    1cca:	0f 29 06             	movaps %xmm0,(%rsi)
    1ccd:	88 56 20             	mov    %dl,0x20(%rsi)
    1cd0:	88 4e 21             	mov    %cl,0x21(%rsi)
    1cd3:	6a 22                	push   $0x22
    1cd5:	5a                   	pop    %rdx
    1cd6:	e8 d0 01 00 00       	call   1eab <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    1cdb:	48 83 c4 28          	add    $0x28,%rsp
    1cdf:	c3                   	ret

0000000000001ce0 <pqcrystals_kyber768_ref_kyber_shake256_prf>:
    1ce0:	48 83 ec 28          	sub    $0x28,%rsp
    1ce4:	0f 10 02             	movups (%rdx),%xmm0
    1ce7:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
    1ceb:	48 89 e2             	mov    %rsp,%rdx
    1cee:	0f 29 4a 10          	movaps %xmm1,0x10(%rdx)
    1cf2:	0f 29 02             	movaps %xmm0,(%rdx)
    1cf5:	88 4a 20             	mov    %cl,0x20(%rdx)
    1cf8:	6a 21                	push   $0x21
    1cfa:	59                   	pop    %rcx
    1cfb:	e8 22 04 00 00       	call   2122 <pqcrystals_kyber_fips202_ref_shake256>
    1d00:	48 83 c4 28          	add    $0x28,%rsp
    1d04:	c3                   	ret
    1d05:	0f 1f 00             	nopl   (%rax)

0000000000001d08 <pqcrystals_kyber_fips202_ref_shake128_init>:
    1d08:	53                   	push   %rbx
    1d09:	48 89 fb             	mov    %rdi,%rbx
    1d0c:	e8 09 00 00 00       	call   1d1a <keccak_init>
    1d11:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    1d18:	5b                   	pop    %rbx
    1d19:	c3                   	ret

0000000000001d1a <keccak_init>:
    1d1a:	31 c0                	xor    %eax,%eax
    1d1c:	48 83 f8 19          	cmp    $0x19,%rax
    1d20:	74 0a                	je     1d2c <keccak_init+0x12>
    1d22:	48 83 24 c7 00       	andq   $0x0,(%rdi,%rax,8)
    1d27:	48 ff c0             	inc    %rax
    1d2a:	eb f0                	jmp    1d1c <keccak_init+0x2>
    1d2c:	c3                   	ret

0000000000001d2d <pqcrystals_kyber_fips202_ref_shake128_absorb>:
    1d2d:	53                   	push   %rbx
    1d2e:	49 89 d0             	mov    %rdx,%r8
    1d31:	48 89 f1             	mov    %rsi,%rcx
    1d34:	48 89 fb             	mov    %rdi,%rbx
    1d37:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    1d3d:	ba a8 00 00 00       	mov    $0xa8,%edx
    1d42:	e8 08 00 00 00       	call   1d4f <keccak_absorb>
    1d47:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    1d4d:	5b                   	pop    %rbx
    1d4e:	c3                   	ret

0000000000001d4f <keccak_absorb>:
    1d4f:	55                   	push   %rbp
    1d50:	41 57                	push   %r15
    1d52:	41 56                	push   %r14
    1d54:	41 54                	push   %r12
    1d56:	53                   	push   %rbx
    1d57:	4d 89 c7             	mov    %r8,%r15
    1d5a:	48 89 cb             	mov    %rcx,%rbx
    1d5d:	89 d5                	mov    %edx,%ebp
    1d5f:	89 f0                	mov    %esi,%eax
    1d61:	49 89 fe             	mov    %rdi,%r14
    1d64:	41 89 d4             	mov    %edx,%r12d
    1d67:	89 c2                	mov    %eax,%edx
    1d69:	4c 01 fa             	add    %r15,%rdx
    1d6c:	4c 39 e2             	cmp    %r12,%rdx
    1d6f:	72 3e                	jb     1daf <keccak_absorb+0x60>
    1d71:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
    1d78:	89 c6                	mov    %eax,%esi
    1d7a:	39 ee                	cmp    %ebp,%esi
    1d7c:	73 1e                	jae    1d9c <keccak_absorb+0x4d>
    1d7e:	0f b6 3b             	movzbl (%rbx),%edi
    1d81:	89 d1                	mov    %edx,%ecx
    1d83:	80 e1 38             	and    $0x38,%cl
    1d86:	48 d3 e7             	shl    %cl,%rdi
    1d89:	89 f1                	mov    %esi,%ecx
    1d8b:	83 e1 f8             	and    $0xfffffff8,%ecx
    1d8e:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    1d92:	48 ff c3             	inc    %rbx
    1d95:	ff c6                	inc    %esi
    1d97:	83 c2 08             	add    $0x8,%edx
    1d9a:	eb de                	jmp    1d7a <keccak_absorb+0x2b>
    1d9c:	89 e9                	mov    %ebp,%ecx
    1d9e:	29 c1                	sub    %eax,%ecx
    1da0:	49 29 cf             	sub    %rcx,%r15
    1da3:	4c 89 f7             	mov    %r14,%rdi
    1da6:	e8 39 04 00 00       	call   21e4 <KeccakF1600_StatePermute>
    1dab:	31 c0                	xor    %eax,%eax
    1dad:	eb b8                	jmp    1d67 <keccak_absorb+0x18>
    1daf:	8d 34 c5 00 00 00 00 	lea    0x0(,%rax,8),%esi
    1db6:	89 c1                	mov    %eax,%ecx
    1db8:	48 39 ca             	cmp    %rcx,%rdx
    1dbb:	76 1e                	jbe    1ddb <keccak_absorb+0x8c>
    1dbd:	0f b6 3b             	movzbl (%rbx),%edi
    1dc0:	89 f1                	mov    %esi,%ecx
    1dc2:	80 e1 38             	and    $0x38,%cl
    1dc5:	48 d3 e7             	shl    %cl,%rdi
    1dc8:	89 c1                	mov    %eax,%ecx
    1dca:	83 e1 f8             	and    $0xfffffff8,%ecx
    1dcd:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    1dd1:	48 ff c3             	inc    %rbx
    1dd4:	ff c0                	inc    %eax
    1dd6:	83 c6 08             	add    $0x8,%esi
    1dd9:	eb db                	jmp    1db6 <keccak_absorb+0x67>
    1ddb:	5b                   	pop    %rbx
    1ddc:	41 5c                	pop    %r12
    1dde:	41 5e                	pop    %r14
    1de0:	41 5f                	pop    %r15
    1de2:	5d                   	pop    %rbp
    1de3:	c3                   	ret

0000000000001de4 <pqcrystals_kyber_fips202_ref_shake128_finalize>:
    1de4:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    1dea:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    1df1:	6a 1f                	push   $0x1f
    1df3:	5a                   	pop    %rdx
    1df4:	48 d3 e2             	shl    %cl,%rdx
    1df7:	83 e0 f8             	and    $0xfffffff8,%eax
    1dfa:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    1dfe:	80 b7 a7 00 00 00 80 	xorb   $0x80,0xa7(%rdi)
    1e05:	c7 87 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rdi)
    1e0c:	00 00 00 
    1e0f:	c3                   	ret

0000000000001e10 <pqcrystals_kyber_fips202_ref_shake128_squeeze>:
    1e10:	53                   	push   %rbx
    1e11:	48 89 d3             	mov    %rdx,%rbx
    1e14:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    1e1a:	41 b8 a8 00 00 00    	mov    $0xa8,%r8d
    1e20:	e8 08 00 00 00       	call   1e2d <keccak_squeeze>
    1e25:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    1e2b:	5b                   	pop    %rbx
    1e2c:	c3                   	ret

0000000000001e2d <keccak_squeeze>:
    1e2d:	41 57                	push   %r15
    1e2f:	41 56                	push   %r14
    1e31:	41 55                	push   %r13
    1e33:	41 54                	push   %r12
    1e35:	53                   	push   %rbx
    1e36:	44 89 c3             	mov    %r8d,%ebx
    1e39:	89 c8                	mov    %ecx,%eax
    1e3b:	49 89 d6             	mov    %rdx,%r14
    1e3e:	49 89 f7             	mov    %rsi,%r15
    1e41:	49 89 fc             	mov    %rdi,%r12
    1e44:	45 89 c5             	mov    %r8d,%r13d
    1e47:	4d 85 ff             	test   %r15,%r15
    1e4a:	74 55                	je     1ea1 <keccak_squeeze+0x74>
    1e4c:	39 d8                	cmp    %ebx,%eax
    1e4e:	75 0a                	jne    1e5a <keccak_squeeze+0x2d>
    1e50:	4c 89 f7             	mov    %r14,%rdi
    1e53:	e8 8c 03 00 00       	call   21e4 <KeccakF1600_StatePermute>
    1e58:	31 c0                	xor    %eax,%eax
    1e5a:	89 c0                	mov    %eax,%eax
    1e5c:	49 8d 34 07          	lea    (%r15,%rax,1),%rsi
    1e60:	49 39 f5             	cmp    %rsi,%r13
    1e63:	49 0f 42 f5          	cmovb  %r13,%rsi
    1e67:	48 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%rdi
    1e6e:	00 
    1e6f:	31 d2                	xor    %edx,%edx
    1e71:	48 39 f0             	cmp    %rsi,%rax
    1e74:	73 21                	jae    1e97 <keccak_squeeze+0x6a>
    1e76:	89 c1                	mov    %eax,%ecx
    1e78:	83 e1 f8             	and    $0xfffffff8,%ecx
    1e7b:	4d 8b 04 0e          	mov    (%r14,%rcx,1),%r8
    1e7f:	89 f9                	mov    %edi,%ecx
    1e81:	80 e1 38             	and    $0x38,%cl
    1e84:	49 d3 e8             	shr    %cl,%r8
    1e87:	45 88 04 14          	mov    %r8b,(%r12,%rdx,1)
    1e8b:	48 ff c0             	inc    %rax
    1e8e:	48 ff c2             	inc    %rdx
    1e91:	48 83 c7 08          	add    $0x8,%rdi
    1e95:	eb da                	jmp    1e71 <keccak_squeeze+0x44>
    1e97:	89 d1                	mov    %edx,%ecx
    1e99:	49 29 cf             	sub    %rcx,%r15
    1e9c:	49 01 d4             	add    %rdx,%r12
    1e9f:	eb a6                	jmp    1e47 <keccak_squeeze+0x1a>
    1ea1:	5b                   	pop    %rbx
    1ea2:	41 5c                	pop    %r12
    1ea4:	41 5d                	pop    %r13
    1ea6:	41 5e                	pop    %r14
    1ea8:	41 5f                	pop    %r15
    1eaa:	c3                   	ret

0000000000001eab <pqcrystals_kyber_fips202_ref_shake128_absorb_once>:
    1eab:	53                   	push   %rbx
    1eac:	48 89 d1             	mov    %rdx,%rcx
    1eaf:	48 89 f2             	mov    %rsi,%rdx
    1eb2:	48 89 fb             	mov    %rdi,%rbx
    1eb5:	6a 1f                	push   $0x1f
    1eb7:	41 58                	pop    %r8
    1eb9:	be a8 00 00 00       	mov    $0xa8,%esi
    1ebe:	e8 0c 00 00 00       	call   1ecf <keccak_absorb_once>
    1ec3:	c7 83 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rbx)
    1eca:	00 00 00 
    1ecd:	5b                   	pop    %rbx
    1ece:	c3                   	ret

0000000000001ecf <keccak_absorb_once>:
    1ecf:	55                   	push   %rbp
    1ed0:	41 57                	push   %r15
    1ed2:	41 56                	push   %r14
    1ed4:	41 55                	push   %r13
    1ed6:	41 54                	push   %r12
    1ed8:	53                   	push   %rbx
    1ed9:	50                   	push   %rax
    1eda:	44 89 44 24 04       	mov    %r8d,0x4(%rsp)
    1edf:	48 89 c8             	mov    %rcx,%rax
    1ee2:	49 89 d7             	mov    %rdx,%r15
    1ee5:	89 f3                	mov    %esi,%ebx
    1ee7:	49 89 fe             	mov    %rdi,%r14
    1eea:	31 c9                	xor    %ecx,%ecx
    1eec:	48 83 f9 19          	cmp    $0x19,%rcx
    1ef0:	74 0a                	je     1efc <keccak_absorb_once+0x2d>
    1ef2:	49 83 24 ce 00       	andq   $0x0,(%r14,%rcx,8)
    1ef7:	48 ff c1             	inc    %rcx
    1efa:	eb f0                	jmp    1eec <keccak_absorb_once+0x1d>
    1efc:	41 89 dc             	mov    %ebx,%r12d
    1eff:	41 89 dd             	mov    %ebx,%r13d
    1f02:	41 c1 ed 03          	shr    $0x3,%r13d
    1f06:	48 89 c5             	mov    %rax,%rbp
    1f09:	4c 29 e5             	sub    %r12,%rbp
    1f0c:	72 47                	jb     1f55 <keccak_absorb_once+0x86>
    1f0e:	4c 89 f8             	mov    %r15,%rax
    1f11:	31 d2                	xor    %edx,%edx
    1f13:	4c 39 ea             	cmp    %r13,%rdx
    1f16:	74 2d                	je     1f45 <keccak_absorb_once+0x76>
    1f18:	48 89 c6             	mov    %rax,%rsi
    1f1b:	31 c9                	xor    %ecx,%ecx
    1f1d:	31 ff                	xor    %edi,%edi
    1f1f:	48 83 f9 40          	cmp    $0x40,%rcx
    1f23:	74 13                	je     1f38 <keccak_absorb_once+0x69>
    1f25:	44 0f b6 06          	movzbl (%rsi),%r8d
    1f29:	49 d3 e0             	shl    %cl,%r8
    1f2c:	4c 09 c7             	or     %r8,%rdi
    1f2f:	48 83 c1 08          	add    $0x8,%rcx
    1f33:	48 ff c6             	inc    %rsi
    1f36:	eb e7                	jmp    1f1f <keccak_absorb_once+0x50>
    1f38:	49 31 3c d6          	xor    %rdi,(%r14,%rdx,8)
    1f3c:	48 ff c2             	inc    %rdx
    1f3f:	48 83 c0 08          	add    $0x8,%rax
    1f43:	eb ce                	jmp    1f13 <keccak_absorb_once+0x44>
    1f45:	4d 01 e7             	add    %r12,%r15
    1f48:	4c 89 f7             	mov    %r14,%rdi
    1f4b:	e8 94 02 00 00       	call   21e4 <KeccakF1600_StatePermute>
    1f50:	48 89 e8             	mov    %rbp,%rax
    1f53:	eb b4                	jmp    1f09 <keccak_absorb_once+0x3a>
    1f55:	31 d2                	xor    %edx,%edx
    1f57:	31 c9                	xor    %ecx,%ecx
    1f59:	89 ce                	mov    %ecx,%esi
    1f5b:	48 39 f0             	cmp    %rsi,%rax
    1f5e:	76 1e                	jbe    1f7e <keccak_absorb_once+0xaf>
    1f60:	41 0f b6 3c 37       	movzbl (%r15,%rsi,1),%edi
    1f65:	89 d1                	mov    %edx,%ecx
    1f67:	80 e1 38             	and    $0x38,%cl
    1f6a:	48 d3 e7             	shl    %cl,%rdi
    1f6d:	89 f1                	mov    %esi,%ecx
    1f6f:	83 e1 f8             	and    $0xfffffff8,%ecx
    1f72:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    1f76:	8d 4e 01             	lea    0x1(%rsi),%ecx
    1f79:	83 c2 08             	add    $0x8,%edx
    1f7c:	eb db                	jmp    1f59 <keccak_absorb_once+0x8a>
    1f7e:	0f b6 44 24 04       	movzbl 0x4(%rsp),%eax
    1f83:	80 e2 38             	and    $0x38,%dl
    1f86:	89 d1                	mov    %edx,%ecx
    1f88:	48 d3 e0             	shl    %cl,%rax
    1f8b:	83 e6 f8             	and    $0xfffffff8,%esi
    1f8e:	49 31 04 36          	xor    %rax,(%r14,%rsi,1)
    1f92:	ff cb                	dec    %ebx
    1f94:	83 e3 f8             	and    $0xfffffff8,%ebx
    1f97:	41 80 74 1e 07 80    	xorb   $0x80,0x7(%r14,%rbx,1)
    1f9d:	48 83 c4 08          	add    $0x8,%rsp
    1fa1:	5b                   	pop    %rbx
    1fa2:	41 5c                	pop    %r12
    1fa4:	41 5d                	pop    %r13
    1fa6:	41 5e                	pop    %r14
    1fa8:	41 5f                	pop    %r15
    1faa:	5d                   	pop    %rbp
    1fab:	c3                   	ret

0000000000001fac <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>:
    1fac:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    1fb1:	eb 00                	jmp    1fb3 <keccak_squeezeblocks>

0000000000001fb3 <keccak_squeezeblocks>:
    1fb3:	55                   	push   %rbp
    1fb4:	41 57                	push   %r15
    1fb6:	41 56                	push   %r14
    1fb8:	41 55                	push   %r13
    1fba:	41 54                	push   %r12
    1fbc:	53                   	push   %rbx
    1fbd:	50                   	push   %rax
    1fbe:	89 cb                	mov    %ecx,%ebx
    1fc0:	49 89 d6             	mov    %rdx,%r14
    1fc3:	49 89 f7             	mov    %rsi,%r15
    1fc6:	49 89 fc             	mov    %rdi,%r12
    1fc9:	41 89 cd             	mov    %ecx,%r13d
    1fcc:	83 e3 f8             	and    $0xfffffff8,%ebx
    1fcf:	49 83 ef 01          	sub    $0x1,%r15
    1fd3:	72 27                	jb     1ffc <keccak_squeezeblocks+0x49>
    1fd5:	4c 89 f7             	mov    %r14,%rdi
    1fd8:	e8 07 02 00 00       	call   21e4 <KeccakF1600_StatePermute>
    1fdd:	31 ed                	xor    %ebp,%ebp
    1fdf:	48 39 eb             	cmp    %rbp,%rbx
    1fe2:	74 13                	je     1ff7 <keccak_squeezeblocks+0x44>
    1fe4:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
    1fe8:	49 8b 34 2e          	mov    (%r14,%rbp,1),%rsi
    1fec:	e8 ac 0a 00 00       	call   2a9d <store64>
    1ff1:	48 83 c5 08          	add    $0x8,%rbp
    1ff5:	eb e8                	jmp    1fdf <keccak_squeezeblocks+0x2c>
    1ff7:	4d 01 ec             	add    %r13,%r12
    1ffa:	eb d3                	jmp    1fcf <keccak_squeezeblocks+0x1c>
    1ffc:	48 83 c4 08          	add    $0x8,%rsp
    2000:	5b                   	pop    %rbx
    2001:	41 5c                	pop    %r12
    2003:	41 5d                	pop    %r13
    2005:	41 5e                	pop    %r14
    2007:	41 5f                	pop    %r15
    2009:	5d                   	pop    %rbp
    200a:	c3                   	ret

000000000000200b <pqcrystals_kyber_fips202_ref_shake256_init>:
    200b:	53                   	push   %rbx
    200c:	48 89 fb             	mov    %rdi,%rbx
    200f:	e8 06 fd ff ff       	call   1d1a <keccak_init>
    2014:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    201b:	5b                   	pop    %rbx
    201c:	c3                   	ret

000000000000201d <pqcrystals_kyber_fips202_ref_shake256_absorb>:
    201d:	53                   	push   %rbx
    201e:	49 89 d0             	mov    %rdx,%r8
    2021:	48 89 f1             	mov    %rsi,%rcx
    2024:	48 89 fb             	mov    %rdi,%rbx
    2027:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    202d:	ba 88 00 00 00       	mov    $0x88,%edx
    2032:	e8 18 fd ff ff       	call   1d4f <keccak_absorb>
    2037:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    203d:	5b                   	pop    %rbx
    203e:	c3                   	ret

000000000000203f <pqcrystals_kyber_fips202_ref_shake256_finalize>:
    203f:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    2045:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    204c:	6a 1f                	push   $0x1f
    204e:	5a                   	pop    %rdx
    204f:	48 d3 e2             	shl    %cl,%rdx
    2052:	83 e0 f8             	and    $0xfffffff8,%eax
    2055:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    2059:	80 b7 87 00 00 00 80 	xorb   $0x80,0x87(%rdi)
    2060:	c7 87 c8 00 00 00 88 	movl   $0x88,0xc8(%rdi)
    2067:	00 00 00 
    206a:	c3                   	ret

000000000000206b <pqcrystals_kyber_fips202_ref_shake256_squeeze>:
    206b:	53                   	push   %rbx
    206c:	48 89 d3             	mov    %rdx,%rbx
    206f:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    2075:	41 b8 88 00 00 00    	mov    $0x88,%r8d
    207b:	e8 ad fd ff ff       	call   1e2d <keccak_squeeze>
    2080:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    2086:	5b                   	pop    %rbx
    2087:	c3                   	ret

0000000000002088 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>:
    2088:	53                   	push   %rbx
    2089:	48 89 d1             	mov    %rdx,%rcx
    208c:	48 89 f2             	mov    %rsi,%rdx
    208f:	48 89 fb             	mov    %rdi,%rbx
    2092:	6a 1f                	push   $0x1f
    2094:	41 58                	pop    %r8
    2096:	be 88 00 00 00       	mov    $0x88,%esi
    209b:	e8 2f fe ff ff       	call   1ecf <keccak_absorb_once>
    20a0:	c7 83 c8 00 00 00 88 	movl   $0x88,0xc8(%rbx)
    20a7:	00 00 00 
    20aa:	5b                   	pop    %rbx
    20ab:	c3                   	ret

00000000000020ac <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>:
    20ac:	b9 88 00 00 00       	mov    $0x88,%ecx
    20b1:	e9 fd fe ff ff       	jmp    1fb3 <keccak_squeezeblocks>

00000000000020b6 <pqcrystals_kyber_fips202_ref_shake128>:
    20b6:	41 57                	push   %r15
    20b8:	41 56                	push   %r14
    20ba:	41 54                	push   %r12
    20bc:	53                   	push   %rbx
    20bd:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    20c4:	48 89 f3             	mov    %rsi,%rbx
    20c7:	49 89 fe             	mov    %rdi,%r14
    20ca:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    20cf:	4c 89 ff             	mov    %r15,%rdi
    20d2:	48 89 d6             	mov    %rdx,%rsi
    20d5:	48 89 ca             	mov    %rcx,%rdx
    20d8:	e8 ce fd ff ff       	call   1eab <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    20dd:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    20e2:	48 89 d8             	mov    %rbx,%rax
    20e5:	31 d2                	xor    %edx,%edx
    20e7:	48 f7 f1             	div    %rcx
    20ea:	48 89 d3             	mov    %rdx,%rbx
    20ed:	49 89 c4             	mov    %rax,%r12
    20f0:	4c 89 f7             	mov    %r14,%rdi
    20f3:	48 89 c6             	mov    %rax,%rsi
    20f6:	4c 89 fa             	mov    %r15,%rdx
    20f9:	e8 ae fe ff ff       	call   1fac <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>
    20fe:	49 69 fc a8 00 00 00 	imul   $0xa8,%r12,%rdi
    2105:	4c 01 f7             	add    %r14,%rdi
    2108:	48 89 de             	mov    %rbx,%rsi
    210b:	4c 89 fa             	mov    %r15,%rdx
    210e:	e8 fd fc ff ff       	call   1e10 <pqcrystals_kyber_fips202_ref_shake128_squeeze>
    2113:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    211a:	5b                   	pop    %rbx
    211b:	41 5c                	pop    %r12
    211d:	41 5e                	pop    %r14
    211f:	41 5f                	pop    %r15
    2121:	c3                   	ret

0000000000002122 <pqcrystals_kyber_fips202_ref_shake256>:
    2122:	41 57                	push   %r15
    2124:	41 56                	push   %r14
    2126:	41 54                	push   %r12
    2128:	53                   	push   %rbx
    2129:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    2130:	48 89 f3             	mov    %rsi,%rbx
    2133:	49 89 fe             	mov    %rdi,%r14
    2136:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    213b:	4c 89 ff             	mov    %r15,%rdi
    213e:	48 89 d6             	mov    %rdx,%rsi
    2141:	48 89 ca             	mov    %rcx,%rdx
    2144:	e8 3f ff ff ff       	call   2088 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>
    2149:	b9 88 00 00 00       	mov    $0x88,%ecx
    214e:	48 89 d8             	mov    %rbx,%rax
    2151:	31 d2                	xor    %edx,%edx
    2153:	48 f7 f1             	div    %rcx
    2156:	48 89 d3             	mov    %rdx,%rbx
    2159:	49 89 c4             	mov    %rax,%r12
    215c:	4c 89 f7             	mov    %r14,%rdi
    215f:	48 89 c6             	mov    %rax,%rsi
    2162:	4c 89 fa             	mov    %r15,%rdx
    2165:	e8 42 ff ff ff       	call   20ac <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>
    216a:	49 69 fc 88 00 00 00 	imul   $0x88,%r12,%rdi
    2171:	4c 01 f7             	add    %r14,%rdi
    2174:	48 89 de             	mov    %rbx,%rsi
    2177:	4c 89 fa             	mov    %r15,%rdx
    217a:	e8 ec fe ff ff       	call   206b <pqcrystals_kyber_fips202_ref_shake256_squeeze>
    217f:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    2186:	5b                   	pop    %rbx
    2187:	41 5c                	pop    %r12
    2189:	41 5e                	pop    %r14
    218b:	41 5f                	pop    %r15
    218d:	c3                   	ret

000000000000218e <pqcrystals_kyber_fips202_ref_sha3_256>:
    218e:	41 56                	push   %r14
    2190:	53                   	push   %rbx
    2191:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    2198:	48 89 d1             	mov    %rdx,%rcx
    219b:	48 89 f2             	mov    %rsi,%rdx
    219e:	48 89 fb             	mov    %rdi,%rbx
    21a1:	49 89 e6             	mov    %rsp,%r14
    21a4:	6a 06                	push   $0x6
    21a6:	41 58                	pop    %r8
    21a8:	4c 89 f7             	mov    %r14,%rdi
    21ab:	be 88 00 00 00       	mov    $0x88,%esi
    21b0:	e8 1a fd ff ff       	call   1ecf <keccak_absorb_once>
    21b5:	4c 89 f7             	mov    %r14,%rdi
    21b8:	e8 27 00 00 00       	call   21e4 <KeccakF1600_StatePermute>
    21bd:	45 31 f6             	xor    %r14d,%r14d
    21c0:	49 83 fe 20          	cmp    $0x20,%r14
    21c4:	74 13                	je     21d9 <pqcrystals_kyber_fips202_ref_sha3_256+0x4b>
    21c6:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    21ca:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    21ce:	e8 ca 08 00 00       	call   2a9d <store64>
    21d3:	49 83 c6 08          	add    $0x8,%r14
    21d7:	eb e7                	jmp    21c0 <pqcrystals_kyber_fips202_ref_sha3_256+0x32>
    21d9:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    21e0:	5b                   	pop    %rbx
    21e1:	41 5e                	pop    %r14
    21e3:	c3                   	ret

00000000000021e4 <KeccakF1600_StatePermute>:
    21e4:	55                   	push   %rbp
    21e5:	41 57                	push   %r15
    21e7:	41 56                	push   %r14
    21e9:	41 55                	push   %r13
    21eb:	41 54                	push   %r12
    21ed:	53                   	push   %rbx
    21ee:	48 83 ec 68          	sub    $0x68,%rsp
    21f2:	48 8b 07             	mov    (%rdi),%rax
    21f5:	48 89 44 24 80       	mov    %rax,-0x80(%rsp)
    21fa:	48 8b 6f 08          	mov    0x8(%rdi),%rbp
    21fe:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2202:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    2207:	48 8b 47 18          	mov    0x18(%rdi),%rax
    220b:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    2210:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    2214:	48 8b 47 28          	mov    0x28(%rdi),%rax
    2218:	48 89 04 24          	mov    %rax,(%rsp)
    221c:	48 8b 47 30          	mov    0x30(%rdi),%rax
    2220:	48 89 44 24 98       	mov    %rax,-0x68(%rsp)
    2225:	48 8b 47 38          	mov    0x38(%rdi),%rax
    2229:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    222e:	48 8b 47 40          	mov    0x40(%rdi),%rax
    2232:	48 89 44 24 f8       	mov    %rax,-0x8(%rsp)
    2237:	4c 8b 7f 48          	mov    0x48(%rdi),%r15
    223b:	48 8b 47 50          	mov    0x50(%rdi),%rax
    223f:	48 89 44 24 90       	mov    %rax,-0x70(%rsp)
    2244:	48 8b 47 58          	mov    0x58(%rdi),%rax
    2248:	48 89 44 24 f0       	mov    %rax,-0x10(%rsp)
    224d:	48 8b 47 60          	mov    0x60(%rdi),%rax
    2251:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    2256:	48 8b 47 68          	mov    0x68(%rdi),%rax
    225a:	48 89 44 24 a0       	mov    %rax,-0x60(%rsp)
    225f:	4c 8b 77 70          	mov    0x70(%rdi),%r14
    2263:	48 8b 47 78          	mov    0x78(%rdi),%rax
    2267:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    226c:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
    2273:	48 89 44 24 88       	mov    %rax,-0x78(%rsp)
    2278:	48 8b 87 88 00 00 00 	mov    0x88(%rdi),%rax
    227f:	48 89 44 24 c8       	mov    %rax,-0x38(%rsp)
    2284:	4c 8b a7 90 00 00 00 	mov    0x90(%rdi),%r12
    228b:	4c 8b 87 98 00 00 00 	mov    0x98(%rdi),%r8
    2292:	4c 8b af a0 00 00 00 	mov    0xa0(%rdi),%r13
    2299:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    22a0:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    22a7:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    22ae:	48 89 4c 24 c0       	mov    %rcx,-0x40(%rsp)
    22b3:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    22b8:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    22bf:	48 89 4c 24 b0       	mov    %rcx,-0x50(%rsp)
    22c4:	31 c9                	xor    %ecx,%ecx
    22c6:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    22cb:	48 83 7c 24 10 17    	cmpq   $0x17,0x10(%rsp)
    22d1:	0f 87 e5 06 00 00    	ja     29bc <KeccakF1600_StatePermute+0x7d8>
    22d7:	48 8b 4c 24 d0       	mov    -0x30(%rsp),%rcx
    22dc:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    22e1:	4c 31 e9             	xor    %r13,%rcx
    22e4:	4c 89 d7             	mov    %r10,%rdi
    22e7:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    22ec:	4c 8b 54 24 90       	mov    -0x70(%rsp),%r10
    22f1:	4c 33 14 24          	xor    (%rsp),%r10
    22f5:	49 31 ca             	xor    %rcx,%r10
    22f8:	48 8b 4c 24 88       	mov    -0x78(%rsp),%rcx
    22fd:	48 31 f9             	xor    %rdi,%rcx
    2300:	4c 89 fb             	mov    %r15,%rbx
    2303:	4d 89 f5             	mov    %r14,%r13
    2306:	4c 8b 74 24 f0       	mov    -0x10(%rsp),%r14
    230b:	4c 33 74 24 98       	xor    -0x68(%rsp),%r14
    2310:	49 31 ce             	xor    %rcx,%r14
    2313:	48 8b 4c 24 c8       	mov    -0x38(%rsp),%rcx
    2318:	48 31 c1             	xor    %rax,%rcx
    231b:	49 89 d7             	mov    %rdx,%r15
    231e:	4d 89 c3             	mov    %r8,%r11
    2321:	4c 89 44 24 e0       	mov    %r8,-0x20(%rsp)
    2326:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
    232b:	4c 89 c2             	mov    %r8,%rdx
    232e:	48 33 54 24 a8       	xor    -0x58(%rsp),%rdx
    2333:	48 31 ca             	xor    %rcx,%rdx
    2336:	48 89 6c 24 d8       	mov    %rbp,-0x28(%rsp)
    233b:	4d 89 e1             	mov    %r12,%r9
    233e:	4c 33 4c 24 c0       	xor    -0x40(%rsp),%r9
    2343:	48 8b 4c 24 a0       	mov    -0x60(%rsp),%rcx
    2348:	48 33 4c 24 f8       	xor    -0x8(%rsp),%rcx
    234d:	4c 31 c9             	xor    %r9,%rcx
    2350:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    2355:	49 31 fb             	xor    %rdi,%r11
    2358:	4d 89 e9             	mov    %r13,%r9
    235b:	49 31 d9             	xor    %rbx,%r9
    235e:	48 89 de             	mov    %rbx,%rsi
    2361:	4d 31 d9             	xor    %r11,%r9
    2364:	4c 33 54 24 80       	xor    -0x80(%rsp),%r10
    2369:	49 31 ee             	xor    %rbp,%r14
    236c:	48 33 54 24 08       	xor    0x8(%rsp),%rdx
    2371:	4c 8b 5c 24 b8       	mov    -0x48(%rsp),%r11
    2376:	4c 31 d9             	xor    %r11,%rcx
    2379:	48 89 cd             	mov    %rcx,%rbp
    237c:	48 d1 c5             	rol    $1,%rbp
    237f:	4c 31 f5             	xor    %r14,%rbp
    2382:	49 d1 c6             	rol    $1,%r14
    2385:	4d 31 f9             	xor    %r15,%r9
    2388:	4d 31 ce             	xor    %r9,%r14
    238b:	49 d1 c1             	rol    $1,%r9
    238e:	49 31 d1             	xor    %rdx,%r9
    2391:	48 89 d3             	mov    %rdx,%rbx
    2394:	48 d1 c3             	rol    $1,%rbx
    2397:	4c 31 d3             	xor    %r10,%rbx
    239a:	49 d1 c2             	rol    $1,%r10
    239d:	49 31 ca             	xor    %rcx,%r10
    23a0:	4c 31 d7             	xor    %r10,%rdi
    23a3:	4c 31 d6             	xor    %r10,%rsi
    23a6:	48 89 74 24 b0       	mov    %rsi,-0x50(%rsp)
    23ab:	4c 31 54 24 e0       	xor    %r10,-0x20(%rsp)
    23b0:	4d 31 d7             	xor    %r10,%r15
    23b3:	4c 89 7c 24 e8       	mov    %r15,-0x18(%rsp)
    23b8:	4d 31 ea             	xor    %r13,%r10
    23bb:	4c 89 54 24 60       	mov    %r10,0x60(%rsp)
    23c0:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    23c5:	48 31 da             	xor    %rbx,%rdx
    23c8:	48 c1 c2 2c          	rol    $0x2c,%rdx
    23cc:	49 31 e8             	xor    %rbp,%r8
    23cf:	49 c1 c0 2b          	rol    $0x2b,%r8
    23d3:	4d 31 cc             	xor    %r9,%r12
    23d6:	49 c1 c4 15          	rol    $0x15,%r12
    23da:	48 c1 c7 0e          	rol    $0xe,%rdi
    23de:	4c 8b 7c 24 80       	mov    -0x80(%rsp),%r15
    23e3:	4d 31 f7             	xor    %r14,%r15
    23e6:	48 89 d6             	mov    %rdx,%rsi
    23e9:	48 f7 d6             	not    %rsi
    23ec:	4c 21 c6             	and    %r8,%rsi
    23ef:	4c 8d 15 3a 0d 00 00 	lea    0xd3a(%rip),%r10        # 3130 <KeccakF_RoundConstants>
    23f6:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
    23fb:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    2400:	49 33 34 ca          	xor    (%r10,%rcx,8),%rsi
    2404:	4c 89 e1             	mov    %r12,%rcx
    2407:	48 f7 d1             	not    %rcx
    240a:	48 21 f9             	and    %rdi,%rcx
    240d:	4c 31 c1             	xor    %r8,%rcx
    2410:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    2415:	49 f7 d0             	not    %r8
    2418:	4d 21 e0             	and    %r12,%r8
    241b:	48 89 f9             	mov    %rdi,%rcx
    241e:	48 f7 d1             	not    %rcx
    2421:	4c 21 f9             	and    %r15,%rcx
    2424:	4c 31 e1             	xor    %r12,%rcx
    2427:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    242c:	4c 31 fe             	xor    %r15,%rsi
    242f:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    2434:	49 31 d0             	xor    %rdx,%r8
    2437:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
    243c:	4d 31 cb             	xor    %r9,%r11
    243f:	49 c1 c3 1c          	rol    $0x1c,%r11
    2443:	48 89 f9             	mov    %rdi,%rcx
    2446:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
    244b:	48 c1 c6 14          	rol    $0x14,%rsi
    244f:	49 f7 d7             	not    %r15
    2452:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
    2457:	4c 31 f7             	xor    %r14,%rdi
    245a:	48 c1 c7 03          	rol    $0x3,%rdi
    245e:	49 21 d7             	and    %rdx,%r15
    2461:	4c 8b 44 24 88       	mov    -0x78(%rsp),%r8
    2466:	49 31 d8             	xor    %rbx,%r8
    2469:	49 c1 c0 2d          	rol    $0x2d,%r8
    246d:	49 31 cf             	xor    %rcx,%r15
    2470:	4c 89 7c 24 80       	mov    %r15,-0x80(%rsp)
    2475:	48 31 e8             	xor    %rbp,%rax
    2478:	48 c1 c0 3d          	rol    $0x3d,%rax
    247c:	48 89 f1             	mov    %rsi,%rcx
    247f:	49 89 f7             	mov    %rsi,%r15
    2482:	48 f7 d1             	not    %rcx
    2485:	48 21 f9             	and    %rdi,%rcx
    2488:	48 89 ce             	mov    %rcx,%rsi
    248b:	4c 89 c1             	mov    %r8,%rcx
    248e:	48 f7 d1             	not    %rcx
    2491:	48 21 c1             	and    %rax,%rcx
    2494:	48 31 f9             	xor    %rdi,%rcx
    2497:	48 89 4c 24 90       	mov    %rcx,-0x70(%rsp)
    249c:	48 89 fa             	mov    %rdi,%rdx
    249f:	48 f7 d2             	not    %rdx
    24a2:	4c 21 c2             	and    %r8,%rdx
    24a5:	48 89 c1             	mov    %rax,%rcx
    24a8:	48 f7 d1             	not    %rcx
    24ab:	4c 21 d9             	and    %r11,%rcx
    24ae:	4c 31 c1             	xor    %r8,%rcx
    24b1:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    24b6:	4c 31 de             	xor    %r11,%rsi
    24b9:	48 89 74 24 88       	mov    %rsi,-0x78(%rsp)
    24be:	4c 31 fa             	xor    %r15,%rdx
    24c1:	48 89 54 24 98       	mov    %rdx,-0x68(%rsp)
    24c6:	49 f7 d3             	not    %r11
    24c9:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    24ce:	48 31 de             	xor    %rbx,%rsi
    24d1:	48 d1 c6             	rol    $1,%rsi
    24d4:	4c 8b 44 24 a8       	mov    -0x58(%rsp),%r8
    24d9:	49 31 e8             	xor    %rbp,%r8
    24dc:	49 c1 c0 06          	rol    $0x6,%r8
    24e0:	4c 8b 64 24 a0       	mov    -0x60(%rsp),%r12
    24e5:	4d 31 cc             	xor    %r9,%r12
    24e8:	49 c1 c4 19          	rol    $0x19,%r12
    24ec:	48 8b 7c 24 e0       	mov    -0x20(%rsp),%rdi
    24f1:	48 c1 c7 08          	rol    $0x8,%rdi
    24f5:	4d 21 fb             	and    %r15,%r11
    24f8:	4d 31 f5             	xor    %r14,%r13
    24fb:	49 c1 c5 12          	rol    $0x12,%r13
    24ff:	49 31 c3             	xor    %rax,%r11
    2502:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    2507:	4c 89 c0             	mov    %r8,%rax
    250a:	48 f7 d0             	not    %rax
    250d:	4c 21 e0             	and    %r12,%rax
    2510:	48 89 c1             	mov    %rax,%rcx
    2513:	49 89 ff             	mov    %rdi,%r15
    2516:	49 f7 d7             	not    %r15
    2519:	4d 21 ef             	and    %r13,%r15
    251c:	4d 31 e7             	xor    %r12,%r15
    251f:	4c 89 e0             	mov    %r12,%rax
    2522:	48 f7 d0             	not    %rax
    2525:	48 21 f8             	and    %rdi,%rax
    2528:	49 89 fb             	mov    %rdi,%r11
    252b:	4c 89 ef             	mov    %r13,%rdi
    252e:	48 f7 d7             	not    %rdi
    2531:	48 21 f7             	and    %rsi,%rdi
    2534:	4c 31 df             	xor    %r11,%rdi
    2537:	48 89 7c 24 a0       	mov    %rdi,-0x60(%rsp)
    253c:	48 31 f1             	xor    %rsi,%rcx
    253f:	48 89 4c 24 a8       	mov    %rcx,-0x58(%rsp)
    2544:	4c 31 c0             	xor    %r8,%rax
    2547:	48 89 44 24 e0       	mov    %rax,-0x20(%rsp)
    254c:	48 f7 d6             	not    %rsi
    254f:	48 8b 7c 24 e8       	mov    -0x18(%rsp),%rdi
    2554:	48 c1 c7 1b          	rol    $0x1b,%rdi
    2558:	4c 21 c6             	and    %r8,%rsi
    255b:	48 8b 0c 24          	mov    (%rsp),%rcx
    255f:	4c 31 f1             	xor    %r14,%rcx
    2562:	48 c1 c1 24          	rol    $0x24,%rcx
    2566:	4c 31 ee             	xor    %r13,%rsi
    2569:	48 89 74 24 d8       	mov    %rsi,-0x28(%rsp)
    256e:	4c 8b 6c 24 f0       	mov    -0x10(%rsp),%r13
    2573:	49 31 dd             	xor    %rbx,%r13
    2576:	49 c1 c5 0a          	rol    $0xa,%r13
    257a:	4c 8b 44 24 c8       	mov    -0x38(%rsp),%r8
    257f:	49 31 e8             	xor    %rbp,%r8
    2582:	49 c1 c0 0f          	rol    $0xf,%r8
    2586:	4c 8b 64 24 c0       	mov    -0x40(%rsp),%r12
    258b:	4d 31 cc             	xor    %r9,%r12
    258e:	4c 89 ca             	mov    %r9,%rdx
    2591:	49 c1 c4 38          	rol    $0x38,%r12
    2595:	49 89 c9             	mov    %rcx,%r9
    2598:	49 f7 d1             	not    %r9
    259b:	4d 21 e9             	and    %r13,%r9
    259e:	4d 89 c3             	mov    %r8,%r11
    25a1:	49 f7 d3             	not    %r11
    25a4:	4d 21 e3             	and    %r12,%r11
    25a7:	4d 31 eb             	xor    %r13,%r11
    25aa:	4c 89 5c 24 c8       	mov    %r11,-0x38(%rsp)
    25af:	49 f7 d5             	not    %r13
    25b2:	4d 21 c5             	and    %r8,%r13
    25b5:	4c 89 e6             	mov    %r12,%rsi
    25b8:	48 f7 d6             	not    %rsi
    25bb:	48 21 fe             	and    %rdi,%rsi
    25be:	4c 31 c6             	xor    %r8,%rsi
    25c1:	49 31 f9             	xor    %rdi,%r9
    25c4:	4c 89 4c 24 c0       	mov    %r9,-0x40(%rsp)
    25c9:	49 31 cd             	xor    %rcx,%r13
    25cc:	48 f7 d7             	not    %rdi
    25cf:	48 21 cf             	and    %rcx,%rdi
    25d2:	4c 31 e7             	xor    %r12,%rdi
    25d5:	48 89 7c 24 e8       	mov    %rdi,-0x18(%rsp)
    25da:	48 33 6c 24 08       	xor    0x8(%rsp),%rbp
    25df:	48 89 d0             	mov    %rdx,%rax
    25e2:	48 33 44 24 f8       	xor    -0x8(%rsp),%rax
    25e7:	4c 33 74 24 d0       	xor    -0x30(%rsp),%r14
    25ec:	48 c1 c5 3e          	rol    $0x3e,%rbp
    25f0:	48 c1 c0 37          	rol    $0x37,%rax
    25f4:	4c 8b 54 24 60       	mov    0x60(%rsp),%r10
    25f9:	49 c1 c2 27          	rol    $0x27,%r10
    25fd:	49 c1 c6 29          	rol    $0x29,%r14
    2601:	48 33 5c 24 38       	xor    0x38(%rsp),%rbx
    2606:	48 c1 c3 02          	rol    $0x2,%rbx
    260a:	48 89 c7             	mov    %rax,%rdi
    260d:	48 89 c2             	mov    %rax,%rdx
    2610:	48 f7 d7             	not    %rdi
    2613:	4c 21 d7             	and    %r10,%rdi
    2616:	4c 89 d0             	mov    %r10,%rax
    2619:	4d 89 f4             	mov    %r14,%r12
    261c:	49 f7 d4             	not    %r12
    261f:	49 21 dc             	and    %rbx,%r12
    2622:	4d 31 d4             	xor    %r10,%r12
    2625:	48 f7 d0             	not    %rax
    2628:	4c 21 f0             	and    %r14,%rax
    262b:	49 89 da             	mov    %rbx,%r10
    262e:	49 f7 d2             	not    %r10
    2631:	49 21 ea             	and    %rbp,%r10
    2634:	4d 31 f2             	xor    %r14,%r10
    2637:	4d 89 d6             	mov    %r10,%r14
    263a:	4c 89 54 24 d0       	mov    %r10,-0x30(%rsp)
    263f:	48 31 ef             	xor    %rbp,%rdi
    2642:	48 31 d0             	xor    %rdx,%rax
    2645:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    264a:	48 f7 d5             	not    %rbp
    264d:	48 21 d5             	and    %rdx,%rbp
    2650:	48 31 dd             	xor    %rbx,%rbp
    2653:	4c 33 4c 24 a8       	xor    -0x58(%rsp),%r9
    2658:	4c 8b 54 24 88       	mov    -0x78(%rsp),%r10
    265d:	49 31 fa             	xor    %rdi,%r10
    2660:	4d 31 ca             	xor    %r9,%r10
    2663:	4c 8b 4c 24 98       	mov    -0x68(%rsp),%r9
    2668:	4c 33 4c 24 28       	xor    0x28(%rsp),%r9
    266d:	4c 89 ea             	mov    %r13,%rdx
    2670:	48 33 54 24 e0       	xor    -0x20(%rsp),%rdx
    2675:	4c 31 ca             	xor    %r9,%rdx
    2678:	4c 8b 4c 24 90       	mov    -0x70(%rsp),%r9
    267d:	4d 31 d9             	xor    %r11,%r9
    2680:	4c 89 e3             	mov    %r12,%rbx
    2683:	48 33 5c 24 50       	xor    0x50(%rsp),%rbx
    2688:	4c 31 cb             	xor    %r9,%rbx
    268b:	4c 8b 4c 24 a0       	mov    -0x60(%rsp),%r9
    2690:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    2695:	4d 89 f3             	mov    %r14,%r11
    2698:	4c 33 5c 24 20       	xor    0x20(%rsp),%r11
    269d:	4d 31 cb             	xor    %r9,%r11
    26a0:	4c 8b 74 24 80       	mov    -0x80(%rsp),%r14
    26a5:	49 31 ee             	xor    %rbp,%r14
    26a8:	4c 8b 4c 24 d8       	mov    -0x28(%rsp),%r9
    26ad:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    26b2:	49 31 c9             	xor    %rcx,%r9
    26b5:	4d 31 f1             	xor    %r14,%r9
    26b8:	4c 33 54 24 18       	xor    0x18(%rsp),%r10
    26bd:	48 31 c2             	xor    %rax,%rdx
    26c0:	4c 31 fb             	xor    %r15,%rbx
    26c3:	49 31 f3             	xor    %rsi,%r11
    26c6:	4c 33 4c 24 e8       	xor    -0x18(%rsp),%r9
    26cb:	4c 89 d8             	mov    %r11,%rax
    26ce:	48 d1 c0             	rol    $1,%rax
    26d1:	48 31 d0             	xor    %rdx,%rax
    26d4:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    26d9:	49 89 d6             	mov    %rdx,%r14
    26dc:	49 d1 c6             	rol    $1,%r14
    26df:	4d 31 ce             	xor    %r9,%r14
    26e2:	48 89 da             	mov    %rbx,%rdx
    26e5:	48 d1 c2             	rol    $1,%rdx
    26e8:	4c 31 d2             	xor    %r10,%rdx
    26eb:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    26f0:	49 d1 c1             	rol    $1,%r9
    26f3:	49 d1 c2             	rol    $1,%r10
    26f6:	49 31 d9             	xor    %rbx,%r9
    26f9:	4c 8b 44 24 98       	mov    -0x68(%rsp),%r8
    26fe:	49 31 d0             	xor    %rdx,%r8
    2701:	49 c1 c0 2c          	rol    $0x2c,%r8
    2705:	4d 31 da             	xor    %r11,%r10
    2708:	49 31 c7             	xor    %rax,%r15
    270b:	49 c1 c7 2b          	rol    $0x2b,%r15
    270f:	4c 31 d5             	xor    %r10,%rbp
    2712:	4c 31 d1             	xor    %r10,%rcx
    2715:	48 89 4c 24 b8       	mov    %rcx,-0x48(%rsp)
    271a:	4c 31 54 24 e8       	xor    %r10,-0x18(%rsp)
    271f:	4c 31 54 24 80       	xor    %r10,-0x80(%rsp)
    2724:	4c 33 54 24 d8       	xor    -0x28(%rsp),%r10
    2729:	4c 31 ce             	xor    %r9,%rsi
    272c:	48 c1 c6 15          	rol    $0x15,%rsi
    2730:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2735:	4c 31 f1             	xor    %r14,%rcx
    2738:	48 c1 c5 0e          	rol    $0xe,%rbp
    273c:	4c 89 c3             	mov    %r8,%rbx
    273f:	48 f7 d3             	not    %rbx
    2742:	4c 21 fb             	and    %r15,%rbx
    2745:	49 89 f3             	mov    %rsi,%r11
    2748:	49 f7 d3             	not    %r11
    274b:	49 21 eb             	and    %rbp,%r11
    274e:	4d 31 fb             	xor    %r15,%r11
    2751:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    2756:	49 f7 d7             	not    %r15
    2759:	49 21 f7             	and    %rsi,%r15
    275c:	49 89 eb             	mov    %rbp,%r11
    275f:	49 f7 d3             	not    %r11
    2762:	49 21 cb             	and    %rcx,%r11
    2765:	49 31 f3             	xor    %rsi,%r11
    2768:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    276d:	48 8d 05 bc 09 00 00 	lea    0x9bc(%rip),%rax        # 3130 <KeccakF_RoundConstants>
    2774:	48 33 5c f0 08       	xor    0x8(%rax,%rsi,8),%rbx
    2779:	48 89 ce             	mov    %rcx,%rsi
    277c:	48 31 cb             	xor    %rcx,%rbx
    277f:	4d 31 c7             	xor    %r8,%r15
    2782:	4c 89 7c 24 d8       	mov    %r15,-0x28(%rsp)
    2787:	48 f7 d6             	not    %rsi
    278a:	4c 21 c6             	and    %r8,%rsi
    278d:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    2792:	4c 31 ca             	xor    %r9,%rdx
    2795:	48 c1 c2 1c          	rol    $0x1c,%rdx
    2799:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    279e:	48 c1 c1 14          	rol    $0x14,%rcx
    27a2:	48 31 ee             	xor    %rbp,%rsi
    27a5:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    27aa:	48 8b 74 24 a8       	mov    -0x58(%rsp),%rsi
    27af:	4c 31 f6             	xor    %r14,%rsi
    27b2:	48 c1 c6 03          	rol    $0x3,%rsi
    27b6:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    27bb:	49 31 c5             	xor    %rax,%r13
    27be:	49 c1 c5 2d          	rol    $0x2d,%r13
    27c2:	4c 8b 7c 24 b0       	mov    -0x50(%rsp),%r15
    27c7:	4d 31 fc             	xor    %r15,%r12
    27ca:	49 c1 c4 3d          	rol    $0x3d,%r12
    27ce:	49 89 c8             	mov    %rcx,%r8
    27d1:	49 f7 d0             	not    %r8
    27d4:	49 21 f0             	and    %rsi,%r8
    27d7:	4c 89 ed             	mov    %r13,%rbp
    27da:	48 f7 d5             	not    %rbp
    27dd:	4c 21 e5             	and    %r12,%rbp
    27e0:	48 31 f5             	xor    %rsi,%rbp
    27e3:	48 89 6c 24 a8       	mov    %rbp,-0x58(%rsp)
    27e8:	48 f7 d6             	not    %rsi
    27eb:	4c 21 ee             	and    %r13,%rsi
    27ee:	4c 89 e5             	mov    %r12,%rbp
    27f1:	48 f7 d5             	not    %rbp
    27f4:	48 21 d5             	and    %rdx,%rbp
    27f7:	4c 31 ed             	xor    %r13,%rbp
    27fa:	48 89 6c 24 f8       	mov    %rbp,-0x8(%rsp)
    27ff:	49 31 d0             	xor    %rdx,%r8
    2802:	4c 89 04 24          	mov    %r8,(%rsp)
    2806:	48 31 ce             	xor    %rcx,%rsi
    2809:	48 89 74 24 98       	mov    %rsi,-0x68(%rsp)
    280e:	48 f7 d2             	not    %rdx
    2811:	48 21 ca             	and    %rcx,%rdx
    2814:	4c 31 e2             	xor    %r12,%rdx
    2817:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    281c:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
    2821:	48 31 c5             	xor    %rax,%rbp
    2824:	48 89 c2             	mov    %rax,%rdx
    2827:	48 d1 c5             	rol    $1,%rbp
    282a:	4c 8b 44 24 90       	mov    -0x70(%rsp),%r8
    282f:	4d 31 f8             	xor    %r15,%r8
    2832:	49 c1 c0 06          	rol    $0x6,%r8
    2836:	48 8b 44 24 a0       	mov    -0x60(%rsp),%rax
    283b:	4c 31 c8             	xor    %r9,%rax
    283e:	48 c1 c0 19          	rol    $0x19,%rax
    2842:	48 8b 4c 24 e8       	mov    -0x18(%rsp),%rcx
    2847:	48 c1 c1 08          	rol    $0x8,%rcx
    284b:	4c 31 f7             	xor    %r14,%rdi
    284e:	48 c1 c7 12          	rol    $0x12,%rdi
    2852:	4c 89 c6             	mov    %r8,%rsi
    2855:	48 f7 d6             	not    %rsi
    2858:	48 21 c6             	and    %rax,%rsi
    285b:	49 89 cc             	mov    %rcx,%r12
    285e:	49 f7 d4             	not    %r12
    2861:	49 21 fc             	and    %rdi,%r12
    2864:	49 31 c4             	xor    %rax,%r12
    2867:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    286c:	49 89 c4             	mov    %rax,%r12
    286f:	49 f7 d4             	not    %r12
    2872:	49 21 cc             	and    %rcx,%r12
    2875:	49 89 fd             	mov    %rdi,%r13
    2878:	49 f7 d5             	not    %r13
    287b:	49 21 ed             	and    %rbp,%r13
    287e:	49 31 cd             	xor    %rcx,%r13
    2881:	4c 89 6c 24 a0       	mov    %r13,-0x60(%rsp)
    2886:	48 31 ee             	xor    %rbp,%rsi
    2889:	48 89 74 24 90       	mov    %rsi,-0x70(%rsp)
    288e:	4d 31 c4             	xor    %r8,%r12
    2891:	4c 89 64 24 f0       	mov    %r12,-0x10(%rsp)
    2896:	48 f7 d5             	not    %rbp
    2899:	4c 21 c5             	and    %r8,%rbp
    289c:	4c 8b 6c 24 88       	mov    -0x78(%rsp),%r13
    28a1:	4d 31 f5             	xor    %r14,%r13
    28a4:	49 c1 c5 24          	rol    $0x24,%r13
    28a8:	48 31 fd             	xor    %rdi,%rbp
    28ab:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
    28b0:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
    28b5:	48 31 d6             	xor    %rdx,%rsi
    28b8:	48 89 d5             	mov    %rdx,%rbp
    28bb:	48 c1 c6 0a          	rol    $0xa,%rsi
    28bf:	48 8b 7c 24 c8       	mov    -0x38(%rsp),%rdi
    28c4:	4c 31 ff             	xor    %r15,%rdi
    28c7:	48 c1 c7 0f          	rol    $0xf,%rdi
    28cb:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    28d0:	4c 31 ca             	xor    %r9,%rdx
    28d3:	48 c1 c2 38          	rol    $0x38,%rdx
    28d7:	4c 89 e8             	mov    %r13,%rax
    28da:	48 f7 d0             	not    %rax
    28dd:	48 21 f0             	and    %rsi,%rax
    28e0:	49 89 fc             	mov    %rdi,%r12
    28e3:	49 f7 d4             	not    %r12
    28e6:	49 21 d4             	and    %rdx,%r12
    28e9:	49 31 f4             	xor    %rsi,%r12
    28ec:	4c 89 64 24 c8       	mov    %r12,-0x38(%rsp)
    28f1:	48 89 f1             	mov    %rsi,%rcx
    28f4:	4c 8b 44 24 80       	mov    -0x80(%rsp),%r8
    28f9:	49 c1 c0 1b          	rol    $0x1b,%r8
    28fd:	48 f7 d1             	not    %rcx
    2900:	48 21 f9             	and    %rdi,%rcx
    2903:	49 89 d4             	mov    %rdx,%r12
    2906:	49 f7 d4             	not    %r12
    2909:	4d 21 c4             	and    %r8,%r12
    290c:	49 31 fc             	xor    %rdi,%r12
    290f:	4c 31 c0             	xor    %r8,%rax
    2912:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    2917:	4c 31 e9             	xor    %r13,%rcx
    291a:	48 89 4c 24 88       	mov    %rcx,-0x78(%rsp)
    291f:	49 f7 d0             	not    %r8
    2922:	4d 21 e8             	and    %r13,%r8
    2925:	4c 33 7c 24 50       	xor    0x50(%rsp),%r15
    292a:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    292f:	4c 33 74 24 c0       	xor    -0x40(%rsp),%r14
    2934:	48 33 6c 24 38       	xor    0x38(%rsp),%rbp
    2939:	49 c1 c7 3e          	rol    $0x3e,%r15
    293d:	49 c1 c1 37          	rol    $0x37,%r9
    2941:	49 c1 c2 27          	rol    $0x27,%r10
    2945:	49 c1 c6 29          	rol    $0x29,%r14
    2949:	48 c1 c5 02          	rol    $0x2,%rbp
    294d:	49 31 d0             	xor    %rdx,%r8
    2950:	4c 89 ca             	mov    %r9,%rdx
    2953:	48 f7 d2             	not    %rdx
    2956:	4c 21 d2             	and    %r10,%rdx
    2959:	4c 89 f0             	mov    %r14,%rax
    295c:	48 f7 d0             	not    %rax
    295f:	48 21 e8             	and    %rbp,%rax
    2962:	4c 31 d0             	xor    %r10,%rax
    2965:	49 f7 d2             	not    %r10
    2968:	4d 21 f2             	and    %r14,%r10
    296b:	48 89 ef             	mov    %rbp,%rdi
    296e:	48 f7 d7             	not    %rdi
    2971:	4c 21 ff             	and    %r15,%rdi
    2974:	4c 31 f7             	xor    %r14,%rdi
    2977:	48 89 7c 24 c0       	mov    %rdi,-0x40(%rsp)
    297c:	4c 31 fa             	xor    %r15,%rdx
    297f:	49 89 d5             	mov    %rdx,%r13
    2982:	4d 31 ca             	xor    %r9,%r10
    2985:	49 f7 d7             	not    %r15
    2988:	4d 21 cf             	and    %r9,%r15
    298b:	49 31 ef             	xor    %rbp,%r15
    298e:	4c 89 7c 24 b0       	mov    %r15,-0x50(%rsp)
    2993:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
    2998:	48 83 44 24 10 02    	addq   $0x2,0x10(%rsp)
    299e:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
    29a3:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    29a8:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    29ad:	48 8b 6c 24 d8       	mov    -0x28(%rsp),%rbp
    29b2:	48 89 5c 24 80       	mov    %rbx,-0x80(%rsp)
    29b7:	e9 0f f9 ff ff       	jmp    22cb <KeccakF1600_StatePermute+0xe7>
    29bc:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    29c1:	48 8b 7c 24 80       	mov    -0x80(%rsp),%rdi
    29c6:	48 89 39             	mov    %rdi,(%rcx)
    29c9:	48 89 69 08          	mov    %rbp,0x8(%rcx)
    29cd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    29d2:	48 89 79 10          	mov    %rdi,0x10(%rcx)
    29d6:	48 8b 74 24 b8       	mov    -0x48(%rsp),%rsi
    29db:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    29df:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    29e3:	48 8b 14 24          	mov    (%rsp),%rdx
    29e7:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    29eb:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    29f0:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    29f4:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
    29f9:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    29fd:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
    2a02:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    2a06:	4c 89 79 48          	mov    %r15,0x48(%rcx)
    2a0a:	48 8b 54 24 90       	mov    -0x70(%rsp),%rdx
    2a0f:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2a13:	48 8b 54 24 f0       	mov    -0x10(%rsp),%rdx
    2a18:	48 89 51 58          	mov    %rdx,0x58(%rcx)
    2a1c:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    2a21:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    2a25:	48 8b 54 24 a0       	mov    -0x60(%rsp),%rdx
    2a2a:	48 89 51 68          	mov    %rdx,0x68(%rcx)
    2a2e:	4c 89 71 70          	mov    %r14,0x70(%rcx)
    2a32:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    2a37:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    2a3b:	48 8b 54 24 88       	mov    -0x78(%rsp),%rdx
    2a40:	48 89 91 80 00 00 00 	mov    %rdx,0x80(%rcx)
    2a47:	48 8b 54 24 c8       	mov    -0x38(%rsp),%rdx
    2a4c:	48 89 91 88 00 00 00 	mov    %rdx,0x88(%rcx)
    2a53:	4c 89 a1 90 00 00 00 	mov    %r12,0x90(%rcx)
    2a5a:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2a61:	4c 89 a9 a0 00 00 00 	mov    %r13,0xa0(%rcx)
    2a68:	4c 89 91 a8 00 00 00 	mov    %r10,0xa8(%rcx)
    2a6f:	48 89 81 b0 00 00 00 	mov    %rax,0xb0(%rcx)
    2a76:	48 8b 44 24 c0       	mov    -0x40(%rsp),%rax
    2a7b:	48 89 81 b8 00 00 00 	mov    %rax,0xb8(%rcx)
    2a82:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    2a87:	48 89 81 c0 00 00 00 	mov    %rax,0xc0(%rcx)
    2a8e:	48 83 c4 68          	add    $0x68,%rsp
    2a92:	5b                   	pop    %rbx
    2a93:	41 5c                	pop    %r12
    2a95:	41 5d                	pop    %r13
    2a97:	41 5e                	pop    %r14
    2a99:	41 5f                	pop    %r15
    2a9b:	5d                   	pop    %rbp
    2a9c:	c3                   	ret

0000000000002a9d <store64>:
    2a9d:	31 c9                	xor    %ecx,%ecx
    2a9f:	48 83 f9 40          	cmp    $0x40,%rcx
    2aa3:	74 11                	je     2ab6 <store64+0x19>
    2aa5:	48 89 f0             	mov    %rsi,%rax
    2aa8:	48 d3 e8             	shr    %cl,%rax
    2aab:	88 07                	mov    %al,(%rdi)
    2aad:	48 83 c1 08          	add    $0x8,%rcx
    2ab1:	48 ff c7             	inc    %rdi
    2ab4:	eb e9                	jmp    2a9f <store64+0x2>
    2ab6:	c3                   	ret

0000000000002ab7 <pqcrystals_kyber_fips202_ref_sha3_512>:
    2ab7:	41 56                	push   %r14
    2ab9:	53                   	push   %rbx
    2aba:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    2ac1:	48 89 d1             	mov    %rdx,%rcx
    2ac4:	48 89 f2             	mov    %rsi,%rdx
    2ac7:	48 89 fb             	mov    %rdi,%rbx
    2aca:	49 89 e6             	mov    %rsp,%r14
    2acd:	6a 48                	push   $0x48
    2acf:	5e                   	pop    %rsi
    2ad0:	6a 06                	push   $0x6
    2ad2:	41 58                	pop    %r8
    2ad4:	4c 89 f7             	mov    %r14,%rdi
    2ad7:	e8 f3 f3 ff ff       	call   1ecf <keccak_absorb_once>
    2adc:	4c 89 f7             	mov    %r14,%rdi
    2adf:	e8 00 f7 ff ff       	call   21e4 <KeccakF1600_StatePermute>
    2ae4:	45 31 f6             	xor    %r14d,%r14d
    2ae7:	49 83 fe 40          	cmp    $0x40,%r14
    2aeb:	74 13                	je     2b00 <pqcrystals_kyber_fips202_ref_sha3_512+0x49>
    2aed:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    2af1:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    2af5:	e8 a3 ff ff ff       	call   2a9d <store64>
    2afa:	49 83 c6 08          	add    $0x8,%r14
    2afe:	eb e7                	jmp    2ae7 <pqcrystals_kyber_fips202_ref_sha3_512+0x30>
    2b00:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    2b07:	5b                   	pop    %rbx
    2b08:	41 5e                	pop    %r14
    2b0a:	c3                   	ret

Disassembly of section .fini:

0000000000002b0c <_fini>:
    2b0c:	f3 0f 1e fa          	endbr64
    2b10:	48 83 ec 08          	sub    $0x8,%rsp
    2b14:	48 83 c4 08          	add    $0x8,%rsp
    2b18:	c3                   	ret

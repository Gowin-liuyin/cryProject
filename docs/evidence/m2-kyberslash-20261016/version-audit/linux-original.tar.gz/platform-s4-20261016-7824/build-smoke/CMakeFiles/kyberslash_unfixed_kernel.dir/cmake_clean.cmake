file(REMOVE_RECURSE
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/cbd.c.o"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/cbd.c.o.d"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/fips202.c.o"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/fips202.c.o.d"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/ntt.c.o"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/ntt.c.o.d"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/poly.c.o"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/poly.c.o.d"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/polyvec.c.o"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/polyvec.c.o.d"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/reduce.c.o"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/reduce.c.o.d"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/symmetric-shake.c.o"
  "CMakeFiles/kyberslash_unfixed_kernel.dir/home/nss-marker/yhr/Cry/platform-s4-20261016-7824/source/vendor/kyber-kyberslash-unfixed/ref/symmetric-shake.c.o.d"
  "libkyberslash_unfixed_kernel.a"
  "libkyberslash_unfixed_kernel.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/kyberslash_unfixed_kernel.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

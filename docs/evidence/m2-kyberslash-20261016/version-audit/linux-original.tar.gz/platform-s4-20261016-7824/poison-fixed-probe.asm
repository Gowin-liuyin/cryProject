
build-poison/kyberslash_fixed_probe:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 c1 3f 00 00 	mov    0x3fc1(%rip),%rax        # 4fd0 <__gmon_start__@Base>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <puts@plt-0x10>:
    1020:	ff 35 ca 3f 00 00    	push   0x3fca(%rip)        # 4ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 cc 3f 00 00    	jmp    *0x3fcc(%rip)        # 4ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001030 <puts@plt>:
    1030:	ff 25 ca 3f 00 00    	jmp    *0x3fca(%rip)        # 5000 <puts@GLIBC_2.2.5>
    1036:	68 00 00 00 00       	push   $0x0
    103b:	e9 e0 ff ff ff       	jmp    1020 <_init+0x20>

Disassembly of section .plt.got:

0000000000001040 <__cxa_finalize@plt>:
    1040:	ff 25 9a 3f 00 00    	jmp    *0x3f9a(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1046:	66 90                	xchg   %ax,%ax

Disassembly of section .text:

0000000000001050 <_start>:
    1050:	f3 0f 1e fa          	endbr64
    1054:	31 ed                	xor    %ebp,%ebp
    1056:	49 89 d1             	mov    %rdx,%r9
    1059:	5e                   	pop    %rsi
    105a:	48 89 e2             	mov    %rsp,%rdx
    105d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    1061:	50                   	push   %rax
    1062:	54                   	push   %rsp
    1063:	45 31 c0             	xor    %r8d,%r8d
    1066:	31 c9                	xor    %ecx,%ecx
    1068:	48 8d 3d d1 00 00 00 	lea    0xd1(%rip),%rdi        # 1140 <main>
    106f:	ff 15 4b 3f 00 00    	call   *0x3f4b(%rip)        # 4fc0 <__libc_start_main@GLIBC_2.34>
    1075:	f4                   	hlt
    1076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    107d:	00 00 00 

0000000000001080 <deregister_tm_clones>:
    1080:	48 8d 3d 91 3f 00 00 	lea    0x3f91(%rip),%rdi        # 5018 <__TMC_END__>
    1087:	48 8d 05 8a 3f 00 00 	lea    0x3f8a(%rip),%rax        # 5018 <__TMC_END__>
    108e:	48 39 f8             	cmp    %rdi,%rax
    1091:	74 15                	je     10a8 <deregister_tm_clones+0x28>
    1093:	48 8b 05 2e 3f 00 00 	mov    0x3f2e(%rip),%rax        # 4fc8 <_ITM_deregisterTMCloneTable@Base>
    109a:	48 85 c0             	test   %rax,%rax
    109d:	74 09                	je     10a8 <deregister_tm_clones+0x28>
    109f:	ff e0                	jmp    *%rax
    10a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    10a8:	c3                   	ret
    10a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010b0 <register_tm_clones>:
    10b0:	48 8d 3d 61 3f 00 00 	lea    0x3f61(%rip),%rdi        # 5018 <__TMC_END__>
    10b7:	48 8d 35 5a 3f 00 00 	lea    0x3f5a(%rip),%rsi        # 5018 <__TMC_END__>
    10be:	48 29 fe             	sub    %rdi,%rsi
    10c1:	48 89 f0             	mov    %rsi,%rax
    10c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    10c8:	48 c1 f8 03          	sar    $0x3,%rax
    10cc:	48 01 c6             	add    %rax,%rsi
    10cf:	48 d1 fe             	sar    $1,%rsi
    10d2:	74 14                	je     10e8 <register_tm_clones+0x38>
    10d4:	48 8b 05 fd 3e 00 00 	mov    0x3efd(%rip),%rax        # 4fd8 <_ITM_registerTMCloneTable@Base>
    10db:	48 85 c0             	test   %rax,%rax
    10de:	74 08                	je     10e8 <register_tm_clones+0x38>
    10e0:	ff e0                	jmp    *%rax
    10e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    10e8:	c3                   	ret
    10e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000010f0 <__do_global_dtors_aux>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	80 3d 1d 3f 00 00 00 	cmpb   $0x0,0x3f1d(%rip)        # 5018 <__TMC_END__>
    10fb:	75 2b                	jne    1128 <__do_global_dtors_aux+0x38>
    10fd:	55                   	push   %rbp
    10fe:	48 83 3d da 3e 00 00 	cmpq   $0x0,0x3eda(%rip)        # 4fe0 <__cxa_finalize@GLIBC_2.2.5>
    1105:	00 
    1106:	48 89 e5             	mov    %rsp,%rbp
    1109:	74 0c                	je     1117 <__do_global_dtors_aux+0x27>
    110b:	48 8b 3d fe 3e 00 00 	mov    0x3efe(%rip),%rdi        # 5010 <__dso_handle>
    1112:	e8 29 ff ff ff       	call   1040 <__cxa_finalize@plt>
    1117:	e8 64 ff ff ff       	call   1080 <deregister_tm_clones>
    111c:	c6 05 f5 3e 00 00 01 	movb   $0x1,0x3ef5(%rip)        # 5018 <__TMC_END__>
    1123:	5d                   	pop    %rbp
    1124:	c3                   	ret
    1125:	0f 1f 00             	nopl   (%rax)
    1128:	c3                   	ret
    1129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001130 <frame_dummy>:
    1130:	f3 0f 1e fa          	endbr64
    1134:	e9 77 ff ff ff       	jmp    10b0 <register_tm_clones>
    1139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001140 <main>:
    1140:	55                   	push   %rbp
    1141:	48 89 e5             	mov    %rsp,%rbp
    1144:	48 81 ec 70 0e 00 00 	sub    $0xe70,%rsp
    114b:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%rbp)
    1152:	c6 85 8f f3 ff ff 00 	movb   $0x0,-0xc71(%rbp)
    1159:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
    1160:	00 00 00 00 
    1164:	48 81 bd 80 f3 ff ff 	cmpq   $0x100,-0xc80(%rbp)
    116b:	00 01 00 00 
    116f:	0f 83 9f 00 00 00    	jae    1214 <main+0xd4>
    1175:	48 6b 85 80 f3 ff ff 	imul   $0xd,-0xc80(%rbp),%rax
    117c:	0d 
    117d:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    1182:	31 d2                	xor    %edx,%edx
    1184:	48 f7 f1             	div    %rcx
    1187:	66 89 d1             	mov    %dx,%cx
    118a:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1191:	66 89 8c 45 fc fd ff 	mov    %cx,-0x204(%rbp,%rax,2)
    1198:	ff 
    1199:	48 c7 85 78 f3 ff ff 	movq   $0x0,-0xc88(%rbp)
    11a0:	00 00 00 00 
    11a4:	48 83 bd 78 f3 ff ff 	cmpq   $0x3,-0xc88(%rbp)
    11ab:	03 
    11ac:	0f 83 46 00 00 00    	jae    11f8 <main+0xb8>
    11b2:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    11b9:	66 8b 94 45 fc fd ff 	mov    -0x204(%rbp,%rax,2),%dx
    11c0:	ff 
    11c1:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    11c8:	48 8b 8d 78 f3 ff ff 	mov    -0xc88(%rbp),%rcx
    11cf:	48 c1 e1 09          	shl    $0x9,%rcx
    11d3:	48 01 c8             	add    %rcx,%rax
    11d6:	48 8b 8d 80 f3 ff ff 	mov    -0xc80(%rbp),%rcx
    11dd:	66 89 14 48          	mov    %dx,(%rax,%rcx,2)
    11e1:	48 8b 85 78 f3 ff ff 	mov    -0xc88(%rbp),%rax
    11e8:	48 83 c0 01          	add    $0x1,%rax
    11ec:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
    11f3:	e9 ac ff ff ff       	jmp    11a4 <main+0x64>
    11f8:	e9 00 00 00 00       	jmp    11fd <main+0xbd>
    11fd:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
    1204:	48 83 c0 01          	add    $0x1,%rax
    1208:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
    120f:	e9 50 ff ff ff       	jmp    1164 <main+0x24>
    1214:	48 c7 85 40 f3 ff ff 	movq   $0x4d430001,-0xcc0(%rbp)
    121b:	01 00 43 4d 
    121f:	48 8d 85 fc fd ff ff 	lea    -0x204(%rbp),%rax
    1226:	48 89 85 48 f3 ff ff 	mov    %rax,-0xcb8(%rbp)
    122d:	48 c7 85 50 f3 ff ff 	movq   $0x200,-0xcb0(%rbp)
    1234:	00 02 00 00 
    1238:	48 c7 85 58 f3 ff ff 	movq   $0x0,-0xca8(%rbp)
    123f:	00 00 00 00 
    1243:	48 c7 85 60 f3 ff ff 	movq   $0x0,-0xca0(%rbp)
    124a:	00 00 00 00 
    124e:	48 c7 85 68 f3 ff ff 	movq   $0x0,-0xc98(%rbp)
    1255:	00 00 00 00 
    1259:	48 8d 85 40 f3 ff ff 	lea    -0xcc0(%rbp),%rax
    1260:	31 c9                	xor    %ecx,%ecx
    1262:	89 ca                	mov    %ecx,%edx
    1264:	48 c1 c7 03          	rol    $0x3,%rdi
    1268:	48 c1 c7 0d          	rol    $0xd,%rdi
    126c:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1270:	48 c1 c7 33          	rol    $0x33,%rdi
    1274:	48 87 db             	xchg   %rbx,%rbx
    1277:	48 89 95 38 f3 ff ff 	mov    %rdx,-0xcc8(%rbp)
    127e:	48 8b 85 38 f3 ff ff 	mov    -0xcc8(%rbp),%rax
    1285:	48 89 85 30 f3 ff ff 	mov    %rax,-0xcd0(%rbp)
    128c:	48 c7 85 00 f3 ff ff 	movq   $0x4d430001,-0xd00(%rbp)
    1293:	01 00 43 4d 
    1297:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    129e:	48 89 85 08 f3 ff ff 	mov    %rax,-0xcf8(%rbp)
    12a5:	48 c7 85 10 f3 ff ff 	movq   $0x600,-0xcf0(%rbp)
    12ac:	00 06 00 00 
    12b0:	48 c7 85 18 f3 ff ff 	movq   $0x0,-0xce8(%rbp)
    12b7:	00 00 00 00 
    12bb:	48 c7 85 20 f3 ff ff 	movq   $0x0,-0xce0(%rbp)
    12c2:	00 00 00 00 
    12c6:	48 c7 85 28 f3 ff ff 	movq   $0x0,-0xcd8(%rbp)
    12cd:	00 00 00 00 
    12d1:	48 8d 85 00 f3 ff ff 	lea    -0xd00(%rbp),%rax
    12d8:	31 c9                	xor    %ecx,%ecx
    12da:	89 ca                	mov    %ecx,%edx
    12dc:	48 c1 c7 03          	rol    $0x3,%rdi
    12e0:	48 c1 c7 0d          	rol    $0xd,%rdi
    12e4:	48 c1 c7 3d          	rol    $0x3d,%rdi
    12e8:	48 c1 c7 33          	rol    $0x33,%rdi
    12ec:	48 87 db             	xchg   %rbx,%rbx
    12ef:	48 89 95 f8 f2 ff ff 	mov    %rdx,-0xd08(%rbp)
    12f6:	48 8b 85 f8 f2 ff ff 	mov    -0xd08(%rbp),%rax
    12fd:	48 89 85 f0 f2 ff ff 	mov    %rax,-0xd10(%rbp)
    1304:	48 8d bd d0 f7 ff ff 	lea    -0x830(%rbp),%rdi
    130b:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1312:	e8 2d 05 00 00       	call   1844 <pqcrystals_kyber768_ref_poly_tomsg>
    1317:	48 8d bd 50 f7 ff ff 	lea    -0x8b0(%rbp),%rdi
    131e:	48 8d b5 fc fd ff ff 	lea    -0x204(%rbp),%rsi
    1325:	e8 7e 03 00 00       	call   16a8 <pqcrystals_kyber768_ref_poly_compress>
    132a:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
    1331:	48 8d b5 fc f7 ff ff 	lea    -0x804(%rbp),%rsi
    1338:	e8 f3 06 00 00       	call   1a30 <pqcrystals_kyber768_ref_polyvec_compress>
    133d:	48 c7 85 c0 f2 ff ff 	movq   $0x4d430002,-0xd40(%rbp)
    1344:	02 00 43 4d 
    1348:	48 8d 85 fc fd ff ff 	lea    -0x204(%rbp),%rax
    134f:	48 89 85 c8 f2 ff ff 	mov    %rax,-0xd38(%rbp)
    1356:	48 c7 85 d0 f2 ff ff 	movq   $0x200,-0xd30(%rbp)
    135d:	00 02 00 00 
    1361:	48 c7 85 d8 f2 ff ff 	movq   $0x0,-0xd28(%rbp)
    1368:	00 00 00 00 
    136c:	48 c7 85 e0 f2 ff ff 	movq   $0x0,-0xd20(%rbp)
    1373:	00 00 00 00 
    1377:	48 c7 85 e8 f2 ff ff 	movq   $0x0,-0xd18(%rbp)
    137e:	00 00 00 00 
    1382:	48 8d 85 c0 f2 ff ff 	lea    -0xd40(%rbp),%rax
    1389:	31 c9                	xor    %ecx,%ecx
    138b:	89 ca                	mov    %ecx,%edx
    138d:	48 c1 c7 03          	rol    $0x3,%rdi
    1391:	48 c1 c7 0d          	rol    $0xd,%rdi
    1395:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1399:	48 c1 c7 33          	rol    $0x33,%rdi
    139d:	48 87 db             	xchg   %rbx,%rbx
    13a0:	48 89 95 b8 f2 ff ff 	mov    %rdx,-0xd48(%rbp)
    13a7:	48 8b 85 b8 f2 ff ff 	mov    -0xd48(%rbp),%rax
    13ae:	48 89 85 b0 f2 ff ff 	mov    %rax,-0xd50(%rbp)
    13b5:	48 c7 85 80 f2 ff ff 	movq   $0x4d430002,-0xd80(%rbp)
    13bc:	02 00 43 4d 
    13c0:	48 8d 85 fc f7 ff ff 	lea    -0x804(%rbp),%rax
    13c7:	48 89 85 88 f2 ff ff 	mov    %rax,-0xd78(%rbp)
    13ce:	48 c7 85 90 f2 ff ff 	movq   $0x600,-0xd70(%rbp)
    13d5:	00 06 00 00 
    13d9:	48 c7 85 98 f2 ff ff 	movq   $0x0,-0xd68(%rbp)
    13e0:	00 00 00 00 
    13e4:	48 c7 85 a0 f2 ff ff 	movq   $0x0,-0xd60(%rbp)
    13eb:	00 00 00 00 
    13ef:	48 c7 85 a8 f2 ff ff 	movq   $0x0,-0xd58(%rbp)
    13f6:	00 00 00 00 
    13fa:	48 8d 85 80 f2 ff ff 	lea    -0xd80(%rbp),%rax
    1401:	31 c9                	xor    %ecx,%ecx
    1403:	89 ca                	mov    %ecx,%edx
    1405:	48 c1 c7 03          	rol    $0x3,%rdi
    1409:	48 c1 c7 0d          	rol    $0xd,%rdi
    140d:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1411:	48 c1 c7 33          	rol    $0x33,%rdi
    1415:	48 87 db             	xchg   %rbx,%rbx
    1418:	48 89 95 78 f2 ff ff 	mov    %rdx,-0xd88(%rbp)
    141f:	48 8b 85 78 f2 ff ff 	mov    -0xd88(%rbp),%rax
    1426:	48 89 85 70 f2 ff ff 	mov    %rax,-0xd90(%rbp)
    142d:	48 c7 85 40 f2 ff ff 	movq   $0x4d430002,-0xdc0(%rbp)
    1434:	02 00 43 4d 
    1438:	48 8d 85 d0 f7 ff ff 	lea    -0x830(%rbp),%rax
    143f:	48 89 85 48 f2 ff ff 	mov    %rax,-0xdb8(%rbp)
    1446:	48 c7 85 50 f2 ff ff 	movq   $0x20,-0xdb0(%rbp)
    144d:	20 00 00 00 
    1451:	48 c7 85 58 f2 ff ff 	movq   $0x0,-0xda8(%rbp)
    1458:	00 00 00 00 
    145c:	48 c7 85 60 f2 ff ff 	movq   $0x0,-0xda0(%rbp)
    1463:	00 00 00 00 
    1467:	48 c7 85 68 f2 ff ff 	movq   $0x0,-0xd98(%rbp)
    146e:	00 00 00 00 
    1472:	48 8d 85 40 f2 ff ff 	lea    -0xdc0(%rbp),%rax
    1479:	31 c9                	xor    %ecx,%ecx
    147b:	89 ca                	mov    %ecx,%edx
    147d:	48 c1 c7 03          	rol    $0x3,%rdi
    1481:	48 c1 c7 0d          	rol    $0xd,%rdi
    1485:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1489:	48 c1 c7 33          	rol    $0x33,%rdi
    148d:	48 87 db             	xchg   %rbx,%rbx
    1490:	48 89 95 38 f2 ff ff 	mov    %rdx,-0xdc8(%rbp)
    1497:	48 8b 85 38 f2 ff ff 	mov    -0xdc8(%rbp),%rax
    149e:	48 89 85 30 f2 ff ff 	mov    %rax,-0xdd0(%rbp)
    14a5:	48 c7 85 00 f2 ff ff 	movq   $0x4d430002,-0xe00(%rbp)
    14ac:	02 00 43 4d 
    14b0:	48 8d 85 50 f7 ff ff 	lea    -0x8b0(%rbp),%rax
    14b7:	48 89 85 08 f2 ff ff 	mov    %rax,-0xdf8(%rbp)
    14be:	48 c7 85 10 f2 ff ff 	movq   $0x80,-0xdf0(%rbp)
    14c5:	80 00 00 00 
    14c9:	48 c7 85 18 f2 ff ff 	movq   $0x0,-0xde8(%rbp)
    14d0:	00 00 00 00 
    14d4:	48 c7 85 20 f2 ff ff 	movq   $0x0,-0xde0(%rbp)
    14db:	00 00 00 00 
    14df:	48 c7 85 28 f2 ff ff 	movq   $0x0,-0xdd8(%rbp)
    14e6:	00 00 00 00 
    14ea:	48 8d 85 00 f2 ff ff 	lea    -0xe00(%rbp),%rax
    14f1:	31 c9                	xor    %ecx,%ecx
    14f3:	89 ca                	mov    %ecx,%edx
    14f5:	48 c1 c7 03          	rol    $0x3,%rdi
    14f9:	48 c1 c7 0d          	rol    $0xd,%rdi
    14fd:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1501:	48 c1 c7 33          	rol    $0x33,%rdi
    1505:	48 87 db             	xchg   %rbx,%rbx
    1508:	48 89 95 f8 f1 ff ff 	mov    %rdx,-0xe08(%rbp)
    150f:	48 8b 85 f8 f1 ff ff 	mov    -0xe08(%rbp),%rax
    1516:	48 89 85 f0 f1 ff ff 	mov    %rax,-0xe10(%rbp)
    151d:	48 c7 85 c0 f1 ff ff 	movq   $0x4d430002,-0xe40(%rbp)
    1524:	02 00 43 4d 
    1528:	48 8d 85 90 f3 ff ff 	lea    -0xc70(%rbp),%rax
    152f:	48 89 85 c8 f1 ff ff 	mov    %rax,-0xe38(%rbp)
    1536:	48 c7 85 d0 f1 ff ff 	movq   $0x3c0,-0xe30(%rbp)
    153d:	c0 03 00 00 
    1541:	48 c7 85 d8 f1 ff ff 	movq   $0x0,-0xe28(%rbp)
    1548:	00 00 00 00 
    154c:	48 c7 85 e0 f1 ff ff 	movq   $0x0,-0xe20(%rbp)
    1553:	00 00 00 00 
    1557:	48 c7 85 e8 f1 ff ff 	movq   $0x0,-0xe18(%rbp)
    155e:	00 00 00 00 
    1562:	48 8d 85 c0 f1 ff ff 	lea    -0xe40(%rbp),%rax
    1569:	31 c9                	xor    %ecx,%ecx
    156b:	89 ca                	mov    %ecx,%edx
    156d:	48 c1 c7 03          	rol    $0x3,%rdi
    1571:	48 c1 c7 0d          	rol    $0xd,%rdi
    1575:	48 c1 c7 3d          	rol    $0x3d,%rdi
    1579:	48 c1 c7 33          	rol    $0x33,%rdi
    157d:	48 87 db             	xchg   %rbx,%rbx
    1580:	48 89 95 b8 f1 ff ff 	mov    %rdx,-0xe48(%rbp)
    1587:	48 8b 85 b8 f1 ff ff 	mov    -0xe48(%rbp),%rax
    158e:	48 89 85 b0 f1 ff ff 	mov    %rax,-0xe50(%rbp)
    1595:	48 c7 85 a8 f1 ff ff 	movq   $0x0,-0xe58(%rbp)
    159c:	00 00 00 00 
    15a0:	48 83 bd a8 f1 ff ff 	cmpq   $0x20,-0xe58(%rbp)
    15a7:	20 
    15a8:	0f 83 37 00 00 00    	jae    15e5 <main+0x4a5>
    15ae:	48 8b 85 a8 f1 ff ff 	mov    -0xe58(%rbp),%rax
    15b5:	0f b6 8c 05 d0 f7 ff 	movzbl -0x830(%rbp,%rax,1),%ecx
    15bc:	ff 
    15bd:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    15c3:	0f b6 c0             	movzbl %al,%eax
    15c6:	31 c8                	xor    %ecx,%eax
    15c8:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    15ce:	48 8b 85 a8 f1 ff ff 	mov    -0xe58(%rbp),%rax
    15d5:	48 83 c0 01          	add    $0x1,%rax
    15d9:	48 89 85 a8 f1 ff ff 	mov    %rax,-0xe58(%rbp)
    15e0:	e9 bb ff ff ff       	jmp    15a0 <main+0x460>
    15e5:	48 c7 85 a0 f1 ff ff 	movq   $0x0,-0xe60(%rbp)
    15ec:	00 00 00 00 
    15f0:	48 81 bd a0 f1 ff ff 	cmpq   $0x80,-0xe60(%rbp)
    15f7:	80 00 00 00 
    15fb:	0f 83 37 00 00 00    	jae    1638 <main+0x4f8>
    1601:	48 8b 85 a0 f1 ff ff 	mov    -0xe60(%rbp),%rax
    1608:	0f b6 8c 05 50 f7 ff 	movzbl -0x8b0(%rbp,%rax,1),%ecx
    160f:	ff 
    1610:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1616:	0f b6 c0             	movzbl %al,%eax
    1619:	31 c8                	xor    %ecx,%eax
    161b:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    1621:	48 8b 85 a0 f1 ff ff 	mov    -0xe60(%rbp),%rax
    1628:	48 83 c0 01          	add    $0x1,%rax
    162c:	48 89 85 a0 f1 ff ff 	mov    %rax,-0xe60(%rbp)
    1633:	e9 b8 ff ff ff       	jmp    15f0 <main+0x4b0>
    1638:	48 c7 85 98 f1 ff ff 	movq   $0x0,-0xe68(%rbp)
    163f:	00 00 00 00 
    1643:	48 81 bd 98 f1 ff ff 	cmpq   $0x3c0,-0xe68(%rbp)
    164a:	c0 03 00 00 
    164e:	0f 83 37 00 00 00    	jae    168b <main+0x54b>
    1654:	48 8b 85 98 f1 ff ff 	mov    -0xe68(%rbp),%rax
    165b:	0f b6 8c 05 90 f3 ff 	movzbl -0xc70(%rbp,%rax,1),%ecx
    1662:	ff 
    1663:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1669:	0f b6 c0             	movzbl %al,%eax
    166c:	31 c8                	xor    %ecx,%eax
    166e:	88 85 8f f3 ff ff    	mov    %al,-0xc71(%rbp)
    1674:	48 8b 85 98 f1 ff ff 	mov    -0xe68(%rbp),%rax
    167b:	48 83 c0 01          	add    $0x1,%rax
    167f:	48 89 85 98 f1 ff ff 	mov    %rax,-0xe68(%rbp)
    1686:	e9 b8 ff ff ff       	jmp    1643 <main+0x503>
    168b:	8a 85 8f f3 ff ff    	mov    -0xc71(%rbp),%al
    1691:	48 8d 3d 6c 19 00 00 	lea    0x196c(%rip),%rdi        # 3004 <_IO_stdin_used+0x4>
    1698:	e8 93 f9 ff ff       	call   1030 <puts@plt>
    169d:	31 c0                	xor    %eax,%eax
    169f:	48 81 c4 70 0e 00 00 	add    $0xe70,%rsp
    16a6:	5d                   	pop    %rbp
    16a7:	c3                   	ret

00000000000016a8 <pqcrystals_kyber768_ref_poly_compress>:
    16a8:	31 c0                	xor    %eax,%eax
    16aa:	48 83 f8 20          	cmp    $0x20,%rax
    16ae:	0f 84 80 00 00 00    	je     1734 <pqcrystals_kyber768_ref_poly_compress+0x8c>
    16b4:	31 c9                	xor    %ecx,%ecx
    16b6:	48 83 f9 08          	cmp    $0x8,%rcx
    16ba:	74 31                	je     16ed <pqcrystals_kyber768_ref_poly_compress+0x45>
    16bc:	0f bf 14 4e          	movswl (%rsi,%rcx,2),%edx
    16c0:	41 89 d0             	mov    %edx,%r8d
    16c3:	41 c1 e8 0f          	shr    $0xf,%r8d
    16c7:	41 81 e0 01 0d 00 00 	and    $0xd01,%r8d
    16ce:	41 01 d0             	add    %edx,%r8d
    16d1:	41 0f bf d0          	movswl %r8w,%edx
    16d5:	69 d2 b0 af 13 00    	imul   $0x13afb0,%edx,%edx
    16db:	81 c2 7b 9a 00 08    	add    $0x8009a7b,%edx
    16e1:	c1 ea 1c             	shr    $0x1c,%edx
    16e4:	88 54 0c f8          	mov    %dl,-0x8(%rsp,%rcx,1)
    16e8:	48 ff c1             	inc    %rcx
    16eb:	eb c9                	jmp    16b6 <pqcrystals_kyber768_ref_poly_compress+0xe>
    16ed:	8a 4c 24 f9          	mov    -0x7(%rsp),%cl
    16f1:	c0 e1 04             	shl    $0x4,%cl
    16f4:	0a 4c 24 f8          	or     -0x8(%rsp),%cl
    16f8:	88 0f                	mov    %cl,(%rdi)
    16fa:	8a 4c 24 fb          	mov    -0x5(%rsp),%cl
    16fe:	c0 e1 04             	shl    $0x4,%cl
    1701:	0a 4c 24 fa          	or     -0x6(%rsp),%cl
    1705:	88 4f 01             	mov    %cl,0x1(%rdi)
    1708:	8a 4c 24 fd          	mov    -0x3(%rsp),%cl
    170c:	c0 e1 04             	shl    $0x4,%cl
    170f:	0a 4c 24 fc          	or     -0x4(%rsp),%cl
    1713:	88 4f 02             	mov    %cl,0x2(%rdi)
    1716:	8a 4c 24 ff          	mov    -0x1(%rsp),%cl
    171a:	c0 e1 04             	shl    $0x4,%cl
    171d:	0a 4c 24 fe          	or     -0x2(%rsp),%cl
    1721:	88 4f 03             	mov    %cl,0x3(%rdi)
    1724:	48 83 c7 04          	add    $0x4,%rdi
    1728:	48 ff c0             	inc    %rax
    172b:	48 83 c6 10          	add    $0x10,%rsi
    172f:	e9 76 ff ff ff       	jmp    16aa <pqcrystals_kyber768_ref_poly_compress+0x2>
    1734:	c3                   	ret

0000000000001735 <pqcrystals_kyber768_ref_poly_decompress>:
    1735:	31 c0                	xor    %eax,%eax
    1737:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    173d:	74 34                	je     1773 <pqcrystals_kyber768_ref_poly_decompress+0x3e>
    173f:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    1743:	83 e1 0f             	and    $0xf,%ecx
    1746:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    174c:	83 c1 08             	add    $0x8,%ecx
    174f:	c1 e9 04             	shr    $0x4,%ecx
    1752:	66 89 0c 87          	mov    %cx,(%rdi,%rax,4)
    1756:	0f b6 0c 06          	movzbl (%rsi,%rax,1),%ecx
    175a:	c1 e9 04             	shr    $0x4,%ecx
    175d:	69 c9 01 0d 00 00    	imul   $0xd01,%ecx,%ecx
    1763:	83 c1 08             	add    $0x8,%ecx
    1766:	c1 e9 04             	shr    $0x4,%ecx
    1769:	66 89 4c 87 02       	mov    %cx,0x2(%rdi,%rax,4)
    176e:	48 ff c0             	inc    %rax
    1771:	eb c4                	jmp    1737 <pqcrystals_kyber768_ref_poly_decompress+0x2>
    1773:	c3                   	ret

0000000000001774 <pqcrystals_kyber768_ref_poly_tobytes>:
    1774:	48 83 c7 02          	add    $0x2,%rdi
    1778:	31 c0                	xor    %eax,%eax
    177a:	b9 01 0d 00 00       	mov    $0xd01,%ecx
    177f:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    1785:	74 47                	je     17ce <pqcrystals_kyber768_ref_poly_tobytes+0x5a>
    1787:	44 0f bf 04 86       	movswl (%rsi,%rax,4),%r8d
    178c:	44 89 c2             	mov    %r8d,%edx
    178f:	c1 ea 0f             	shr    $0xf,%edx
    1792:	21 ca                	and    %ecx,%edx
    1794:	44 01 c2             	add    %r8d,%edx
    1797:	44 0f bf 44 86 02    	movswl 0x2(%rsi,%rax,4),%r8d
    179d:	45 89 c1             	mov    %r8d,%r9d
    17a0:	41 c1 e9 0f          	shr    $0xf,%r9d
    17a4:	41 21 c9             	and    %ecx,%r9d
    17a7:	45 01 c1             	add    %r8d,%r9d
    17aa:	88 57 fe             	mov    %dl,-0x2(%rdi)
    17ad:	0f b6 d6             	movzbl %dh,%edx
    17b0:	45 89 c8             	mov    %r9d,%r8d
    17b3:	41 c1 e0 04          	shl    $0x4,%r8d
    17b7:	41 09 d0             	or     %edx,%r8d
    17ba:	44 88 47 ff          	mov    %r8b,-0x1(%rdi)
    17be:	41 c1 e9 04          	shr    $0x4,%r9d
    17c2:	44 88 0f             	mov    %r9b,(%rdi)
    17c5:	48 ff c0             	inc    %rax
    17c8:	48 83 c7 03          	add    $0x3,%rdi
    17cc:	eb b1                	jmp    177f <pqcrystals_kyber768_ref_poly_tobytes+0xb>
    17ce:	c3                   	ret

00000000000017cf <pqcrystals_kyber768_ref_poly_frombytes>:
    17cf:	48 83 c6 02          	add    $0x2,%rsi
    17d3:	31 c0                	xor    %eax,%eax
    17d5:	48 3d 80 00 00 00    	cmp    $0x80,%rax
    17db:	74 31                	je     180e <pqcrystals_kyber768_ref_poly_frombytes+0x3f>
    17dd:	0f b6 4e fe          	movzbl -0x2(%rsi),%ecx
    17e1:	0f b6 56 ff          	movzbl -0x1(%rsi),%edx
    17e5:	83 e2 0f             	and    $0xf,%edx
    17e8:	c1 e2 08             	shl    $0x8,%edx
    17eb:	09 ca                	or     %ecx,%edx
    17ed:	66 89 14 87          	mov    %dx,(%rdi,%rax,4)
    17f1:	0f b6 4e ff          	movzbl -0x1(%rsi),%ecx
    17f5:	c1 e9 04             	shr    $0x4,%ecx
    17f8:	0f b6 16             	movzbl (%rsi),%edx
    17fb:	c1 e2 04             	shl    $0x4,%edx
    17fe:	09 ca                	or     %ecx,%edx
    1800:	66 89 54 87 02       	mov    %dx,0x2(%rdi,%rax,4)
    1805:	48 ff c0             	inc    %rax
    1808:	48 83 c6 03          	add    $0x3,%rsi
    180c:	eb c7                	jmp    17d5 <pqcrystals_kyber768_ref_poly_frombytes+0x6>
    180e:	c3                   	ret

000000000000180f <pqcrystals_kyber768_ref_poly_frommsg>:
    180f:	31 c0                	xor    %eax,%eax
    1811:	48 83 f8 20          	cmp    $0x20,%rax
    1815:	74 2c                	je     1843 <pqcrystals_kyber768_ref_poly_frommsg+0x34>
    1817:	31 c9                	xor    %ecx,%ecx
    1819:	48 83 f9 08          	cmp    $0x8,%rcx
    181d:	74 1b                	je     183a <pqcrystals_kyber768_ref_poly_frommsg+0x2b>
    181f:	44 0f b6 04 06       	movzbl (%rsi,%rax,1),%r8d
    1824:	31 d2                	xor    %edx,%edx
    1826:	41 0f a3 c8          	bt     %ecx,%r8d
    182a:	73 05                	jae    1831 <pqcrystals_kyber768_ref_poly_frommsg+0x22>
    182c:	ba 81 06 00 00       	mov    $0x681,%edx
    1831:	66 89 14 4f          	mov    %dx,(%rdi,%rcx,2)
    1835:	48 ff c1             	inc    %rcx
    1838:	eb df                	jmp    1819 <pqcrystals_kyber768_ref_poly_frommsg+0xa>
    183a:	48 ff c0             	inc    %rax
    183d:	48 83 c7 10          	add    $0x10,%rdi
    1841:	eb ce                	jmp    1811 <pqcrystals_kyber768_ref_poly_frommsg+0x2>
    1843:	c3                   	ret

0000000000001844 <pqcrystals_kyber768_ref_poly_tomsg>:
    1844:	31 c0                	xor    %eax,%eax
    1846:	48 83 f8 20          	cmp    $0x20,%rax
    184a:	74 40                	je     188c <pqcrystals_kyber768_ref_poly_tomsg+0x48>
    184c:	c6 04 07 00          	movb   $0x0,(%rdi,%rax,1)
    1850:	31 c9                	xor    %ecx,%ecx
    1852:	31 d2                	xor    %edx,%edx
    1854:	48 83 f9 08          	cmp    $0x8,%rcx
    1858:	74 29                	je     1883 <pqcrystals_kyber768_ref_poly_tomsg+0x3f>
    185a:	44 0f bf 04 4e       	movswl (%rsi,%rcx,2),%r8d
    185f:	45 69 c0 f6 75 02 00 	imul   $0x275f6,%r8d,%r8d
    1866:	41 81 c0 7b 9a 00 08 	add    $0x8009a7b,%r8d
    186d:	41 c1 e8 1c          	shr    $0x1c,%r8d
    1871:	41 83 e0 01          	and    $0x1,%r8d
    1875:	41 d3 e0             	shl    %cl,%r8d
    1878:	44 08 c2             	or     %r8b,%dl
    187b:	88 14 07             	mov    %dl,(%rdi,%rax,1)
    187e:	48 ff c1             	inc    %rcx
    1881:	eb d1                	jmp    1854 <pqcrystals_kyber768_ref_poly_tomsg+0x10>
    1883:	48 ff c0             	inc    %rax
    1886:	48 83 c6 10          	add    $0x10,%rsi
    188a:	eb ba                	jmp    1846 <pqcrystals_kyber768_ref_poly_tomsg+0x2>
    188c:	c3                   	ret

000000000000188d <pqcrystals_kyber768_ref_poly_getnoise_eta1>:
    188d:	41 56                	push   %r14
    188f:	53                   	push   %rbx
    1890:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    1897:	89 d1                	mov    %edx,%ecx
    1899:	48 89 f2             	mov    %rsi,%rdx
    189c:	48 89 fb             	mov    %rdi,%rbx
    189f:	49 89 e6             	mov    %rsp,%r14
    18a2:	be 80 00 00 00       	mov    $0x80,%esi
    18a7:	4c 89 f7             	mov    %r14,%rdi
    18aa:	e8 91 07 00 00       	call   2040 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    18af:	48 89 df             	mov    %rbx,%rdi
    18b2:	4c 89 f6             	mov    %r14,%rsi
    18b5:	e8 c6 06 00 00       	call   1f80 <pqcrystals_kyber768_ref_poly_cbd_eta1>
    18ba:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    18c1:	5b                   	pop    %rbx
    18c2:	41 5e                	pop    %r14
    18c4:	c3                   	ret

00000000000018c5 <pqcrystals_kyber768_ref_poly_getnoise_eta2>:
    18c5:	41 56                	push   %r14
    18c7:	53                   	push   %rbx
    18c8:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    18cf:	89 d1                	mov    %edx,%ecx
    18d1:	48 89 f2             	mov    %rsi,%rdx
    18d4:	48 89 fb             	mov    %rdi,%rbx
    18d7:	49 89 e6             	mov    %rsp,%r14
    18da:	be 80 00 00 00       	mov    $0x80,%esi
    18df:	4c 89 f7             	mov    %r14,%rdi
    18e2:	e8 59 07 00 00       	call   2040 <pqcrystals_kyber768_ref_kyber_shake256_prf>
    18e7:	48 89 df             	mov    %rbx,%rdi
    18ea:	4c 89 f6             	mov    %r14,%rsi
    18ed:	e8 f0 06 00 00       	call   1fe2 <pqcrystals_kyber768_ref_poly_cbd_eta2>
    18f2:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    18f9:	5b                   	pop    %rbx
    18fa:	41 5e                	pop    %r14
    18fc:	c3                   	ret

00000000000018fd <pqcrystals_kyber768_ref_poly_ntt>:
    18fd:	53                   	push   %rbx
    18fe:	48 89 fb             	mov    %rdi,%rbx
    1901:	e8 86 04 00 00       	call   1d8c <pqcrystals_kyber768_ref_ntt>
    1906:	48 89 df             	mov    %rbx,%rdi
    1909:	5b                   	pop    %rbx
    190a:	e9 00 00 00 00       	jmp    190f <pqcrystals_kyber768_ref_poly_reduce>

000000000000190f <pqcrystals_kyber768_ref_poly_reduce>:
    190f:	41 56                	push   %r14
    1911:	53                   	push   %rbx
    1912:	50                   	push   %rax
    1913:	48 89 fb             	mov    %rdi,%rbx
    1916:	45 31 f6             	xor    %r14d,%r14d
    1919:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    1920:	74 14                	je     1936 <pqcrystals_kyber768_ref_poly_reduce+0x27>
    1922:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    1927:	e8 cd 06 00 00       	call   1ff9 <pqcrystals_kyber768_ref_barrett_reduce>
    192c:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1931:	49 ff c6             	inc    %r14
    1934:	eb e3                	jmp    1919 <pqcrystals_kyber768_ref_poly_reduce+0xa>
    1936:	48 83 c4 08          	add    $0x8,%rsp
    193a:	5b                   	pop    %rbx
    193b:	41 5e                	pop    %r14
    193d:	c3                   	ret

000000000000193e <pqcrystals_kyber768_ref_poly_invntt_tomont>:
    193e:	e9 e8 04 00 00       	jmp    1e2b <pqcrystals_kyber768_ref_invntt>

0000000000001943 <pqcrystals_kyber768_ref_poly_basemul_montgomery>:
    1943:	55                   	push   %rbp
    1944:	41 57                	push   %r15
    1946:	41 56                	push   %r14
    1948:	41 55                	push   %r13
    194a:	41 54                	push   %r12
    194c:	53                   	push   %rbx
    194d:	50                   	push   %rax
    194e:	48 89 d3             	mov    %rdx,%rbx
    1951:	49 89 f6             	mov    %rsi,%r14
    1954:	49 89 ff             	mov    %rdi,%r15
    1957:	4c 8d 25 d2 16 00 00 	lea    0x16d2(%rip),%r12        # 3030 <pqcrystals_kyber768_ref_zetas>
    195e:	49 83 ec 80          	sub    $0xffffffffffffff80,%r12
    1962:	45 31 ed             	xor    %r13d,%r13d
    1965:	49 81 fd 00 02 00 00 	cmp    $0x200,%r13
    196c:	74 44                	je     19b2 <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x6f>
    196e:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    1972:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    1976:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    197a:	41 0f bf 2c 24       	movswl (%r12),%ebp
    197f:	89 e9                	mov    %ebp,%ecx
    1981:	e8 8a 05 00 00       	call   1f10 <pqcrystals_kyber768_ref_basemul>
    1986:	4b 8d 3c 2f          	lea    (%r15,%r13,1),%rdi
    198a:	48 83 c7 04          	add    $0x4,%rdi
    198e:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
    1992:	48 83 c6 04          	add    $0x4,%rsi
    1996:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
    199a:	48 83 c2 04          	add    $0x4,%rdx
    199e:	f7 dd                	neg    %ebp
    19a0:	0f bf cd             	movswl %bp,%ecx
    19a3:	e8 68 05 00 00       	call   1f10 <pqcrystals_kyber768_ref_basemul>
    19a8:	49 83 c5 08          	add    $0x8,%r13
    19ac:	49 83 c4 02          	add    $0x2,%r12
    19b0:	eb b3                	jmp    1965 <pqcrystals_kyber768_ref_poly_basemul_montgomery+0x22>
    19b2:	48 83 c4 08          	add    $0x8,%rsp
    19b6:	5b                   	pop    %rbx
    19b7:	41 5c                	pop    %r12
    19b9:	41 5d                	pop    %r13
    19bb:	41 5e                	pop    %r14
    19bd:	41 5f                	pop    %r15
    19bf:	5d                   	pop    %rbp
    19c0:	c3                   	ret

00000000000019c1 <pqcrystals_kyber768_ref_poly_tomont>:
    19c1:	41 56                	push   %r14
    19c3:	53                   	push   %rbx
    19c4:	50                   	push   %rax
    19c5:	48 89 fb             	mov    %rdi,%rbx
    19c8:	45 31 f6             	xor    %r14d,%r14d
    19cb:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    19d2:	74 1a                	je     19ee <pqcrystals_kyber768_ref_poly_tomont+0x2d>
    19d4:	42 0f bf 04 73       	movswl (%rbx,%r14,2),%eax
    19d9:	69 f8 49 05 00 00    	imul   $0x549,%eax,%edi
    19df:	e8 00 06 00 00       	call   1fe4 <pqcrystals_kyber768_ref_montgomery_reduce>
    19e4:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    19e9:	49 ff c6             	inc    %r14
    19ec:	eb dd                	jmp    19cb <pqcrystals_kyber768_ref_poly_tomont+0xa>
    19ee:	48 83 c4 08          	add    $0x8,%rsp
    19f2:	5b                   	pop    %rbx
    19f3:	41 5e                	pop    %r14
    19f5:	c3                   	ret

00000000000019f6 <pqcrystals_kyber768_ref_poly_add>:
    19f6:	31 c0                	xor    %eax,%eax
    19f8:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    19fe:	74 11                	je     1a11 <pqcrystals_kyber768_ref_poly_add+0x1b>
    1a00:	0f b7 0c 42          	movzwl (%rdx,%rax,2),%ecx
    1a04:	66 03 0c 46          	add    (%rsi,%rax,2),%cx
    1a08:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    1a0c:	48 ff c0             	inc    %rax
    1a0f:	eb e7                	jmp    19f8 <pqcrystals_kyber768_ref_poly_add+0x2>
    1a11:	c3                   	ret

0000000000001a12 <pqcrystals_kyber768_ref_poly_sub>:
    1a12:	31 c0                	xor    %eax,%eax
    1a14:	48 3d 00 01 00 00    	cmp    $0x100,%rax
    1a1a:	74 11                	je     1a2d <pqcrystals_kyber768_ref_poly_sub+0x1b>
    1a1c:	0f b7 0c 46          	movzwl (%rsi,%rax,2),%ecx
    1a20:	66 2b 0c 42          	sub    (%rdx,%rax,2),%cx
    1a24:	66 89 0c 47          	mov    %cx,(%rdi,%rax,2)
    1a28:	48 ff c0             	inc    %rax
    1a2b:	eb e7                	jmp    1a14 <pqcrystals_kyber768_ref_poly_sub+0x2>
    1a2d:	c3                   	ret
    1a2e:	66 90                	xchg   %ax,%ax

0000000000001a30 <pqcrystals_kyber768_ref_polyvec_compress>:
    1a30:	31 c0                	xor    %eax,%eax
    1a32:	b9 37 d5 09 80       	mov    $0x8009d537,%ecx
    1a37:	48 83 f8 03          	cmp    $0x3,%rax
    1a3b:	0f 84 ce 00 00 00    	je     1b0f <pqcrystals_kyber768_ref_polyvec_compress+0xdf>
    1a41:	48 89 f2             	mov    %rsi,%rdx
    1a44:	45 31 c0             	xor    %r8d,%r8d
    1a47:	49 83 f8 40          	cmp    $0x40,%r8
    1a4b:	0f 84 af 00 00 00    	je     1b00 <pqcrystals_kyber768_ref_polyvec_compress+0xd0>
    1a51:	45 31 c9             	xor    %r9d,%r9d
    1a54:	49 83 f9 04          	cmp    $0x4,%r9
    1a58:	74 3a                	je     1a94 <pqcrystals_kyber768_ref_polyvec_compress+0x64>
    1a5a:	46 0f bf 14 4a       	movswl (%rdx,%r9,2),%r10d
    1a5f:	45 89 d3             	mov    %r10d,%r11d
    1a62:	41 c1 eb 0f          	shr    $0xf,%r11d
    1a66:	41 81 e3 01 0d 00 00 	and    $0xd01,%r11d
    1a6d:	45 01 d3             	add    %r10d,%r11d
    1a70:	45 0f b7 d3          	movzwl %r11w,%r10d
    1a74:	4d 69 d2 00 dc be 4e 	imul   $0x4ebedc00,%r10,%r10
    1a7b:	49 01 ca             	add    %rcx,%r10
    1a7e:	49 c1 ea 20          	shr    $0x20,%r10
    1a82:	41 81 e2 ff 03 00 00 	and    $0x3ff,%r10d
    1a89:	66 46 89 54 4c f8    	mov    %r10w,-0x8(%rsp,%r9,2)
    1a8f:	49 ff c1             	inc    %r9
    1a92:	eb c0                	jmp    1a54 <pqcrystals_kyber768_ref_polyvec_compress+0x24>
    1a94:	44 8a 4c 24 f8       	mov    -0x8(%rsp),%r9b
    1a99:	44 88 0f             	mov    %r9b,(%rdi)
    1a9c:	44 8a 4c 24 fa       	mov    -0x6(%rsp),%r9b
    1aa1:	41 c0 e1 02          	shl    $0x2,%r9b
    1aa5:	44 0a 4c 24 f9       	or     -0x7(%rsp),%r9b
    1aaa:	44 88 4f 01          	mov    %r9b,0x1(%rdi)
    1aae:	44 0f b7 4c 24 fa    	movzwl -0x6(%rsp),%r9d
    1ab4:	41 c1 e9 06          	shr    $0x6,%r9d
    1ab8:	44 8a 54 24 fc       	mov    -0x4(%rsp),%r10b
    1abd:	41 c0 e2 04          	shl    $0x4,%r10b
    1ac1:	45 08 ca             	or     %r9b,%r10b
    1ac4:	44 88 57 02          	mov    %r10b,0x2(%rdi)
    1ac8:	44 0f b7 4c 24 fc    	movzwl -0x4(%rsp),%r9d
    1ace:	41 c1 e9 04          	shr    $0x4,%r9d
    1ad2:	44 8a 54 24 fe       	mov    -0x2(%rsp),%r10b
    1ad7:	41 c0 e2 06          	shl    $0x6,%r10b
    1adb:	45 08 ca             	or     %r9b,%r10b
    1ade:	44 88 57 03          	mov    %r10b,0x3(%rdi)
    1ae2:	44 0f b7 4c 24 fe    	movzwl -0x2(%rsp),%r9d
    1ae8:	41 c1 e9 02          	shr    $0x2,%r9d
    1aec:	44 88 4f 04          	mov    %r9b,0x4(%rdi)
    1af0:	48 83 c7 05          	add    $0x5,%rdi
    1af4:	49 ff c0             	inc    %r8
    1af7:	48 83 c2 08          	add    $0x8,%rdx
    1afb:	e9 47 ff ff ff       	jmp    1a47 <pqcrystals_kyber768_ref_polyvec_compress+0x17>
    1b00:	48 ff c0             	inc    %rax
    1b03:	48 81 c6 00 02 00 00 	add    $0x200,%rsi
    1b0a:	e9 28 ff ff ff       	jmp    1a37 <pqcrystals_kyber768_ref_polyvec_compress+0x7>
    1b0f:	c3                   	ret

0000000000001b10 <pqcrystals_kyber768_ref_polyvec_decompress>:
    1b10:	31 c0                	xor    %eax,%eax
    1b12:	48 83 f8 03          	cmp    $0x3,%rax
    1b16:	0f 84 b8 00 00 00    	je     1bd4 <pqcrystals_kyber768_ref_polyvec_decompress+0xc4>
    1b1c:	48 89 f9             	mov    %rdi,%rcx
    1b1f:	31 d2                	xor    %edx,%edx
    1b21:	48 83 fa 40          	cmp    $0x40,%rdx
    1b25:	0f 84 9a 00 00 00    	je     1bc5 <pqcrystals_kyber768_ref_polyvec_decompress+0xb5>
    1b2b:	44 0f b7 06          	movzwl (%rsi),%r8d
    1b2f:	66 44 89 44 24 f8    	mov    %r8w,-0x8(%rsp)
    1b35:	44 0f b6 46 01       	movzbl 0x1(%rsi),%r8d
    1b3a:	41 c1 e8 02          	shr    $0x2,%r8d
    1b3e:	44 0f b6 4e 02       	movzbl 0x2(%rsi),%r9d
    1b43:	41 c1 e1 06          	shl    $0x6,%r9d
    1b47:	45 09 c1             	or     %r8d,%r9d
    1b4a:	66 44 89 4c 24 fa    	mov    %r9w,-0x6(%rsp)
    1b50:	44 0f b6 46 02       	movzbl 0x2(%rsi),%r8d
    1b55:	41 c1 e8 04          	shr    $0x4,%r8d
    1b59:	44 0f b6 4e 03       	movzbl 0x3(%rsi),%r9d
    1b5e:	41 c1 e1 04          	shl    $0x4,%r9d
    1b62:	45 09 c1             	or     %r8d,%r9d
    1b65:	66 44 89 4c 24 fc    	mov    %r9w,-0x4(%rsp)
    1b6b:	44 0f b6 46 03       	movzbl 0x3(%rsi),%r8d
    1b70:	41 c1 e8 06          	shr    $0x6,%r8d
    1b74:	44 0f b6 4e 04       	movzbl 0x4(%rsi),%r9d
    1b79:	47 8d 04 88          	lea    (%r8,%r9,4),%r8d
    1b7d:	66 44 89 44 24 fe    	mov    %r8w,-0x2(%rsp)
    1b83:	45 31 c0             	xor    %r8d,%r8d
    1b86:	49 83 f8 04          	cmp    $0x4,%r8
    1b8a:	74 29                	je     1bb5 <pqcrystals_kyber768_ref_polyvec_decompress+0xa5>
    1b8c:	46 0f b7 4c 44 f8    	movzwl -0x8(%rsp,%r8,2),%r9d
    1b92:	41 81 e1 ff 03 00 00 	and    $0x3ff,%r9d
    1b99:	45 69 c9 01 0d 00 00 	imul   $0xd01,%r9d,%r9d
    1ba0:	41 81 c1 00 02 00 00 	add    $0x200,%r9d
    1ba7:	41 c1 e9 0a          	shr    $0xa,%r9d
    1bab:	66 46 89 0c 41       	mov    %r9w,(%rcx,%r8,2)
    1bb0:	49 ff c0             	inc    %r8
    1bb3:	eb d1                	jmp    1b86 <pqcrystals_kyber768_ref_polyvec_decompress+0x76>
    1bb5:	48 83 c6 05          	add    $0x5,%rsi
    1bb9:	48 ff c2             	inc    %rdx
    1bbc:	48 83 c1 08          	add    $0x8,%rcx
    1bc0:	e9 5c ff ff ff       	jmp    1b21 <pqcrystals_kyber768_ref_polyvec_decompress+0x11>
    1bc5:	48 ff c0             	inc    %rax
    1bc8:	48 81 c7 00 02 00 00 	add    $0x200,%rdi
    1bcf:	e9 3e ff ff ff       	jmp    1b12 <pqcrystals_kyber768_ref_polyvec_decompress+0x2>
    1bd4:	c3                   	ret

0000000000001bd5 <pqcrystals_kyber768_ref_polyvec_tobytes>:
    1bd5:	41 57                	push   %r15
    1bd7:	41 56                	push   %r14
    1bd9:	53                   	push   %rbx
    1bda:	48 89 f3             	mov    %rsi,%rbx
    1bdd:	49 89 fe             	mov    %rdi,%r14
    1be0:	45 31 ff             	xor    %r15d,%r15d
    1be3:	49 81 ff 00 06 00 00 	cmp    $0x600,%r15
    1bea:	74 1c                	je     1c08 <pqcrystals_kyber768_ref_polyvec_tobytes+0x33>
    1bec:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    1bf0:	4c 89 f7             	mov    %r14,%rdi
    1bf3:	e8 7c fb ff ff       	call   1774 <pqcrystals_kyber768_ref_poly_tobytes>
    1bf8:	49 81 c7 00 02 00 00 	add    $0x200,%r15
    1bff:	49 81 c6 80 01 00 00 	add    $0x180,%r14
    1c06:	eb db                	jmp    1be3 <pqcrystals_kyber768_ref_polyvec_tobytes+0xe>
    1c08:	5b                   	pop    %rbx
    1c09:	41 5e                	pop    %r14
    1c0b:	41 5f                	pop    %r15
    1c0d:	c3                   	ret

0000000000001c0e <pqcrystals_kyber768_ref_polyvec_frombytes>:
    1c0e:	41 57                	push   %r15
    1c10:	41 56                	push   %r14
    1c12:	53                   	push   %rbx
    1c13:	48 89 f3             	mov    %rsi,%rbx
    1c16:	49 89 fe             	mov    %rdi,%r14
    1c19:	45 31 ff             	xor    %r15d,%r15d
    1c1c:	49 81 ff 80 04 00 00 	cmp    $0x480,%r15
    1c23:	74 1c                	je     1c41 <pqcrystals_kyber768_ref_polyvec_frombytes+0x33>
    1c25:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
    1c29:	4c 89 f7             	mov    %r14,%rdi
    1c2c:	e8 9e fb ff ff       	call   17cf <pqcrystals_kyber768_ref_poly_frombytes>
    1c31:	49 81 c7 80 01 00 00 	add    $0x180,%r15
    1c38:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1c3f:	eb db                	jmp    1c1c <pqcrystals_kyber768_ref_polyvec_frombytes+0xe>
    1c41:	5b                   	pop    %rbx
    1c42:	41 5e                	pop    %r14
    1c44:	41 5f                	pop    %r15
    1c46:	c3                   	ret

0000000000001c47 <pqcrystals_kyber768_ref_polyvec_ntt>:
    1c47:	41 56                	push   %r14
    1c49:	53                   	push   %rbx
    1c4a:	50                   	push   %rax
    1c4b:	48 89 fb             	mov    %rdi,%rbx
    1c4e:	45 31 f6             	xor    %r14d,%r14d
    1c51:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1c58:	74 12                	je     1c6c <pqcrystals_kyber768_ref_polyvec_ntt+0x25>
    1c5a:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1c5e:	e8 9a fc ff ff       	call   18fd <pqcrystals_kyber768_ref_poly_ntt>
    1c63:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1c6a:	eb e5                	jmp    1c51 <pqcrystals_kyber768_ref_polyvec_ntt+0xa>
    1c6c:	48 83 c4 08          	add    $0x8,%rsp
    1c70:	5b                   	pop    %rbx
    1c71:	41 5e                	pop    %r14
    1c73:	c3                   	ret

0000000000001c74 <pqcrystals_kyber768_ref_polyvec_invntt_tomont>:
    1c74:	41 56                	push   %r14
    1c76:	53                   	push   %rbx
    1c77:	50                   	push   %rax
    1c78:	48 89 fb             	mov    %rdi,%rbx
    1c7b:	45 31 f6             	xor    %r14d,%r14d
    1c7e:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1c85:	74 12                	je     1c99 <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0x25>
    1c87:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1c8b:	e8 ae fc ff ff       	call   193e <pqcrystals_kyber768_ref_poly_invntt_tomont>
    1c90:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1c97:	eb e5                	jmp    1c7e <pqcrystals_kyber768_ref_polyvec_invntt_tomont+0xa>
    1c99:	48 83 c4 08          	add    $0x8,%rsp
    1c9d:	5b                   	pop    %rbx
    1c9e:	41 5e                	pop    %r14
    1ca0:	c3                   	ret

0000000000001ca1 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery>:
    1ca1:	41 57                	push   %r15
    1ca3:	41 56                	push   %r14
    1ca5:	41 55                	push   %r13
    1ca7:	41 54                	push   %r12
    1ca9:	53                   	push   %rbx
    1caa:	48 81 ec 00 02 00 00 	sub    $0x200,%rsp
    1cb1:	49 89 d6             	mov    %rdx,%r14
    1cb4:	49 89 f7             	mov    %rsi,%r15
    1cb7:	48 89 fb             	mov    %rdi,%rbx
    1cba:	e8 84 fc ff ff       	call   1943 <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    1cbf:	b8 00 02 00 00       	mov    $0x200,%eax
    1cc4:	49 01 c7             	add    %rax,%r15
    1cc7:	49 01 c6             	add    %rax,%r14
    1cca:	45 31 ed             	xor    %r13d,%r13d
    1ccd:	49 89 e4             	mov    %rsp,%r12
    1cd0:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
    1cd7:	74 27                	je     1d00 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x5f>
    1cd9:	4b 8d 34 2f          	lea    (%r15,%r13,1),%rsi
    1cdd:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
    1ce1:	4c 89 e7             	mov    %r12,%rdi
    1ce4:	e8 5a fc ff ff       	call   1943 <pqcrystals_kyber768_ref_poly_basemul_montgomery>
    1ce9:	48 89 df             	mov    %rbx,%rdi
    1cec:	48 89 de             	mov    %rbx,%rsi
    1cef:	4c 89 e2             	mov    %r12,%rdx
    1cf2:	e8 ff fc ff ff       	call   19f6 <pqcrystals_kyber768_ref_poly_add>
    1cf7:	49 81 c5 00 02 00 00 	add    $0x200,%r13
    1cfe:	eb d0                	jmp    1cd0 <pqcrystals_kyber768_ref_polyvec_basemul_acc_montgomery+0x2f>
    1d00:	48 89 df             	mov    %rbx,%rdi
    1d03:	e8 07 fc ff ff       	call   190f <pqcrystals_kyber768_ref_poly_reduce>
    1d08:	48 81 c4 00 02 00 00 	add    $0x200,%rsp
    1d0f:	5b                   	pop    %rbx
    1d10:	41 5c                	pop    %r12
    1d12:	41 5d                	pop    %r13
    1d14:	41 5e                	pop    %r14
    1d16:	41 5f                	pop    %r15
    1d18:	c3                   	ret

0000000000001d19 <pqcrystals_kyber768_ref_polyvec_reduce>:
    1d19:	41 56                	push   %r14
    1d1b:	53                   	push   %rbx
    1d1c:	50                   	push   %rax
    1d1d:	48 89 fb             	mov    %rdi,%rbx
    1d20:	45 31 f6             	xor    %r14d,%r14d
    1d23:	49 81 fe 00 06 00 00 	cmp    $0x600,%r14
    1d2a:	74 12                	je     1d3e <pqcrystals_kyber768_ref_polyvec_reduce+0x25>
    1d2c:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    1d30:	e8 da fb ff ff       	call   190f <pqcrystals_kyber768_ref_poly_reduce>
    1d35:	49 81 c6 00 02 00 00 	add    $0x200,%r14
    1d3c:	eb e5                	jmp    1d23 <pqcrystals_kyber768_ref_polyvec_reduce+0xa>
    1d3e:	48 83 c4 08          	add    $0x8,%rsp
    1d42:	5b                   	pop    %rbx
    1d43:	41 5e                	pop    %r14
    1d45:	c3                   	ret

0000000000001d46 <pqcrystals_kyber768_ref_polyvec_add>:
    1d46:	41 57                	push   %r15
    1d48:	41 56                	push   %r14
    1d4a:	41 54                	push   %r12
    1d4c:	53                   	push   %rbx
    1d4d:	50                   	push   %rax
    1d4e:	48 89 d3             	mov    %rdx,%rbx
    1d51:	49 89 f6             	mov    %rsi,%r14
    1d54:	49 89 ff             	mov    %rdi,%r15
    1d57:	45 31 e4             	xor    %r12d,%r12d
    1d5a:	49 81 fc 00 06 00 00 	cmp    $0x600,%r12
    1d61:	74 1a                	je     1d7d <pqcrystals_kyber768_ref_polyvec_add+0x37>
    1d63:	4b 8d 3c 27          	lea    (%r15,%r12,1),%rdi
    1d67:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    1d6b:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
    1d6f:	e8 82 fc ff ff       	call   19f6 <pqcrystals_kyber768_ref_poly_add>
    1d74:	49 81 c4 00 02 00 00 	add    $0x200,%r12
    1d7b:	eb dd                	jmp    1d5a <pqcrystals_kyber768_ref_polyvec_add+0x14>
    1d7d:	48 83 c4 08          	add    $0x8,%rsp
    1d81:	5b                   	pop    %rbx
    1d82:	41 5c                	pop    %r12
    1d84:	41 5e                	pop    %r14
    1d86:	41 5f                	pop    %r15
    1d88:	c3                   	ret
    1d89:	0f 1f 00             	nopl   (%rax)

0000000000001d8c <pqcrystals_kyber768_ref_ntt>:
    1d8c:	55                   	push   %rbp
    1d8d:	41 57                	push   %r15
    1d8f:	41 56                	push   %r14
    1d91:	41 55                	push   %r13
    1d93:	41 54                	push   %r12
    1d95:	53                   	push   %rbx
    1d96:	50                   	push   %rax
    1d97:	48 89 fb             	mov    %rdi,%rbx
    1d9a:	b9 80 00 00 00       	mov    $0x80,%ecx
    1d9f:	6a 01                	push   $0x1
    1da1:	58                   	pop    %rax
    1da2:	83 f9 02             	cmp    $0x2,%ecx
    1da5:	72 6d                	jb     1e14 <pqcrystals_kyber768_ref_ntt+0x88>
    1da7:	41 89 cd             	mov    %ecx,%r13d
    1daa:	45 31 f6             	xor    %r14d,%r14d
    1dad:	89 0c 24             	mov    %ecx,(%rsp)
    1db0:	41 81 fe ff 00 00 00 	cmp    $0xff,%r14d
    1db7:	77 57                	ja     1e10 <pqcrystals_kyber768_ref_ntt+0x84>
    1db9:	89 44 24 04          	mov    %eax,0x4(%rsp)
    1dbd:	89 c0                	mov    %eax,%eax
    1dbf:	45 89 f4             	mov    %r14d,%r12d
    1dc2:	41 01 ce             	add    %ecx,%r14d
    1dc5:	48 8d 0d 64 12 00 00 	lea    0x1264(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1dcc:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1dd0:	4d 39 f4             	cmp    %r14,%r12
    1dd3:	73 2a                	jae    1dff <pqcrystals_kyber768_ref_ntt+0x73>
    1dd5:	47 8d 3c 2c          	lea    (%r12,%r13,1),%r15d
    1dd9:	42 0f bf 34 7b       	movswl (%rbx,%r15,2),%esi
    1dde:	89 ef                	mov    %ebp,%edi
    1de0:	e8 3e 00 00 00       	call   1e23 <fqmul>
    1de5:	42 0f b7 0c 63       	movzwl (%rbx,%r12,2),%ecx
    1dea:	89 ca                	mov    %ecx,%edx
    1dec:	29 c2                	sub    %eax,%edx
    1dee:	66 42 89 14 7b       	mov    %dx,(%rbx,%r15,2)
    1df3:	01 c1                	add    %eax,%ecx
    1df5:	66 42 89 0c 63       	mov    %cx,(%rbx,%r12,2)
    1dfa:	49 ff c4             	inc    %r12
    1dfd:	eb d1                	jmp    1dd0 <pqcrystals_kyber768_ref_ntt+0x44>
    1dff:	8b 44 24 04          	mov    0x4(%rsp),%eax
    1e03:	ff c0                	inc    %eax
    1e05:	45 01 ec             	add    %r13d,%r12d
    1e08:	45 89 e6             	mov    %r12d,%r14d
    1e0b:	8b 0c 24             	mov    (%rsp),%ecx
    1e0e:	eb a0                	jmp    1db0 <pqcrystals_kyber768_ref_ntt+0x24>
    1e10:	d1 e9                	shr    $1,%ecx
    1e12:	eb 8e                	jmp    1da2 <pqcrystals_kyber768_ref_ntt+0x16>
    1e14:	48 83 c4 08          	add    $0x8,%rsp
    1e18:	5b                   	pop    %rbx
    1e19:	41 5c                	pop    %r12
    1e1b:	41 5d                	pop    %r13
    1e1d:	41 5e                	pop    %r14
    1e1f:	41 5f                	pop    %r15
    1e21:	5d                   	pop    %rbp
    1e22:	c3                   	ret

0000000000001e23 <fqmul>:
    1e23:	0f af fe             	imul   %esi,%edi
    1e26:	e9 b9 01 00 00       	jmp    1fe4 <pqcrystals_kyber768_ref_montgomery_reduce>

0000000000001e2b <pqcrystals_kyber768_ref_invntt>:
    1e2b:	55                   	push   %rbp
    1e2c:	41 57                	push   %r15
    1e2e:	41 56                	push   %r14
    1e30:	41 55                	push   %r13
    1e32:	41 54                	push   %r12
    1e34:	53                   	push   %rbx
    1e35:	48 83 ec 18          	sub    $0x18,%rsp
    1e39:	48 89 fb             	mov    %rdi,%rbx
    1e3c:	6a 02                	push   $0x2
    1e3e:	59                   	pop    %rcx
    1e3f:	6a 7f                	push   $0x7f
    1e41:	58                   	pop    %rax
    1e42:	81 f9 81 00 00 00    	cmp    $0x81,%ecx
    1e48:	0f 83 8e 00 00 00    	jae    1edc <pqcrystals_kyber768_ref_invntt+0xb1>
    1e4e:	89 ca                	mov    %ecx,%edx
    1e50:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    1e55:	4c 8d 24 53          	lea    (%rbx,%rdx,2),%r12
    1e59:	45 31 ed             	xor    %r13d,%r13d
    1e5c:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
    1e60:	41 81 fd ff 00 00 00 	cmp    $0xff,%r13d
    1e67:	77 6c                	ja     1ed5 <pqcrystals_kyber768_ref_invntt+0xaa>
    1e69:	89 44 24 0c          	mov    %eax,0xc(%rsp)
    1e6d:	89 c0                	mov    %eax,%eax
    1e6f:	45 89 ee             	mov    %r13d,%r14d
    1e72:	41 01 cd             	add    %ecx,%r13d
    1e75:	48 8d 0d b4 11 00 00 	lea    0x11b4(%rip),%rcx        # 3030 <pqcrystals_kyber768_ref_zetas>
    1e7c:	0f bf 2c 41          	movswl (%rcx,%rax,2),%ebp
    1e80:	4d 39 ee             	cmp    %r13,%r14
    1e83:	73 3c                	jae    1ec1 <pqcrystals_kyber768_ref_invntt+0x96>
    1e85:	46 0f b7 3c 73       	movzwl (%rbx,%r14,2),%r15d
    1e8a:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1e8f:	66 44 01 f8          	add    %r15w,%ax
    1e93:	0f bf f8             	movswl %ax,%edi
    1e96:	e8 5e 01 00 00       	call   1ff9 <pqcrystals_kyber768_ref_barrett_reduce>
    1e9b:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1ea0:	43 0f b7 04 74       	movzwl (%r12,%r14,2),%eax
    1ea5:	44 29 f8             	sub    %r15d,%eax
    1ea8:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1ead:	0f bf f0             	movswl %ax,%esi
    1eb0:	89 ef                	mov    %ebp,%edi
    1eb2:	e8 6c ff ff ff       	call   1e23 <fqmul>
    1eb7:	66 43 89 04 74       	mov    %ax,(%r12,%r14,2)
    1ebc:	49 ff c6             	inc    %r14
    1ebf:	eb bf                	jmp    1e80 <pqcrystals_kyber768_ref_invntt+0x55>
    1ec1:	8b 44 24 0c          	mov    0xc(%rsp),%eax
    1ec5:	ff c8                	dec    %eax
    1ec7:	44 03 74 24 10       	add    0x10(%rsp),%r14d
    1ecc:	45 89 f5             	mov    %r14d,%r13d
    1ecf:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
    1ed3:	eb 8b                	jmp    1e60 <pqcrystals_kyber768_ref_invntt+0x35>
    1ed5:	01 c9                	add    %ecx,%ecx
    1ed7:	e9 66 ff ff ff       	jmp    1e42 <pqcrystals_kyber768_ref_invntt+0x17>
    1edc:	45 31 f6             	xor    %r14d,%r14d
    1edf:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
    1ee6:	74 19                	je     1f01 <pqcrystals_kyber768_ref_invntt+0xd6>
    1ee8:	42 0f bf 3c 73       	movswl (%rbx,%r14,2),%edi
    1eed:	be a1 05 00 00       	mov    $0x5a1,%esi
    1ef2:	e8 2c ff ff ff       	call   1e23 <fqmul>
    1ef7:	66 42 89 04 73       	mov    %ax,(%rbx,%r14,2)
    1efc:	49 ff c6             	inc    %r14
    1eff:	eb de                	jmp    1edf <pqcrystals_kyber768_ref_invntt+0xb4>
    1f01:	48 83 c4 18          	add    $0x18,%rsp
    1f05:	5b                   	pop    %rbx
    1f06:	41 5c                	pop    %r12
    1f08:	41 5d                	pop    %r13
    1f0a:	41 5e                	pop    %r14
    1f0c:	41 5f                	pop    %r15
    1f0e:	5d                   	pop    %rbp
    1f0f:	c3                   	ret

0000000000001f10 <pqcrystals_kyber768_ref_basemul>:
    1f10:	55                   	push   %rbp
    1f11:	41 57                	push   %r15
    1f13:	41 56                	push   %r14
    1f15:	53                   	push   %rbx
    1f16:	50                   	push   %rax
    1f17:	89 cd                	mov    %ecx,%ebp
    1f19:	49 89 d6             	mov    %rdx,%r14
    1f1c:	49 89 f7             	mov    %rsi,%r15
    1f1f:	48 89 fb             	mov    %rdi,%rbx
    1f22:	0f bf 7e 02          	movswl 0x2(%rsi),%edi
    1f26:	0f bf 72 02          	movswl 0x2(%rdx),%esi
    1f2a:	e8 f4 fe ff ff       	call   1e23 <fqmul>
    1f2f:	66 89 03             	mov    %ax,(%rbx)
    1f32:	0f bf f8             	movswl %ax,%edi
    1f35:	89 ee                	mov    %ebp,%esi
    1f37:	e8 e7 fe ff ff       	call   1e23 <fqmul>
    1f3c:	66 89 03             	mov    %ax,(%rbx)
    1f3f:	41 0f bf 3f          	movswl (%r15),%edi
    1f43:	41 0f bf 36          	movswl (%r14),%esi
    1f47:	e8 d7 fe ff ff       	call   1e23 <fqmul>
    1f4c:	66 01 03             	add    %ax,(%rbx)
    1f4f:	41 0f bf 3f          	movswl (%r15),%edi
    1f53:	41 0f bf 76 02       	movswl 0x2(%r14),%esi
    1f58:	e8 c6 fe ff ff       	call   1e23 <fqmul>
    1f5d:	66 89 43 02          	mov    %ax,0x2(%rbx)
    1f61:	41 0f bf 7f 02       	movswl 0x2(%r15),%edi
    1f66:	41 0f bf 36          	movswl (%r14),%esi
    1f6a:	e8 b4 fe ff ff       	call   1e23 <fqmul>
    1f6f:	66 01 43 02          	add    %ax,0x2(%rbx)
    1f73:	48 83 c4 08          	add    $0x8,%rsp
    1f77:	5b                   	pop    %rbx
    1f78:	41 5e                	pop    %r14
    1f7a:	41 5f                	pop    %r15
    1f7c:	5d                   	pop    %rbp
    1f7d:	c3                   	ret
    1f7e:	66 90                	xchg   %ax,%ax

0000000000001f80 <pqcrystals_kyber768_ref_poly_cbd_eta1>:
    1f80:	eb 00                	jmp    1f82 <cbd2>

0000000000001f82 <cbd2>:
    1f82:	53                   	push   %rbx
    1f83:	31 d2                	xor    %edx,%edx
    1f85:	41 b8 55 55 55 55    	mov    $0x55555555,%r8d
    1f8b:	48 83 fa 20          	cmp    $0x20,%rdx
    1f8f:	74 4f                	je     1fe0 <cbd2+0x5e>
    1f91:	44 8b 0c 96          	mov    (%rsi,%rdx,4),%r9d
    1f95:	44 89 c8             	mov    %r9d,%eax
    1f98:	44 21 c0             	and    %r8d,%eax
    1f9b:	41 d1 e9             	shr    $1,%r9d
    1f9e:	45 21 c1             	and    %r8d,%r9d
    1fa1:	41 01 c1             	add    %eax,%r9d
    1fa4:	49 89 fa             	mov    %rdi,%r10
    1fa7:	31 c0                	xor    %eax,%eax
    1fa9:	48 83 f8 20          	cmp    $0x20,%rax
    1fad:	74 28                	je     1fd7 <cbd2+0x55>
    1faf:	45 89 cb             	mov    %r9d,%r11d
    1fb2:	89 c1                	mov    %eax,%ecx
    1fb4:	41 d3 eb             	shr    %cl,%r11d
    1fb7:	41 83 e3 03          	and    $0x3,%r11d
    1fbb:	8d 48 02             	lea    0x2(%rax),%ecx
    1fbe:	44 89 cb             	mov    %r9d,%ebx
    1fc1:	d3 eb                	shr    %cl,%ebx
    1fc3:	83 e3 03             	and    $0x3,%ebx
    1fc6:	41 29 db             	sub    %ebx,%r11d
    1fc9:	66 45 89 1a          	mov    %r11w,(%r10)
    1fcd:	48 83 c0 04          	add    $0x4,%rax
    1fd1:	49 83 c2 02          	add    $0x2,%r10
    1fd5:	eb d2                	jmp    1fa9 <cbd2+0x27>
    1fd7:	48 ff c2             	inc    %rdx
    1fda:	48 83 c7 10          	add    $0x10,%rdi
    1fde:	eb ab                	jmp    1f8b <cbd2+0x9>
    1fe0:	5b                   	pop    %rbx
    1fe1:	c3                   	ret

0000000000001fe2 <pqcrystals_kyber768_ref_poly_cbd_eta2>:
    1fe2:	eb 9e                	jmp    1f82 <cbd2>

0000000000001fe4 <pqcrystals_kyber768_ref_montgomery_reduce>:
    1fe4:	69 c7 00 00 01 f3    	imul   $0xf3010000,%edi,%eax
    1fea:	c1 f8 10             	sar    $0x10,%eax
    1fed:	69 c0 ff f2 ff ff    	imul   $0xfffff2ff,%eax,%eax
    1ff3:	01 f8                	add    %edi,%eax
    1ff5:	c1 e8 10             	shr    $0x10,%eax
    1ff8:	c3                   	ret

0000000000001ff9 <pqcrystals_kyber768_ref_barrett_reduce>:
    1ff9:	89 f8                	mov    %edi,%eax
    1ffb:	69 cf bf 4e 00 00    	imul   $0x4ebf,%edi,%ecx
    2001:	81 c1 00 00 00 02    	add    $0x2000000,%ecx
    2007:	c1 f9 1a             	sar    $0x1a,%ecx
    200a:	69 c9 00 00 01 0d    	imul   $0xd010000,%ecx,%ecx
    2010:	c1 e9 10             	shr    $0x10,%ecx
    2013:	29 c8                	sub    %ecx,%eax
    2015:	c3                   	ret
    2016:	66 90                	xchg   %ax,%ax

0000000000002018 <pqcrystals_kyber768_ref_kyber_shake128_absorb>:
    2018:	48 83 ec 28          	sub    $0x28,%rsp
    201c:	0f 10 06             	movups (%rsi),%xmm0
    201f:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
    2023:	48 89 e6             	mov    %rsp,%rsi
    2026:	0f 29 4e 10          	movaps %xmm1,0x10(%rsi)
    202a:	0f 29 06             	movaps %xmm0,(%rsi)
    202d:	88 56 20             	mov    %dl,0x20(%rsi)
    2030:	88 4e 21             	mov    %cl,0x21(%rsi)
    2033:	6a 22                	push   $0x22
    2035:	5a                   	pop    %rdx
    2036:	e8 d0 01 00 00       	call   220b <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    203b:	48 83 c4 28          	add    $0x28,%rsp
    203f:	c3                   	ret

0000000000002040 <pqcrystals_kyber768_ref_kyber_shake256_prf>:
    2040:	48 83 ec 28          	sub    $0x28,%rsp
    2044:	0f 10 02             	movups (%rdx),%xmm0
    2047:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
    204b:	48 89 e2             	mov    %rsp,%rdx
    204e:	0f 29 4a 10          	movaps %xmm1,0x10(%rdx)
    2052:	0f 29 02             	movaps %xmm0,(%rdx)
    2055:	88 4a 20             	mov    %cl,0x20(%rdx)
    2058:	6a 21                	push   $0x21
    205a:	59                   	pop    %rcx
    205b:	e8 22 04 00 00       	call   2482 <pqcrystals_kyber_fips202_ref_shake256>
    2060:	48 83 c4 28          	add    $0x28,%rsp
    2064:	c3                   	ret
    2065:	0f 1f 00             	nopl   (%rax)

0000000000002068 <pqcrystals_kyber_fips202_ref_shake128_init>:
    2068:	53                   	push   %rbx
    2069:	48 89 fb             	mov    %rdi,%rbx
    206c:	e8 09 00 00 00       	call   207a <keccak_init>
    2071:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    2078:	5b                   	pop    %rbx
    2079:	c3                   	ret

000000000000207a <keccak_init>:
    207a:	31 c0                	xor    %eax,%eax
    207c:	48 83 f8 19          	cmp    $0x19,%rax
    2080:	74 0a                	je     208c <keccak_init+0x12>
    2082:	48 83 24 c7 00       	andq   $0x0,(%rdi,%rax,8)
    2087:	48 ff c0             	inc    %rax
    208a:	eb f0                	jmp    207c <keccak_init+0x2>
    208c:	c3                   	ret

000000000000208d <pqcrystals_kyber_fips202_ref_shake128_absorb>:
    208d:	53                   	push   %rbx
    208e:	49 89 d0             	mov    %rdx,%r8
    2091:	48 89 f1             	mov    %rsi,%rcx
    2094:	48 89 fb             	mov    %rdi,%rbx
    2097:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    209d:	ba a8 00 00 00       	mov    $0xa8,%edx
    20a2:	e8 08 00 00 00       	call   20af <keccak_absorb>
    20a7:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    20ad:	5b                   	pop    %rbx
    20ae:	c3                   	ret

00000000000020af <keccak_absorb>:
    20af:	55                   	push   %rbp
    20b0:	41 57                	push   %r15
    20b2:	41 56                	push   %r14
    20b4:	41 54                	push   %r12
    20b6:	53                   	push   %rbx
    20b7:	4d 89 c7             	mov    %r8,%r15
    20ba:	48 89 cb             	mov    %rcx,%rbx
    20bd:	89 d5                	mov    %edx,%ebp
    20bf:	89 f0                	mov    %esi,%eax
    20c1:	49 89 fe             	mov    %rdi,%r14
    20c4:	41 89 d4             	mov    %edx,%r12d
    20c7:	89 c2                	mov    %eax,%edx
    20c9:	4c 01 fa             	add    %r15,%rdx
    20cc:	4c 39 e2             	cmp    %r12,%rdx
    20cf:	72 3e                	jb     210f <keccak_absorb+0x60>
    20d1:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
    20d8:	89 c6                	mov    %eax,%esi
    20da:	39 ee                	cmp    %ebp,%esi
    20dc:	73 1e                	jae    20fc <keccak_absorb+0x4d>
    20de:	0f b6 3b             	movzbl (%rbx),%edi
    20e1:	89 d1                	mov    %edx,%ecx
    20e3:	80 e1 38             	and    $0x38,%cl
    20e6:	48 d3 e7             	shl    %cl,%rdi
    20e9:	89 f1                	mov    %esi,%ecx
    20eb:	83 e1 f8             	and    $0xfffffff8,%ecx
    20ee:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    20f2:	48 ff c3             	inc    %rbx
    20f5:	ff c6                	inc    %esi
    20f7:	83 c2 08             	add    $0x8,%edx
    20fa:	eb de                	jmp    20da <keccak_absorb+0x2b>
    20fc:	89 e9                	mov    %ebp,%ecx
    20fe:	29 c1                	sub    %eax,%ecx
    2100:	49 29 cf             	sub    %rcx,%r15
    2103:	4c 89 f7             	mov    %r14,%rdi
    2106:	e8 39 04 00 00       	call   2544 <KeccakF1600_StatePermute>
    210b:	31 c0                	xor    %eax,%eax
    210d:	eb b8                	jmp    20c7 <keccak_absorb+0x18>
    210f:	8d 34 c5 00 00 00 00 	lea    0x0(,%rax,8),%esi
    2116:	89 c1                	mov    %eax,%ecx
    2118:	48 39 ca             	cmp    %rcx,%rdx
    211b:	76 1e                	jbe    213b <keccak_absorb+0x8c>
    211d:	0f b6 3b             	movzbl (%rbx),%edi
    2120:	89 f1                	mov    %esi,%ecx
    2122:	80 e1 38             	and    $0x38,%cl
    2125:	48 d3 e7             	shl    %cl,%rdi
    2128:	89 c1                	mov    %eax,%ecx
    212a:	83 e1 f8             	and    $0xfffffff8,%ecx
    212d:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    2131:	48 ff c3             	inc    %rbx
    2134:	ff c0                	inc    %eax
    2136:	83 c6 08             	add    $0x8,%esi
    2139:	eb db                	jmp    2116 <keccak_absorb+0x67>
    213b:	5b                   	pop    %rbx
    213c:	41 5c                	pop    %r12
    213e:	41 5e                	pop    %r14
    2140:	41 5f                	pop    %r15
    2142:	5d                   	pop    %rbp
    2143:	c3                   	ret

0000000000002144 <pqcrystals_kyber_fips202_ref_shake128_finalize>:
    2144:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    214a:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    2151:	6a 1f                	push   $0x1f
    2153:	5a                   	pop    %rdx
    2154:	48 d3 e2             	shl    %cl,%rdx
    2157:	83 e0 f8             	and    $0xfffffff8,%eax
    215a:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    215e:	80 b7 a7 00 00 00 80 	xorb   $0x80,0xa7(%rdi)
    2165:	c7 87 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rdi)
    216c:	00 00 00 
    216f:	c3                   	ret

0000000000002170 <pqcrystals_kyber_fips202_ref_shake128_squeeze>:
    2170:	53                   	push   %rbx
    2171:	48 89 d3             	mov    %rdx,%rbx
    2174:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    217a:	41 b8 a8 00 00 00    	mov    $0xa8,%r8d
    2180:	e8 08 00 00 00       	call   218d <keccak_squeeze>
    2185:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    218b:	5b                   	pop    %rbx
    218c:	c3                   	ret

000000000000218d <keccak_squeeze>:
    218d:	41 57                	push   %r15
    218f:	41 56                	push   %r14
    2191:	41 55                	push   %r13
    2193:	41 54                	push   %r12
    2195:	53                   	push   %rbx
    2196:	44 89 c3             	mov    %r8d,%ebx
    2199:	89 c8                	mov    %ecx,%eax
    219b:	49 89 d6             	mov    %rdx,%r14
    219e:	49 89 f7             	mov    %rsi,%r15
    21a1:	49 89 fc             	mov    %rdi,%r12
    21a4:	45 89 c5             	mov    %r8d,%r13d
    21a7:	4d 85 ff             	test   %r15,%r15
    21aa:	74 55                	je     2201 <keccak_squeeze+0x74>
    21ac:	39 d8                	cmp    %ebx,%eax
    21ae:	75 0a                	jne    21ba <keccak_squeeze+0x2d>
    21b0:	4c 89 f7             	mov    %r14,%rdi
    21b3:	e8 8c 03 00 00       	call   2544 <KeccakF1600_StatePermute>
    21b8:	31 c0                	xor    %eax,%eax
    21ba:	89 c0                	mov    %eax,%eax
    21bc:	49 8d 34 07          	lea    (%r15,%rax,1),%rsi
    21c0:	49 39 f5             	cmp    %rsi,%r13
    21c3:	49 0f 42 f5          	cmovb  %r13,%rsi
    21c7:	48 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%rdi
    21ce:	00 
    21cf:	31 d2                	xor    %edx,%edx
    21d1:	48 39 f0             	cmp    %rsi,%rax
    21d4:	73 21                	jae    21f7 <keccak_squeeze+0x6a>
    21d6:	89 c1                	mov    %eax,%ecx
    21d8:	83 e1 f8             	and    $0xfffffff8,%ecx
    21db:	4d 8b 04 0e          	mov    (%r14,%rcx,1),%r8
    21df:	89 f9                	mov    %edi,%ecx
    21e1:	80 e1 38             	and    $0x38,%cl
    21e4:	49 d3 e8             	shr    %cl,%r8
    21e7:	45 88 04 14          	mov    %r8b,(%r12,%rdx,1)
    21eb:	48 ff c0             	inc    %rax
    21ee:	48 ff c2             	inc    %rdx
    21f1:	48 83 c7 08          	add    $0x8,%rdi
    21f5:	eb da                	jmp    21d1 <keccak_squeeze+0x44>
    21f7:	89 d1                	mov    %edx,%ecx
    21f9:	49 29 cf             	sub    %rcx,%r15
    21fc:	49 01 d4             	add    %rdx,%r12
    21ff:	eb a6                	jmp    21a7 <keccak_squeeze+0x1a>
    2201:	5b                   	pop    %rbx
    2202:	41 5c                	pop    %r12
    2204:	41 5d                	pop    %r13
    2206:	41 5e                	pop    %r14
    2208:	41 5f                	pop    %r15
    220a:	c3                   	ret

000000000000220b <pqcrystals_kyber_fips202_ref_shake128_absorb_once>:
    220b:	53                   	push   %rbx
    220c:	48 89 d1             	mov    %rdx,%rcx
    220f:	48 89 f2             	mov    %rsi,%rdx
    2212:	48 89 fb             	mov    %rdi,%rbx
    2215:	6a 1f                	push   $0x1f
    2217:	41 58                	pop    %r8
    2219:	be a8 00 00 00       	mov    $0xa8,%esi
    221e:	e8 0c 00 00 00       	call   222f <keccak_absorb_once>
    2223:	c7 83 c8 00 00 00 a8 	movl   $0xa8,0xc8(%rbx)
    222a:	00 00 00 
    222d:	5b                   	pop    %rbx
    222e:	c3                   	ret

000000000000222f <keccak_absorb_once>:
    222f:	55                   	push   %rbp
    2230:	41 57                	push   %r15
    2232:	41 56                	push   %r14
    2234:	41 55                	push   %r13
    2236:	41 54                	push   %r12
    2238:	53                   	push   %rbx
    2239:	50                   	push   %rax
    223a:	44 89 44 24 04       	mov    %r8d,0x4(%rsp)
    223f:	48 89 c8             	mov    %rcx,%rax
    2242:	49 89 d7             	mov    %rdx,%r15
    2245:	89 f3                	mov    %esi,%ebx
    2247:	49 89 fe             	mov    %rdi,%r14
    224a:	31 c9                	xor    %ecx,%ecx
    224c:	48 83 f9 19          	cmp    $0x19,%rcx
    2250:	74 0a                	je     225c <keccak_absorb_once+0x2d>
    2252:	49 83 24 ce 00       	andq   $0x0,(%r14,%rcx,8)
    2257:	48 ff c1             	inc    %rcx
    225a:	eb f0                	jmp    224c <keccak_absorb_once+0x1d>
    225c:	41 89 dc             	mov    %ebx,%r12d
    225f:	41 89 dd             	mov    %ebx,%r13d
    2262:	41 c1 ed 03          	shr    $0x3,%r13d
    2266:	48 89 c5             	mov    %rax,%rbp
    2269:	4c 29 e5             	sub    %r12,%rbp
    226c:	72 47                	jb     22b5 <keccak_absorb_once+0x86>
    226e:	4c 89 f8             	mov    %r15,%rax
    2271:	31 d2                	xor    %edx,%edx
    2273:	4c 39 ea             	cmp    %r13,%rdx
    2276:	74 2d                	je     22a5 <keccak_absorb_once+0x76>
    2278:	48 89 c6             	mov    %rax,%rsi
    227b:	31 c9                	xor    %ecx,%ecx
    227d:	31 ff                	xor    %edi,%edi
    227f:	48 83 f9 40          	cmp    $0x40,%rcx
    2283:	74 13                	je     2298 <keccak_absorb_once+0x69>
    2285:	44 0f b6 06          	movzbl (%rsi),%r8d
    2289:	49 d3 e0             	shl    %cl,%r8
    228c:	4c 09 c7             	or     %r8,%rdi
    228f:	48 83 c1 08          	add    $0x8,%rcx
    2293:	48 ff c6             	inc    %rsi
    2296:	eb e7                	jmp    227f <keccak_absorb_once+0x50>
    2298:	49 31 3c d6          	xor    %rdi,(%r14,%rdx,8)
    229c:	48 ff c2             	inc    %rdx
    229f:	48 83 c0 08          	add    $0x8,%rax
    22a3:	eb ce                	jmp    2273 <keccak_absorb_once+0x44>
    22a5:	4d 01 e7             	add    %r12,%r15
    22a8:	4c 89 f7             	mov    %r14,%rdi
    22ab:	e8 94 02 00 00       	call   2544 <KeccakF1600_StatePermute>
    22b0:	48 89 e8             	mov    %rbp,%rax
    22b3:	eb b4                	jmp    2269 <keccak_absorb_once+0x3a>
    22b5:	31 d2                	xor    %edx,%edx
    22b7:	31 c9                	xor    %ecx,%ecx
    22b9:	89 ce                	mov    %ecx,%esi
    22bb:	48 39 f0             	cmp    %rsi,%rax
    22be:	76 1e                	jbe    22de <keccak_absorb_once+0xaf>
    22c0:	41 0f b6 3c 37       	movzbl (%r15,%rsi,1),%edi
    22c5:	89 d1                	mov    %edx,%ecx
    22c7:	80 e1 38             	and    $0x38,%cl
    22ca:	48 d3 e7             	shl    %cl,%rdi
    22cd:	89 f1                	mov    %esi,%ecx
    22cf:	83 e1 f8             	and    $0xfffffff8,%ecx
    22d2:	49 31 3c 0e          	xor    %rdi,(%r14,%rcx,1)
    22d6:	8d 4e 01             	lea    0x1(%rsi),%ecx
    22d9:	83 c2 08             	add    $0x8,%edx
    22dc:	eb db                	jmp    22b9 <keccak_absorb_once+0x8a>
    22de:	0f b6 44 24 04       	movzbl 0x4(%rsp),%eax
    22e3:	80 e2 38             	and    $0x38,%dl
    22e6:	89 d1                	mov    %edx,%ecx
    22e8:	48 d3 e0             	shl    %cl,%rax
    22eb:	83 e6 f8             	and    $0xfffffff8,%esi
    22ee:	49 31 04 36          	xor    %rax,(%r14,%rsi,1)
    22f2:	ff cb                	dec    %ebx
    22f4:	83 e3 f8             	and    $0xfffffff8,%ebx
    22f7:	41 80 74 1e 07 80    	xorb   $0x80,0x7(%r14,%rbx,1)
    22fd:	48 83 c4 08          	add    $0x8,%rsp
    2301:	5b                   	pop    %rbx
    2302:	41 5c                	pop    %r12
    2304:	41 5d                	pop    %r13
    2306:	41 5e                	pop    %r14
    2308:	41 5f                	pop    %r15
    230a:	5d                   	pop    %rbp
    230b:	c3                   	ret

000000000000230c <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>:
    230c:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    2311:	eb 00                	jmp    2313 <keccak_squeezeblocks>

0000000000002313 <keccak_squeezeblocks>:
    2313:	55                   	push   %rbp
    2314:	41 57                	push   %r15
    2316:	41 56                	push   %r14
    2318:	41 55                	push   %r13
    231a:	41 54                	push   %r12
    231c:	53                   	push   %rbx
    231d:	50                   	push   %rax
    231e:	89 cb                	mov    %ecx,%ebx
    2320:	49 89 d6             	mov    %rdx,%r14
    2323:	49 89 f7             	mov    %rsi,%r15
    2326:	49 89 fc             	mov    %rdi,%r12
    2329:	41 89 cd             	mov    %ecx,%r13d
    232c:	83 e3 f8             	and    $0xfffffff8,%ebx
    232f:	49 83 ef 01          	sub    $0x1,%r15
    2333:	72 27                	jb     235c <keccak_squeezeblocks+0x49>
    2335:	4c 89 f7             	mov    %r14,%rdi
    2338:	e8 07 02 00 00       	call   2544 <KeccakF1600_StatePermute>
    233d:	31 ed                	xor    %ebp,%ebp
    233f:	48 39 eb             	cmp    %rbp,%rbx
    2342:	74 13                	je     2357 <keccak_squeezeblocks+0x44>
    2344:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
    2348:	49 8b 34 2e          	mov    (%r14,%rbp,1),%rsi
    234c:	e8 ac 0a 00 00       	call   2dfd <store64>
    2351:	48 83 c5 08          	add    $0x8,%rbp
    2355:	eb e8                	jmp    233f <keccak_squeezeblocks+0x2c>
    2357:	4d 01 ec             	add    %r13,%r12
    235a:	eb d3                	jmp    232f <keccak_squeezeblocks+0x1c>
    235c:	48 83 c4 08          	add    $0x8,%rsp
    2360:	5b                   	pop    %rbx
    2361:	41 5c                	pop    %r12
    2363:	41 5d                	pop    %r13
    2365:	41 5e                	pop    %r14
    2367:	41 5f                	pop    %r15
    2369:	5d                   	pop    %rbp
    236a:	c3                   	ret

000000000000236b <pqcrystals_kyber_fips202_ref_shake256_init>:
    236b:	53                   	push   %rbx
    236c:	48 89 fb             	mov    %rdi,%rbx
    236f:	e8 06 fd ff ff       	call   207a <keccak_init>
    2374:	83 a3 c8 00 00 00 00 	andl   $0x0,0xc8(%rbx)
    237b:	5b                   	pop    %rbx
    237c:	c3                   	ret

000000000000237d <pqcrystals_kyber_fips202_ref_shake256_absorb>:
    237d:	53                   	push   %rbx
    237e:	49 89 d0             	mov    %rdx,%r8
    2381:	48 89 f1             	mov    %rsi,%rcx
    2384:	48 89 fb             	mov    %rdi,%rbx
    2387:	8b b7 c8 00 00 00    	mov    0xc8(%rdi),%esi
    238d:	ba 88 00 00 00       	mov    $0x88,%edx
    2392:	e8 18 fd ff ff       	call   20af <keccak_absorb>
    2397:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    239d:	5b                   	pop    %rbx
    239e:	c3                   	ret

000000000000239f <pqcrystals_kyber_fips202_ref_shake256_finalize>:
    239f:	8b 87 c8 00 00 00    	mov    0xc8(%rdi),%eax
    23a5:	8d 0c c5 00 00 00 00 	lea    0x0(,%rax,8),%ecx
    23ac:	6a 1f                	push   $0x1f
    23ae:	5a                   	pop    %rdx
    23af:	48 d3 e2             	shl    %cl,%rdx
    23b2:	83 e0 f8             	and    $0xfffffff8,%eax
    23b5:	48 31 14 07          	xor    %rdx,(%rdi,%rax,1)
    23b9:	80 b7 87 00 00 00 80 	xorb   $0x80,0x87(%rdi)
    23c0:	c7 87 c8 00 00 00 88 	movl   $0x88,0xc8(%rdi)
    23c7:	00 00 00 
    23ca:	c3                   	ret

00000000000023cb <pqcrystals_kyber_fips202_ref_shake256_squeeze>:
    23cb:	53                   	push   %rbx
    23cc:	48 89 d3             	mov    %rdx,%rbx
    23cf:	8b 8a c8 00 00 00    	mov    0xc8(%rdx),%ecx
    23d5:	41 b8 88 00 00 00    	mov    $0x88,%r8d
    23db:	e8 ad fd ff ff       	call   218d <keccak_squeeze>
    23e0:	89 83 c8 00 00 00    	mov    %eax,0xc8(%rbx)
    23e6:	5b                   	pop    %rbx
    23e7:	c3                   	ret

00000000000023e8 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>:
    23e8:	53                   	push   %rbx
    23e9:	48 89 d1             	mov    %rdx,%rcx
    23ec:	48 89 f2             	mov    %rsi,%rdx
    23ef:	48 89 fb             	mov    %rdi,%rbx
    23f2:	6a 1f                	push   $0x1f
    23f4:	41 58                	pop    %r8
    23f6:	be 88 00 00 00       	mov    $0x88,%esi
    23fb:	e8 2f fe ff ff       	call   222f <keccak_absorb_once>
    2400:	c7 83 c8 00 00 00 88 	movl   $0x88,0xc8(%rbx)
    2407:	00 00 00 
    240a:	5b                   	pop    %rbx
    240b:	c3                   	ret

000000000000240c <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>:
    240c:	b9 88 00 00 00       	mov    $0x88,%ecx
    2411:	e9 fd fe ff ff       	jmp    2313 <keccak_squeezeblocks>

0000000000002416 <pqcrystals_kyber_fips202_ref_shake128>:
    2416:	41 57                	push   %r15
    2418:	41 56                	push   %r14
    241a:	41 54                	push   %r12
    241c:	53                   	push   %rbx
    241d:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    2424:	48 89 f3             	mov    %rsi,%rbx
    2427:	49 89 fe             	mov    %rdi,%r14
    242a:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    242f:	4c 89 ff             	mov    %r15,%rdi
    2432:	48 89 d6             	mov    %rdx,%rsi
    2435:	48 89 ca             	mov    %rcx,%rdx
    2438:	e8 ce fd ff ff       	call   220b <pqcrystals_kyber_fips202_ref_shake128_absorb_once>
    243d:	b9 a8 00 00 00       	mov    $0xa8,%ecx
    2442:	48 89 d8             	mov    %rbx,%rax
    2445:	31 d2                	xor    %edx,%edx
    2447:	48 f7 f1             	div    %rcx
    244a:	48 89 d3             	mov    %rdx,%rbx
    244d:	49 89 c4             	mov    %rax,%r12
    2450:	4c 89 f7             	mov    %r14,%rdi
    2453:	48 89 c6             	mov    %rax,%rsi
    2456:	4c 89 fa             	mov    %r15,%rdx
    2459:	e8 ae fe ff ff       	call   230c <pqcrystals_kyber_fips202_ref_shake128_squeezeblocks>
    245e:	49 69 fc a8 00 00 00 	imul   $0xa8,%r12,%rdi
    2465:	4c 01 f7             	add    %r14,%rdi
    2468:	48 89 de             	mov    %rbx,%rsi
    246b:	4c 89 fa             	mov    %r15,%rdx
    246e:	e8 fd fc ff ff       	call   2170 <pqcrystals_kyber_fips202_ref_shake128_squeeze>
    2473:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    247a:	5b                   	pop    %rbx
    247b:	41 5c                	pop    %r12
    247d:	41 5e                	pop    %r14
    247f:	41 5f                	pop    %r15
    2481:	c3                   	ret

0000000000002482 <pqcrystals_kyber_fips202_ref_shake256>:
    2482:	41 57                	push   %r15
    2484:	41 56                	push   %r14
    2486:	41 54                	push   %r12
    2488:	53                   	push   %rbx
    2489:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    2490:	48 89 f3             	mov    %rsi,%rbx
    2493:	49 89 fe             	mov    %rdi,%r14
    2496:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
    249b:	4c 89 ff             	mov    %r15,%rdi
    249e:	48 89 d6             	mov    %rdx,%rsi
    24a1:	48 89 ca             	mov    %rcx,%rdx
    24a4:	e8 3f ff ff ff       	call   23e8 <pqcrystals_kyber_fips202_ref_shake256_absorb_once>
    24a9:	b9 88 00 00 00       	mov    $0x88,%ecx
    24ae:	48 89 d8             	mov    %rbx,%rax
    24b1:	31 d2                	xor    %edx,%edx
    24b3:	48 f7 f1             	div    %rcx
    24b6:	48 89 d3             	mov    %rdx,%rbx
    24b9:	49 89 c4             	mov    %rax,%r12
    24bc:	4c 89 f7             	mov    %r14,%rdi
    24bf:	48 89 c6             	mov    %rax,%rsi
    24c2:	4c 89 fa             	mov    %r15,%rdx
    24c5:	e8 42 ff ff ff       	call   240c <pqcrystals_kyber_fips202_ref_shake256_squeezeblocks>
    24ca:	49 69 fc 88 00 00 00 	imul   $0x88,%r12,%rdi
    24d1:	4c 01 f7             	add    %r14,%rdi
    24d4:	48 89 de             	mov    %rbx,%rsi
    24d7:	4c 89 fa             	mov    %r15,%rdx
    24da:	e8 ec fe ff ff       	call   23cb <pqcrystals_kyber_fips202_ref_shake256_squeeze>
    24df:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    24e6:	5b                   	pop    %rbx
    24e7:	41 5c                	pop    %r12
    24e9:	41 5e                	pop    %r14
    24eb:	41 5f                	pop    %r15
    24ed:	c3                   	ret

00000000000024ee <pqcrystals_kyber_fips202_ref_sha3_256>:
    24ee:	41 56                	push   %r14
    24f0:	53                   	push   %rbx
    24f1:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    24f8:	48 89 d1             	mov    %rdx,%rcx
    24fb:	48 89 f2             	mov    %rsi,%rdx
    24fe:	48 89 fb             	mov    %rdi,%rbx
    2501:	49 89 e6             	mov    %rsp,%r14
    2504:	6a 06                	push   $0x6
    2506:	41 58                	pop    %r8
    2508:	4c 89 f7             	mov    %r14,%rdi
    250b:	be 88 00 00 00       	mov    $0x88,%esi
    2510:	e8 1a fd ff ff       	call   222f <keccak_absorb_once>
    2515:	4c 89 f7             	mov    %r14,%rdi
    2518:	e8 27 00 00 00       	call   2544 <KeccakF1600_StatePermute>
    251d:	45 31 f6             	xor    %r14d,%r14d
    2520:	49 83 fe 20          	cmp    $0x20,%r14
    2524:	74 13                	je     2539 <pqcrystals_kyber_fips202_ref_sha3_256+0x4b>
    2526:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    252a:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    252e:	e8 ca 08 00 00       	call   2dfd <store64>
    2533:	49 83 c6 08          	add    $0x8,%r14
    2537:	eb e7                	jmp    2520 <pqcrystals_kyber_fips202_ref_sha3_256+0x32>
    2539:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    2540:	5b                   	pop    %rbx
    2541:	41 5e                	pop    %r14
    2543:	c3                   	ret

0000000000002544 <KeccakF1600_StatePermute>:
    2544:	55                   	push   %rbp
    2545:	41 57                	push   %r15
    2547:	41 56                	push   %r14
    2549:	41 55                	push   %r13
    254b:	41 54                	push   %r12
    254d:	53                   	push   %rbx
    254e:	48 83 ec 68          	sub    $0x68,%rsp
    2552:	48 8b 07             	mov    (%rdi),%rax
    2555:	48 89 44 24 80       	mov    %rax,-0x80(%rsp)
    255a:	48 8b 6f 08          	mov    0x8(%rdi),%rbp
    255e:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2562:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    2567:	48 8b 47 18          	mov    0x18(%rdi),%rax
    256b:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
    2570:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    2574:	48 8b 47 28          	mov    0x28(%rdi),%rax
    2578:	48 89 04 24          	mov    %rax,(%rsp)
    257c:	48 8b 47 30          	mov    0x30(%rdi),%rax
    2580:	48 89 44 24 98       	mov    %rax,-0x68(%rsp)
    2585:	48 8b 47 38          	mov    0x38(%rdi),%rax
    2589:	48 89 44 24 a8       	mov    %rax,-0x58(%rsp)
    258e:	48 8b 47 40          	mov    0x40(%rdi),%rax
    2592:	48 89 44 24 f8       	mov    %rax,-0x8(%rsp)
    2597:	4c 8b 7f 48          	mov    0x48(%rdi),%r15
    259b:	48 8b 47 50          	mov    0x50(%rdi),%rax
    259f:	48 89 44 24 90       	mov    %rax,-0x70(%rsp)
    25a4:	48 8b 47 58          	mov    0x58(%rdi),%rax
    25a8:	48 89 44 24 f0       	mov    %rax,-0x10(%rsp)
    25ad:	48 8b 47 60          	mov    0x60(%rdi),%rax
    25b1:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    25b6:	48 8b 47 68          	mov    0x68(%rdi),%rax
    25ba:	48 89 44 24 a0       	mov    %rax,-0x60(%rsp)
    25bf:	4c 8b 77 70          	mov    0x70(%rdi),%r14
    25c3:	48 8b 47 78          	mov    0x78(%rdi),%rax
    25c7:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    25cc:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
    25d3:	48 89 44 24 88       	mov    %rax,-0x78(%rsp)
    25d8:	48 8b 87 88 00 00 00 	mov    0x88(%rdi),%rax
    25df:	48 89 44 24 c8       	mov    %rax,-0x38(%rsp)
    25e4:	4c 8b a7 90 00 00 00 	mov    0x90(%rdi),%r12
    25eb:	4c 8b 87 98 00 00 00 	mov    0x98(%rdi),%r8
    25f2:	4c 8b af a0 00 00 00 	mov    0xa0(%rdi),%r13
    25f9:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    2600:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    2607:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    260e:	48 89 4c 24 c0       	mov    %rcx,-0x40(%rsp)
    2613:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    2618:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    261f:	48 89 4c 24 b0       	mov    %rcx,-0x50(%rsp)
    2624:	31 c9                	xor    %ecx,%ecx
    2626:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    262b:	48 83 7c 24 10 17    	cmpq   $0x17,0x10(%rsp)
    2631:	0f 87 e5 06 00 00    	ja     2d1c <KeccakF1600_StatePermute+0x7d8>
    2637:	48 8b 4c 24 d0       	mov    -0x30(%rsp),%rcx
    263c:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    2641:	4c 31 e9             	xor    %r13,%rcx
    2644:	4c 89 d7             	mov    %r10,%rdi
    2647:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    264c:	4c 8b 54 24 90       	mov    -0x70(%rsp),%r10
    2651:	4c 33 14 24          	xor    (%rsp),%r10
    2655:	49 31 ca             	xor    %rcx,%r10
    2658:	48 8b 4c 24 88       	mov    -0x78(%rsp),%rcx
    265d:	48 31 f9             	xor    %rdi,%rcx
    2660:	4c 89 fb             	mov    %r15,%rbx
    2663:	4d 89 f5             	mov    %r14,%r13
    2666:	4c 8b 74 24 f0       	mov    -0x10(%rsp),%r14
    266b:	4c 33 74 24 98       	xor    -0x68(%rsp),%r14
    2670:	49 31 ce             	xor    %rcx,%r14
    2673:	48 8b 4c 24 c8       	mov    -0x38(%rsp),%rcx
    2678:	48 31 c1             	xor    %rax,%rcx
    267b:	49 89 d7             	mov    %rdx,%r15
    267e:	4d 89 c3             	mov    %r8,%r11
    2681:	4c 89 44 24 e0       	mov    %r8,-0x20(%rsp)
    2686:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
    268b:	4c 89 c2             	mov    %r8,%rdx
    268e:	48 33 54 24 a8       	xor    -0x58(%rsp),%rdx
    2693:	48 31 ca             	xor    %rcx,%rdx
    2696:	48 89 6c 24 d8       	mov    %rbp,-0x28(%rsp)
    269b:	4d 89 e1             	mov    %r12,%r9
    269e:	4c 33 4c 24 c0       	xor    -0x40(%rsp),%r9
    26a3:	48 8b 4c 24 a0       	mov    -0x60(%rsp),%rcx
    26a8:	48 33 4c 24 f8       	xor    -0x8(%rsp),%rcx
    26ad:	4c 31 c9             	xor    %r9,%rcx
    26b0:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
    26b5:	49 31 fb             	xor    %rdi,%r11
    26b8:	4d 89 e9             	mov    %r13,%r9
    26bb:	49 31 d9             	xor    %rbx,%r9
    26be:	48 89 de             	mov    %rbx,%rsi
    26c1:	4d 31 d9             	xor    %r11,%r9
    26c4:	4c 33 54 24 80       	xor    -0x80(%rsp),%r10
    26c9:	49 31 ee             	xor    %rbp,%r14
    26cc:	48 33 54 24 08       	xor    0x8(%rsp),%rdx
    26d1:	4c 8b 5c 24 b8       	mov    -0x48(%rsp),%r11
    26d6:	4c 31 d9             	xor    %r11,%rcx
    26d9:	48 89 cd             	mov    %rcx,%rbp
    26dc:	48 d1 c5             	rol    $1,%rbp
    26df:	4c 31 f5             	xor    %r14,%rbp
    26e2:	49 d1 c6             	rol    $1,%r14
    26e5:	4d 31 f9             	xor    %r15,%r9
    26e8:	4d 31 ce             	xor    %r9,%r14
    26eb:	49 d1 c1             	rol    $1,%r9
    26ee:	49 31 d1             	xor    %rdx,%r9
    26f1:	48 89 d3             	mov    %rdx,%rbx
    26f4:	48 d1 c3             	rol    $1,%rbx
    26f7:	4c 31 d3             	xor    %r10,%rbx
    26fa:	49 d1 c2             	rol    $1,%r10
    26fd:	49 31 ca             	xor    %rcx,%r10
    2700:	4c 31 d7             	xor    %r10,%rdi
    2703:	4c 31 d6             	xor    %r10,%rsi
    2706:	48 89 74 24 b0       	mov    %rsi,-0x50(%rsp)
    270b:	4c 31 54 24 e0       	xor    %r10,-0x20(%rsp)
    2710:	4d 31 d7             	xor    %r10,%r15
    2713:	4c 89 7c 24 e8       	mov    %r15,-0x18(%rsp)
    2718:	4d 31 ea             	xor    %r13,%r10
    271b:	4c 89 54 24 60       	mov    %r10,0x60(%rsp)
    2720:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    2725:	48 31 da             	xor    %rbx,%rdx
    2728:	48 c1 c2 2c          	rol    $0x2c,%rdx
    272c:	49 31 e8             	xor    %rbp,%r8
    272f:	49 c1 c0 2b          	rol    $0x2b,%r8
    2733:	4d 31 cc             	xor    %r9,%r12
    2736:	49 c1 c4 15          	rol    $0x15,%r12
    273a:	48 c1 c7 0e          	rol    $0xe,%rdi
    273e:	4c 8b 7c 24 80       	mov    -0x80(%rsp),%r15
    2743:	4d 31 f7             	xor    %r14,%r15
    2746:	48 89 d6             	mov    %rdx,%rsi
    2749:	48 f7 d6             	not    %rsi
    274c:	4c 21 c6             	and    %r8,%rsi
    274f:	4c 8d 15 da 09 00 00 	lea    0x9da(%rip),%r10        # 3130 <KeccakF_RoundConstants>
    2756:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
    275b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    2760:	49 33 34 ca          	xor    (%r10,%rcx,8),%rsi
    2764:	4c 89 e1             	mov    %r12,%rcx
    2767:	48 f7 d1             	not    %rcx
    276a:	48 21 f9             	and    %rdi,%rcx
    276d:	4c 31 c1             	xor    %r8,%rcx
    2770:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    2775:	49 f7 d0             	not    %r8
    2778:	4d 21 e0             	and    %r12,%r8
    277b:	48 89 f9             	mov    %rdi,%rcx
    277e:	48 f7 d1             	not    %rcx
    2781:	4c 21 f9             	and    %r15,%rcx
    2784:	4c 31 e1             	xor    %r12,%rcx
    2787:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    278c:	4c 31 fe             	xor    %r15,%rsi
    278f:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    2794:	49 31 d0             	xor    %rdx,%r8
    2797:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
    279c:	4d 31 cb             	xor    %r9,%r11
    279f:	49 c1 c3 1c          	rol    $0x1c,%r11
    27a3:	48 89 f9             	mov    %rdi,%rcx
    27a6:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
    27ab:	48 c1 c6 14          	rol    $0x14,%rsi
    27af:	49 f7 d7             	not    %r15
    27b2:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
    27b7:	4c 31 f7             	xor    %r14,%rdi
    27ba:	48 c1 c7 03          	rol    $0x3,%rdi
    27be:	49 21 d7             	and    %rdx,%r15
    27c1:	4c 8b 44 24 88       	mov    -0x78(%rsp),%r8
    27c6:	49 31 d8             	xor    %rbx,%r8
    27c9:	49 c1 c0 2d          	rol    $0x2d,%r8
    27cd:	49 31 cf             	xor    %rcx,%r15
    27d0:	4c 89 7c 24 80       	mov    %r15,-0x80(%rsp)
    27d5:	48 31 e8             	xor    %rbp,%rax
    27d8:	48 c1 c0 3d          	rol    $0x3d,%rax
    27dc:	48 89 f1             	mov    %rsi,%rcx
    27df:	49 89 f7             	mov    %rsi,%r15
    27e2:	48 f7 d1             	not    %rcx
    27e5:	48 21 f9             	and    %rdi,%rcx
    27e8:	48 89 ce             	mov    %rcx,%rsi
    27eb:	4c 89 c1             	mov    %r8,%rcx
    27ee:	48 f7 d1             	not    %rcx
    27f1:	48 21 c1             	and    %rax,%rcx
    27f4:	48 31 f9             	xor    %rdi,%rcx
    27f7:	48 89 4c 24 90       	mov    %rcx,-0x70(%rsp)
    27fc:	48 89 fa             	mov    %rdi,%rdx
    27ff:	48 f7 d2             	not    %rdx
    2802:	4c 21 c2             	and    %r8,%rdx
    2805:	48 89 c1             	mov    %rax,%rcx
    2808:	48 f7 d1             	not    %rcx
    280b:	4c 21 d9             	and    %r11,%rcx
    280e:	4c 31 c1             	xor    %r8,%rcx
    2811:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    2816:	4c 31 de             	xor    %r11,%rsi
    2819:	48 89 74 24 88       	mov    %rsi,-0x78(%rsp)
    281e:	4c 31 fa             	xor    %r15,%rdx
    2821:	48 89 54 24 98       	mov    %rdx,-0x68(%rsp)
    2826:	49 f7 d3             	not    %r11
    2829:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
    282e:	48 31 de             	xor    %rbx,%rsi
    2831:	48 d1 c6             	rol    $1,%rsi
    2834:	4c 8b 44 24 a8       	mov    -0x58(%rsp),%r8
    2839:	49 31 e8             	xor    %rbp,%r8
    283c:	49 c1 c0 06          	rol    $0x6,%r8
    2840:	4c 8b 64 24 a0       	mov    -0x60(%rsp),%r12
    2845:	4d 31 cc             	xor    %r9,%r12
    2848:	49 c1 c4 19          	rol    $0x19,%r12
    284c:	48 8b 7c 24 e0       	mov    -0x20(%rsp),%rdi
    2851:	48 c1 c7 08          	rol    $0x8,%rdi
    2855:	4d 21 fb             	and    %r15,%r11
    2858:	4d 31 f5             	xor    %r14,%r13
    285b:	49 c1 c5 12          	rol    $0x12,%r13
    285f:	49 31 c3             	xor    %rax,%r11
    2862:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    2867:	4c 89 c0             	mov    %r8,%rax
    286a:	48 f7 d0             	not    %rax
    286d:	4c 21 e0             	and    %r12,%rax
    2870:	48 89 c1             	mov    %rax,%rcx
    2873:	49 89 ff             	mov    %rdi,%r15
    2876:	49 f7 d7             	not    %r15
    2879:	4d 21 ef             	and    %r13,%r15
    287c:	4d 31 e7             	xor    %r12,%r15
    287f:	4c 89 e0             	mov    %r12,%rax
    2882:	48 f7 d0             	not    %rax
    2885:	48 21 f8             	and    %rdi,%rax
    2888:	49 89 fb             	mov    %rdi,%r11
    288b:	4c 89 ef             	mov    %r13,%rdi
    288e:	48 f7 d7             	not    %rdi
    2891:	48 21 f7             	and    %rsi,%rdi
    2894:	4c 31 df             	xor    %r11,%rdi
    2897:	48 89 7c 24 a0       	mov    %rdi,-0x60(%rsp)
    289c:	48 31 f1             	xor    %rsi,%rcx
    289f:	48 89 4c 24 a8       	mov    %rcx,-0x58(%rsp)
    28a4:	4c 31 c0             	xor    %r8,%rax
    28a7:	48 89 44 24 e0       	mov    %rax,-0x20(%rsp)
    28ac:	48 f7 d6             	not    %rsi
    28af:	48 8b 7c 24 e8       	mov    -0x18(%rsp),%rdi
    28b4:	48 c1 c7 1b          	rol    $0x1b,%rdi
    28b8:	4c 21 c6             	and    %r8,%rsi
    28bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    28bf:	4c 31 f1             	xor    %r14,%rcx
    28c2:	48 c1 c1 24          	rol    $0x24,%rcx
    28c6:	4c 31 ee             	xor    %r13,%rsi
    28c9:	48 89 74 24 d8       	mov    %rsi,-0x28(%rsp)
    28ce:	4c 8b 6c 24 f0       	mov    -0x10(%rsp),%r13
    28d3:	49 31 dd             	xor    %rbx,%r13
    28d6:	49 c1 c5 0a          	rol    $0xa,%r13
    28da:	4c 8b 44 24 c8       	mov    -0x38(%rsp),%r8
    28df:	49 31 e8             	xor    %rbp,%r8
    28e2:	49 c1 c0 0f          	rol    $0xf,%r8
    28e6:	4c 8b 64 24 c0       	mov    -0x40(%rsp),%r12
    28eb:	4d 31 cc             	xor    %r9,%r12
    28ee:	4c 89 ca             	mov    %r9,%rdx
    28f1:	49 c1 c4 38          	rol    $0x38,%r12
    28f5:	49 89 c9             	mov    %rcx,%r9
    28f8:	49 f7 d1             	not    %r9
    28fb:	4d 21 e9             	and    %r13,%r9
    28fe:	4d 89 c3             	mov    %r8,%r11
    2901:	49 f7 d3             	not    %r11
    2904:	4d 21 e3             	and    %r12,%r11
    2907:	4d 31 eb             	xor    %r13,%r11
    290a:	4c 89 5c 24 c8       	mov    %r11,-0x38(%rsp)
    290f:	49 f7 d5             	not    %r13
    2912:	4d 21 c5             	and    %r8,%r13
    2915:	4c 89 e6             	mov    %r12,%rsi
    2918:	48 f7 d6             	not    %rsi
    291b:	48 21 fe             	and    %rdi,%rsi
    291e:	4c 31 c6             	xor    %r8,%rsi
    2921:	49 31 f9             	xor    %rdi,%r9
    2924:	4c 89 4c 24 c0       	mov    %r9,-0x40(%rsp)
    2929:	49 31 cd             	xor    %rcx,%r13
    292c:	48 f7 d7             	not    %rdi
    292f:	48 21 cf             	and    %rcx,%rdi
    2932:	4c 31 e7             	xor    %r12,%rdi
    2935:	48 89 7c 24 e8       	mov    %rdi,-0x18(%rsp)
    293a:	48 33 6c 24 08       	xor    0x8(%rsp),%rbp
    293f:	48 89 d0             	mov    %rdx,%rax
    2942:	48 33 44 24 f8       	xor    -0x8(%rsp),%rax
    2947:	4c 33 74 24 d0       	xor    -0x30(%rsp),%r14
    294c:	48 c1 c5 3e          	rol    $0x3e,%rbp
    2950:	48 c1 c0 37          	rol    $0x37,%rax
    2954:	4c 8b 54 24 60       	mov    0x60(%rsp),%r10
    2959:	49 c1 c2 27          	rol    $0x27,%r10
    295d:	49 c1 c6 29          	rol    $0x29,%r14
    2961:	48 33 5c 24 38       	xor    0x38(%rsp),%rbx
    2966:	48 c1 c3 02          	rol    $0x2,%rbx
    296a:	48 89 c7             	mov    %rax,%rdi
    296d:	48 89 c2             	mov    %rax,%rdx
    2970:	48 f7 d7             	not    %rdi
    2973:	4c 21 d7             	and    %r10,%rdi
    2976:	4c 89 d0             	mov    %r10,%rax
    2979:	4d 89 f4             	mov    %r14,%r12
    297c:	49 f7 d4             	not    %r12
    297f:	49 21 dc             	and    %rbx,%r12
    2982:	4d 31 d4             	xor    %r10,%r12
    2985:	48 f7 d0             	not    %rax
    2988:	4c 21 f0             	and    %r14,%rax
    298b:	49 89 da             	mov    %rbx,%r10
    298e:	49 f7 d2             	not    %r10
    2991:	49 21 ea             	and    %rbp,%r10
    2994:	4d 31 f2             	xor    %r14,%r10
    2997:	4d 89 d6             	mov    %r10,%r14
    299a:	4c 89 54 24 d0       	mov    %r10,-0x30(%rsp)
    299f:	48 31 ef             	xor    %rbp,%rdi
    29a2:	48 31 d0             	xor    %rdx,%rax
    29a5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    29aa:	48 f7 d5             	not    %rbp
    29ad:	48 21 d5             	and    %rdx,%rbp
    29b0:	48 31 dd             	xor    %rbx,%rbp
    29b3:	4c 33 4c 24 a8       	xor    -0x58(%rsp),%r9
    29b8:	4c 8b 54 24 88       	mov    -0x78(%rsp),%r10
    29bd:	49 31 fa             	xor    %rdi,%r10
    29c0:	4d 31 ca             	xor    %r9,%r10
    29c3:	4c 8b 4c 24 98       	mov    -0x68(%rsp),%r9
    29c8:	4c 33 4c 24 28       	xor    0x28(%rsp),%r9
    29cd:	4c 89 ea             	mov    %r13,%rdx
    29d0:	48 33 54 24 e0       	xor    -0x20(%rsp),%rdx
    29d5:	4c 31 ca             	xor    %r9,%rdx
    29d8:	4c 8b 4c 24 90       	mov    -0x70(%rsp),%r9
    29dd:	4d 31 d9             	xor    %r11,%r9
    29e0:	4c 89 e3             	mov    %r12,%rbx
    29e3:	48 33 5c 24 50       	xor    0x50(%rsp),%rbx
    29e8:	4c 31 cb             	xor    %r9,%rbx
    29eb:	4c 8b 4c 24 a0       	mov    -0x60(%rsp),%r9
    29f0:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    29f5:	4d 89 f3             	mov    %r14,%r11
    29f8:	4c 33 5c 24 20       	xor    0x20(%rsp),%r11
    29fd:	4d 31 cb             	xor    %r9,%r11
    2a00:	4c 8b 74 24 80       	mov    -0x80(%rsp),%r14
    2a05:	49 31 ee             	xor    %rbp,%r14
    2a08:	4c 8b 4c 24 d8       	mov    -0x28(%rsp),%r9
    2a0d:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    2a12:	49 31 c9             	xor    %rcx,%r9
    2a15:	4d 31 f1             	xor    %r14,%r9
    2a18:	4c 33 54 24 18       	xor    0x18(%rsp),%r10
    2a1d:	48 31 c2             	xor    %rax,%rdx
    2a20:	4c 31 fb             	xor    %r15,%rbx
    2a23:	49 31 f3             	xor    %rsi,%r11
    2a26:	4c 33 4c 24 e8       	xor    -0x18(%rsp),%r9
    2a2b:	4c 89 d8             	mov    %r11,%rax
    2a2e:	48 d1 c0             	rol    $1,%rax
    2a31:	48 31 d0             	xor    %rdx,%rax
    2a34:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
    2a39:	49 89 d6             	mov    %rdx,%r14
    2a3c:	49 d1 c6             	rol    $1,%r14
    2a3f:	4d 31 ce             	xor    %r9,%r14
    2a42:	48 89 da             	mov    %rbx,%rdx
    2a45:	48 d1 c2             	rol    $1,%rdx
    2a48:	4c 31 d2             	xor    %r10,%rdx
    2a4b:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    2a50:	49 d1 c1             	rol    $1,%r9
    2a53:	49 d1 c2             	rol    $1,%r10
    2a56:	49 31 d9             	xor    %rbx,%r9
    2a59:	4c 8b 44 24 98       	mov    -0x68(%rsp),%r8
    2a5e:	49 31 d0             	xor    %rdx,%r8
    2a61:	49 c1 c0 2c          	rol    $0x2c,%r8
    2a65:	4d 31 da             	xor    %r11,%r10
    2a68:	49 31 c7             	xor    %rax,%r15
    2a6b:	49 c1 c7 2b          	rol    $0x2b,%r15
    2a6f:	4c 31 d5             	xor    %r10,%rbp
    2a72:	4c 31 d1             	xor    %r10,%rcx
    2a75:	48 89 4c 24 b8       	mov    %rcx,-0x48(%rsp)
    2a7a:	4c 31 54 24 e8       	xor    %r10,-0x18(%rsp)
    2a7f:	4c 31 54 24 80       	xor    %r10,-0x80(%rsp)
    2a84:	4c 33 54 24 d8       	xor    -0x28(%rsp),%r10
    2a89:	4c 31 ce             	xor    %r9,%rsi
    2a8c:	48 c1 c6 15          	rol    $0x15,%rsi
    2a90:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2a95:	4c 31 f1             	xor    %r14,%rcx
    2a98:	48 c1 c5 0e          	rol    $0xe,%rbp
    2a9c:	4c 89 c3             	mov    %r8,%rbx
    2a9f:	48 f7 d3             	not    %rbx
    2aa2:	4c 21 fb             	and    %r15,%rbx
    2aa5:	49 89 f3             	mov    %rsi,%r11
    2aa8:	49 f7 d3             	not    %r11
    2aab:	49 21 eb             	and    %rbp,%r11
    2aae:	4d 31 fb             	xor    %r15,%r11
    2ab1:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    2ab6:	49 f7 d7             	not    %r15
    2ab9:	49 21 f7             	and    %rsi,%r15
    2abc:	49 89 eb             	mov    %rbp,%r11
    2abf:	49 f7 d3             	not    %r11
    2ac2:	49 21 cb             	and    %rcx,%r11
    2ac5:	49 31 f3             	xor    %rsi,%r11
    2ac8:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    2acd:	48 8d 05 5c 06 00 00 	lea    0x65c(%rip),%rax        # 3130 <KeccakF_RoundConstants>
    2ad4:	48 33 5c f0 08       	xor    0x8(%rax,%rsi,8),%rbx
    2ad9:	48 89 ce             	mov    %rcx,%rsi
    2adc:	48 31 cb             	xor    %rcx,%rbx
    2adf:	4d 31 c7             	xor    %r8,%r15
    2ae2:	4c 89 7c 24 d8       	mov    %r15,-0x28(%rsp)
    2ae7:	48 f7 d6             	not    %rsi
    2aea:	4c 21 c6             	and    %r8,%rsi
    2aed:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    2af2:	4c 31 ca             	xor    %r9,%rdx
    2af5:	48 c1 c2 1c          	rol    $0x1c,%rdx
    2af9:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
    2afe:	48 c1 c1 14          	rol    $0x14,%rcx
    2b02:	48 31 ee             	xor    %rbp,%rsi
    2b05:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    2b0a:	48 8b 74 24 a8       	mov    -0x58(%rsp),%rsi
    2b0f:	4c 31 f6             	xor    %r14,%rsi
    2b12:	48 c1 c6 03          	rol    $0x3,%rsi
    2b16:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    2b1b:	49 31 c5             	xor    %rax,%r13
    2b1e:	49 c1 c5 2d          	rol    $0x2d,%r13
    2b22:	4c 8b 7c 24 b0       	mov    -0x50(%rsp),%r15
    2b27:	4d 31 fc             	xor    %r15,%r12
    2b2a:	49 c1 c4 3d          	rol    $0x3d,%r12
    2b2e:	49 89 c8             	mov    %rcx,%r8
    2b31:	49 f7 d0             	not    %r8
    2b34:	49 21 f0             	and    %rsi,%r8
    2b37:	4c 89 ed             	mov    %r13,%rbp
    2b3a:	48 f7 d5             	not    %rbp
    2b3d:	4c 21 e5             	and    %r12,%rbp
    2b40:	48 31 f5             	xor    %rsi,%rbp
    2b43:	48 89 6c 24 a8       	mov    %rbp,-0x58(%rsp)
    2b48:	48 f7 d6             	not    %rsi
    2b4b:	4c 21 ee             	and    %r13,%rsi
    2b4e:	4c 89 e5             	mov    %r12,%rbp
    2b51:	48 f7 d5             	not    %rbp
    2b54:	48 21 d5             	and    %rdx,%rbp
    2b57:	4c 31 ed             	xor    %r13,%rbp
    2b5a:	48 89 6c 24 f8       	mov    %rbp,-0x8(%rsp)
    2b5f:	49 31 d0             	xor    %rdx,%r8
    2b62:	4c 89 04 24          	mov    %r8,(%rsp)
    2b66:	48 31 ce             	xor    %rcx,%rsi
    2b69:	48 89 74 24 98       	mov    %rsi,-0x68(%rsp)
    2b6e:	48 f7 d2             	not    %rdx
    2b71:	48 21 ca             	and    %rcx,%rdx
    2b74:	4c 31 e2             	xor    %r12,%rdx
    2b77:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    2b7c:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
    2b81:	48 31 c5             	xor    %rax,%rbp
    2b84:	48 89 c2             	mov    %rax,%rdx
    2b87:	48 d1 c5             	rol    $1,%rbp
    2b8a:	4c 8b 44 24 90       	mov    -0x70(%rsp),%r8
    2b8f:	4d 31 f8             	xor    %r15,%r8
    2b92:	49 c1 c0 06          	rol    $0x6,%r8
    2b96:	48 8b 44 24 a0       	mov    -0x60(%rsp),%rax
    2b9b:	4c 31 c8             	xor    %r9,%rax
    2b9e:	48 c1 c0 19          	rol    $0x19,%rax
    2ba2:	48 8b 4c 24 e8       	mov    -0x18(%rsp),%rcx
    2ba7:	48 c1 c1 08          	rol    $0x8,%rcx
    2bab:	4c 31 f7             	xor    %r14,%rdi
    2bae:	48 c1 c7 12          	rol    $0x12,%rdi
    2bb2:	4c 89 c6             	mov    %r8,%rsi
    2bb5:	48 f7 d6             	not    %rsi
    2bb8:	48 21 c6             	and    %rax,%rsi
    2bbb:	49 89 cc             	mov    %rcx,%r12
    2bbe:	49 f7 d4             	not    %r12
    2bc1:	49 21 fc             	and    %rdi,%r12
    2bc4:	49 31 c4             	xor    %rax,%r12
    2bc7:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    2bcc:	49 89 c4             	mov    %rax,%r12
    2bcf:	49 f7 d4             	not    %r12
    2bd2:	49 21 cc             	and    %rcx,%r12
    2bd5:	49 89 fd             	mov    %rdi,%r13
    2bd8:	49 f7 d5             	not    %r13
    2bdb:	49 21 ed             	and    %rbp,%r13
    2bde:	49 31 cd             	xor    %rcx,%r13
    2be1:	4c 89 6c 24 a0       	mov    %r13,-0x60(%rsp)
    2be6:	48 31 ee             	xor    %rbp,%rsi
    2be9:	48 89 74 24 90       	mov    %rsi,-0x70(%rsp)
    2bee:	4d 31 c4             	xor    %r8,%r12
    2bf1:	4c 89 64 24 f0       	mov    %r12,-0x10(%rsp)
    2bf6:	48 f7 d5             	not    %rbp
    2bf9:	4c 21 c5             	and    %r8,%rbp
    2bfc:	4c 8b 6c 24 88       	mov    -0x78(%rsp),%r13
    2c01:	4d 31 f5             	xor    %r14,%r13
    2c04:	49 c1 c5 24          	rol    $0x24,%r13
    2c08:	48 31 fd             	xor    %rdi,%rbp
    2c0b:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
    2c10:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
    2c15:	48 31 d6             	xor    %rdx,%rsi
    2c18:	48 89 d5             	mov    %rdx,%rbp
    2c1b:	48 c1 c6 0a          	rol    $0xa,%rsi
    2c1f:	48 8b 7c 24 c8       	mov    -0x38(%rsp),%rdi
    2c24:	4c 31 ff             	xor    %r15,%rdi
    2c27:	48 c1 c7 0f          	rol    $0xf,%rdi
    2c2b:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    2c30:	4c 31 ca             	xor    %r9,%rdx
    2c33:	48 c1 c2 38          	rol    $0x38,%rdx
    2c37:	4c 89 e8             	mov    %r13,%rax
    2c3a:	48 f7 d0             	not    %rax
    2c3d:	48 21 f0             	and    %rsi,%rax
    2c40:	49 89 fc             	mov    %rdi,%r12
    2c43:	49 f7 d4             	not    %r12
    2c46:	49 21 d4             	and    %rdx,%r12
    2c49:	49 31 f4             	xor    %rsi,%r12
    2c4c:	4c 89 64 24 c8       	mov    %r12,-0x38(%rsp)
    2c51:	48 89 f1             	mov    %rsi,%rcx
    2c54:	4c 8b 44 24 80       	mov    -0x80(%rsp),%r8
    2c59:	49 c1 c0 1b          	rol    $0x1b,%r8
    2c5d:	48 f7 d1             	not    %rcx
    2c60:	48 21 f9             	and    %rdi,%rcx
    2c63:	49 89 d4             	mov    %rdx,%r12
    2c66:	49 f7 d4             	not    %r12
    2c69:	4d 21 c4             	and    %r8,%r12
    2c6c:	49 31 fc             	xor    %rdi,%r12
    2c6f:	4c 31 c0             	xor    %r8,%rax
    2c72:	48 89 44 24 d0       	mov    %rax,-0x30(%rsp)
    2c77:	4c 31 e9             	xor    %r13,%rcx
    2c7a:	48 89 4c 24 88       	mov    %rcx,-0x78(%rsp)
    2c7f:	49 f7 d0             	not    %r8
    2c82:	4d 21 e8             	and    %r13,%r8
    2c85:	4c 33 7c 24 50       	xor    0x50(%rsp),%r15
    2c8a:	4c 33 4c 24 48       	xor    0x48(%rsp),%r9
    2c8f:	4c 33 74 24 c0       	xor    -0x40(%rsp),%r14
    2c94:	48 33 6c 24 38       	xor    0x38(%rsp),%rbp
    2c99:	49 c1 c7 3e          	rol    $0x3e,%r15
    2c9d:	49 c1 c1 37          	rol    $0x37,%r9
    2ca1:	49 c1 c2 27          	rol    $0x27,%r10
    2ca5:	49 c1 c6 29          	rol    $0x29,%r14
    2ca9:	48 c1 c5 02          	rol    $0x2,%rbp
    2cad:	49 31 d0             	xor    %rdx,%r8
    2cb0:	4c 89 ca             	mov    %r9,%rdx
    2cb3:	48 f7 d2             	not    %rdx
    2cb6:	4c 21 d2             	and    %r10,%rdx
    2cb9:	4c 89 f0             	mov    %r14,%rax
    2cbc:	48 f7 d0             	not    %rax
    2cbf:	48 21 e8             	and    %rbp,%rax
    2cc2:	4c 31 d0             	xor    %r10,%rax
    2cc5:	49 f7 d2             	not    %r10
    2cc8:	4d 21 f2             	and    %r14,%r10
    2ccb:	48 89 ef             	mov    %rbp,%rdi
    2cce:	48 f7 d7             	not    %rdi
    2cd1:	4c 21 ff             	and    %r15,%rdi
    2cd4:	4c 31 f7             	xor    %r14,%rdi
    2cd7:	48 89 7c 24 c0       	mov    %rdi,-0x40(%rsp)
    2cdc:	4c 31 fa             	xor    %r15,%rdx
    2cdf:	49 89 d5             	mov    %rdx,%r13
    2ce2:	4d 31 ca             	xor    %r9,%r10
    2ce5:	49 f7 d7             	not    %r15
    2ce8:	4d 21 cf             	and    %r9,%r15
    2ceb:	49 31 ef             	xor    %rbp,%r15
    2cee:	4c 89 7c 24 b0       	mov    %r15,-0x50(%rsp)
    2cf3:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
    2cf8:	48 83 44 24 10 02    	addq   $0x2,0x10(%rsp)
    2cfe:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
    2d03:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    2d08:	4c 89 5c 24 b8       	mov    %r11,-0x48(%rsp)
    2d0d:	48 8b 6c 24 d8       	mov    -0x28(%rsp),%rbp
    2d12:	48 89 5c 24 80       	mov    %rbx,-0x80(%rsp)
    2d17:	e9 0f f9 ff ff       	jmp    262b <KeccakF1600_StatePermute+0xe7>
    2d1c:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    2d21:	48 8b 7c 24 80       	mov    -0x80(%rsp),%rdi
    2d26:	48 89 39             	mov    %rdi,(%rcx)
    2d29:	48 89 69 08          	mov    %rbp,0x8(%rcx)
    2d2d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    2d32:	48 89 79 10          	mov    %rdi,0x10(%rcx)
    2d36:	48 8b 74 24 b8       	mov    -0x48(%rsp),%rsi
    2d3b:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    2d3f:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    2d43:	48 8b 14 24          	mov    (%rsp),%rdx
    2d47:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    2d4b:	48 8b 54 24 98       	mov    -0x68(%rsp),%rdx
    2d50:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    2d54:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
    2d59:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    2d5d:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
    2d62:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    2d66:	4c 89 79 48          	mov    %r15,0x48(%rcx)
    2d6a:	48 8b 54 24 90       	mov    -0x70(%rsp),%rdx
    2d6f:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2d73:	48 8b 54 24 f0       	mov    -0x10(%rsp),%rdx
    2d78:	48 89 51 58          	mov    %rdx,0x58(%rcx)
    2d7c:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    2d81:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    2d85:	48 8b 54 24 a0       	mov    -0x60(%rsp),%rdx
    2d8a:	48 89 51 68          	mov    %rdx,0x68(%rcx)
    2d8e:	4c 89 71 70          	mov    %r14,0x70(%rcx)
    2d92:	48 8b 54 24 d0       	mov    -0x30(%rsp),%rdx
    2d97:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    2d9b:	48 8b 54 24 88       	mov    -0x78(%rsp),%rdx
    2da0:	48 89 91 80 00 00 00 	mov    %rdx,0x80(%rcx)
    2da7:	48 8b 54 24 c8       	mov    -0x38(%rsp),%rdx
    2dac:	48 89 91 88 00 00 00 	mov    %rdx,0x88(%rcx)
    2db3:	4c 89 a1 90 00 00 00 	mov    %r12,0x90(%rcx)
    2dba:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2dc1:	4c 89 a9 a0 00 00 00 	mov    %r13,0xa0(%rcx)
    2dc8:	4c 89 91 a8 00 00 00 	mov    %r10,0xa8(%rcx)
    2dcf:	48 89 81 b0 00 00 00 	mov    %rax,0xb0(%rcx)
    2dd6:	48 8b 44 24 c0       	mov    -0x40(%rsp),%rax
    2ddb:	48 89 81 b8 00 00 00 	mov    %rax,0xb8(%rcx)
    2de2:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
    2de7:	48 89 81 c0 00 00 00 	mov    %rax,0xc0(%rcx)
    2dee:	48 83 c4 68          	add    $0x68,%rsp
    2df2:	5b                   	pop    %rbx
    2df3:	41 5c                	pop    %r12
    2df5:	41 5d                	pop    %r13
    2df7:	41 5e                	pop    %r14
    2df9:	41 5f                	pop    %r15
    2dfb:	5d                   	pop    %rbp
    2dfc:	c3                   	ret

0000000000002dfd <store64>:
    2dfd:	31 c9                	xor    %ecx,%ecx
    2dff:	48 83 f9 40          	cmp    $0x40,%rcx
    2e03:	74 11                	je     2e16 <store64+0x19>
    2e05:	48 89 f0             	mov    %rsi,%rax
    2e08:	48 d3 e8             	shr    %cl,%rax
    2e0b:	88 07                	mov    %al,(%rdi)
    2e0d:	48 83 c1 08          	add    $0x8,%rcx
    2e11:	48 ff c7             	inc    %rdi
    2e14:	eb e9                	jmp    2dff <store64+0x2>
    2e16:	c3                   	ret

0000000000002e17 <pqcrystals_kyber_fips202_ref_sha3_512>:
    2e17:	41 56                	push   %r14
    2e19:	53                   	push   %rbx
    2e1a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    2e21:	48 89 d1             	mov    %rdx,%rcx
    2e24:	48 89 f2             	mov    %rsi,%rdx
    2e27:	48 89 fb             	mov    %rdi,%rbx
    2e2a:	49 89 e6             	mov    %rsp,%r14
    2e2d:	6a 48                	push   $0x48
    2e2f:	5e                   	pop    %rsi
    2e30:	6a 06                	push   $0x6
    2e32:	41 58                	pop    %r8
    2e34:	4c 89 f7             	mov    %r14,%rdi
    2e37:	e8 f3 f3 ff ff       	call   222f <keccak_absorb_once>
    2e3c:	4c 89 f7             	mov    %r14,%rdi
    2e3f:	e8 00 f7 ff ff       	call   2544 <KeccakF1600_StatePermute>
    2e44:	45 31 f6             	xor    %r14d,%r14d
    2e47:	49 83 fe 40          	cmp    $0x40,%r14
    2e4b:	74 13                	je     2e60 <pqcrystals_kyber_fips202_ref_sha3_512+0x49>
    2e4d:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
    2e51:	4a 8b 34 34          	mov    (%rsp,%r14,1),%rsi
    2e55:	e8 a3 ff ff ff       	call   2dfd <store64>
    2e5a:	49 83 c6 08          	add    $0x8,%r14
    2e5e:	eb e7                	jmp    2e47 <pqcrystals_kyber_fips202_ref_sha3_512+0x30>
    2e60:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    2e67:	5b                   	pop    %rbx
    2e68:	41 5e                	pop    %r14
    2e6a:	c3                   	ret

Disassembly of section .fini:

0000000000002e6c <_fini>:
    2e6c:	f3 0f 1e fa          	endbr64
    2e70:	48 83 ec 08          	sub    $0x8,%rsp
    2e74:	48 83 c4 08          	add    $0x8,%rsp
    2e78:	c3                   	ret
